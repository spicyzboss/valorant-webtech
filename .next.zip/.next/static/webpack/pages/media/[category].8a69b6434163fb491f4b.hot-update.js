"use strict";
self["webpackHotUpdate_N_E"]("pages/media/[category]",{

/***/ "./components/MediaComponent/FilterDropbox.jsx":
/*!*****************************************************!*\
  !*** ./components/MediaComponent/FilterDropbox.jsx ***!
  \*****************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\FilterDropbox.jsx",
    _s = $RefreshSig$();








const Text = styled_components__WEBPACK_IMPORTED_MODULE_4__.default.div.withConfig({
  displayName: "FilterDropbox__Text",
  componentId: "sc-3iobc0-0"
})(["text-align:center;position:absolute;color:black;background:antiquewhite;"]);
_c = Text;
const Box = styled_components__WEBPACK_IMPORTED_MODULE_4__.default.div.withConfig({
  displayName: "FilterDropbox__Box",
  componentId: "sc-3iobc0-1"
})(["width:10vw;height:10vh;position:absolute;right:10vw;background:none;top:0;cursor:pointer;border:1px solid #8b978f;"]);
_c2 = Box;

const FilterDropbox = () => {
  _s();

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  let {
    category,
    type
  } = router.query;

  if (typeof type === 'undefined') {
    type = `all`;
  }

  const onSelectChange = e => {
    let locale = e.target.value;

    if (typeof category === 'undefined') {
      category = `all`;
      locale = `media/${category}/${locale}`;
      router.push(locale);
    } else if (typeof type === 'undefined') {
      locale = `${category}/${locale}`;
      router.push(locale);
    } else {
      locale = {
        pathname: '/media/[category]/[type]',
        query: {
          category: `${category}`,
          "type": `${locale}`
        },
        asPath: `/media/${category}/${locale}`
      };
      router.push(locale.asPath, locale.asPath, {
        scroll: false
      });
    }
  };

  let convert = {
    "all": "ทั้งหมด",
    "agents": "เอเจนท์",
    "maps": "แผนที่",
    "arsenals": "คลังแสง"
  };
  let itemList = [{
    "type": "ทั้งหมด",
    "value": `all`
  }, {
    "type": "เอเจนท์",
    "value": `agents`
  }, {
    "type": "แผนที่",
    "value": `maps`
  }, {
    "type": "คลังแสง",
    "value": `arsenals`
  }];

  const openDropbox = e => {
    console.log(e.target.children);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Box, {
      onClick: openDropbox,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Text, {
        value: `/${type}`,
        children: convert[type]
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 17
      }, undefined), itemList.map((item, index) => {
        if (item.type != convert[type]) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Text, {
            value: item.value,
            children: item.type
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 36
          }, undefined);
        }
      })]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

_s(FilterDropbox, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter];
});

_c3 = FilterDropbox;
/* harmony default export */ __webpack_exports__["default"] = (FilterDropbox);

var _c, _c2, _c3;

$RefreshReg$(_c, "Text");
$RefreshReg$(_c2, "Box");
$RefreshReg$(_c3, "FilterDropbox");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvbWVkaWEvW2NhdGVnb3J5XS44YTY5YjY0MzQxNjNmYjQ5MWY0Yi5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsTUFBTUssSUFBSSxHQUFHSixxRUFBSDtBQUFBO0FBQUE7QUFBQSxnRkFBVjtLQUFNSTtBQVFOLE1BQU1FLEdBQUcsR0FBR04scUVBQUg7QUFBQTtBQUFBO0FBQUEsMEhBQVQ7TUFBTU07O0FBWU4sTUFBTUMsYUFBYSxHQUFHLE1BQU07QUFBQTs7QUFDeEIsUUFBTUMsTUFBTSxHQUFHTCxzREFBUyxFQUF4QjtBQUNBLE1BQUk7QUFBRU0sSUFBQUEsUUFBRjtBQUFZQyxJQUFBQTtBQUFaLE1BQXFCRixNQUFNLENBQUNHLEtBQWhDOztBQUNBLE1BQUcsT0FBT0QsSUFBUCxLQUFnQixXQUFuQixFQUErQjtBQUMzQkEsSUFBQUEsSUFBSSxHQUFJLEtBQVI7QUFDSDs7QUFDRCxRQUFNRSxjQUFjLEdBQUlDLENBQUQsSUFBTztBQUMxQixRQUFJQyxNQUFNLEdBQUdELENBQUMsQ0FBQ0UsTUFBRixDQUFTQyxLQUF0Qjs7QUFDQSxRQUFHLE9BQU9QLFFBQVAsS0FBb0IsV0FBdkIsRUFBbUM7QUFDL0JBLE1BQUFBLFFBQVEsR0FBSSxLQUFaO0FBQ0FLLE1BQUFBLE1BQU0sR0FBSSxTQUFTTCxRQUFVLElBQUlLLE1BQVEsRUFBekM7QUFDQU4sTUFBQUEsTUFBTSxDQUFDUyxJQUFQLENBQVlILE1BQVo7QUFDSCxLQUpELE1BTUssSUFBRyxPQUFPSixJQUFQLEtBQWdCLFdBQW5CLEVBQStCO0FBQ2hDSSxNQUFBQSxNQUFNLEdBQUksR0FBR0wsUUFBVSxJQUFJSyxNQUFRLEVBQW5DO0FBQ0FOLE1BQUFBLE1BQU0sQ0FBQ1MsSUFBUCxDQUFZSCxNQUFaO0FBQ0gsS0FISSxNQUlEO0FBQ0FBLE1BQUFBLE1BQU0sR0FBRztBQUNMSSxRQUFBQSxRQUFRLEVBQUUsMEJBREw7QUFFTFAsUUFBQUEsS0FBSyxFQUFFO0FBQUNGLFVBQUFBLFFBQVEsRUFBRyxHQUFHQSxRQUFVLEVBQXpCO0FBQTRCLGtCQUFTLEdBQUdLLE1BQVE7QUFBaEQsU0FGRjtBQUdMSyxRQUFBQSxNQUFNLEVBQUcsVUFBVVYsUUFBVSxJQUFJSyxNQUFRO0FBSHBDLE9BQVQ7QUFLQU4sTUFBQUEsTUFBTSxDQUFDUyxJQUFQLENBQVlILE1BQU0sQ0FBQ0ssTUFBbkIsRUFBMkJMLE1BQU0sQ0FBQ0ssTUFBbEMsRUFBeUM7QUFDckNDLFFBQUFBLE1BQU0sRUFBRTtBQUQ2QixPQUF6QztBQUdIO0FBQ0osR0F0QkQ7O0FBdUJBLE1BQUlDLE9BQU8sR0FBRztBQUNWLFdBQU8sU0FERztBQUVWLGNBQVUsU0FGQTtBQUdWLFlBQVEsUUFIRTtBQUlWLGdCQUFZO0FBSkYsR0FBZDtBQU1BLE1BQUlDLFFBQVEsR0FBRyxDQUFDO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FBRCxFQUNkO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FEYyxFQUVkO0FBQUMsWUFBUyxRQUFWO0FBQW9CLGFBQVc7QUFBL0IsR0FGYyxFQUdkO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FIYyxDQUFmOztBQUlBLFFBQU1DLFdBQVcsR0FBSVYsQ0FBRCxJQUFPO0FBQ3ZCVyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVosQ0FBQyxDQUFDRSxNQUFGLENBQVNXLFFBQXJCO0FBQ0gsR0FGRDs7QUFHQSxzQkFDSTtBQUFBLDJCQUNJLDhEQUFDLEdBQUQ7QUFBSyxhQUFPLEVBQUdILFdBQWY7QUFBQSw4QkFDSSw4REFBQyxJQUFEO0FBQU0sYUFBSyxFQUFHLElBQUdiLElBQUssRUFBdEI7QUFBQSxrQkFBMkJXLE9BQU8sQ0FBQ1gsSUFBRDtBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLEVBR1FZLFFBQVEsQ0FBQ0ssR0FBVCxDQUFhLENBQUNDLElBQUQsRUFBT0MsS0FBUCxLQUFlO0FBQ3hCLFlBQUdELElBQUksQ0FBQ2xCLElBQUwsSUFBYVcsT0FBTyxDQUFDWCxJQUFELENBQXZCLEVBQThCO0FBQzFCLDhCQUFPLDhEQUFDLElBQUQ7QUFBb0IsaUJBQUssRUFBRWtCLElBQUksQ0FBQ1osS0FBaEM7QUFBQSxzQkFBd0NZLElBQUksQ0FBQ2xCO0FBQTdDLGFBQVltQixLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVA7QUFDSDtBQUNKLE9BSkQsQ0FIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQWdCSCxDQTFERDs7R0FBTXRCO1VBQ2FKOzs7TUFEYkk7QUEyRE4sK0RBQWVBLGFBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9NZWRpYUNvbXBvbmVudC9GaWx0ZXJEcm9wYm94LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5jb25zdCBUZXh0ID0gc3R5bGVkLmRpdmBcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJhY2tncm91bmQ6IGFudGlxdWV3aGl0ZTtcclxuYFxyXG5cclxuXHJcbmNvbnN0IEJveCA9IHN0eWxlZC5kaXZgXHJcbiAgICB3aWR0aDogMTB2dztcclxuICAgIGhlaWdodDogMTB2aDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAxMHZ3O1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIHRvcDogMDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICM4Yjk3OGY7XHJcblxyXG5gXHJcblxyXG5jb25zdCBGaWx0ZXJEcm9wYm94ID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgICBsZXQgeyBjYXRlZ29yeSwgdHlwZSB9ID0gcm91dGVyLnF1ZXJ5O1xyXG4gICAgaWYodHlwZW9mIHR5cGUgPT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICB0eXBlID0gYGFsbGBcclxuICAgIH1cclxuICAgIGNvbnN0IG9uU2VsZWN0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgICAgICBsZXQgbG9jYWxlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICAgICAgaWYodHlwZW9mIGNhdGVnb3J5ID09PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgIGNhdGVnb3J5ID0gYGFsbGA7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IGBtZWRpYS8keyBjYXRlZ29yeSB9LyR7IGxvY2FsZSB9YFxyXG4gICAgICAgICAgICByb3V0ZXIucHVzaChsb2NhbGUpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmKHR5cGVvZiB0eXBlID09PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IGAkeyBjYXRlZ29yeSB9LyR7IGxvY2FsZSB9YFxyXG4gICAgICAgICAgICByb3V0ZXIucHVzaChsb2NhbGUpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IHtcclxuICAgICAgICAgICAgICAgIHBhdGhuYW1lOiAnL21lZGlhL1tjYXRlZ29yeV0vW3R5cGVdJyxcclxuICAgICAgICAgICAgICAgIHF1ZXJ5OiB7Y2F0ZWdvcnk6IGAkeyBjYXRlZ29yeSB9YCwgXCJ0eXBlXCI6IGAkeyBsb2NhbGUgfWB9LFxyXG4gICAgICAgICAgICAgICAgYXNQYXRoOiBgL21lZGlhLyR7IGNhdGVnb3J5IH0vJHsgbG9jYWxlIH1gXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcm91dGVyLnB1c2gobG9jYWxlLmFzUGF0aCwgbG9jYWxlLmFzUGF0aCx7XHJcbiAgICAgICAgICAgICAgICBzY3JvbGw6IGZhbHNlXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgbGV0IGNvbnZlcnQgPSB7XHJcbiAgICAgICAgXCJhbGxcIjogXCLguJfguLHguYnguIfguKvguKHguJRcIixcclxuICAgICAgICBcImFnZW50c1wiOiBcIuC5gOC4reC5gOC4iOC4meC4l+C5jFwiLFxyXG4gICAgICAgIFwibWFwc1wiOiBcIuC5geC4nOC4meC4l+C4teC5iFwiLFxyXG4gICAgICAgIFwiYXJzZW5hbHNcIjogXCLguITguKXguLHguIfguYHguKrguIdcIixcclxuICAgIH1cclxuICAgIGxldCBpdGVtTGlzdCA9IFt7XCJ0eXBlXCIgOiBcIuC4l+C4seC5ieC4h+C4q+C4oeC4lFwiLCBcInZhbHVlXCIgOiBgYWxsYH0sXHJcbiAgICAge1widHlwZVwiIDogXCLguYDguK3guYDguIjguJnguJfguYxcIiwgXCJ2YWx1ZVwiIDogYGFnZW50c2B9LFxyXG4gICAgIHtcInR5cGVcIiA6IFwi4LmB4Lic4LiZ4LiX4Li14LmIXCIsIFwidmFsdWVcIiA6IGBtYXBzYH0sXHJcbiAgICAge1widHlwZVwiIDogXCLguITguKXguLHguIfguYHguKrguIdcIiwgXCJ2YWx1ZVwiIDogYGFyc2VuYWxzYH1dXHJcbiAgICBjb25zdCBvcGVuRHJvcGJveCA9IChlKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZS50YXJnZXQuY2hpbGRyZW4pXHJcbiAgICB9XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxCb3ggb25DbGljaz17IG9wZW5Ecm9wYm94IH0+XHJcbiAgICAgICAgICAgICAgICA8VGV4dCB2YWx1ZT17YC8ke3R5cGV9YH0+eyBjb252ZXJ0W3R5cGVdIH08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbUxpc3QubWFwKChpdGVtLCBpbmRleCk9PntcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYoaXRlbS50eXBlICE9IGNvbnZlcnRbdHlwZV0pe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxUZXh0IGtleT17IGluZGV4IH0gdmFsdWU9e2l0ZW0udmFsdWV9PntpdGVtLnR5cGV9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICA8Lz5cclxuXHJcbiAgICApXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgRmlsdGVyRHJvcGJveDsiXSwibmFtZXMiOlsidXNlU3RhdGUiLCJzdHlsZWQiLCJSZWFjdCIsIkxpbmsiLCJ1c2VSb3V0ZXIiLCJUZXh0IiwiZGl2IiwiQm94IiwiRmlsdGVyRHJvcGJveCIsInJvdXRlciIsImNhdGVnb3J5IiwidHlwZSIsInF1ZXJ5Iiwib25TZWxlY3RDaGFuZ2UiLCJlIiwibG9jYWxlIiwidGFyZ2V0IiwidmFsdWUiLCJwdXNoIiwicGF0aG5hbWUiLCJhc1BhdGgiLCJzY3JvbGwiLCJjb252ZXJ0IiwiaXRlbUxpc3QiLCJvcGVuRHJvcGJveCIsImNvbnNvbGUiLCJsb2ciLCJjaGlsZHJlbiIsIm1hcCIsIml0ZW0iLCJpbmRleCJdLCJzb3VyY2VSb290IjoiIn0=