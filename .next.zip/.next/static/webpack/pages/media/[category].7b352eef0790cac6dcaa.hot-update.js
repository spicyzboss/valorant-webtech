"use strict";
self["webpackHotUpdate_N_E"]("pages/media/[category]",{

/***/ "./components/MediaComponent/FilterDropbox.jsx":
/*!*****************************************************!*\
  !*** ./components/MediaComponent/FilterDropbox.jsx ***!
  \*****************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\FilterDropbox.jsx",
    _s = $RefreshSig$();








const Text = styled_components__WEBPACK_IMPORTED_MODULE_4__.default.div.withConfig({
  displayName: "FilterDropbox__Text",
  componentId: "sc-3iobc0-0"
})(["text-align:center;position:absolute;color:black;white-space:pre;min-height:20px;padding:0px 2px 1px;background:antiquewhite;"]);
_c = Text;
const Box = styled_components__WEBPACK_IMPORTED_MODULE_4__.default.div.withConfig({
  displayName: "FilterDropbox__Box",
  componentId: "sc-3iobc0-1"
})(["width:10vw;height:10vh;position:absolute;right:10vw;background:none;top:0;cursor:pointer;border:1px solid #8b978f;"]);
_c2 = Box;

const FilterDropbox = () => {
  _s();

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  let {
    category,
    type
  } = router.query;

  if (typeof type === 'undefined') {
    type = `all`;
  }

  const onSelectChange = e => {
    let locale = e.target.value;

    if (typeof category === 'undefined') {
      category = `all`;
      locale = `media/${category}/${locale}`;
      router.push(locale);
    } else if (typeof type === 'undefined') {
      locale = `${category}/${locale}`;
      router.push(locale);
    } else {
      locale = {
        pathname: '/media/[category]/[type]',
        query: {
          category: `${category}`,
          "type": `${locale}`
        },
        asPath: `/media/${category}/${locale}`
      };
      router.push(locale.asPath, locale.asPath, {
        scroll: false
      });
    }
  };

  let convert = {
    "all": "ทั้งหมด",
    "agents": "เอเจนท์",
    "maps": "แผนที่",
    "arsenals": "คลังแสง"
  };
  let itemList = [{
    "type": "ทั้งหมด",
    "value": `all`
  }, {
    "type": "เอเจนท์",
    "value": `agents`
  }, {
    "type": "แผนที่",
    "value": `maps`
  }, {
    "type": "คลังแสง",
    "value": `arsenals`
  }];

  const openDropbox = e => {
    console.log(e.target.children);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Box, {
      onClick: openDropbox,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Text, {
        value: `/${type}`,
        children: convert[type]
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 17
      }, undefined), itemList.map((item, index) => {
        if (item.type != convert[type]) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Text, {
            value: item.value,
            children: item.type
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 36
          }, undefined);
        }
      })]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 74,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

_s(FilterDropbox, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter];
});

_c3 = FilterDropbox;
/* harmony default export */ __webpack_exports__["default"] = (FilterDropbox);

var _c, _c2, _c3;

$RefreshReg$(_c, "Text");
$RefreshReg$(_c2, "Box");
$RefreshReg$(_c3, "FilterDropbox");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvbWVkaWEvW2NhdGVnb3J5XS43YjM1MmVlZjA3OTBjYWM2ZGNhYS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsTUFBTUssSUFBSSxHQUFHSixxRUFBSDtBQUFBO0FBQUE7QUFBQSxvSUFBVjtLQUFNSTtBQVdOLE1BQU1FLEdBQUcsR0FBR04scUVBQUg7QUFBQTtBQUFBO0FBQUEsMEhBQVQ7TUFBTU07O0FBWU4sTUFBTUMsYUFBYSxHQUFHLE1BQU07QUFBQTs7QUFDeEIsUUFBTUMsTUFBTSxHQUFHTCxzREFBUyxFQUF4QjtBQUNBLE1BQUk7QUFBRU0sSUFBQUEsUUFBRjtBQUFZQyxJQUFBQTtBQUFaLE1BQXFCRixNQUFNLENBQUNHLEtBQWhDOztBQUNBLE1BQUcsT0FBT0QsSUFBUCxLQUFnQixXQUFuQixFQUErQjtBQUMzQkEsSUFBQUEsSUFBSSxHQUFJLEtBQVI7QUFDSDs7QUFDRCxRQUFNRSxjQUFjLEdBQUlDLENBQUQsSUFBTztBQUMxQixRQUFJQyxNQUFNLEdBQUdELENBQUMsQ0FBQ0UsTUFBRixDQUFTQyxLQUF0Qjs7QUFDQSxRQUFHLE9BQU9QLFFBQVAsS0FBb0IsV0FBdkIsRUFBbUM7QUFDL0JBLE1BQUFBLFFBQVEsR0FBSSxLQUFaO0FBQ0FLLE1BQUFBLE1BQU0sR0FBSSxTQUFTTCxRQUFVLElBQUlLLE1BQVEsRUFBekM7QUFDQU4sTUFBQUEsTUFBTSxDQUFDUyxJQUFQLENBQVlILE1BQVo7QUFDSCxLQUpELE1BTUssSUFBRyxPQUFPSixJQUFQLEtBQWdCLFdBQW5CLEVBQStCO0FBQ2hDSSxNQUFBQSxNQUFNLEdBQUksR0FBR0wsUUFBVSxJQUFJSyxNQUFRLEVBQW5DO0FBQ0FOLE1BQUFBLE1BQU0sQ0FBQ1MsSUFBUCxDQUFZSCxNQUFaO0FBQ0gsS0FISSxNQUlEO0FBQ0FBLE1BQUFBLE1BQU0sR0FBRztBQUNMSSxRQUFBQSxRQUFRLEVBQUUsMEJBREw7QUFFTFAsUUFBQUEsS0FBSyxFQUFFO0FBQUNGLFVBQUFBLFFBQVEsRUFBRyxHQUFHQSxRQUFVLEVBQXpCO0FBQTRCLGtCQUFTLEdBQUdLLE1BQVE7QUFBaEQsU0FGRjtBQUdMSyxRQUFBQSxNQUFNLEVBQUcsVUFBVVYsUUFBVSxJQUFJSyxNQUFRO0FBSHBDLE9BQVQ7QUFLQU4sTUFBQUEsTUFBTSxDQUFDUyxJQUFQLENBQVlILE1BQU0sQ0FBQ0ssTUFBbkIsRUFBMkJMLE1BQU0sQ0FBQ0ssTUFBbEMsRUFBeUM7QUFDckNDLFFBQUFBLE1BQU0sRUFBRTtBQUQ2QixPQUF6QztBQUdIO0FBQ0osR0F0QkQ7O0FBdUJBLE1BQUlDLE9BQU8sR0FBRztBQUNWLFdBQU8sU0FERztBQUVWLGNBQVUsU0FGQTtBQUdWLFlBQVEsUUFIRTtBQUlWLGdCQUFZO0FBSkYsR0FBZDtBQU1BLE1BQUlDLFFBQVEsR0FBRyxDQUFDO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FBRCxFQUNkO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FEYyxFQUVkO0FBQUMsWUFBUyxRQUFWO0FBQW9CLGFBQVc7QUFBL0IsR0FGYyxFQUdkO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FIYyxDQUFmOztBQUlBLFFBQU1DLFdBQVcsR0FBSVYsQ0FBRCxJQUFPO0FBQ3ZCVyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVosQ0FBQyxDQUFDRSxNQUFGLENBQVNXLFFBQXJCO0FBQ0gsR0FGRDs7QUFHQSxzQkFDSTtBQUFBLDJCQUNJLDhEQUFDLEdBQUQ7QUFBSyxhQUFPLEVBQUdILFdBQWY7QUFBQSw4QkFDSSw4REFBQyxJQUFEO0FBQU0sYUFBSyxFQUFHLElBQUdiLElBQUssRUFBdEI7QUFBQSxrQkFBMkJXLE9BQU8sQ0FBQ1gsSUFBRDtBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLEVBR1FZLFFBQVEsQ0FBQ0ssR0FBVCxDQUFhLENBQUNDLElBQUQsRUFBT0MsS0FBUCxLQUFlO0FBQ3hCLFlBQUdELElBQUksQ0FBQ2xCLElBQUwsSUFBYVcsT0FBTyxDQUFDWCxJQUFELENBQXZCLEVBQThCO0FBQzFCLDhCQUFPLDhEQUFDLElBQUQ7QUFBb0IsaUJBQUssRUFBRWtCLElBQUksQ0FBQ1osS0FBaEM7QUFBQSxzQkFBd0NZLElBQUksQ0FBQ2xCO0FBQTdDLGFBQVltQixLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVA7QUFDSDtBQUNKLE9BSkQsQ0FIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQWdCSCxDQTFERDs7R0FBTXRCO1VBQ2FKOzs7TUFEYkk7QUEyRE4sK0RBQWVBLGFBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9NZWRpYUNvbXBvbmVudC9GaWx0ZXJEcm9wYm94LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5jb25zdCBUZXh0ID0gc3R5bGVkLmRpdmBcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIHdoaXRlLXNwYWNlOiBwcmU7XHJcbiAgICBtaW4taGVpZ2h0OiAyMHB4O1xyXG4gICAgcGFkZGluZzogMHB4IDJweCAxcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiBhbnRpcXVld2hpdGU7XHJcbmBcclxuXHJcblxyXG5jb25zdCBCb3ggPSBzdHlsZWQuZGl2YFxyXG4gICAgd2lkdGg6IDEwdnc7XHJcbiAgICBoZWlnaHQ6IDEwdmg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogMTB2dztcclxuICAgIGJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjOGI5NzhmO1xyXG5cclxuYFxyXG5cclxuY29uc3QgRmlsdGVyRHJvcGJveCA9ICgpID0+IHtcclxuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gICAgbGV0IHsgY2F0ZWdvcnksIHR5cGUgfSA9IHJvdXRlci5xdWVyeTtcclxuICAgIGlmKHR5cGVvZiB0eXBlID09PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgdHlwZSA9IGBhbGxgXHJcbiAgICB9XHJcbiAgICBjb25zdCBvblNlbGVjdENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICAgICAgbGV0IGxvY2FsZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgICAgIGlmKHR5cGVvZiBjYXRlZ29yeSA9PT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgICAgICBjYXRlZ29yeSA9IGBhbGxgO1xyXG4gICAgICAgICAgICBsb2NhbGUgPSBgbWVkaWEvJHsgY2F0ZWdvcnkgfS8keyBsb2NhbGUgfWBcclxuICAgICAgICAgICAgcm91dGVyLnB1c2gobG9jYWxlKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZih0eXBlb2YgdHlwZSA9PT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgICAgICBsb2NhbGUgPSBgJHsgY2F0ZWdvcnkgfS8keyBsb2NhbGUgfWBcclxuICAgICAgICAgICAgcm91dGVyLnB1c2gobG9jYWxlKVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNle1xyXG4gICAgICAgICAgICBsb2NhbGUgPSB7XHJcbiAgICAgICAgICAgICAgICBwYXRobmFtZTogJy9tZWRpYS9bY2F0ZWdvcnldL1t0eXBlXScsXHJcbiAgICAgICAgICAgICAgICBxdWVyeToge2NhdGVnb3J5OiBgJHsgY2F0ZWdvcnkgfWAsIFwidHlwZVwiOiBgJHsgbG9jYWxlIH1gfSxcclxuICAgICAgICAgICAgICAgIGFzUGF0aDogYC9tZWRpYS8keyBjYXRlZ29yeSB9LyR7IGxvY2FsZSB9YFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJvdXRlci5wdXNoKGxvY2FsZS5hc1BhdGgsIGxvY2FsZS5hc1BhdGgse1xyXG4gICAgICAgICAgICAgICAgc2Nyb2xsOiBmYWxzZVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGxldCBjb252ZXJ0ID0ge1xyXG4gICAgICAgIFwiYWxsXCI6IFwi4LiX4Lix4LmJ4LiH4Lir4Lih4LiUXCIsXHJcbiAgICAgICAgXCJhZ2VudHNcIjogXCLguYDguK3guYDguIjguJnguJfguYxcIixcclxuICAgICAgICBcIm1hcHNcIjogXCLguYHguJzguJnguJfguLXguYhcIixcclxuICAgICAgICBcImFyc2VuYWxzXCI6IFwi4LiE4Lil4Lix4LiH4LmB4Liq4LiHXCIsXHJcbiAgICB9XHJcbiAgICBsZXQgaXRlbUxpc3QgPSBbe1widHlwZVwiIDogXCLguJfguLHguYnguIfguKvguKHguJRcIiwgXCJ2YWx1ZVwiIDogYGFsbGB9LFxyXG4gICAgIHtcInR5cGVcIiA6IFwi4LmA4Lit4LmA4LiI4LiZ4LiX4LmMXCIsIFwidmFsdWVcIiA6IGBhZ2VudHNgfSxcclxuICAgICB7XCJ0eXBlXCIgOiBcIuC5geC4nOC4meC4l+C4teC5iFwiLCBcInZhbHVlXCIgOiBgbWFwc2B9LFxyXG4gICAgIHtcInR5cGVcIiA6IFwi4LiE4Lil4Lix4LiH4LmB4Liq4LiHXCIsIFwidmFsdWVcIiA6IGBhcnNlbmFsc2B9XVxyXG4gICAgY29uc3Qgb3BlbkRyb3Bib3ggPSAoZSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGUudGFyZ2V0LmNoaWxkcmVuKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8Qm94IG9uQ2xpY2s9eyBvcGVuRHJvcGJveCB9PlxyXG4gICAgICAgICAgICAgICAgPFRleHQgdmFsdWU9e2AvJHt0eXBlfWB9PnsgY29udmVydFt0eXBlXSB9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1MaXN0Lm1hcCgoaXRlbSwgaW5kZXgpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmKGl0ZW0udHlwZSAhPSBjb252ZXJ0W3R5cGVdKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiA8VGV4dCBrZXk9eyBpbmRleCB9IHZhbHVlPXtpdGVtLnZhbHVlfT57aXRlbS50eXBlfTwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC8+XHJcblxyXG4gICAgKVxyXG59XHJcbmV4cG9ydCBkZWZhdWx0IEZpbHRlckRyb3Bib3g7Il0sIm5hbWVzIjpbInVzZVN0YXRlIiwic3R5bGVkIiwiUmVhY3QiLCJMaW5rIiwidXNlUm91dGVyIiwiVGV4dCIsImRpdiIsIkJveCIsIkZpbHRlckRyb3Bib3giLCJyb3V0ZXIiLCJjYXRlZ29yeSIsInR5cGUiLCJxdWVyeSIsIm9uU2VsZWN0Q2hhbmdlIiwiZSIsImxvY2FsZSIsInRhcmdldCIsInZhbHVlIiwicHVzaCIsInBhdGhuYW1lIiwiYXNQYXRoIiwic2Nyb2xsIiwiY29udmVydCIsIml0ZW1MaXN0Iiwib3BlbkRyb3Bib3giLCJjb25zb2xlIiwibG9nIiwiY2hpbGRyZW4iLCJtYXAiLCJpdGVtIiwiaW5kZXgiXSwic291cmNlUm9vdCI6IiJ9