"use strict";
self["webpackHotUpdate_N_E"]("pages/media/[category]",{

/***/ "./components/MediaComponent/FilterDropbox.jsx":
/*!*****************************************************!*\
  !*** ./components/MediaComponent/FilterDropbox.jsx ***!
  \*****************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\FilterDropbox.jsx",
    _s = $RefreshSig$();








const Text = styled_components__WEBPACK_IMPORTED_MODULE_4__.default.div.withConfig({
  displayName: "FilterDropbox__Text",
  componentId: "sc-3iobc0-0"
})(["text-align:center;position:relative;color:black;background:antiquewhite;width:10vw;height:10vh;"]);
_c = Text;
const Box = styled_components__WEBPACK_IMPORTED_MODULE_4__.default.div.withConfig({
  displayName: "FilterDropbox__Box",
  componentId: "sc-3iobc0-1"
})(["width:10vw;height:10vh;position:absolute;right:10vw;background:none;top:0;cursor:pointer;border:1px solid #8b978f;"]);
_c2 = Box;

const FilterDropbox = () => {
  _s();

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  let {
    category,
    type
  } = router.query;

  if (typeof type === 'undefined') {
    type = `all`;
  }

  const onSelectChange = e => {
    let locale = e.target.value;

    if (typeof category === 'undefined') {
      category = `all`;
      locale = `media/${category}/${locale}`;
      router.push(locale);
    } else if (typeof type === 'undefined') {
      locale = `${category}/${locale}`;
      router.push(locale);
    } else {
      locale = {
        pathname: '/media/[category]/[type]',
        query: {
          category: `${category}`,
          "type": `${locale}`
        },
        asPath: `/media/${category}/${locale}`
      };
      router.push(locale.asPath, locale.asPath, {
        scroll: false
      });
    }
  };

  let convert = {
    "all": "ทั้งหมด",
    "agents": "เอเจนท์",
    "maps": "แผนที่",
    "arsenals": "คลังแสง"
  };
  let itemList = [{
    "type": "ทั้งหมด",
    "value": `all`
  }, {
    "type": "เอเจนท์",
    "value": `agents`
  }, {
    "type": "แผนที่",
    "value": `maps`
  }, {
    "type": "คลังแสง",
    "value": `arsenals`
  }];

  const openDropbox = e => {
    console.log(e.target);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Box, {
      onClick: openDropbox,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Text, {
        value: `/${type}`,
        children: convert[type]
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 17
      }, undefined), itemList.map((item, index) => {
        if (item.type != convert[type]) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Text, {
            value: item.value,
            children: item.type
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 36
          }, undefined);
        }
      })]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

_s(FilterDropbox, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter];
});

_c3 = FilterDropbox;
/* harmony default export */ __webpack_exports__["default"] = (FilterDropbox);

var _c, _c2, _c3;

$RefreshReg$(_c, "Text");
$RefreshReg$(_c2, "Box");
$RefreshReg$(_c3, "FilterDropbox");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvbWVkaWEvW2NhdGVnb3J5XS5kNDQ0ODEwMGU2MTcxMmUwYzI0NC5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsTUFBTUssSUFBSSxHQUFHSixxRUFBSDtBQUFBO0FBQUE7QUFBQSx1R0FBVjtLQUFNSTtBQVVOLE1BQU1FLEdBQUcsR0FBR04scUVBQUg7QUFBQTtBQUFBO0FBQUEsMEhBQVQ7TUFBTU07O0FBWU4sTUFBTUMsYUFBYSxHQUFHLE1BQU07QUFBQTs7QUFDeEIsUUFBTUMsTUFBTSxHQUFHTCxzREFBUyxFQUF4QjtBQUNBLE1BQUk7QUFBRU0sSUFBQUEsUUFBRjtBQUFZQyxJQUFBQTtBQUFaLE1BQXFCRixNQUFNLENBQUNHLEtBQWhDOztBQUNBLE1BQUcsT0FBT0QsSUFBUCxLQUFnQixXQUFuQixFQUErQjtBQUMzQkEsSUFBQUEsSUFBSSxHQUFJLEtBQVI7QUFDSDs7QUFDRCxRQUFNRSxjQUFjLEdBQUlDLENBQUQsSUFBTztBQUMxQixRQUFJQyxNQUFNLEdBQUdELENBQUMsQ0FBQ0UsTUFBRixDQUFTQyxLQUF0Qjs7QUFDQSxRQUFHLE9BQU9QLFFBQVAsS0FBb0IsV0FBdkIsRUFBbUM7QUFDL0JBLE1BQUFBLFFBQVEsR0FBSSxLQUFaO0FBQ0FLLE1BQUFBLE1BQU0sR0FBSSxTQUFTTCxRQUFVLElBQUlLLE1BQVEsRUFBekM7QUFDQU4sTUFBQUEsTUFBTSxDQUFDUyxJQUFQLENBQVlILE1BQVo7QUFDSCxLQUpELE1BTUssSUFBRyxPQUFPSixJQUFQLEtBQWdCLFdBQW5CLEVBQStCO0FBQ2hDSSxNQUFBQSxNQUFNLEdBQUksR0FBR0wsUUFBVSxJQUFJSyxNQUFRLEVBQW5DO0FBQ0FOLE1BQUFBLE1BQU0sQ0FBQ1MsSUFBUCxDQUFZSCxNQUFaO0FBQ0gsS0FISSxNQUlEO0FBQ0FBLE1BQUFBLE1BQU0sR0FBRztBQUNMSSxRQUFBQSxRQUFRLEVBQUUsMEJBREw7QUFFTFAsUUFBQUEsS0FBSyxFQUFFO0FBQUNGLFVBQUFBLFFBQVEsRUFBRyxHQUFHQSxRQUFVLEVBQXpCO0FBQTRCLGtCQUFTLEdBQUdLLE1BQVE7QUFBaEQsU0FGRjtBQUdMSyxRQUFBQSxNQUFNLEVBQUcsVUFBVVYsUUFBVSxJQUFJSyxNQUFRO0FBSHBDLE9BQVQ7QUFLQU4sTUFBQUEsTUFBTSxDQUFDUyxJQUFQLENBQVlILE1BQU0sQ0FBQ0ssTUFBbkIsRUFBMkJMLE1BQU0sQ0FBQ0ssTUFBbEMsRUFBeUM7QUFDckNDLFFBQUFBLE1BQU0sRUFBRTtBQUQ2QixPQUF6QztBQUdIO0FBQ0osR0F0QkQ7O0FBdUJBLE1BQUlDLE9BQU8sR0FBRztBQUNWLFdBQU8sU0FERztBQUVWLGNBQVUsU0FGQTtBQUdWLFlBQVEsUUFIRTtBQUlWLGdCQUFZO0FBSkYsR0FBZDtBQU1BLE1BQUlDLFFBQVEsR0FBRyxDQUFDO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FBRCxFQUNkO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FEYyxFQUVkO0FBQUMsWUFBUyxRQUFWO0FBQW9CLGFBQVc7QUFBL0IsR0FGYyxFQUdkO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FIYyxDQUFmOztBQUlBLFFBQU1DLFdBQVcsR0FBSVYsQ0FBRCxJQUFPO0FBQ3ZCVyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVosQ0FBQyxDQUFDRSxNQUFkO0FBQ0gsR0FGRDs7QUFHQSxzQkFDSTtBQUFBLDJCQUNJLDhEQUFDLEdBQUQ7QUFBSyxhQUFPLEVBQUdRLFdBQWY7QUFBQSw4QkFDSSw4REFBQyxJQUFEO0FBQU0sYUFBSyxFQUFHLElBQUdiLElBQUssRUFBdEI7QUFBQSxrQkFBMkJXLE9BQU8sQ0FBQ1gsSUFBRDtBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLEVBR1FZLFFBQVEsQ0FBQ0ksR0FBVCxDQUFhLENBQUNDLElBQUQsRUFBT0MsS0FBUCxLQUFlO0FBQ3hCLFlBQUdELElBQUksQ0FBQ2pCLElBQUwsSUFBYVcsT0FBTyxDQUFDWCxJQUFELENBQXZCLEVBQThCO0FBQzFCLDhCQUFPLDhEQUFDLElBQUQ7QUFBb0IsaUJBQUssRUFBRWlCLElBQUksQ0FBQ1gsS0FBaEM7QUFBQSxzQkFBd0NXLElBQUksQ0FBQ2pCO0FBQTdDLGFBQVlrQixLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVA7QUFDSDtBQUNKLE9BSkQsQ0FIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQWdCSCxDQTFERDs7R0FBTXJCO1VBQ2FKOzs7TUFEYkk7QUEyRE4sK0RBQWVBLGFBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9NZWRpYUNvbXBvbmVudC9GaWx0ZXJEcm9wYm94LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5jb25zdCBUZXh0ID0gc3R5bGVkLmRpdmBcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJhY2tncm91bmQ6IGFudGlxdWV3aGl0ZTtcclxuICAgIHdpZHRoOiAxMHZ3O1xyXG4gICAgaGVpZ2h0OiAxMHZoO1xyXG5gXHJcblxyXG5cclxuY29uc3QgQm94ID0gc3R5bGVkLmRpdmBcclxuICAgIHdpZHRoOiAxMHZ3O1xyXG4gICAgaGVpZ2h0OiAxMHZoO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDEwdnc7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzhiOTc4ZjtcclxuXHJcbmBcclxuXHJcbmNvbnN0IEZpbHRlckRyb3Bib3ggPSAoKSA9PiB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICAgIGxldCB7IGNhdGVnb3J5LCB0eXBlIH0gPSByb3V0ZXIucXVlcnk7XHJcbiAgICBpZih0eXBlb2YgdHlwZSA9PT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgIHR5cGUgPSBgYWxsYFxyXG4gICAgfVxyXG4gICAgY29uc3Qgb25TZWxlY3RDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgICAgIGxldCBsb2NhbGUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgICAgICBpZih0eXBlb2YgY2F0ZWdvcnkgPT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgY2F0ZWdvcnkgPSBgYWxsYDtcclxuICAgICAgICAgICAgbG9jYWxlID0gYG1lZGlhLyR7IGNhdGVnb3J5IH0vJHsgbG9jYWxlIH1gXHJcbiAgICAgICAgICAgIHJvdXRlci5wdXNoKGxvY2FsZSlcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYodHlwZW9mIHR5cGUgPT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgbG9jYWxlID0gYCR7IGNhdGVnb3J5IH0vJHsgbG9jYWxlIH1gXHJcbiAgICAgICAgICAgIHJvdXRlci5wdXNoKGxvY2FsZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgbG9jYWxlID0ge1xyXG4gICAgICAgICAgICAgICAgcGF0aG5hbWU6ICcvbWVkaWEvW2NhdGVnb3J5XS9bdHlwZV0nLFxyXG4gICAgICAgICAgICAgICAgcXVlcnk6IHtjYXRlZ29yeTogYCR7IGNhdGVnb3J5IH1gLCBcInR5cGVcIjogYCR7IGxvY2FsZSB9YH0sXHJcbiAgICAgICAgICAgICAgICBhc1BhdGg6IGAvbWVkaWEvJHsgY2F0ZWdvcnkgfS8keyBsb2NhbGUgfWBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByb3V0ZXIucHVzaChsb2NhbGUuYXNQYXRoLCBsb2NhbGUuYXNQYXRoLHtcclxuICAgICAgICAgICAgICAgIHNjcm9sbDogZmFsc2VcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBsZXQgY29udmVydCA9IHtcclxuICAgICAgICBcImFsbFwiOiBcIuC4l+C4seC5ieC4h+C4q+C4oeC4lFwiLFxyXG4gICAgICAgIFwiYWdlbnRzXCI6IFwi4LmA4Lit4LmA4LiI4LiZ4LiX4LmMXCIsXHJcbiAgICAgICAgXCJtYXBzXCI6IFwi4LmB4Lic4LiZ4LiX4Li14LmIXCIsXHJcbiAgICAgICAgXCJhcnNlbmFsc1wiOiBcIuC4hOC4peC4seC4h+C5geC4quC4h1wiLFxyXG4gICAgfVxyXG4gICAgbGV0IGl0ZW1MaXN0ID0gW3tcInR5cGVcIiA6IFwi4LiX4Lix4LmJ4LiH4Lir4Lih4LiUXCIsIFwidmFsdWVcIiA6IGBhbGxgfSxcclxuICAgICB7XCJ0eXBlXCIgOiBcIuC5gOC4reC5gOC4iOC4meC4l+C5jFwiLCBcInZhbHVlXCIgOiBgYWdlbnRzYH0sXHJcbiAgICAge1widHlwZVwiIDogXCLguYHguJzguJnguJfguLXguYhcIiwgXCJ2YWx1ZVwiIDogYG1hcHNgfSxcclxuICAgICB7XCJ0eXBlXCIgOiBcIuC4hOC4peC4seC4h+C5geC4quC4h1wiLCBcInZhbHVlXCIgOiBgYXJzZW5hbHNgfV1cclxuICAgIGNvbnN0IG9wZW5Ecm9wYm94ID0gKGUpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlLnRhcmdldClcclxuICAgIH1cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEJveCBvbkNsaWNrPXsgb3BlbkRyb3Bib3ggfT5cclxuICAgICAgICAgICAgICAgIDxUZXh0IHZhbHVlPXtgLyR7dHlwZX1gfT57IGNvbnZlcnRbdHlwZV0gfTwvVGV4dD5cclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBpdGVtTGlzdC5tYXAoKGl0ZW0sIGluZGV4KT0+e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZihpdGVtLnR5cGUgIT0gY29udmVydFt0eXBlXSl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gPFRleHQga2V5PXsgaW5kZXggfSB2YWx1ZT17aXRlbS52YWx1ZX0+e2l0ZW0udHlwZX08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvPlxyXG5cclxuICAgIClcclxufVxyXG5leHBvcnQgZGVmYXVsdCBGaWx0ZXJEcm9wYm94OyJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInN0eWxlZCIsIlJlYWN0IiwiTGluayIsInVzZVJvdXRlciIsIlRleHQiLCJkaXYiLCJCb3giLCJGaWx0ZXJEcm9wYm94Iiwicm91dGVyIiwiY2F0ZWdvcnkiLCJ0eXBlIiwicXVlcnkiLCJvblNlbGVjdENoYW5nZSIsImUiLCJsb2NhbGUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInB1c2giLCJwYXRobmFtZSIsImFzUGF0aCIsInNjcm9sbCIsImNvbnZlcnQiLCJpdGVtTGlzdCIsIm9wZW5Ecm9wYm94IiwiY29uc29sZSIsImxvZyIsIm1hcCIsIml0ZW0iLCJpbmRleCJdLCJzb3VyY2VSb290IjoiIn0=