"use strict";
self["webpackHotUpdate_N_E"]("pages/media",{

/***/ "./components/MediaComponent/FilterDropbox.jsx":
/*!*****************************************************!*\
  !*** ./components/MediaComponent/FilterDropbox.jsx ***!
  \*****************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\FilterDropbox.jsx",
    _s = $RefreshSig$();








const Text = styled_components__WEBPACK_IMPORTED_MODULE_4__.default.div.withConfig({
  displayName: "FilterDropbox__Text",
  componentId: "sc-3iobc0-0"
})(["text-align:center;position:relative;color:black;background:antiquewhite;width:10vw;height:10vh;"]);
_c = Text;
const Box = styled_components__WEBPACK_IMPORTED_MODULE_4__.default.div.withConfig({
  displayName: "FilterDropbox__Box",
  componentId: "sc-3iobc0-1"
})(["width:10vw;height:10vh;position:absolute;right:10vw;background:none;top:0;cursor:pointer;border:1px solid #8b978f;"]);
_c2 = Box;

const FilterDropbox = () => {
  _s();

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  let {
    category,
    type
  } = router.query;

  if (typeof type === 'undefined') {
    type = `all`;
  }

  const onSelectChange = e => {
    let locale = e.target.value;

    if (typeof category === 'undefined') {
      category = `all`;
      locale = `media/${category}/${locale}`;
      router.push(locale);
    } else if (typeof type === 'undefined') {
      locale = `${category}/${locale}`;
      router.push(locale);
    } else {
      locale = {
        pathname: '/media/[category]/[type]',
        query: {
          category: `${category}`,
          "type": `${locale}`
        },
        asPath: `/media/${category}/${locale}`
      };
      router.push(locale.asPath, locale.asPath, {
        scroll: false
      });
    }
  };

  let convert = {
    "all": "ทั้งหมด",
    "agents": "เอเจนท์",
    "maps": "แผนที่",
    "arsenals": "คลังแสง"
  };
  let itemList = [{
    "type": "ทั้งหมด",
    "value": `all`
  }, {
    "type": "เอเจนท์",
    "value": `agents`
  }, {
    "type": "แผนที่",
    "value": `maps`
  }, {
    "type": "คลังแสง",
    "value": `arsenals`
  }];

  const openDropbox = e => {
    console.log(e.target);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Box, {
      onClick: openDropbox,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Text, {
        value: `/${type}`,
        children: convert[type]
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 17
      }, undefined), itemList.map((item, index) => {
        if (item.type != convert[type]) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Text, {
            value: item.value,
            children: item.type
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 36
          }, undefined);
        }
      })]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

_s(FilterDropbox, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter];
});

_c3 = FilterDropbox;
/* harmony default export */ __webpack_exports__["default"] = (FilterDropbox);

var _c, _c2, _c3;

$RefreshReg$(_c, "Text");
$RefreshReg$(_c2, "Box");
$RefreshReg$(_c3, "FilterDropbox");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvbWVkaWEuZDQ0NDgxMDBlNjE3MTJlMGMyNDQuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBLE1BQU1LLElBQUksR0FBR0oscUVBQUg7QUFBQTtBQUFBO0FBQUEsdUdBQVY7S0FBTUk7QUFVTixNQUFNRSxHQUFHLEdBQUdOLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDBIQUFUO01BQU1NOztBQVlOLE1BQU1DLGFBQWEsR0FBRyxNQUFNO0FBQUE7O0FBQ3hCLFFBQU1DLE1BQU0sR0FBR0wsc0RBQVMsRUFBeEI7QUFDQSxNQUFJO0FBQUVNLElBQUFBLFFBQUY7QUFBWUMsSUFBQUE7QUFBWixNQUFxQkYsTUFBTSxDQUFDRyxLQUFoQzs7QUFDQSxNQUFHLE9BQU9ELElBQVAsS0FBZ0IsV0FBbkIsRUFBK0I7QUFDM0JBLElBQUFBLElBQUksR0FBSSxLQUFSO0FBQ0g7O0FBQ0QsUUFBTUUsY0FBYyxHQUFJQyxDQUFELElBQU87QUFDMUIsUUFBSUMsTUFBTSxHQUFHRCxDQUFDLENBQUNFLE1BQUYsQ0FBU0MsS0FBdEI7O0FBQ0EsUUFBRyxPQUFPUCxRQUFQLEtBQW9CLFdBQXZCLEVBQW1DO0FBQy9CQSxNQUFBQSxRQUFRLEdBQUksS0FBWjtBQUNBSyxNQUFBQSxNQUFNLEdBQUksU0FBU0wsUUFBVSxJQUFJSyxNQUFRLEVBQXpDO0FBQ0FOLE1BQUFBLE1BQU0sQ0FBQ1MsSUFBUCxDQUFZSCxNQUFaO0FBQ0gsS0FKRCxNQU1LLElBQUcsT0FBT0osSUFBUCxLQUFnQixXQUFuQixFQUErQjtBQUNoQ0ksTUFBQUEsTUFBTSxHQUFJLEdBQUdMLFFBQVUsSUFBSUssTUFBUSxFQUFuQztBQUNBTixNQUFBQSxNQUFNLENBQUNTLElBQVAsQ0FBWUgsTUFBWjtBQUNILEtBSEksTUFJRDtBQUNBQSxNQUFBQSxNQUFNLEdBQUc7QUFDTEksUUFBQUEsUUFBUSxFQUFFLDBCQURMO0FBRUxQLFFBQUFBLEtBQUssRUFBRTtBQUFDRixVQUFBQSxRQUFRLEVBQUcsR0FBR0EsUUFBVSxFQUF6QjtBQUE0QixrQkFBUyxHQUFHSyxNQUFRO0FBQWhELFNBRkY7QUFHTEssUUFBQUEsTUFBTSxFQUFHLFVBQVVWLFFBQVUsSUFBSUssTUFBUTtBQUhwQyxPQUFUO0FBS0FOLE1BQUFBLE1BQU0sQ0FBQ1MsSUFBUCxDQUFZSCxNQUFNLENBQUNLLE1BQW5CLEVBQTJCTCxNQUFNLENBQUNLLE1BQWxDLEVBQXlDO0FBQ3JDQyxRQUFBQSxNQUFNLEVBQUU7QUFENkIsT0FBekM7QUFHSDtBQUNKLEdBdEJEOztBQXVCQSxNQUFJQyxPQUFPLEdBQUc7QUFDVixXQUFPLFNBREc7QUFFVixjQUFVLFNBRkE7QUFHVixZQUFRLFFBSEU7QUFJVixnQkFBWTtBQUpGLEdBQWQ7QUFNQSxNQUFJQyxRQUFRLEdBQUcsQ0FBQztBQUFDLFlBQVMsU0FBVjtBQUFxQixhQUFXO0FBQWhDLEdBQUQsRUFDZDtBQUFDLFlBQVMsU0FBVjtBQUFxQixhQUFXO0FBQWhDLEdBRGMsRUFFZDtBQUFDLFlBQVMsUUFBVjtBQUFvQixhQUFXO0FBQS9CLEdBRmMsRUFHZDtBQUFDLFlBQVMsU0FBVjtBQUFxQixhQUFXO0FBQWhDLEdBSGMsQ0FBZjs7QUFJQSxRQUFNQyxXQUFXLEdBQUlWLENBQUQsSUFBTztBQUN2QlcsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlaLENBQUMsQ0FBQ0UsTUFBZDtBQUNILEdBRkQ7O0FBR0Esc0JBQ0k7QUFBQSwyQkFDSSw4REFBQyxHQUFEO0FBQUssYUFBTyxFQUFHUSxXQUFmO0FBQUEsOEJBQ0ksOERBQUMsSUFBRDtBQUFNLGFBQUssRUFBRyxJQUFHYixJQUFLLEVBQXRCO0FBQUEsa0JBQTJCVyxPQUFPLENBQUNYLElBQUQ7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixFQUdRWSxRQUFRLENBQUNJLEdBQVQsQ0FBYSxDQUFDQyxJQUFELEVBQU9DLEtBQVAsS0FBZTtBQUN4QixZQUFHRCxJQUFJLENBQUNqQixJQUFMLElBQWFXLE9BQU8sQ0FBQ1gsSUFBRCxDQUF2QixFQUE4QjtBQUMxQiw4QkFBTyw4REFBQyxJQUFEO0FBQW9CLGlCQUFLLEVBQUVpQixJQUFJLENBQUNYLEtBQWhDO0FBQUEsc0JBQXdDVyxJQUFJLENBQUNqQjtBQUE3QyxhQUFZa0IsS0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFQO0FBQ0g7QUFDSixPQUpELENBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosbUJBREo7QUFnQkgsQ0ExREQ7O0dBQU1yQjtVQUNhSjs7O01BRGJJO0FBMkROLCtEQUFlQSxhQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvTWVkaWFDb21wb25lbnQvRmlsdGVyRHJvcGJveC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxuY29uc3QgVGV4dCA9IHN0eWxlZC5kaXZgXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBiYWNrZ3JvdW5kOiBhbnRpcXVld2hpdGU7XHJcbiAgICB3aWR0aDogMTB2dztcclxuICAgIGhlaWdodDogMTB2aDtcclxuYFxyXG5cclxuXHJcbmNvbnN0IEJveCA9IHN0eWxlZC5kaXZgXHJcbiAgICB3aWR0aDogMTB2dztcclxuICAgIGhlaWdodDogMTB2aDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAxMHZ3O1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIHRvcDogMDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICM4Yjk3OGY7XHJcblxyXG5gXHJcblxyXG5jb25zdCBGaWx0ZXJEcm9wYm94ID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgICBsZXQgeyBjYXRlZ29yeSwgdHlwZSB9ID0gcm91dGVyLnF1ZXJ5O1xyXG4gICAgaWYodHlwZW9mIHR5cGUgPT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICB0eXBlID0gYGFsbGBcclxuICAgIH1cclxuICAgIGNvbnN0IG9uU2VsZWN0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgICAgICBsZXQgbG9jYWxlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICAgICAgaWYodHlwZW9mIGNhdGVnb3J5ID09PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgIGNhdGVnb3J5ID0gYGFsbGA7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IGBtZWRpYS8keyBjYXRlZ29yeSB9LyR7IGxvY2FsZSB9YFxyXG4gICAgICAgICAgICByb3V0ZXIucHVzaChsb2NhbGUpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmKHR5cGVvZiB0eXBlID09PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IGAkeyBjYXRlZ29yeSB9LyR7IGxvY2FsZSB9YFxyXG4gICAgICAgICAgICByb3V0ZXIucHVzaChsb2NhbGUpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IHtcclxuICAgICAgICAgICAgICAgIHBhdGhuYW1lOiAnL21lZGlhL1tjYXRlZ29yeV0vW3R5cGVdJyxcclxuICAgICAgICAgICAgICAgIHF1ZXJ5OiB7Y2F0ZWdvcnk6IGAkeyBjYXRlZ29yeSB9YCwgXCJ0eXBlXCI6IGAkeyBsb2NhbGUgfWB9LFxyXG4gICAgICAgICAgICAgICAgYXNQYXRoOiBgL21lZGlhLyR7IGNhdGVnb3J5IH0vJHsgbG9jYWxlIH1gXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcm91dGVyLnB1c2gobG9jYWxlLmFzUGF0aCwgbG9jYWxlLmFzUGF0aCx7XHJcbiAgICAgICAgICAgICAgICBzY3JvbGw6IGZhbHNlXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgbGV0IGNvbnZlcnQgPSB7XHJcbiAgICAgICAgXCJhbGxcIjogXCLguJfguLHguYnguIfguKvguKHguJRcIixcclxuICAgICAgICBcImFnZW50c1wiOiBcIuC5gOC4reC5gOC4iOC4meC4l+C5jFwiLFxyXG4gICAgICAgIFwibWFwc1wiOiBcIuC5geC4nOC4meC4l+C4teC5iFwiLFxyXG4gICAgICAgIFwiYXJzZW5hbHNcIjogXCLguITguKXguLHguIfguYHguKrguIdcIixcclxuICAgIH1cclxuICAgIGxldCBpdGVtTGlzdCA9IFt7XCJ0eXBlXCIgOiBcIuC4l+C4seC5ieC4h+C4q+C4oeC4lFwiLCBcInZhbHVlXCIgOiBgYWxsYH0sXHJcbiAgICAge1widHlwZVwiIDogXCLguYDguK3guYDguIjguJnguJfguYxcIiwgXCJ2YWx1ZVwiIDogYGFnZW50c2B9LFxyXG4gICAgIHtcInR5cGVcIiA6IFwi4LmB4Lic4LiZ4LiX4Li14LmIXCIsIFwidmFsdWVcIiA6IGBtYXBzYH0sXHJcbiAgICAge1widHlwZVwiIDogXCLguITguKXguLHguIfguYHguKrguIdcIiwgXCJ2YWx1ZVwiIDogYGFyc2VuYWxzYH1dXHJcbiAgICBjb25zdCBvcGVuRHJvcGJveCA9IChlKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZS50YXJnZXQpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxCb3ggb25DbGljaz17IG9wZW5Ecm9wYm94IH0+XHJcbiAgICAgICAgICAgICAgICA8VGV4dCB2YWx1ZT17YC8ke3R5cGV9YH0+eyBjb252ZXJ0W3R5cGVdIH08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbUxpc3QubWFwKChpdGVtLCBpbmRleCk9PntcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYoaXRlbS50eXBlICE9IGNvbnZlcnRbdHlwZV0pe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxUZXh0IGtleT17IGluZGV4IH0gdmFsdWU9e2l0ZW0udmFsdWV9PntpdGVtLnR5cGV9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICA8Lz5cclxuXHJcbiAgICApXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgRmlsdGVyRHJvcGJveDsiXSwibmFtZXMiOlsidXNlU3RhdGUiLCJzdHlsZWQiLCJSZWFjdCIsIkxpbmsiLCJ1c2VSb3V0ZXIiLCJUZXh0IiwiZGl2IiwiQm94IiwiRmlsdGVyRHJvcGJveCIsInJvdXRlciIsImNhdGVnb3J5IiwidHlwZSIsInF1ZXJ5Iiwib25TZWxlY3RDaGFuZ2UiLCJlIiwibG9jYWxlIiwidGFyZ2V0IiwidmFsdWUiLCJwdXNoIiwicGF0aG5hbWUiLCJhc1BhdGgiLCJzY3JvbGwiLCJjb252ZXJ0IiwiaXRlbUxpc3QiLCJvcGVuRHJvcGJveCIsImNvbnNvbGUiLCJsb2ciLCJtYXAiLCJpdGVtIiwiaW5kZXgiXSwic291cmNlUm9vdCI6IiJ9