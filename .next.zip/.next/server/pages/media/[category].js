(() => {
var exports = {};
exports.id = "pages/media/[category]";
exports.ids = ["pages/media/[category]"];
exports.modules = {

/***/ "./components/Button/Button.jsx":
/*!**************************************!*\
  !*** ./components/Button/Button.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Button\\Button.jsx";


const StyledButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    border: none;
    width: 270px;
    height: 68px;
    background: none;
    padding: 6px;
    cursor: pointer;
    margin: 0;
    position: relative;
`;
const Content = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    background-color: ${props => props.isWhite ? "#ece8e1" : "#ff4655"};
    height: 100%;
    width: 100%;
    font-family: 'Bai Jamjuree', sans-serif;
    font-weight: 500;
    color: ${props => props.isWhite ? "#0f1923" : "white"};
    transition: background ease-in .2s, border .2s;
    &:hover {
        background: #0f1923;
        outline: ${props => props.isBordered ? `solid ${props.isWhite ? "#ece8e144" : "#ff465544"} 1px` : "none"};
        color: white;
    }
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
`;
const WhiteBox = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    position: absolute;
    background-color: #0f1923;
    width: 5px;
    height: 5px;
    right: 0;
    bottom: 0;
    transition: background ease-in .3s;
    ${Content}:hover & {
        background-color: white;
    }
`;
const ButtonBorder = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    border-left: solid #bdbcb7 1px;
    border-right: solid #bdbcb7 1px;
    left: 0;
    width: 100%;
    height: 29px;
    position: absolute;
`;
const TopBorder = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(ButtonBorder)`
    border-top: solid #bdbcb7 1px;
    top: 0;
`;
const BottomBorder = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(ButtonBorder)`
    border-bottom: solid #bdbcb7 1px;
    bottom: 0;
`;

const Button = ({
  children,
  isWhite,
  isBordered
}) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledButtonWrapper, {
  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TopBorder, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 67,
    columnNumber: 9
  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(BottomBorder, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 68,
    columnNumber: 9
  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Content, {
    isWhite: isWhite,
    isBordered: isBordered,
    children: [children, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(WhiteBox, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 69,
    columnNumber: 9
  }, undefined)]
}, void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 66,
  columnNumber: 5
}, undefined);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);

/***/ }),

/***/ "./components/Button/index.js":
/*!************************************!*\
  !*** ./components/Button/index.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Button": () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ "./components/Button/Button.jsx");


/***/ }),

/***/ "./components/Footer/FistLogo.jsx":
/*!****************************************!*\
  !*** ./components/Footer/FistLogo.jsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\FistLogo.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 30px;
    height: 30px;
    margin-right: 6px;
`;

const FistLogo = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 24 24",
    fill: "#E6E6E6",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "M12.534 21.77l-1.09-2.81 10.52.54-.451 4.5zM15.06 0L.307 6.969 2.59 17.471H5.6l-.52-7.512.461-.144 1.81 7.656h3.126l-.116-9.15.462-.144 1.582 9.294h3.31l.78-11.053.462-.144.82 11.197h4.376l1.54-15.37Z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FistLogo);

/***/ }),

/***/ "./components/Footer/Footer.jsx":
/*!**************************************!*\
  !*** ./components/Footer/Footer.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _FooterLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FooterLayout */ "./components/Footer/FooterLayout.jsx");
/* harmony import */ var _RiotGamesLogo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./RiotGamesLogo */ "./components/Footer/RiotGamesLogo.jsx");
/* harmony import */ var _FistLogo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FistLogo */ "./components/Footer/FistLogo.jsx");
/* harmony import */ var _LinkHover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./LinkHover */ "./components/Footer/LinkHover.jsx");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Icon */ "./components/Footer/Icon/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\Footer.jsx";







const P = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
    user-select: none;
    font-size: 12px;
`;
const Reserved = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(P)`
    max-width: 500px;
    text-align: center;
    cursor: default;
`;
const LogoWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    display: flex;
    cursor: pointer;
`;
const Underline = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(P)`
    text-decoration: underline;
    cursor: pointer;
`;
const LinkWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    display: flex;
    column-gap: 12px;
`;
const SocialWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    display: flex;
    column-gap: 24px;
`;

const Footer = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_FooterLayout__WEBPACK_IMPORTED_MODULE_1__.FooterLayout, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_LinkHover__WEBPACK_IMPORTED_MODULE_4__.default, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(P, {
        children: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E40\u0E01\u0E21"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(LogoWrapper, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_FistLogo__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_RiotGamesLogo__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(SocialWrapper, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_Icon__WEBPACK_IMPORTED_MODULE_5__.FacebookIcon, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_Icon__WEBPACK_IMPORTED_MODULE_5__.YoutubeIcon, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_Icon__WEBPACK_IMPORTED_MODULE_5__.InstagramIcon, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Reserved, {
      children: "\xA9 \u0E2A\u0E07\u0E27\u0E19\u0E25\u0E34\u0E02\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E15\u0E32\u0E21\u0E01\u0E0F\u0E2B\u0E21\u0E32\u0E22 \u0E1E.\u0E28. 2563 \u0E1A\u0E23\u0E34\u0E29\u0E31\u0E17 Riot, VALORANT \u0E41\u0E25\u0E30\u0E42\u0E25\u0E42\u0E01\u0E49\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E41\u0E25\u0E30/\u0E2B\u0E23\u0E37\u0E2D \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32\u0E08\u0E14\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E02\u0E49\u0E2D\u0E07 \u0E16\u0E37\u0E2D\u0E40\u0E1B\u0E47\u0E19\u0E01\u0E23\u0E23\u0E21\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E02\u0E2D\u0E07 Riot Games, Inc."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(LinkWrapper, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Underline, {
        children: "\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E04\u0E27\u0E32\u0E21\u0E40\u0E1B\u0E47\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E31\u0E27"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Underline, {
        children: "\u0E02\u0E49\u0E2D\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Underline, {
        children: "\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E04\u0E38\u0E01\u0E01\u0E35\u0E49"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 41,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

/***/ }),

/***/ "./components/Footer/FooterLayout.jsx":
/*!********************************************!*\
  !*** ./components/Footer/FooterLayout.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FooterLayout": () => (/* binding */ FooterLayout)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const FooterLayout = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().footer)`
    width: 100%;
    height: 570px;
    background-color: #111;
    display: flex;
    flex-direction: column;
    align-items: center;
    color: #7e7e7e;
    fill: #7e7e7e;
    row-gap: 32px;
    padding: 28px;
    font-family: 'Bai Jamjuree', sans-serif;
`;

/***/ }),

/***/ "./components/Footer/Icon/FacebookIcon.jsx":
/*!*************************************************!*\
  !*** ./components/Footer/Icon/FacebookIcon.jsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\Icon\\FacebookIcon.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 24px;
    height: 24px;
    transition: fill .3s;
    cursor: pointer;
    &:hover {
        fill: white;
    }
`;

const FacebookIcon = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FacebookIcon);

/***/ }),

/***/ "./components/Footer/Icon/InstagramIcon.jsx":
/*!**************************************************!*\
  !*** ./components/Footer/Icon/InstagramIcon.jsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\Icon\\InstagramIcon.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 24px;
    height: 24px;
    transition: fill .3s;
    cursor: pointer;
    &:hover {
        fill: white;
    }
`;

const InstagramIcon = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 24 24",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12zm2.829-17.698c-.739-.034-.96-.04-2.829-.04-1.87 0-2.09.006-2.829.04-.682.031-1.053.145-1.3.241-.326.127-.56.278-.805.523a2.171 2.171 0 00-.523.805c-.096.247-.21.618-.24 1.3-.035.739-.042.96-.042 2.829 0 1.87.007 2.09.041 2.829.031.682.145 1.053.241 1.3.127.326.278.56.523.804.246.245.479.397.805.524.247.096.618.21 1.3.24.738.035.96.042 2.829.042 1.87 0 2.09-.008 2.829-.041.682-.031 1.053-.145 1.3-.241.326-.127.56-.278.804-.524.245-.245.397-.478.524-.805.096-.246.21-.617.24-1.3.035-.738.042-.959.042-2.828 0-1.87-.008-2.09-.041-2.829-.031-.682-.145-1.053-.241-1.3a2.164 2.164 0 00-.524-.805 2.172 2.172 0 00-.805-.523c-.246-.096-.617-.21-1.3-.24zm-5.715-1.26C9.86 5.008 10.099 5 12 5c1.901 0 2.14.008 2.886.042.745.034 1.254.153 1.7.325.46.18.85.419 1.24.808.389.389.628.78.807 1.24.173.445.291.954.325 1.699.035.746.043.985.043 2.886 0 1.901-.009 2.14-.043 2.886-.034.745-.152 1.254-.325 1.7a3.43 3.43 0 01-.807 1.24c-.39.389-.78.628-1.24.807-.445.173-.955.291-1.7.325-.746.034-.985.042-2.886.042-1.9 0-2.14-.008-2.886-.042-.745-.034-1.254-.152-1.7-.325a3.43 3.43 0 01-1.239-.808 3.428 3.428 0 01-.807-1.24c-.173-.445-.292-.954-.326-1.699C5.008 14.14 5 13.901 5 12c0-1.901.008-2.14.042-2.886.034-.745.153-1.254.326-1.7.178-.46.418-.85.807-1.239.389-.39.78-.628 1.24-.807.445-.173.954-.292 1.699-.326zM12 8.405a3.594 3.594 0 100 7.19 3.594 3.594 0 000-7.19zm0 5.928a2.333 2.333 0 110-4.666 2.333 2.333 0 010 4.666zm4.577-6.07a.84.84 0 11-1.68 0 .84.84 0 011.68 0z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InstagramIcon);

/***/ }),

/***/ "./components/Footer/Icon/YoutubeIcon.jsx":
/*!************************************************!*\
  !*** ./components/Footer/Icon/YoutubeIcon.jsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\Icon\\YoutubeIcon.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 24px;
    height: 24px;
    transition: fill .3s;
    cursor: pointer;
    &:hover {
        fill: white;
    }
`;

const YoutubeIcon = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 24 24",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12zm5.47-16.231c.602.148 1.077.583 1.237 1.136C19 9.908 19 12 19 12s0 2.092-.293 3.095c-.16.553-.635.988-1.238 1.136C16.38 16.5 12 16.5 12 16.5s-4.378 0-5.47-.268c-.602-.149-1.077-.584-1.237-1.137C5 14.092 5 12 5 12s0-2.092.293-3.095c.16-.553.635-.988 1.237-1.136C7.622 7.5 12 7.5 12 7.5s4.378 0 5.47.269zM14.226 12l-3.659-1.9v3.8l3.66-1.9z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (YoutubeIcon);

/***/ }),

/***/ "./components/Footer/Icon/index.js":
/*!*****************************************!*\
  !*** ./components/Footer/Icon/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FacebookIcon": () => (/* reexport safe */ _FacebookIcon__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "InstagramIcon": () => (/* reexport safe */ _InstagramIcon__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "YoutubeIcon": () => (/* reexport safe */ _YoutubeIcon__WEBPACK_IMPORTED_MODULE_2__.default)
/* harmony export */ });
/* harmony import */ var _FacebookIcon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FacebookIcon */ "./components/Footer/Icon/FacebookIcon.jsx");
/* harmony import */ var _InstagramIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InstagramIcon */ "./components/Footer/Icon/InstagramIcon.jsx");
/* harmony import */ var _YoutubeIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./YoutubeIcon */ "./components/Footer/Icon/YoutubeIcon.jsx");




/***/ }),

/***/ "./components/Footer/LinkHover.jsx":
/*!*****************************************!*\
  !*** ./components/Footer/LinkHover.jsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\LinkHover.jsx";


const Wrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().a)`
    transition: color .3s;
    cursor: pointer;
    &:hover {
        color: white;
    }
    font-weight: 700;
`;

const ButtonWrapper = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Wrapper, {
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonWrapper);

/***/ }),

/***/ "./components/Footer/RiotGamesLogo.jsx":
/*!*********************************************!*\
  !*** ./components/Footer/RiotGamesLogo.jsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\RiotGamesLogo.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 60px;
    height: 30px;
`;

const RiotGamesLogo = ({
  href
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 600 305.41",
    fill: "#E6E6E6",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m404.82 290.61-.39225-11.291 39.032-.46128.35814-12.305-39.851-.49538-.39793-11.431 52.503-1.2291.43285-13.5h-70.833l-2.1115 65.51h74.251l-.52138-13.525zm-353.18-24.086-.83372 12.256 19.699.65862-.24932 12.442-41.232-1.209 1.7963-35.938 56.692-1.3121-.81934-13.525h-73.228l-6.5665 65.51h83.436l-2.1631-39.519zm516.81 5.0681-54.116-9.1478.2347-7.0907 51.77-1.931-1.3064-13.525h-66.547l-3.4036 33.955 55.016 9.566.24932 6.2399-57.242 2.2232-1.4038 13.525h80.115z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m347.63 305.41-6.5664-65.51h-18.851l-27.082 31.228-27.085-31.228h-18.851l-6.5664 65.51h22.146l2.1201-42.499 28.237 28.973 28.231-28.973 2.1258 42.499z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m254.55 0h-44.324l-4.0338 202.59h53.552z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m391.89 158.52-48.907 1.5786-1.6215-119.15 51.151 1.5499zm42.862-158.43h-138.19l-5.3804 202.5h153.38z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m600 44.336-4.9363-44.335h-136.15l1.1517 39.493 43.547 1.507 4.4635 161.59h53.66l-16.052-160.14z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m73.64 41.444 42.711-1.4296 4.8675 40.364-49.297 23.286zm49.899 161.15h58.167l-37.909-90.925 30.251-16.528-20.668-95.139h-148.48l-4.8875 43.905 33.216-1.1088-16.018 159.8h51.984l1.4067-50.939 37.456-20.462z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m151.82 275.89 4.5037-21.433 21.625-.97698 4.518 21.507zm37.044 29.526h22.424l-17.743-65.513h-52.615l-17.74 65.513h22.424l3.4723-16.528 36.402.47021z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RiotGamesLogo);

/***/ }),

/***/ "./components/Footer/index.js":
/*!************************************!*\
  !*** ./components/Footer/index.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Footer": () => (/* reexport safe */ _Footer__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Footer */ "./components/Footer/Footer.jsx");


/***/ }),

/***/ "./components/Head.jsx":
/*!*****************************!*\
  !*** ./components/Head.jsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Head.jsx";



const Head = ({
  title
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_0___default()), {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      charSet: "UTF-8"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      httpEquiv: "X-UA-Compatible",
      content: "IE=edge"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      name: "viewport",
      content: "width=device-width, initial-scale=1.0"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("link", {
      rel: "shortcut icon",
      href: "favicon.svg",
      type: "image/x-svg"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("title", {
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Head);

/***/ }),

/***/ "./components/MediaComponent/CategoryBar.jsx":
/*!***************************************************!*\
  !*** ./components/MediaComponent/CategoryBar.jsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! . */ "./components/MediaComponent/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\CategoryBar.jsx";






const Bar = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().ul)`
    height: 10vh;
    position: relative;
    display: block;
    }
`;
const Category = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().li)`
float: left;
margin-left: 50px;
list-style-type: none; 
height: 5vh;
`;

const CategoryBar = () => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  const {
    category
  } = router.query;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Bar, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "all" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "all" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/all",
          scroll: false,
          children: "\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 151
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "wallpaper" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "wallpaper" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/wallpaper",
          scroll: false,
          children: "\u0E27\u0E2D\u0E25\u0E40\u0E1B\u0E40\u0E1B\u0E2D\u0E23\u0E4C"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 163
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "video" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "video" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/video",
          scroll: false,
          children: "\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 155
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "screenshot" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "screenshot" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/screenshot",
          scroll: false,
          children: "\u0E2A\u0E01\u0E23\u0E35\u0E19\u0E0A\u0E47\u0E2D\u0E15"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 165
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "artwork" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "artwork" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/artwork",
          scroll: false,
          children: "\u0E2D\u0E32\u0E23\u0E4C\u0E17\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 159
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "logo" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "logo" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/logo",
          scroll: false,
          children: "\u0E42\u0E25\u0E42\u0E01\u0E49"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 153
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "content_creator" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "content_creator" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/content_creator",
          scroll: false,
          children: "\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C\u0E04\u0E23\u0E35\u0E40\u0E2D\u0E40\u0E15\u0E2D\u0E23\u0E4C"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 175
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_2__.FilterDropbox, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 9
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryBar);

/***/ }),

/***/ "./components/MediaComponent/FilterDropbox.jsx":
/*!*****************************************************!*\
  !*** ./components/MediaComponent/FilterDropbox.jsx ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\FilterDropbox.jsx";







const Text = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "FilterDropbox__Text",
  componentId: "sc-3iobc0-0"
})(["text-align:center;position:relative;color:black;background:antiquewhite;width:10vw;height:10vh;"]);
const Box = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "FilterDropbox__Box",
  componentId: "sc-3iobc0-1"
})(["width:10vw;height:10vh;position:absolute;right:10vw;background:none;top:0;cursor:pointer;border:1px solid #8b978f;"]);

const FilterDropbox = () => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  let {
    category,
    type
  } = router.query;

  if (typeof type === 'undefined') {
    type = `all`;
  }

  const onSelectChange = e => {
    let locale = e.target.value;

    if (typeof category === 'undefined') {
      category = `all`;
      locale = `media/${category}/${locale}`;
      router.push(locale);
    } else if (typeof type === 'undefined') {
      locale = `${category}/${locale}`;
      router.push(locale);
    } else {
      locale = {
        pathname: '/media/[category]/[type]',
        query: {
          category: `${category}`,
          "type": `${locale}`
        },
        asPath: `/media/${category}/${locale}`
      };
      router.push(locale.asPath, locale.asPath, {
        scroll: false
      });
    }
  };

  let convert = {
    "all": "ทั้งหมด",
    "agents": "เอเจนท์",
    "maps": "แผนที่",
    "arsenals": "คลังแสง"
  };
  let itemList = [{
    "type": "ทั้งหมด",
    "value": `all`
  }, {
    "type": "เอเจนท์",
    "value": `agents`
  }, {
    "type": "แผนที่",
    "value": `maps`
  }, {
    "type": "คลังแสง",
    "value": `arsenals`
  }];

  const openDropbox = e => {
    console.log(e.target);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Box, {
      onClick: openDropbox,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Text, {
        value: `/${type}`,
        children: convert[type]
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 17
      }, undefined), itemList.map((item, index) => {
        if (item.type != convert[type]) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Text, {
            value: item.value,
            children: item.type
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 36
          }, undefined);
        }
      })]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilterDropbox);

/***/ }),

/***/ "./components/MediaComponent/MediaHead.jsx":
/*!*************************************************!*\
  !*** ./components/MediaComponent/MediaHead.jsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _TextBg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../TextBg */ "./components/TextBg.jsx");
/* harmony import */ var _styles_media_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../styles/media.module.css */ "./styles/media.module.css");
/* harmony import */ var _styles_media_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_media_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\MediaHead.jsx";





const Box = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
position: relative;
width: 100vw;
display: block;
box-sizing: border-box;
`;
const MediaHeader = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
width: 60vw;
height: 90vh;
background: #ff4655;
position: relative;

&:after{
    content: "";
    width: 90%;
    position: absolute;
    height: 7.5vh;
    background: antiquewhite;
    bottom: 0;
    transform: translateX(-10%) skewX(50deg);
}
`;
const MediaTopicContianer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
position: absolute;
height: 60%;
width: 90%;
right: 0;
bottom: 20%;
border-top: 1px solid white;
z-index: 1;
&:before{
    content: "";
    position: absolute;
    width: 20px;
    height: 20%;
    border-left: 1px solid white;
    bottom: -20%;
}

`;
const MediaTopic = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().h1)`
font-size: 10vh;
color: white;
position: relative;
margin-top: 30px;
margin-bottom: 30px;
overflow: hidden;
`;
const MediaTopicContent = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
width: 55%;
color: white;
font-size: 2.5vh;
margin-bottom: 3vh;
overflow: hidden;
`;
const MediaHeaderImg = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().span)`
background: url("../../../../media_content/pic/Media_Header.jpg");
background-size: cover;
width: 52.75vw;
height: 74.5vh;
position: absolute;
right: 7.5%;
bottom: -1px;
z-index: 1;
transform-origin: bottom;
&:before{
    content: "";
    width: 50px;
    height: 50px;
    background: #ff4655;
    position: absolute;
}
&:after{
    content: "";
    position: absolute;
    background: antiquewhite;
    width: 6vw;
    height: 10vh;
    bottom: 0;
    transform: skewX(40deg) translateX(-4vw);
}
`;
const BotLeftImg = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
position: absolute;
width: 100px;
height: 100px;
border: 1px solid white;
opacity: .5;
bottom: 0;
right: 0;
&:before{
    content: "";
    position: absolute;
    width: 50%;
    height: 50%;
    right: -7.5px;
    top: 25%;
    transform: skewX(-45deg);
    border-left: 3px solid white;
}
&:after{
    content: "";
    position: absolute;
    width: 5px;
    height: 5px;
    bottom: 0;
    background: white;
}
`;
const Line = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    position: absolute;
    width: 33.6313vw;
    height: 10px;
    bottom: 0;
    border-bottom: 1px solid white;
    &:after{
        content: "";
        position: absolute;
        width: 20%;
        border-top: 1px solid #ff4655;
        bottom: -1px;
        left: 10%;
    }

`;

const MediaHead = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Box, {
      style: {
        height: "92.5vh",
        overflow: "hidden"
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_TextBg__WEBPACK_IMPORTED_MODULE_1__.TextBgContainer, {
        style: {
          background: "none",
          zIndex: 1,
          top: "35vh"
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_TextBg__WEBPACK_IMPORTED_MODULE_1__.Txt, {
          className: ((_styles_media_module_css__WEBPACK_IMPORTED_MODULE_3___default().textBackground), (_styles_media_module_css__WEBPACK_IMPORTED_MODULE_3___default().stroke)),
          style: {
            fontSize: "15vw"
          },
          children: "VALORANT"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 136,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 135,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaHeader, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaTopicContianer, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaTopic, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: "MoveUp",
              children: "\u0E2A\u0E37\u0E48\u0E2D"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 140,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 140,
            columnNumber: 21
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaTopicContent, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: "MoveUp",
              children: "\u0E07\u0E32\u0E19\u0E02\u0E2D\u0E07\u0E40\u0E23\u0E32\u0E04\u0E37\u0E2D\u0E01\u0E32\u0E23\u0E40\u0E25\u0E48\u0E19\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13 \u0E44\u0E21\u0E48\u0E27\u0E48\u0E32\u0E04\u0E38\u0E13\u0E08\u0E30\u0E40\u0E1B\u0E47\u0E19\u0E2A\u0E37\u0E48\u0E2D \u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C\u0E04\u0E23\u0E35\u0E40\u0E2D\u0E40\u0E15\u0E2D\u0E23\u0E4C \u0E2B\u0E23\u0E37\u0E2D\u0E17\u0E31\u0E49\u0E07\u0E2A\u0E2D\u0E07 \u0E04\u0E38\u0E13\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E43\u0E0A\u0E49\u0E17\u0E38\u0E01\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E17\u0E35\u0E48\u0E04\u0E38\u0E13\u0E40\u0E2B\u0E47\u0E19\u0E17\u0E35\u0E48\u0E19\u0E35\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 141,
              columnNumber: 40
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 141,
            columnNumber: 21
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaTopicContent, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: "MoveUp",
              children: ["\u0E42\u0E1B\u0E23\u0E14\u0E2D\u0E22\u0E48\u0E32\u0E25\u0E37\u0E21\u0E41\u0E17\u0E47\u0E01 @PlayVALORANT \u0E1A\u0E19\u0E42\u0E0B\u0E40\u0E0A\u0E35\u0E22\u0E25\u0E21\u0E35\u0E40\u0E14\u0E35\u0E22\u0E2B\u0E32\u0E01\u0E04\u0E38\u0E13\u0E44\u0E14\u0E49\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E07\u0E32\u0E19\u0E14\u0E49\u0E27\u0E22\u0E44\u0E1F\u0E25\u0E4C\u0E19\u0E35\u0E49 \u0E40\u0E23\u0E32\u0E2D\u0E14\u0E43\u0E08\u0E23\u0E2D\u0E41\u0E17\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E2B\u0E27\u0E17\u0E35\u0E48\u0E08\u0E30\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E0A\u0E21\u0E2A\u0E34\u0E48\u0E07\u0E17\u0E35\u0E48\u0E04\u0E38\u0E13\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E02\u0E36\u0E49\u0E19\u0E21\u0E32 \u0E41\u0E15\u0E48\u0E2D\u0E22\u0E48\u0E32\u0E25\u0E37\u0E21\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("a", {
                className: "condition",
                href: "#",
                children: "\u0E40\u0E07\u0E37\u0E48\u0E2D\u0E19\u0E44\u0E02\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u0E02\u0E2D\u0E07\u0E40\u0E23\u0E32\u0E25\u0E48\u0E30"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 142,
                columnNumber: 212
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 40
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 142,
            columnNumber: 21
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Line, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 143,
            columnNumber: 21
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 139,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 138,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaHeaderImg, {
        className: "MoveUp",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(BotLeftImg, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 146,
          columnNumber: 48
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 146,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 134,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MediaHead);

/***/ }),

/***/ "./components/MediaComponent/index.js":
/*!********************************************!*\
  !*** ./components/MediaComponent/index.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterDropbox": () => (/* reexport safe */ _FilterDropbox__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "MediaHead": () => (/* reexport safe */ _MediaHead__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "CategoryBar": () => (/* reexport safe */ _CategoryBar__WEBPACK_IMPORTED_MODULE_2__.default)
/* harmony export */ });
/* harmony import */ var _FilterDropbox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FilterDropbox */ "./components/MediaComponent/FilterDropbox.jsx");
/* harmony import */ var _MediaHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MediaHead */ "./components/MediaComponent/MediaHead.jsx");
/* harmony import */ var _CategoryBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CategoryBar */ "./components/MediaComponent/CategoryBar.jsx");




/***/ }),

/***/ "./components/Nav/LangButton.jsx":
/*!***************************************!*\
  !*** ./components/Nav/LangButton.jsx ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _LangSelector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./LangSelector */ "./components/Nav/LangSelector.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\LangButton.jsx";




const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 32px;
    height: 32px;
    margin-left: 12px;
    margin-right: 12px;
    padding: 8px;
    background-color: #33333377;
    border-radius: 50%;
    cursor: pointer;
    right: 164px;
`;
const ButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    background: none;
    padding: 0;
    margin: 0;
    border: none;
    cursor: pointer;
`;

const LangButton = ({
  isOpen,
  onClick
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonWrapper, {
      onClick: onClick,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledLogo, {
        viewBox: "0 0 16 16",
        fill: "#fff",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
          d: "M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm7.5-6.923c-.67.204-1.335.82-1.887 1.855A7.97 7.97 0 0 0 5.145 4H7.5V1.077zM4.09 4a9.267 9.267 0 0 1 .64-1.539 6.7 6.7 0 0 1 .597-.933A7.025 7.025 0 0 0 2.255 4H4.09zm-.582 3.5c.03-.877.138-1.718.312-2.5H1.674a6.958 6.958 0 0 0-.656 2.5h2.49zM4.847 5a12.5 12.5 0 0 0-.338 2.5H7.5V5H4.847zM8.5 5v2.5h2.99a12.495 12.495 0 0 0-.337-2.5H8.5zM4.51 8.5a12.5 12.5 0 0 0 .337 2.5H7.5V8.5H4.51zm3.99 0V11h2.653c.187-.765.306-1.608.338-2.5H8.5zM5.145 12c.138.386.295.744.468 1.068.552 1.035 1.218 1.65 1.887 1.855V12H5.145zm.182 2.472a6.696 6.696 0 0 1-.597-.933A9.268 9.268 0 0 1 4.09 12H2.255a7.024 7.024 0 0 0 3.072 2.472zM3.82 11a13.652 13.652 0 0 1-.312-2.5h-2.49c.062.89.291 1.733.656 2.5H3.82zm6.853 3.472A7.024 7.024 0 0 0 13.745 12H11.91a9.27 9.27 0 0 1-.64 1.539 6.688 6.688 0 0 1-.597.933zM8.5 12v2.923c.67-.204 1.335-.82 1.887-1.855.173-.324.33-.682.468-1.068H8.5zm3.68-1h2.146c.365-.767.594-1.61.656-2.5h-2.49a13.65 13.65 0 0 1-.312 2.5zm2.802-3.5a6.959 6.959 0 0 0-.656-2.5H12.18c.174.782.282 1.623.312 2.5h2.49zM11.27 2.461c.247.464.462.98.64 1.539h1.835a7.024 7.024 0 0 0-3.072-2.472c.218.284.418.598.597.933zM10.855 4a7.966 7.966 0 0 0-.468-1.068C9.835 1.897 9.17 1.282 8.5 1.077V4h2.355z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_LangSelector__WEBPACK_IMPORTED_MODULE_1__.LangSelector, {
      isOpen: isOpen
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LangButton);

/***/ }),

/***/ "./components/Nav/LangSelector.jsx":
/*!*****************************************!*\
  !*** ./components/Nav/LangSelector.jsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LangSelector": () => (/* binding */ LangSelector)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\LangSelector.jsx";



const StyledLayout = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    width: 240px;
    height: 360px;
    background-color: white;
    position: fixed;
    right: 70px;
    top: 94px;
    z-index: 5000;
    border-radius: 4px;
    display: ${props => props.isOpen ? "block" : "none"};
`;
const StyledCheckedIcon = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 20px;
    height: 20px;
    fill: #c4202b;
    position: absolute;
    right: 16px;
`;

const CheckedIcon = () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledCheckedIcon, {
  viewBox: "0 0 16 16",
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
    d: "M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 25,
    columnNumber: 9
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 24,
  columnNumber: 5
}, undefined);

const StyledTriangleUp = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 32px;
    height: 32px;
    position: absolute;
    top: -14px;
    left: 104px;
`;

const TriangleUp = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledTriangleUp, {
    viewBox: "0 0 16 16",
    fill: "#fff",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fillRule: "evenodd",
      d: "M7.022 1.566a1.13 1.13 0 0 1 1.96 0l6.857 11.667c.457.778-.092 1.767-.98 1.767H1.144c-.889 0-1.437-.99-.98-1.767L7.022 1.566z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 9
  }, undefined);
};

const LanguageSupport = ["ENGLISH (NA)", "ENGLISH (EUW)", "DEUTSCH", "ESPAÑOL (EUW)", "FRANÇAIS", "ITALIANO", "POLSKI", "РУССКИЙ", "TÜRKÇE", "ESPAÑOL (LATAM)", "INDONESIAN", "日本語", "한국어", "PORTUGUÊS", "ภาษาไทย", "Tiếng Việt", "繁體中文", "العربية"];
const StyleLangItem = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    font-family: 'Kanit', sans-serif;
    font-size: 13px;
    font-weight: 400;
    padding: 10px 24px;
    margin: 0;
    width: 100%;
    color: ${props => props.selected ? "#c4202b" : "#999"};
    transition: color .4s;
    cursor: ${props => props.selected ? "default" : "pointer"};
    &:hover {
        color: #111;
    }
    position: relative;
    display: flex;
    align-items: flex-end;
`;

const LangItem = ({
  children,
  selected
}) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyleLangItem, {
  selected: children === selected,
  children: [children, children === selected ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(CheckedIcon, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 87,
    columnNumber: 35
  }, undefined) : null]
}, void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 85,
  columnNumber: 5
}, undefined);

const Content = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    overflow: auto;
    height: 100%;
    width: 100%;
    margin: 0;
    padding: 10px 0;
`;
const LangSelector = ({
  isOpen
}) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLayout, {
    isOpen: isOpen,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Content, {
      children: LanguageSupport.map((e, i) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(LangItem, {
        selected: "\u0E20\u0E32\u0E29\u0E32\u0E44\u0E17\u0E22",
        children: e
      }, i, false, {
        fileName: _jsxFileName,
        lineNumber: 104,
        columnNumber: 21
      }, undefined))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 102,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TriangleUp, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 109,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 101,
    columnNumber: 9
  }, undefined)
}, void 0, false);

/***/ }),

/***/ "./components/Nav/NavBar.jsx":
/*!***********************************!*\
  !*** ./components/Nav/NavBar.jsx ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _NavLayout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavLayout */ "./components/Nav/NavLayout.jsx");
/* harmony import */ var _NavItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavItem */ "./components/Nav/NavItem/index.js");
/* harmony import */ var _NavDropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NavDropdown */ "./components/Nav/NavDropdown/index.js");
/* harmony import */ var _NavExternalLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavExternalLink */ "./components/Nav/NavExternalLink/index.js");
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var _NavSeparator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./NavSeparator */ "./components/Nav/NavSeparator.jsx");
/* harmony import */ var _LangButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./LangButton */ "./components/Nav/LangButton.jsx");
/* harmony import */ var _PlayButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./PlayButton */ "./components/Nav/PlayButton.jsx");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _RightNav__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./RightNav */ "./components/Nav/RightNav.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavBar.jsx";












const NavBar = () => {
  const {
    0: openRiotGameBar,
    1: setOpenRiotGameBar
  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
  const {
    0: openLangSelector,
    1: setOpenLangSelector
  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
  const {
    0: openPlayPopup,
    1: setOpenPlayPopup
  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);

  const handleRiotGameBarClick = e => {
    e.preventDefault();
    setOpenRiotGameBar(!openRiotGameBar);
    setOpenLangSelector(false);
  };

  const handleLangClick = e => {
    e.preventDefault();
    setOpenLangSelector(!openLangSelector);
    setOpenRiotGameBar(false);
  };

  const handlePlayPopupClick = e => {
    e.preventDefault();
    setOpenPlayPopup(!openPlayPopup);
    setOpenRiotGameBar(false);
    setOpenLangSelector(false);
  };

  const RiotGameBarStateControl = state => {
    setOpenRiotGameBar(state);
  };

  const PlayPopupStateControl = state => {
    setOpenPlayPopup(state);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavLayout__WEBPACK_IMPORTED_MODULE_0__.default, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_4__.RiotLogo, {
      isGameBarOpen: openRiotGameBar,
      onClick: handleRiotGameBarClick,
      stateControl: RiotGameBarStateControl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavSeparator__WEBPACK_IMPORTED_MODULE_5__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_4__.ValorantLogo, {
      href: "/"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
      title: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E01\u0E21",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/agents",
        title: "\u0E40\u0E2D\u0E40\u0E08\u0E19\u0E17\u0E4C"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/maps",
        title: "\u0E41\u0E1C\u0E19\u0E17\u0E35\u0E48"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/arsenal",
        title: "\u0E04\u0E25\u0E31\u0E07\u0E41\u0E2A\u0E07"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavItem__WEBPACK_IMPORTED_MODULE_1__.NavItem, {
      href: "/media",
      title: "\u0E2A\u0E37\u0E48\u0E2D"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 48,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavItem__WEBPACK_IMPORTED_MODULE_1__.NavItem, {
      href: "/news",
      title: "\u0E02\u0E48\u0E32\u0E27\u0E2A\u0E32\u0E23"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavItem__WEBPACK_IMPORTED_MODULE_1__.NavItem, {
      href: "/leaderboards",
      title: "\u0E01\u0E23\u0E30\u0E14\u0E32\u0E19\u0E1C\u0E39\u0E49\u0E19\u0E33"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
      title: "\u0E0B\u0E31\u0E1E\u0E1E\u0E2D\u0E23\u0E4C\u0E15",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/specs",
        title: "\u0E2A\u0E40\u0E1B\u0E04"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.ExternalLi, {
        title: "\u0E0B\u0E31\u0E1E\u0E1E\u0E2D\u0E23\u0E4C\u0E15"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/community-code",
        title: "\u0E01\u0E0F\u0E23\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E1A"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 51,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
      title: "\u0E42\u0E0B\u0E40\u0E0A\u0E35\u0E22\u0E25",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.ExternalLi, {
        title: "FACEBOOK"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.ExternalLi, {
        title: "YOUTUBE"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.ExternalLi, {
        title: "INSTAGRAM"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavExternalLink__WEBPACK_IMPORTED_MODULE_3__.External, {
      title: "\u0E2D\u0E35\u0E2A\u0E1B\u0E2D\u0E23\u0E4C\u0E15"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 61,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_RightNav__WEBPACK_IMPORTED_MODULE_9__.RightNav, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_LangButton__WEBPACK_IMPORTED_MODULE_6__.default, {
        isOpen: openLangSelector,
        onClick: handleLangClick
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_PlayButton__WEBPACK_IMPORTED_MODULE_7__.default, {
        isOpen: openPlayPopup,
        onClick: handlePlayPopupClick,
        stateControl: PlayPopupStateControl,
        children: "\u0E40\u0E25\u0E48\u0E19\u0E40\u0E25\u0E22"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavBar);

/***/ }),

/***/ "./components/Nav/NavDropdown/ExternalLi.jsx":
/*!***************************************************!*\
  !*** ./components/Nav/NavDropdown/ExternalLi.jsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavDropdown\\ExternalLi.jsx";



const ExternalLi = ({
  title
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_0__.StyledLi, {
    children: [title, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_0__.DropdownArrowUp, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExternalLi);

/***/ }),

/***/ "./components/Nav/NavDropdown/Li.jsx":
/*!*******************************************!*\
  !*** ./components/Nav/NavDropdown/Li.jsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavDropdown\\Li.jsx";




const Li = ({
  href,
  title
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
    href: href,
    passHref: true,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.StyledLi, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("a", {
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 8,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Li);

/***/ }),

/***/ "./components/Nav/NavDropdown/NavDropdown.jsx":
/*!****************************************************!*\
  !*** ./components/Nav/NavDropdown/NavDropdown.jsx ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var _Ul__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Ul */ "./components/Nav/NavDropdown/Ul.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavDropdown\\NavDropdown.jsx";




const Dropdown = ({
  title,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_0__.NavItemLayout, {
    children: [title, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_0__.CaretDown, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_Ul__WEBPACK_IMPORTED_MODULE_1__.Ul, {
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dropdown);

/***/ }),

/***/ "./components/Nav/NavDropdown/Ul.jsx":
/*!*******************************************!*\
  !*** ./components/Nav/NavDropdown/Ul.jsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ul": () => (/* binding */ Ul)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");


const Ul = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().ul)`
    list-style-type: none;
    min-width: 200px;
    background-color: #111;
    position: absolute;
    top: 80px;
    left: 0;
    margin: 0;
    padding: 0;
    display: none;
    ${_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.NavItemLayout}:hover & {
        display: block;
    }
`;

/***/ }),

/***/ "./components/Nav/NavDropdown/index.js":
/*!*********************************************!*\
  !*** ./components/Nav/NavDropdown/index.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Li": () => (/* reexport safe */ _Li__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "Dropdown": () => (/* reexport safe */ _NavDropdown__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "ExternalLi": () => (/* reexport safe */ _ExternalLi__WEBPACK_IMPORTED_MODULE_2__.default)
/* harmony export */ });
/* harmony import */ var _Li__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Li */ "./components/Nav/NavDropdown/Li.jsx");
/* harmony import */ var _NavDropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavDropdown */ "./components/Nav/NavDropdown/NavDropdown.jsx");
/* harmony import */ var _ExternalLi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ExternalLi */ "./components/Nav/NavDropdown/ExternalLi.jsx");




/***/ }),

/***/ "./components/Nav/NavExternalLink/NavExternalLink.jsx":
/*!************************************************************!*\
  !*** ./components/Nav/NavExternalLink/NavExternalLink.jsx ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavExternalLink\\NavExternalLink.jsx";




const ExternalLink = ({
  title,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.NavItemLayout, {
    children: [title, children, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.NavArrowUp, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExternalLink);

/***/ }),

/***/ "./components/Nav/NavExternalLink/index.js":
/*!*************************************************!*\
  !*** ./components/Nav/NavExternalLink/index.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "External": () => (/* reexport safe */ _NavExternalLink__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _NavExternalLink__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavExternalLink */ "./components/Nav/NavExternalLink/NavExternalLink.jsx");


/***/ }),

/***/ "./components/Nav/NavItem/NavItem.jsx":
/*!********************************************!*\
  !*** ./components/Nav/NavItem/NavItem.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavItem\\NavItem.jsx";




const NavItem = ({
  href,
  title,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
    href: href,
    passHref: true,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.StyledLink, {
      children: [title, children]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavItem);

/***/ }),

/***/ "./components/Nav/NavItem/index.js":
/*!*****************************************!*\
  !*** ./components/Nav/NavItem/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavItem": () => (/* reexport safe */ _NavItem__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _NavItem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavItem */ "./components/Nav/NavItem/NavItem.jsx");


/***/ }),

/***/ "./components/Nav/NavLayout.jsx":
/*!**************************************!*\
  !*** ./components/Nav/NavLayout.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavLayout.jsx";


const Nav = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().nav)`
    width: 100%;
    height: 80px;
    background-color: #111;
    display: flex;
    z-index: 4000;
    position: fixed;
    top: 0;
    padding-left: 26px;
    padding-right: 26px;
`;

const NavLayout = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("header", {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Nav, {
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavLayout);

/***/ }),

/***/ "./components/Nav/NavSeparator.jsx":
/*!*****************************************!*\
  !*** ./components/Nav/NavSeparator.jsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const NavSeparator = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    height: 30px;
    width: 2px;
    background-color: #7e7e7e;
    margin-top: 25px;
    margin-left: 12px;
    margin-right: 12px;
    opacity: .4;
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavSeparator);

/***/ }),

/***/ "./components/Nav/PlayButton.jsx":
/*!***************************************!*\
  !*** ./components/Nav/PlayButton.jsx ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _PlayPopup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PlayPopup */ "./components/Nav/PlayPopup.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\PlayButton.jsx";




const Button = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    background-color: rgb(255, 70, 85);
    margin-left: 4px;
    margin-right: 4px;
    height: 40px;
    width: 130px;
    border: none;
    border-radius: 2px;
    color: white;
    font-family: 'Bai Jamjuree', sans-serif;
    font-weight: 500;
    cursor: pointer;
    right: 26px;
`;

const PlayButton = ({
  children,
  onClick,
  isOpen,
  stateControl
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Button, {
      onClick: onClick,
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_PlayPopup__WEBPACK_IMPORTED_MODULE_1__.PlayPopup, {
      isOpen: isOpen,
      stateControl: stateControl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlayButton);

/***/ }),

/***/ "./components/Nav/PlayPopup.jsx":
/*!**************************************!*\
  !*** ./components/Nav/PlayPopup.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlayPopup": () => (/* binding */ PlayPopup)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Button */ "./components/Button/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\PlayPopup.jsx";




const PopupWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    width: 100vw;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    display: ${props => props.isOpen ? "flex" : "none"};
    justify-content: center;
    align-items: center;
`;
const DimmedBackground = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    width: 100%;
    height: 100%;
    background-color: #111;
    opacity: .7;
    position: absolute;
    z-index: 4000;
    top: 0;
`;
const Popup = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    width: 100px;
    height: 100px;
    border-top: 1px solid #968d8c;
    border-bottom: 1px solid #968d8c;
    background-color: #0f1923;
    z-index: 6000;
    height: 40vh;
    width: calc(2/3*100%);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    position: relative;
`;
const PopupTitleWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    height: 70%;
    width: 100%;
    font-family: 'Kanit', sans-serif;
    font-size: 32px;
    font-weight: 600;
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    column-gap: 24px;
`;
const PopupButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: center;
    column-gap: 40px;
`;
const ButtonLabel = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
    color: white;
    font-size: 14px;
    font-weight: 300;
`;
const ButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    display: flex;
    flex-direction: column;
    align-items: center;
`;
const ExitButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    width: 60px;
    height: 60px;
    border: solid white 1px;
    position: absolute;
    top: 15px;
    right: 15px;
    background: transparent;
    cursor: pointer;
`;

const ExitButton = ({
  onClick
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ExitButtonWrapper, {
    onClick: onClick,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ExitButtonStyle, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 88,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 87,
    columnNumber: 9
  }, undefined);
};

const SvgExit = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 48px;
    height: 48px;
    transition: scale .2s;
    ${ExitButtonWrapper}:hover & {
        scale: 1.15;
    }
`;

const ExitButtonStyle = () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(SvgExit, {
  viewBox: "0 0 72 72",
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
    fill: "none",
    stroke: "#ece8e1",
    d: "M61.5 9.5l-7 7m-38 38l-7 7M30.3 42l2.8-3m8.6 3L30.3 30m11.4 0l-2.6 2.8"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 104,
    columnNumber: 9
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 103,
  columnNumber: 5
}, undefined);

const PlayPopup = ({
  isOpen,
  stateControl
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(PopupWrapper, {
      isOpen: isOpen,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Popup, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(PopupTitleWrapper, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
            children: "\\"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 25
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
            children: "\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E15\u0E31\u0E27\u0E43\u0E2B\u0E49\u0E1E\u0E23\u0E49\u0E2D\u0E21"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 115,
            columnNumber: 25
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
            children: "\\"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 116,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 113,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(PopupButtonWrapper, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonWrapper, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonLabel, {
              children: "\u0E09\u0E31\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Riot"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 120,
              columnNumber: 29
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, {
              isWhite: true,
              isBordered: true,
              children: "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E17\u0E31\u0E19\u0E17\u0E35"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 121,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 119,
            columnNumber: 25
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonWrapper, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonLabel, {
              children: "\u0E09\u0E31\u0E19\u0E21\u0E35\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Riot \u0E41\u0E25\u0E49\u0E27"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 124,
              columnNumber: 29
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, {
              isBordered: true,
              children: "\u0E25\u0E07\u0E0A\u0E37\u0E48\u0E2D\u0E40\u0E02\u0E49\u0E32\u0E43\u0E0A\u0E49"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 125,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 123,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 118,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ExitButton, {
          onClick: () => stateControl(false)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 128,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(DimmedBackground, {
        onClick: () => stateControl(false)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 130,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 111,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

/***/ }),

/***/ "./components/Nav/RightNav.jsx":
/*!*************************************!*\
  !*** ./components/Nav/RightNav.jsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RightNav": () => (/* binding */ RightNav)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const RightNav = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    padding: 0;
    margin: 0 24px 0 0;
    position: fixed;
    right: 0;
    display: flex;
    align-items: center;
    height: 80px;
`;

/***/ }),

/***/ "./components/Nav/RiotGamesBar.jsx":
/*!*****************************************!*\
  !*** ./components/Nav/RiotGamesBar.jsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RiotGamesBar": () => (/* binding */ RiotGamesBar)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\RiotGamesBar.jsx";


const GamesBar = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    position: fixed;
    left: 0;
    height: 370px;
    width: 100%;
    background-color: white;
    z-index: 10000;
    opacity: 1;
    padding: 24px 40px;
`;
const DimmedBackground = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    z-index: 9000;
    background-color: #111;
    opacity: .7;
    position: fixed;
    left: 0;
    top: 0;
    margin-top: 80px;
    width: 100vw;
    height: 100vh;
`;
const GamesBarWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    position: fixed;
    left: 0;
    top: 0;
    margin-top: 80px;
    width: 100vw;
    height: 100vh;
    display: ${props => props.isOpen ? "block" : "none"};
`;
const StyledTriangleUp = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 32px;
    height: 32px;
    position: absolute;
    top: -14px;
    left: 38px;
`;
const TitleRiotGames = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
    font-family: 'Kanit', sans-serif;
    font-size: 24px;
    margin: 0;
    font-weight: 700;
`;

const TriangleUp = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledTriangleUp, {
    viewBox: "0 0 16 16",
    fill: "#fff",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fillRule: "evenodd",
      d: "M7.022 1.566a1.13 1.13 0 0 1 1.96 0l6.857 11.667c.457.778-.092 1.767-.98 1.767H1.144c-.889 0-1.437-.99-.98-1.767L7.022 1.566z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 9
  }, undefined);
};

const RiotGamesBar = ({
  isOpen,
  stateControl
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(GamesBarWrapper, {
    isOpen: isOpen,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TriangleUp, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(GamesBar, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TitleRiotGames, {
        children: "RIOT GAMES"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(DimmedBackground, {
      onClick: () => stateControl(false)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 61,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./components/Nav/index.js":
/*!*********************************!*\
  !*** ./components/Nav/index.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavBar": () => (/* reexport safe */ _NavBar__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _NavBar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavBar */ "./components/Nav/NavBar.jsx");


/***/ }),

/***/ "./components/TextBg.jsx":
/*!*******************************!*\
  !*** ./components/TextBg.jsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Txt": () => (/* binding */ Txt),
/* harmony export */   "TextBgContainer": () => (/* binding */ TextBgContainer)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_News_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/News.module.css */ "./styles/News.module.css");
/* harmony import */ var _styles_News_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_News_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\TextBg.jsx";




const TextBgContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "TextBg__TextBgContainer",
  componentId: "sc-1lib2cb-0"
})(["position:absolute;width:100vw;height:150vh;background:#0f1923;"]);
const Txt = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
  displayName: "TextBg__Txt",
  componentId: "sc-1lib2cb-1"
})(["font-family:DINNextLTW04-Medium;font-size:22.65vw;font-weight:400;Z-index:1;@media (max-width:800px){font-size:27.65vw;}"]);

const TextBG = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TextBgContainer, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h2", {
        className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_2___default().stroke),
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Txt, {
          className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_2___default().textBackground1),
          children: "WE ARE"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 17
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Txt, {
          className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_2___default().textBackground2),
          children: "VALORANT"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 17
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 13
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 9
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextBG);


/***/ }),

/***/ "./components/TextTitle.jsx":
/*!**********************************!*\
  !*** ./components/TextTitle.jsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\TextTitle.jsx";


const StyledTitle = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  font-size: 4.25rem;
  font-weight: bold;
  font-family: 'Kanit', sans-serif;
  color: ${props => props.color};
  margin: 0;
  width: 60%;
  line-height: 1.3;
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({
  textColor,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledTitle, {
    color: textColor,
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
});

/***/ }),

/***/ "./components/index.js":
/*!*****************************!*\
  !*** ./components/index.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Head": () => (/* reexport safe */ _Head__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "Title": () => (/* reexport safe */ _TextTitle__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "NavBar": () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_2__.NavBar),
/* harmony export */   "Footer": () => (/* reexport safe */ _Footer__WEBPACK_IMPORTED_MODULE_3__.Footer),
/* harmony export */   "Button": () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_4__.Button)
/* harmony export */ });
/* harmony import */ var _Head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Head */ "./components/Head.jsx");
/* harmony import */ var _TextTitle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TextTitle */ "./components/TextTitle.jsx");
/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Nav */ "./components/Nav/index.js");
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Footer */ "./components/Footer/index.js");
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Button */ "./components/Button/index.js");






/***/ }),

/***/ "./node_modules/next/dist/client/link.js":
/*!***********************************************!*\
  !*** ./node_modules/next/dist/client/link.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ../shared/lib/router/router */ "./node_modules/next/dist/shared/lib/router/router.js");

var _router1 = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router).isLocalURL(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (true) {
      // rethrow to show invalid URL errors
      throw err;
    }
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router).isLocalURL(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null && as.indexOf('#') >= 0) {
    scroll = false;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (true) {
    function createPropError(args) {
      return new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + ( false ? 0 : ''));
    } // TypeScript trick for type-guarding:


    const requiredPropsGuard = {
      href: true
    };
    const requiredProps = Object.keys(requiredPropsGuard);
    requiredProps.forEach(key => {
      if (key === 'href') {
        if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: props[key] === null ? 'null' : typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // TypeScript trick for type-guarding:

    const optionalPropsGuard = {
      as: true,
      replace: true,
      scroll: true,
      shallow: true,
      passHref: true,
      prefetch: true,
      locale: true
    };
    const optionalProps = Object.keys(optionalPropsGuard);
    optionalProps.forEach(key => {
      const valType = typeof props[key];

      if (key === 'as') {
        if (props[key] && valType !== 'string' && valType !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: valType
          });
        }
      } else if (key === 'locale') {
        if (props[key] && valType !== 'string') {
          throw createPropError({
            key,
            expected: '`string`',
            actual: valType
          });
        }
      } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'prefetch') {
        if (props[key] != null && valType !== 'boolean') {
          throw createPropError({
            key,
            expected: '`boolean`',
            actual: valType
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // This hook is in a conditional but that is ok because `process.env.NODE_ENV` never changes
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const hasWarned = _react.default.useRef(false);

    if (props.prefetch && !hasWarned.current) {
      hasWarned.current = true;
      console.warn('Next.js auto-prefetches automatically based on viewport. The prefetch attribute is no longer needed. More: https://nextjs.org/docs/messages/prefetch-true-deprecated');
    }
  }

  const p = props.prefetch !== false;
  const router = (0, _router1).useRouter();

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router).resolveHref(router, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router).resolveHref(router, props.as) : resolvedAs || resolvedHref
    };
  }, [router, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  let child;

  if (true) {
    try {
      child = _react.default.Children.only(children);
    } catch (err) {
      throw new Error(`Multiple children were passed to <Link> with \`href\` of \`${props.href}\` but only one child is supported https://nextjs.org/docs/messages/link-multiple-children` + ( false ? 0 : ''));
    }
  } else {}

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection).useIntersection({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  _react.default.useEffect(() => {
    const shouldPrefetch = isVisible && p && (0, _router).isLocalURL(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);

  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router).isLocalURL(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router).getDomainLocale(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router).addBasePath((0, _router).addLocale(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/client/normalize-trailing-slash.js":
/*!*******************************************************************!*\
  !*** ./node_modules/next/dist/client/normalize-trailing-slash.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}

const normalizePathTrailingSlash =  false ? 0 : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.requestIdleCallback = exports.cancelIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/route-loader.js":
/*!*******************************************************!*\
  !*** ./node_modules/next/dist/client/route-loader.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.createRouteLoader = createRouteLoader;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/router/utils/get-asset-path-from-route */ "../shared/lib/router/utils/get-asset-path-from-route"));

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
} // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (e) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR');

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // We wait for pages to be built in dev before we start the route transition
// timeout to prevent an un-necessary hard navigation in development.


let devBuildPromise; // Resolve a promise that times out after given amount of milliseconds.

function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject); // We wrap these checks separately for better dead-code elimination in
    // production bundles.

    if (true) {
      (devBuildPromise || Promise.resolve()).then(() => {
        (0, _requestIdleCallback).requestIdleCallback(() => setTimeout(() => {
          if (!cancelled) {
            reject(err);
          }
        }, ms));
      });
    }

    if (false) {}
  });
}

function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (true) {
    return Promise.resolve({
      scripts: [assetPrefix + '/_next/static/chunks/pages' + encodeURI((0, _getAssetPathFromRoute).default(route, '.js'))],
      // Styles are handled by `style-loader` in development:
      css: []
    });
  }

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route, prefetch) {
      return withFuture(route, routes, () => {
        const routeFilesPromise = getFilesForRoute(assetPrefix, route).then(({
          scripts,
          css
        }) => {
          return Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
        }).then(res => {
          return this.whenEntrypoint(route).then(entrypoint => ({
            entrypoint,
            styles: res[1]
          }));
        });

        if (true) {
          devBuildPromise = new Promise(resolve => {
            if (routeFilesPromise) {
              return routeFilesPromise.finally(() => {
                resolve();
              });
            }
          });
        }

        return resolvePromiseWithTimeout(routeFilesPromise, MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`))).then(({
          entrypoint,
          styles
        }) => {
          const res = Object.assign({
            styles: styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        }).catch(err => {
          if (prefetch) {
            // we don't want to cache errors during prefetch
            throw err;
          }

          return {
            error: err
          };
        });
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback).requestIdleCallback(() => this.loadRoute(route, true).catch(() => {}));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

/***/ }),

/***/ "./node_modules/next/dist/client/router.js":
/*!*************************************************!*\
  !*** ./node_modules/next/dist/client/router.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "Router", ({
  enumerable: true,
  get: function () {
    return _router.default;
  }
}));
Object.defineProperty(exports, "withRouter", ({
  enumerable: true,
  get: function () {
    return _withRouter.default;
  }
}));
exports.useRouter = useRouter;
exports.createRouter = createRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/router/router */ "./node_modules/next/dist/shared/lib/router/router.js"));

var _routerContext = __webpack_require__(/*! ../shared/lib/router-context */ "../shared/lib/router-context");

var _withRouter = _interopRequireDefault(__webpack_require__(/*! ./with-router */ "./node_modules/next/dist/client/with-router.js"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const singletonRouter = {
  router: null,
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain', 'domainLocales'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" on the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
}

var _default = singletonRouter;
exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
}

function createRouter(...args) {
  singletonRouter.router = new _router.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}

function makePublicRouterInstance(router) {
  const _router1 = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router1[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router1[property]) ? [] : {}, _router1[property]) // makes sure query is not stateful
      ;
      continue;
    }

    instance[property] = _router1[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router1[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react).useRef();
  const [visible, setVisible] = (0, _react).useState(false);
  const setRef = (0, _react).useCallback(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react).useEffect(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback).requestIdleCallback(() => setVisible(true));
        return () => (0, _requestIdleCallback).cancelIdleCallback(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/with-router.js":
/*!******************************************************!*\
  !*** ./node_modules/next/dist/client/with-router.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router).useRouter()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (true) {
    const name = ComposedComponent.displayName || ComposedComponent.name || 'Unknown';
    WithRouterWrapper.displayName = `withRouter(${name})`;
  }

  return WithRouterWrapper;
}

/***/ }),

/***/ "./node_modules/next/dist/shared/lib/router/router.js":
/*!************************************************************!*\
  !*** ./node_modules/next/dist/shared/lib/router/router.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../client/normalize-trailing-slash */ "./node_modules/next/dist/client/normalize-trailing-slash.js");

var _routeLoader = __webpack_require__(/*! ../../../client/route-loader */ "./node_modules/next/dist/client/route-loader.js");

var _denormalizePagePath = __webpack_require__(/*! ../../../server/denormalize-page-path */ "../../../server/denormalize-page-path");

var _normalizeLocalePath = __webpack_require__(/*! ../i18n/normalize-locale-path */ "../i18n/normalize-locale-path");

var _mitt = _interopRequireDefault(__webpack_require__(/*! ../mitt */ "../mitt"));

var _utils = __webpack_require__(/*! ../utils */ "../shared/lib/utils");

var _isDynamic = __webpack_require__(/*! ./utils/is-dynamic */ "./utils/is-dynamic");

var _parseRelativeUrl = __webpack_require__(/*! ./utils/parse-relative-url */ "./utils/parse-relative-url");

var _querystring = __webpack_require__(/*! ./utils/querystring */ "./utils/querystring");

var _resolveRewrites = _interopRequireDefault(__webpack_require__(/*! ./utils/resolve-rewrites */ "?5c99"));

var _routeMatcher = __webpack_require__(/*! ./utils/route-matcher */ "./utils/route-matcher");

var _routeRegex = __webpack_require__(/*! ./utils/route-regex */ "./utils/route-regex");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash).normalizePathTrailingSlash(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {} else {
    return false;
  }
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}

function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#') || url.startsWith('?')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils).getLocationOrigin();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex).getRouteRegex(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher).getRouteMatcher(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && (interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = '' // did not satisfy all requirements
    ; // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}

function resolveHref(router, href, resolveAs) {
  // we use a dummy base url for relative urls
  let base;
  let urlAsString = typeof href === 'string' ? href : (0, _utils).formatWithValidation(href); // repeated slashes and backslashes in the URL are considered
  // invalid and will never match a Next.js page/file

  const urlProtoMatch = urlAsString.match(/^[a-zA-Z]{1,}:\/\//);
  const urlAsStringNoProto = urlProtoMatch ? urlAsString.substr(urlProtoMatch[0].length) : urlAsString;
  const urlParts = urlAsStringNoProto.split('?');

  if ((urlParts[0] || '').match(/(\/\/|\\)/)) {
    console.error(`Invalid href passed to next/router: ${urlAsString}, repeated forward-slashes (//) or backslashes \\ are not valid in the href`);
    const normalizedUrl = (0, _utils).normalizeRepeatedSlashes(urlAsStringNoProto);
    urlAsString = (urlProtoMatch ? urlProtoMatch[0] : '') + normalizedUrl;
  } // Return because it cannot be routed by the Next.js router


  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    base = new URL(urlAsString.startsWith('#') ? router.asPath : router.pathname, 'http://n');
  } catch (_) {
    // fallback to / for invalid asPath values e.g. //
    base = new URL('/', 'http://n');
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash).normalizePathTrailingSlash(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic).isDynamicRoute(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring).searchParamsToUrlQuery(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils).formatWithValidation({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils).getLocationOrigin();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router, url, true);
  const origin = (0, _utils).getLocationOrigin();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash).removePathTrailingSlash((0, _denormalizePagePath).denormalizePagePath(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic).isDynamicRoute(page) && (0, _routeRegex).getRouteRegex(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname);
}

const manualScrollRestoration =  false && 0;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader).markAssetError(err);
    }

    throw err;
  });
}

class Router {
  constructor(pathname1, query1, as1, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component: Component1,
    err: err1,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    // Static Data Cache
    this.sdc = {}; // In-flight Server Data Requests, for deduping

    this.sdr = {};
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname: pathname1,
          query: query1
        } = this;
        this.changeState('replaceState', (0, _utils).formatWithValidation({
          pathname: addBasePath(pathname1),
          query: query1
        }), (0, _utils).getURL());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as: as1,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname: pathname1
      } = (0, _parseRelativeUrl).parseRelativeUrl(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as1 === this.asPath && pathname1 === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as1, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname1); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (pathname1 !== '/_error') {
      this.components[this.route] = {
        Component: Component1,
        initial: true,
        props: initialProps,
        err: err1,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: []
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = pathname1;
    this.query = query1; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic).isDynamicRoute(pathname1) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? pathname1 : as1;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || self.__NEXT_DATA__.appGip && !self.__NEXT_DATA__.gsp || !autoExportDynamic && !self.location.search && !false);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    }

    const shouldResolveHref = url === as || options._h || options._shouldResolveHref; // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated

    if (options._h) {
      this.isReady = true;
    }

    const prevLocale = this.locale;

    if (false) { var ref; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as;
    let localeChange = prevLocale !== this.locale; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs) && !localeChange) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl).parseRelativeUrl(url);
    let {
      pathname: pathname1,
      query: query1
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader).getClientBuildManifest());
    } catch (err1) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname1 = pathname1 ? (0, _normalizeTrailingSlash).removePathTrailingSlash(delBasePath(pathname1)) : pathname1;

    if (shouldResolveHref && pathname1 !== '/_error') {
      options._shouldResolveHref = true;

      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname1, pages);

        if (parsed.pathname !== pathname1) {
          pathname1 = parsed.pathname;
          parsed.pathname = addBasePath(pathname1);
          url = (0, _utils).formatWithValidation(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname1);

    if (!isLocalURL(as)) {
      if (true) {
        throw new Error(`Invalid href: "${url}" and as: "${as}", received relative href and external as` + `\nSee more info: https://nextjs.org/docs/messages/invalid-relative-url-external-as`);
      }

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic).isDynamicRoute(route)) {
      const parsedAs = (0, _parseRelativeUrl).parseRelativeUrl(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex).getRouteRegex(route);
      const routeMatch = (0, _routeMatcher).getRouteMatcher(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query1) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query1[param]);

        if (missingParams.length > 0) {
          if (true) {
            console.warn(`${shouldInterpolate ? `Interpolating href` : `Mismatching \`as\` and \`href\``} failed to manually provide ` + `the params: ${missingParams.join(', ')} in the \`href\`'s \`query\``);
          }

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils).formatWithValidation(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query1, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query1, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var ref, ref1;
      let routeInfo = await this.getRouteInfo(route, pathname1, query1, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl).parseRelativeUrl(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);
            const {
              url: newUrl,
              as: newAs
            } = prepareUrlAs(this, destination, destination);
            return this.change(method, newUrl, newAs, options);
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query1, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (true) {
        const appComp = this.components['/_app'].Component;
        window.next.isPrerendered = appComp.getInitialProps === appComp.origGetInitialProps && !routeInfo.Component.getInitialProps;
      }

      if (options._h && pathname1 === '/_error' && ((ref = self.__NEXT_DATA__.props) === null || ref === void 0 ? void 0 : (ref1 = ref.pageProps) === null || ref1 === void 0 ? void 0 : ref1.statusCode) === 500 && (props === null || props === void 0 ? void 0 : props.pageProps)) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      } // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;

      var _scroll;

      const shouldScroll = (_scroll = options.scroll) !== null && _scroll !== void 0 ? _scroll : !isValidShallowRoute;
      const resetScroll = shouldScroll ? {
        x: 0,
        y: 0
      } : null;
      await this.set(route, pathname1, query1, cleanedAs, routeInfo, forcedScroll !== null && forcedScroll !== void 0 ? forcedScroll : resetScroll).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err1) {
      if (err1.cancelled) {
        return false;
      }

      throw err1;
    }
  }

  changeState(method, url, as, options = {}) {
    if (true) {
      if (typeof window.history === 'undefined') {
        console.error(`Warning: window.history is not available.`);
        return;
      }

      if (typeof window.history[method] === 'undefined') {
        console.error(`Warning: window.history.${method} is not available`);
        return;
      }
    }

    if (method !== 'pushState' || (0, _utils).getURL() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader).isAssetError(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component1;
      let styleSheets;
      let props;

      if (typeof Component1 === 'undefined' || typeof styleSheets === 'undefined') {
        ({
          page: Component1,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component: Component1,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component1, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component: Component1,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (true) {
        const {
          isValidElementType
        } = __webpack_require__(/*! react-is */ "react-is");

        if (!isValidElementType(Component1)) {
          throw new Error(`The default export is not a React Component in page: "${pathname}"`);
        }
      }

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils).formatWithValidation({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component1, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as,
        locale: this.locale,
        locales: this.locales,
        defaultLocale: this.defaultLocale
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err2) {
      return this.handleRouteInfoError(err2, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl).parseRelativeUrl(url);
    let {
      pathname: pathname2
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname2) {
        pathname2 = parsed.pathname;
        parsed.pathname = pathname2;
        url = (0, _utils).formatWithValidation(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname2); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (true) {
      return;
    }

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err2 = new Error('Loading initial props cancelled');
        err2.cancelled = true;
        throw err2;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if (false) {}

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err2 => {
      delete this.sdr[resourceKey];
      throw err2;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App1
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App1);

    ctx.AppTree = AppTree;
    return (0, _utils).loadGetInitialProps(App1, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

Router.events = (0, _mitt).default();
exports.default = Router;

/***/ }),

/***/ "./pages/media/[category]/index.jsx":
/*!******************************************!*\
  !*** ./pages/media/[category]/index.jsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../components */ "./components/index.js");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_MediaComponent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../components/MediaComponent */ "./components/MediaComponent/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\pages\\media\\[category]\\index.jsx";







const Box = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().div)`
    padding-top: 10vh;
    position: relative;
    width: 100vw;
    display: block;
    background: antiquewhite;
    box-sizing: border-box;
`;
const Media_Css = styled_components__WEBPACK_IMPORTED_MODULE_1__.css`
    html,
    body {
        padding: 0;
        margin: 0;
        overflow-x: hidden;
        background-color: antiquewhite;
    }

    .condition {
        color: black;
        display: block;
        text-decoration: underline;
    }

    .condition:hover{
        color: white;
    }

    * {
    box-sizing: border-box;
    }
    
`;
const ImgCss = styled_components__WEBPACK_IMPORTED_MODULE_1__.css`

.imgGallery{
    float: left;
    margin: 10px;
}

.GalContainer{
    width: 90%;
    margin: auto;
    display: block;
    padding-top: 10vh;
}
.categoryContainer{
    display: block;
}
`;
const DontHave = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().h1)`
    font-size: 4rem;
    display: block;

`;

const MediaCategory = () => {
  let data = __webpack_require__(/*! ../../../public/media_content/contents.json */ "./public/media_content/contents.json");

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const {
    category
  } = router.query;
  const size = [["20vw", "20vw"], ["20vw", "30vw"], ["30vw", "30vw"]];

  if (router.asPath == "/media/wallpaper") {
    data = data.wallpaper;
  } else if (router.asPath == "/media/video") {
    data = data.video;
  } else if (router.asPath == "/media/screenshot") {
    data = data.screenshot;
  } else if (router.asPath == "/media/artwork") {
    data = data.artwork;
  } else if (router.asPath == "/media/logo") {
    data = data.logo;
  } else if (router.asPath == "/media/content_creator") {
    data = data.content_creator;
  } else {
    data = data.wallpaper.concat(data.video, data.screenshot, data.artwork, data.logo, data.content_creator);
  }

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components__WEBPACK_IMPORTED_MODULE_0__.Head, {
      title: "VALORANT: \u0E40\u0E01\u0E21\u0E22\u0E34\u0E07\u0E1B\u0E37\u0E19\u0E08\u0E32\u0E01 Riot Games \u0E43\u0E19\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A 5v5 \u0E17\u0E35\u0E48\u0E02\u0E31\u0E1A\u0E40\u0E04\u0E25\u0E37\u0E48\u0E2D\u0E19\u0E42\u0E14\u0E22\u0E15\u0E31\u0E27\u0E25\u0E30\u0E04\u0E23\u0E19\u0E31\u0E01\u0E22\u0E34\u0E07\u0E1B\u0E37\u0E19\u0E1C\u0E39\u0E49\u0E21\u0E32\u0E01\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 90,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components__WEBPACK_IMPORTED_MODULE_0__.NavBar, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("style", {
      children: Media_Css
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("style", {
      children: ImgCss
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 93,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_MediaComponent__WEBPACK_IMPORTED_MODULE_4__.MediaHead, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 94,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Box, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components_MediaComponent__WEBPACK_IMPORTED_MODULE_4__.CategoryBar, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 97,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
        className: "GalContainer",
        children: [data.map((image, index) => {
          let imgSize = size[Math.floor(Math.random() * 3)];
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("div", {
            className: "imgGallery",
            style: {
              background: `url(${image.path})`,
              width: `${imgSize[0]}`,
              height: `${imgSize[1]}`
            }
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 102,
            columnNumber: 37
          }, undefined);
        }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(DontHave, {
          style: {
            display: `${data.length == 0 ? "block" : "none"}`
          },
          children: "\u0E01\u0E25\u0E31\u0E1A\u0E21\u0E32\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E43\u0E2B\u0E21\u0E48\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E43\u0E19\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07!"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 98,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_components__WEBPACK_IMPORTED_MODULE_0__.Footer, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 109,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MediaCategory);

/***/ }),

/***/ "./styles/nav_components/CaretDown.jsx":
/*!*********************************************!*\
  !*** ./styles/nav_components/CaretDown.jsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavItemLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavItemLayout */ "./styles/nav_components/NavItemLayout.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\CaretDown.jsx";



const StyledCaretDown = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-left: 4px;
    padding-top: 6px;
    fill: #7E7E7E;
    ${_NavItemLayout__WEBPACK_IMPORTED_MODULE_1__.NavItemLayout}:hover & {
        fill: white;
    }
`;

const CaretDown = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledCaretDown, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
      d: "M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CaretDown);

/***/ }),

/***/ "./styles/nav_components/DropdownArrowUp.jsx":
/*!***************************************************!*\
  !*** ./styles/nav_components/DropdownArrowUp.jsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _StyledLi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StyledLi */ "./styles/nav_components/StyledLi.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\DropdownArrowUp.jsx";



const StyledArrowUp = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-left: 2px;
    padding-top: 6px;
    fill: #7E7E7E;
    ${_StyledLi__WEBPACK_IMPORTED_MODULE_1__.StyledLi}:hover & {
        fill: white;
    }
`;

const DropdownArrowUp = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledArrowUp, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
      fillRule: "evenodd",
      d: "M14 2.5a.5.5 0 0 0-.5-.5h-6a.5.5 0 0 0 0 1h4.793L2.146 13.146a.5.5 0 0 0 .708.708L13 3.707V8.5a.5.5 0 0 0 1 0v-6z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DropdownArrowUp);

/***/ }),

/***/ "./styles/nav_components/NavArrowUp.jsx":
/*!**********************************************!*\
  !*** ./styles/nav_components/NavArrowUp.jsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavItemLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavItemLayout */ "./styles/nav_components/NavItemLayout.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\NavArrowUp.jsx";



const StyledArrowUp = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-left: 2px;
    padding-top: 6px;
    fill: #7E7E7E;
    ${_NavItemLayout__WEBPACK_IMPORTED_MODULE_1__.NavItemLayout}:hover & {
        fill: white;
    }
`;

const NavArrowUp = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledArrowUp, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
      fillRule: "evenodd",
      d: "M14 2.5a.5.5 0 0 0-.5-.5h-6a.5.5 0 0 0 0 1h4.793L2.146 13.146a.5.5 0 0 0 .708.708L13 3.707V8.5a.5.5 0 0 0 1 0v-6z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavArrowUp);

/***/ }),

/***/ "./styles/nav_components/NavItemLayout.jsx":
/*!*************************************************!*\
  !*** ./styles/nav_components/NavItemLayout.jsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavItemLayout": () => (/* binding */ NavItemLayout)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const NavItemLayout = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    font-family: 'Bai Jamjuree', sans-serif;
    padding-left: 1em;
    padding-right: 1em;
    color: white;
    line-height: 80px;
    font-size: 14px;
    font-weight: 500;
    margin-left: 4px;
    margin-right: 4px;
    cursor: pointer;
    position: relative;
    &:hover {
        border-bottom: 2px rgb(255, 70, 85) solid;
    }
`;

/***/ }),

/***/ "./styles/nav_components/RiotLogo.jsx":
/*!********************************************!*\
  !*** ./styles/nav_components/RiotLogo.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Nav_RiotGamesBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/Nav/RiotGamesBar */ "./components/Nav/RiotGamesBar.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\RiotLogo.jsx";




const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 24px;
    height: 24px;
`;
const RiotLogoWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    cursor: pointer;
    margin: 0 12px;
    padding: 0;
    background: none;
    border: none;
`;
const StyledCaretDown = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-left: 8px;
    margin-bottom: 4px;
    padding-top: 6px;
    fill: #7E7E7E;
    ${RiotLogoWrapper}:hover & {
        fill: white;
    }
`;

const CaretDown = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledCaretDown, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
      d: "M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 9
  }, undefined);
};

const RiotLogo = ({
  isGameBarOpen,
  onClick,
  stateControl
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(RiotLogoWrapper, {
      onClick: onClick,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledLogo, {
        viewBox: "0 0 24 24",
        fill: "#fff",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
          d: "M12.534 21.77l-1.09-2.81 10.52.54-.451 4.5zM15.06 0L.307 6.969 2.59 17.471H5.6l-.52-7.512.461-.144 1.81 7.656h3.126l-.116-9.15.462-.144 1.582 9.294h3.31l.78-11.053.462-.144.82 11.197h4.376l1.54-15.37Z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(CaretDown, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_components_Nav_RiotGamesBar__WEBPACK_IMPORTED_MODULE_1__.RiotGamesBar, {
      isOpen: isGameBarOpen,
      stateControl: stateControl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RiotLogo);

/***/ }),

/***/ "./styles/nav_components/StyledLi.jsx":
/*!********************************************!*\
  !*** ./styles/nav_components/StyledLi.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StyledLi": () => (/* binding */ StyledLi)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const StyledLi = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().li)`
    line-height: 50px;
    padding-left: 24px;
    &:hover {
        background-color: #333;
    }
`;

/***/ }),

/***/ "./styles/nav_components/StyledLink.jsx":
/*!**********************************************!*\
  !*** ./styles/nav_components/StyledLink.jsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StyledLink": () => (/* binding */ StyledLink)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const StyledLink = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().a)`
    font-family: 'Bai Jamjuree', sans-serif;
    padding-left: 12px;
    padding-right: 12px;
    color: white;
    line-height: 80px;
    font-size: 14px;
    font-weight: 500;
    margin: 0 .85em;
    &:hover {
        border-bottom: 2px rgb(255, 70, 85) solid;
    }
`;

/***/ }),

/***/ "./styles/nav_components/ValorantLogo.jsx":
/*!************************************************!*\
  !*** ./styles/nav_components/ValorantLogo.jsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\ValorantLogo.jsx";



const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().svg)`
    width: 35px;
    height: 35px;
    margin-top: 22.5px;
    margin-left: 4px;
    margin-right: 4px;
`;

const ValorantLogo = ({
  href
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
    href: href,
    passHref: true,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("a", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledLogo, {
        viewBox: "0 0 100 100",
        fill: "#fff",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
          d: "M99.25 48.66V10.28c0-.59-.75-.86-1.12-.39l-41.92 52.4a.627.627 0 00.49 1.02h30.29c.82 0 1.59-.37 2.1-1.01l9.57-11.96c.38-.48.59-1.07.59-1.68zM1.17 50.34L32.66 89.7c.51.64 1.28 1.01 2.1 1.01h30.29c.53 0 .82-.61.49-1.02L1.7 9.89c-.37-.46-1.12-.2-1.12.39v38.38c0 .61.21 1.2.59 1.68z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ValorantLogo);

/***/ }),

/***/ "./styles/nav_components/index.js":
/*!****************************************!*\
  !*** ./styles/nav_components/index.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavItemLayout": () => (/* reexport safe */ _NavItemLayout__WEBPACK_IMPORTED_MODULE_0__.NavItemLayout),
/* harmony export */   "NavArrowUp": () => (/* reexport safe */ _NavArrowUp__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "DropdownArrowUp": () => (/* reexport safe */ _DropdownArrowUp__WEBPACK_IMPORTED_MODULE_2__.default),
/* harmony export */   "CaretDown": () => (/* reexport safe */ _CaretDown__WEBPACK_IMPORTED_MODULE_3__.default),
/* harmony export */   "StyledLink": () => (/* reexport safe */ _StyledLink__WEBPACK_IMPORTED_MODULE_4__.StyledLink),
/* harmony export */   "StyledLi": () => (/* reexport safe */ _StyledLi__WEBPACK_IMPORTED_MODULE_5__.StyledLi),
/* harmony export */   "ValorantLogo": () => (/* reexport safe */ _ValorantLogo__WEBPACK_IMPORTED_MODULE_6__.default),
/* harmony export */   "RiotLogo": () => (/* reexport safe */ _RiotLogo__WEBPACK_IMPORTED_MODULE_7__.default)
/* harmony export */ });
/* harmony import */ var _NavItemLayout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavItemLayout */ "./styles/nav_components/NavItemLayout.jsx");
/* harmony import */ var _NavArrowUp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavArrowUp */ "./styles/nav_components/NavArrowUp.jsx");
/* harmony import */ var _DropdownArrowUp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DropdownArrowUp */ "./styles/nav_components/DropdownArrowUp.jsx");
/* harmony import */ var _CaretDown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CaretDown */ "./styles/nav_components/CaretDown.jsx");
/* harmony import */ var _StyledLink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./StyledLink */ "./styles/nav_components/StyledLink.jsx");
/* harmony import */ var _StyledLi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./StyledLi */ "./styles/nav_components/StyledLi.jsx");
/* harmony import */ var _ValorantLogo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ValorantLogo */ "./styles/nav_components/ValorantLogo.jsx");
/* harmony import */ var _RiotLogo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./RiotLogo */ "./styles/nav_components/RiotLogo.jsx");









/***/ }),

/***/ "./styles/News.module.css":
/*!********************************!*\
  !*** ./styles/News.module.css ***!
  \********************************/
/***/ ((module) => {

// Exports
module.exports = {
	"stroke": "News_stroke__1GeBo",
	"sliderNav": "News_sliderNav__2BHf6",
	"textBackground1": "News_textBackground1__jpuvz",
	"textBackground2": "News_textBackground2__jV5qA"
};


/***/ }),

/***/ "./styles/media.module.css":
/*!*********************************!*\
  !*** ./styles/media.module.css ***!
  \*********************************/
/***/ ((module) => {

// Exports
module.exports = {
	"stroke": "media_stroke__nCo27"
};


/***/ }),

/***/ "./node_modules/next/link.js":
/*!***********************************!*\
  !*** ./node_modules/next/link.js ***!
  \***********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(/*! ./dist/client/link */ "./node_modules/next/dist/client/link.js")


/***/ }),

/***/ "../../../server/denormalize-page-path":
/*!************************************************************!*\
  !*** external "next/dist/server/denormalize-page-path.js" ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ "../i18n/normalize-locale-path":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/i18n/normalize-locale-path.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ "../mitt":
/*!***********************************************!*\
  !*** external "next/dist/shared/lib/mitt.js" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ "../shared/lib/router-context":
/*!*********************************************************!*\
  !*** external "next/dist/shared/lib/router-context.js" ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ "../shared/lib/router/utils/get-asset-path-from-route":
/*!*********************************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/get-asset-path-from-route.js" ***!
  \*********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ "./utils/is-dynamic":
/*!******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/is-dynamic.js" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ "./utils/parse-relative-url":
/*!**************************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/parse-relative-url.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ "./utils/querystring":
/*!*******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/querystring.js" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ "./utils/route-matcher":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/route-matcher.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ "./utils/route-regex":
/*!*******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/route-regex.js" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ "../shared/lib/utils":
/*!************************************************!*\
  !*** external "next/dist/shared/lib/utils.js" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-is");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ }),

/***/ "?5c99":
/*!******************************************!*\
  !*** ./utils/resolve-rewrites (ignored) ***!
  \******************************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "./public/media_content/contents.json":
/*!********************************************!*\
  !*** ./public/media_content/contents.json ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"wallpaper":[{"path":"../../media_content/pic/wallpaper/W_01.jpeg","type":"arsenals"},{"path":"../../media_content/pic/wallpaper/W_02.jpeg","type":"maps"},{"path":"../../media_content/pic/wallpaper/W_03.jpeg","type":"agents"},{"path":"../../media_content/pic/wallpaper/W_04.jpeg","type":"arsenals"}],"video":[],"screenshot":[],"artwork":[{"path":"../../media_content/pic/artwork/A_01.jpeg","type":"agents"},{"path":"../../media_content/pic/artwork/A_02.jpeg","type":"arsenals"},{"path":"../../media_content/pic/artwork/A_03.jpeg","type":"agents"},{"path":"../../media_content/pic/artwork/A_04.jpeg","type":"agents"}],"logo":[{"path":"../../media_content/pic/logo/L_01.jpeg","type":"NO RELATE"}],"content_creator":[{"path":"../../media_content/pic/content_creator/C_01.jpeg","type":"NO RELATE"}]}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/media/[category]/index.jsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvbWVkaWEvW2NhdGVnb3J5XS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7O0FBRUEsTUFBTUMsbUJBQW1CLEdBQUdELGlFQUFjO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVRBO0FBV0EsTUFBTUcsT0FBTyxHQUFHSCw4REFBVztBQUMzQix3QkFBd0JLLEtBQUssSUFBSUEsS0FBSyxDQUFDQyxPQUFOLEdBQWdCLFNBQWhCLEdBQTRCLFNBQVU7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhRCxLQUFLLElBQUlBLEtBQUssQ0FBQ0MsT0FBTixHQUFnQixTQUFoQixHQUE0QixPQUFRO0FBQzFEO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQkQsS0FBSyxJQUFJQSxLQUFLLENBQUNFLFVBQU4sR0FBb0IsU0FBUUYsS0FBSyxDQUFDQyxPQUFOLEdBQWdCLFdBQWhCLEdBQThCLFdBQVksTUFBdEUsR0FBOEUsTUFBTztBQUNqSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQWpCQTtBQW1CQSxNQUFNRSxRQUFRLEdBQUdSLDhEQUFXO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUcsT0FBUTtBQUNkO0FBQ0E7QUFDQSxDQVhBO0FBYUEsTUFBTU0sWUFBWSxHQUFHVCw4REFBVztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVBBO0FBU0EsTUFBTVUsU0FBUyxHQUFHVix3REFBTSxDQUFDUyxZQUFELENBQWU7QUFDdkM7QUFDQTtBQUNBLENBSEE7QUFLQSxNQUFNRSxZQUFZLEdBQUdYLHdEQUFNLENBQUNTLFlBQUQsQ0FBZTtBQUMxQztBQUNBO0FBQ0EsQ0FIQTs7QUFLQSxNQUFNRyxNQUFNLEdBQUcsQ0FBQztBQUFFQyxFQUFBQSxRQUFGO0FBQVlQLEVBQUFBLE9BQVo7QUFBcUJDLEVBQUFBO0FBQXJCLENBQUQsa0JBQ1gsOERBQUMsbUJBQUQ7QUFBQSwwQkFDSSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESixlQUVJLDhEQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUZKLGVBR0ksOERBQUMsT0FBRDtBQUFTLFdBQU8sRUFBRUQsT0FBbEI7QUFBMkIsY0FBVSxFQUFFQyxVQUF2QztBQUFBLGVBQ0tNLFFBREwsZUFFSSw4REFBQyxRQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREo7O0FBV0EsaUVBQWVELE1BQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNFQTs7QUFFQSxNQUFNRSxVQUFVLEdBQUdkLDhEQUFXO0FBQzlCO0FBQ0E7QUFDQTtBQUNBLENBSkE7O0FBTUEsTUFBTWdCLFFBQVEsR0FBRyxNQUFNO0FBQ25CLHNCQUNJLDhEQUFDLFVBQUQ7QUFBWSxXQUFPLEVBQUMsV0FBcEI7QUFBZ0MsUUFBSSxFQUFDLFNBQXJDO0FBQUEsMkJBQ0k7QUFBTSxPQUFDLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxpRUFBZUEsUUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTU8sQ0FBQyxHQUFHdkIsNERBQVM7QUFDbkI7QUFDQTtBQUNBLENBSEE7QUFLQSxNQUFNeUIsUUFBUSxHQUFHekIsd0RBQU0sQ0FBQ3VCLENBQUQsQ0FBSTtBQUMzQjtBQUNBO0FBQ0E7QUFDQSxDQUpBO0FBTUEsTUFBTUcsV0FBVyxHQUFHMUIsOERBQVc7QUFDL0I7QUFDQTtBQUNBLENBSEE7QUFLQSxNQUFNMkIsU0FBUyxHQUFHM0Isd0RBQU0sQ0FBQ3VCLENBQUQsQ0FBSTtBQUM1QjtBQUNBO0FBQ0EsQ0FIQTtBQUtBLE1BQU1LLFdBQVcsR0FBRzVCLDhEQUFXO0FBQy9CO0FBQ0E7QUFDQSxDQUhBO0FBS0EsTUFBTTZCLGFBQWEsR0FBRzdCLDhEQUFXO0FBQ2pDO0FBQ0E7QUFDQSxDQUhBOztBQUtBLE1BQU04QixNQUFNLEdBQUcsTUFBTTtBQUNqQixzQkFDSSw4REFBQyx1REFBRDtBQUFBLDRCQUNJLDhEQUFDLCtDQUFEO0FBQUEsNkJBQ0ksOERBQUMsQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFJSSw4REFBQyxXQUFEO0FBQUEsOEJBQ0ksOERBQUMsOENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUVJLDhEQUFDLG1EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpKLGVBUUksOERBQUMsYUFBRDtBQUFBLDhCQUNJLDhEQUFDLCtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFFSSw4REFBQyw4Q0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZKLGVBR0ksOERBQUMsZ0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUkosZUFhSSw4REFBQyxRQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWJKLGVBY0ksOERBQUMsV0FBRDtBQUFBLDhCQUNJLDhEQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFFSSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZKLGVBR0ksOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFzQkgsQ0F2QkQ7O0FBeUJBLGlFQUFlQSxNQUFmOzs7Ozs7Ozs7Ozs7Ozs7OztBQy9EQTtBQUVPLE1BQU1iLFlBQVksR0FBR2pCLGlFQUFjO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVpPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQOztBQUVBLE1BQU1jLFVBQVUsR0FBR2QsOERBQVc7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVJBOztBQVVBLE1BQU1vQixZQUFZLEdBQUcsTUFBTTtBQUN2QixzQkFDSSw4REFBQyxVQUFEO0FBQVksV0FBTyxFQUFDLFdBQXBCO0FBQUEsMkJBQ0k7QUFBTSxPQUFDLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxpRUFBZUEsWUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQkE7O0FBRUEsTUFBTU4sVUFBVSxHQUFHZCw4REFBVztBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBUkE7O0FBVUEsTUFBTXFCLGFBQWEsR0FBRyxNQUFNO0FBQ3hCLHNCQUNJLDhEQUFDLFVBQUQ7QUFBWSxXQUFPLEVBQUMsV0FBcEI7QUFBQSwyQkFDSTtBQUFNLGNBQVEsRUFBQyxTQUFmO0FBQXlCLGNBQVEsRUFBQyxTQUFsQztBQUE0QyxPQUFDLEVBQUM7QUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsaUVBQWVBLGFBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEJBOztBQUVBLE1BQU1QLFVBQVUsR0FBR2QsOERBQVc7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVJBOztBQVVBLE1BQU1zQixXQUFXLEdBQUcsTUFBTTtBQUN0QixzQkFDSSw4REFBQyxVQUFEO0FBQVksV0FBTyxFQUFDLFdBQXBCO0FBQUEsMkJBQ0k7QUFBTSxjQUFRLEVBQUMsU0FBZjtBQUF5QixjQUFRLEVBQUMsU0FBbEM7QUFBNEMsT0FBQyxFQUFDO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFLSCxDQU5EOztBQVFBLGlFQUFlQSxXQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BCQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTs7QUFFQSxNQUFNVyxPQUFPLEdBQUdqQyw0REFBUztBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVBBOztBQVNBLE1BQU1tQixhQUFhLEdBQUcsQ0FBQztBQUFFTixFQUFBQTtBQUFGLENBQUQsS0FBa0I7QUFDcEMsc0JBQ0ksOERBQUMsT0FBRDtBQUFBLGNBQ0tBO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxpRUFBZU0sYUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQkE7O0FBRUEsTUFBTUwsVUFBVSxHQUFHZCw4REFBVztBQUM5QjtBQUNBO0FBQ0EsQ0FIQTs7QUFLQSxNQUFNa0IsYUFBYSxHQUFHLENBQUM7QUFBRWlCLEVBQUFBO0FBQUYsQ0FBRCxLQUFjO0FBQ2hDLHNCQUNJLDhEQUFDLFVBQUQ7QUFBWSxXQUFPLEVBQUMsZ0JBQXBCO0FBQXFDLFFBQUksRUFBQyxTQUExQztBQUFBLDRCQUNJO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQUVJO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGSixlQUdJO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFISixlQUlJO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKSixlQUtJO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMSixlQU1JO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFOSixlQU9JO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQVdILENBWkQ7O0FBY0EsaUVBQWVqQixhQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyQkE7OztBQUVBLE1BQU1tQixJQUFJLEdBQUcsQ0FBQztBQUFFQyxFQUFBQTtBQUFGLENBQUQsS0FBZTtBQUN4QixzQkFDSSw4REFBQyxrREFBRDtBQUFBLDRCQUNJO0FBQU0sYUFBTyxFQUFDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQUVJO0FBQU0sZUFBUyxFQUFDLGlCQUFoQjtBQUFrQyxhQUFPLEVBQUM7QUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGSixlQUdJO0FBQU0sVUFBSSxFQUFDLFVBQVg7QUFBc0IsYUFBTyxFQUFDO0FBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEosZUFJSTtBQUFNLFNBQUcsRUFBQyxlQUFWO0FBQTBCLFVBQUksRUFBQyxhQUEvQjtBQUE2QyxVQUFJLEVBQUM7QUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKSixlQUtJO0FBQUEsZ0JBQVFBO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQVNILENBVkQ7O0FBWUEsaUVBQWVELElBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNkQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTUssR0FBRyxHQUFHMUMsNkRBQVU7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUxBO0FBTUEsTUFBTTRDLFFBQVEsR0FBRzVDLDZEQUFVO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FMQTs7QUFNQSxNQUFNOEMsV0FBVyxHQUFHLE1BQU07QUFDdEIsUUFBTUMsTUFBTSxHQUFHTixzREFBUyxFQUF4QjtBQUNBLFFBQU07QUFBRU8sSUFBQUE7QUFBRixNQUFlRCxNQUFNLENBQUNFLEtBQTVCO0FBRUEsc0JBQ0E7QUFBQSwyQkFDSSw4REFBQyxHQUFEO0FBQUEsOEJBQ0ksOERBQUMsUUFBRDtBQUFVLGFBQUssRUFBRTtBQUFFQyxVQUFBQSxLQUFLLEVBQUcsR0FBR0YsUUFBUSxJQUFJLEtBQVosR0FBa0IsT0FBbEIsR0FBMkIsU0FBVSxFQUFsRDtBQUFxREcsVUFBQUEsWUFBWSxFQUFHLEdBQUdILFFBQVEsSUFBSSxLQUFaLEdBQWtCLGlCQUFsQixHQUFxQyxNQUFPO0FBQW5ILFNBQWpCO0FBQUEsK0JBQTBJLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLFlBQVg7QUFBd0IsZ0JBQU0sRUFBRSxLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUksOERBQUMsUUFBRDtBQUFVLGFBQUssRUFBRTtBQUFFRSxVQUFBQSxLQUFLLEVBQUcsR0FBR0YsUUFBUSxJQUFJLFdBQVosR0FBd0IsT0FBeEIsR0FBaUMsU0FBVSxFQUF4RDtBQUEyREcsVUFBQUEsWUFBWSxFQUFHLEdBQUdILFFBQVEsSUFBSSxXQUFaLEdBQXdCLGlCQUF4QixHQUEyQyxNQUFPO0FBQS9ILFNBQWpCO0FBQUEsK0JBQXNKLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLGtCQUFYO0FBQThCLGdCQUFNLEVBQUUsS0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQUdJLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUU7QUFBRUUsVUFBQUEsS0FBSyxFQUFHLEdBQUdGLFFBQVEsSUFBSSxPQUFaLEdBQW9CLE9BQXBCLEdBQTZCLFNBQVUsRUFBcEQ7QUFBdURHLFVBQUFBLFlBQVksRUFBRyxHQUFHSCxRQUFRLElBQUksT0FBWixHQUFvQixpQkFBcEIsR0FBdUMsTUFBTztBQUF2SCxTQUFqQjtBQUFBLCtCQUE4SSw4REFBQyxrREFBRDtBQUFNLGNBQUksRUFBQyxjQUFYO0FBQTBCLGdCQUFNLEVBQUUsS0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFISixlQUlJLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUU7QUFBRUUsVUFBQUEsS0FBSyxFQUFHLEdBQUdGLFFBQVEsSUFBSSxZQUFaLEdBQXlCLE9BQXpCLEdBQWtDLFNBQVUsRUFBekQ7QUFBNERHLFVBQUFBLFlBQVksRUFBRyxHQUFHSCxRQUFRLElBQUksWUFBWixHQUF5QixpQkFBekIsR0FBNEMsTUFBTztBQUFqSSxTQUFqQjtBQUFBLCtCQUF3Siw4REFBQyxrREFBRDtBQUFNLGNBQUksRUFBQyxtQkFBWDtBQUErQixnQkFBTSxFQUFFLEtBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkosZUFLSSw4REFBQyxRQUFEO0FBQVUsYUFBSyxFQUFFO0FBQUVFLFVBQUFBLEtBQUssRUFBRyxHQUFHRixRQUFRLElBQUksU0FBWixHQUFzQixPQUF0QixHQUErQixTQUFVLEVBQXREO0FBQXlERyxVQUFBQSxZQUFZLEVBQUcsR0FBR0gsUUFBUSxJQUFJLFNBQVosR0FBc0IsaUJBQXRCLEdBQXlDLE1BQU87QUFBM0gsU0FBakI7QUFBQSwrQkFBa0osOERBQUMsa0RBQUQ7QUFBTSxjQUFJLEVBQUMsZ0JBQVg7QUFBNEIsZ0JBQU0sRUFBRSxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxKLGVBTUksOERBQUMsUUFBRDtBQUFVLGFBQUssRUFBRTtBQUFFRSxVQUFBQSxLQUFLLEVBQUcsR0FBR0YsUUFBUSxJQUFJLE1BQVosR0FBbUIsT0FBbkIsR0FBNEIsU0FBVSxFQUFuRDtBQUFzREcsVUFBQUEsWUFBWSxFQUFHLEdBQUdILFFBQVEsSUFBSSxNQUFaLEdBQW1CLGlCQUFuQixHQUFzQyxNQUFPO0FBQXJILFNBQWpCO0FBQUEsK0JBQTRJLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLGFBQVg7QUFBeUIsZ0JBQU0sRUFBRSxLQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUE1STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5KLGVBT0ksOERBQUMsUUFBRDtBQUFVLGFBQUssRUFBRTtBQUFFRSxVQUFBQSxLQUFLLEVBQUcsR0FBR0YsUUFBUSxJQUFJLGlCQUFaLEdBQThCLE9BQTlCLEdBQXVDLFNBQVUsRUFBOUQ7QUFBaUVHLFVBQUFBLFlBQVksRUFBRyxHQUFHSCxRQUFRLElBQUksaUJBQVosR0FBOEIsaUJBQTlCLEdBQWlELE1BQU87QUFBM0ksU0FBakI7QUFBQSwrQkFBa0ssOERBQUMsa0RBQUQ7QUFBTSxjQUFJLEVBQUMsd0JBQVg7QUFBb0MsZ0JBQU0sRUFBRSxLQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFsSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBKLGVBUUksOERBQUMsNENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFEQTtBQWNILENBbEJEOztBQW9CQSxpRUFBZUYsV0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsTUFBTVEsSUFBSSxHQUFHdEQsdUVBQUg7QUFBQTtBQUFBO0FBQUEsdUdBQVY7QUFVQSxNQUFNdUQsR0FBRyxHQUFHdkQsdUVBQUg7QUFBQTtBQUFBO0FBQUEsMEhBQVQ7O0FBWUEsTUFBTXdDLGFBQWEsR0FBRyxNQUFNO0FBQ3hCLFFBQU1PLE1BQU0sR0FBR04sc0RBQVMsRUFBeEI7QUFDQSxNQUFJO0FBQUVPLElBQUFBLFFBQUY7QUFBWVEsSUFBQUE7QUFBWixNQUFxQlQsTUFBTSxDQUFDRSxLQUFoQzs7QUFDQSxNQUFHLE9BQU9PLElBQVAsS0FBZ0IsV0FBbkIsRUFBK0I7QUFDM0JBLElBQUFBLElBQUksR0FBSSxLQUFSO0FBQ0g7O0FBQ0QsUUFBTUMsY0FBYyxHQUFJQyxDQUFELElBQU87QUFDMUIsUUFBSUMsTUFBTSxHQUFHRCxDQUFDLENBQUNFLE1BQUYsQ0FBU0MsS0FBdEI7O0FBQ0EsUUFBRyxPQUFPYixRQUFQLEtBQW9CLFdBQXZCLEVBQW1DO0FBQy9CQSxNQUFBQSxRQUFRLEdBQUksS0FBWjtBQUNBVyxNQUFBQSxNQUFNLEdBQUksU0FBU1gsUUFBVSxJQUFJVyxNQUFRLEVBQXpDO0FBQ0FaLE1BQUFBLE1BQU0sQ0FBQ2UsSUFBUCxDQUFZSCxNQUFaO0FBQ0gsS0FKRCxNQU1LLElBQUcsT0FBT0gsSUFBUCxLQUFnQixXQUFuQixFQUErQjtBQUNoQ0csTUFBQUEsTUFBTSxHQUFJLEdBQUdYLFFBQVUsSUFBSVcsTUFBUSxFQUFuQztBQUNBWixNQUFBQSxNQUFNLENBQUNlLElBQVAsQ0FBWUgsTUFBWjtBQUNILEtBSEksTUFJRDtBQUNBQSxNQUFBQSxNQUFNLEdBQUc7QUFDTEksUUFBQUEsUUFBUSxFQUFFLDBCQURMO0FBRUxkLFFBQUFBLEtBQUssRUFBRTtBQUFDRCxVQUFBQSxRQUFRLEVBQUcsR0FBR0EsUUFBVSxFQUF6QjtBQUE0QixrQkFBUyxHQUFHVyxNQUFRO0FBQWhELFNBRkY7QUFHTEssUUFBQUEsTUFBTSxFQUFHLFVBQVVoQixRQUFVLElBQUlXLE1BQVE7QUFIcEMsT0FBVDtBQUtBWixNQUFBQSxNQUFNLENBQUNlLElBQVAsQ0FBWUgsTUFBTSxDQUFDSyxNQUFuQixFQUEyQkwsTUFBTSxDQUFDSyxNQUFsQyxFQUF5QztBQUNyQ0MsUUFBQUEsTUFBTSxFQUFFO0FBRDZCLE9BQXpDO0FBR0g7QUFDSixHQXRCRDs7QUF1QkEsTUFBSUMsT0FBTyxHQUFHO0FBQ1YsV0FBTyxTQURHO0FBRVYsY0FBVSxTQUZBO0FBR1YsWUFBUSxRQUhFO0FBSVYsZ0JBQVk7QUFKRixHQUFkO0FBTUEsTUFBSUMsUUFBUSxHQUFHLENBQUM7QUFBQyxZQUFTLFNBQVY7QUFBcUIsYUFBVztBQUFoQyxHQUFELEVBQ2Q7QUFBQyxZQUFTLFNBQVY7QUFBcUIsYUFBVztBQUFoQyxHQURjLEVBRWQ7QUFBQyxZQUFTLFFBQVY7QUFBb0IsYUFBVztBQUEvQixHQUZjLEVBR2Q7QUFBQyxZQUFTLFNBQVY7QUFBcUIsYUFBVztBQUFoQyxHQUhjLENBQWY7O0FBSUEsUUFBTUMsV0FBVyxHQUFJVixDQUFELElBQU87QUFDdkJXLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZWixDQUFDLENBQUNFLE1BQWQ7QUFDSCxHQUZEOztBQUdBLHNCQUNJO0FBQUEsMkJBQ0ksOERBQUMsR0FBRDtBQUFLLGFBQU8sRUFBR1EsV0FBZjtBQUFBLDhCQUNJLDhEQUFDLElBQUQ7QUFBTSxhQUFLLEVBQUcsSUFBR1osSUFBSyxFQUF0QjtBQUFBLGtCQUEyQlUsT0FBTyxDQUFDVixJQUFEO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosRUFHUVcsUUFBUSxDQUFDSSxHQUFULENBQWEsQ0FBQ0MsSUFBRCxFQUFPQyxLQUFQLEtBQWU7QUFDeEIsWUFBR0QsSUFBSSxDQUFDaEIsSUFBTCxJQUFhVSxPQUFPLENBQUNWLElBQUQsQ0FBdkIsRUFBOEI7QUFDMUIsOEJBQU8sOERBQUMsSUFBRDtBQUFvQixpQkFBSyxFQUFFZ0IsSUFBSSxDQUFDWCxLQUFoQztBQUFBLHNCQUF3Q1csSUFBSSxDQUFDaEI7QUFBN0MsYUFBWWlCLEtBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBUDtBQUNIO0FBQ0osT0FKRCxDQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLG1CQURKO0FBZ0JILENBMUREOztBQTJEQSxpRUFBZWpDLGFBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkZBO0FBQ0E7QUFDQTs7O0FBRUEsTUFBTWUsR0FBRyxHQUFHdkQsOERBQVc7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUxBO0FBTUEsTUFBTTZFLFdBQVcsR0FBRzdFLDhEQUFXO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQWZBO0FBZ0JBLE1BQU04RSxtQkFBbUIsR0FBRzlFLDhEQUFXO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FqQkE7QUFrQkEsTUFBTStFLFVBQVUsR0FBRy9FLDZEQUFVO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBUEE7QUFRQSxNQUFNaUYsaUJBQWlCLEdBQUdqRiw4REFBVztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTtBQU9BLE1BQU1rRixjQUFjLEdBQUdsRiwrREFBWTtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBMUJBO0FBMkJBLE1BQU1vRixVQUFVLEdBQUdwRiw4REFBVztBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBMUJBO0FBMkJBLE1BQU1xRixJQUFJLEdBQUdyRiw4REFBVztBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FmQTs7QUFpQkEsTUFBTXNGLFNBQVMsR0FBRyxNQUFNO0FBQ3BCLHNCQUNJO0FBQUEsMkJBQ0ksOERBQUMsR0FBRDtBQUFLLFdBQUssRUFBRTtBQUFFQyxRQUFBQSxNQUFNLEVBQUUsUUFBVjtBQUFvQkMsUUFBQUEsUUFBUSxFQUFFO0FBQTlCLE9BQVo7QUFBQSw4QkFDQSw4REFBQyxvREFBRDtBQUFpQixhQUFLLEVBQUU7QUFBRUMsVUFBQUEsVUFBVSxFQUFFLE1BQWQ7QUFBc0JDLFVBQUFBLE1BQU0sRUFBRSxDQUE5QjtBQUFpQ0MsVUFBQUEsR0FBRyxFQUFFO0FBQXRDLFNBQXhCO0FBQUEsK0JBQ0ksOERBQUMsd0NBQUQ7QUFBSyxtQkFBUyxHQUFHZixnRkFBQSxFQUF1QkEsd0VBQTFCLENBQWQ7QUFBd0QsZUFBSyxFQUFFO0FBQUVrQixZQUFBQSxRQUFRLEVBQUU7QUFBWixXQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREEsZUFJQSw4REFBQyxXQUFEO0FBQUEsK0JBQ0ksOERBQUMsbUJBQUQ7QUFBQSxrQ0FDSSw4REFBQyxVQUFEO0FBQUEsbUNBQVk7QUFBSyx1QkFBUyxFQUFDLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBRUksOERBQUMsaUJBQUQ7QUFBQSxtQ0FBbUI7QUFBSyx1QkFBUyxFQUFDLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGSixlQUdJLDhEQUFDLGlCQUFEO0FBQUEsbUNBQW1CO0FBQUssdUJBQVMsRUFBQyxRQUFmO0FBQUEsNjBCQUE0SztBQUFHLHlCQUFTLEVBQUMsV0FBYjtBQUF5QixvQkFBSSxFQUFDLEdBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE1SztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFISixlQUlJLDhEQUFDLElBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpBLGVBWUEsOERBQUMsY0FBRDtBQUFnQixpQkFBUyxFQUFDLFFBQTFCO0FBQUEsK0JBQW1DLDhEQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLG1CQURKO0FBb0JILENBckJEOztBQXNCQSxpRUFBZVIsU0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4SkE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RBO0FBQ0E7OztBQUVBLE1BQU14RSxVQUFVLEdBQUdkLDhEQUFXO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBVkE7QUFZQSxNQUFNbUIsYUFBYSxHQUFHbkIsaUVBQWM7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBTkE7O0FBUUEsTUFBTWdHLFVBQVUsR0FBRyxDQUFDO0FBQUVDLEVBQUFBLE1BQUY7QUFBVUMsRUFBQUE7QUFBVixDQUFELEtBQXlCO0FBQ3hDLHNCQUNJO0FBQUEsNEJBQ0ksOERBQUMsYUFBRDtBQUFlLGFBQU8sRUFBRUEsT0FBeEI7QUFBQSw2QkFDSSw4REFBQyxVQUFEO0FBQVksZUFBTyxFQUFDLFdBQXBCO0FBQWdDLFlBQUksRUFBQyxNQUFyQztBQUFBLCtCQUNJO0FBQU0sV0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBTUksOERBQUMsdURBQUQ7QUFBYyxZQUFNLEVBQUVEO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTko7QUFBQSxrQkFESjtBQVVILENBWEQ7O0FBYUEsaUVBQWVELFVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcENBOzs7QUFFQSxNQUFNRyxZQUFZLEdBQUduRyw4REFBVztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZUssS0FBSyxJQUFJQSxLQUFLLENBQUM0RixNQUFOLEdBQWUsT0FBZixHQUF5QixNQUFPO0FBQ3hELENBVkE7QUFZQSxNQUFNRyxpQkFBaUIsR0FBR3BHLDhEQUFXO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5BOztBQVFBLE1BQU1xRyxXQUFXLEdBQUcsbUJBQ2hCLDhEQUFDLGlCQUFEO0FBQW1CLFNBQU8sRUFBQyxXQUEzQjtBQUFBLHlCQUNJO0FBQU0sS0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESjs7QUFNQSxNQUFNQyxnQkFBZ0IsR0FBR3RHLDhEQUFXO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5BOztBQVFBLE1BQU11RyxVQUFVLEdBQUcsTUFBTTtBQUNyQixzQkFDSSw4REFBQyxnQkFBRDtBQUFrQixXQUFPLEVBQUMsV0FBMUI7QUFBc0MsUUFBSSxFQUFDLE1BQTNDO0FBQUEsMkJBQ0k7QUFBTSxjQUFRLEVBQUMsU0FBZjtBQUF5QixPQUFDLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsTUFBTUMsZUFBZSxHQUFHLENBQ3BCLGNBRG9CLEVBRXBCLGVBRm9CLEVBR3BCLFNBSG9CLEVBSXBCLGVBSm9CLEVBS3BCLFVBTG9CLEVBTXBCLFVBTm9CLEVBT3BCLFFBUG9CLEVBUXBCLFNBUm9CLEVBU3BCLFFBVG9CLEVBVXBCLGlCQVZvQixFQVdwQixZQVhvQixFQVlwQixLQVpvQixFQWFwQixLQWJvQixFQWNwQixXQWRvQixFQWVwQixTQWZvQixFQWdCcEIsWUFoQm9CLEVBaUJwQixNQWpCb0IsRUFrQnBCLFNBbEJvQixDQUF4QjtBQXFCQSxNQUFNQyxhQUFhLEdBQUd6Ryw4REFBVztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhSyxLQUFLLElBQUlBLEtBQUssQ0FBQ3FHLFFBQU4sR0FBaUIsU0FBakIsR0FBNkIsTUFBTztBQUMxRDtBQUNBLGNBQWNyRyxLQUFLLElBQUlBLEtBQUssQ0FBQ3FHLFFBQU4sR0FBaUIsU0FBakIsR0FBNkIsU0FBVTtBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQWhCQTs7QUFrQkEsTUFBTUMsUUFBUSxHQUFHLENBQUM7QUFBRTlGLEVBQUFBLFFBQUY7QUFBWTZGLEVBQUFBO0FBQVosQ0FBRCxrQkFDYiw4REFBQyxhQUFEO0FBQWUsVUFBUSxFQUFFN0YsUUFBUSxLQUFLNkYsUUFBdEM7QUFBQSxhQUNLN0YsUUFETCxFQUVLQSxRQUFRLEtBQUs2RixRQUFiLGdCQUF5Qiw4REFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBekIsR0FBMkMsSUFGaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREo7O0FBT0EsTUFBTXZHLE9BQU8sR0FBR0gsOERBQVc7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBTkE7QUFRTyxNQUFNK0YsWUFBWSxHQUFHLENBQUM7QUFBRUUsRUFBQUE7QUFBRixDQUFELGtCQUN4QjtBQUFBLHlCQUNJLDhEQUFDLFlBQUQ7QUFBYyxVQUFNLEVBQUVBLE1BQXRCO0FBQUEsNEJBQ0ksOERBQUMsT0FBRDtBQUFBLGdCQUNLTyxlQUFlLENBQUNqQyxHQUFoQixDQUFvQixDQUFDYixDQUFELEVBQUlrRCxDQUFKLGtCQUNqQiw4REFBQyxRQUFEO0FBQVUsZ0JBQVEsRUFBQyw0Q0FBbkI7QUFBQSxrQkFDS2xEO0FBREwsU0FBa0NrRCxDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURIO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQVFJLDhEQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixpQkFERzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsR1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBLE1BQU1ZLE1BQU0sR0FBRyxNQUFNO0FBQ2pCLFFBQU07QUFBQSxPQUFDQyxlQUFEO0FBQUEsT0FBa0JDO0FBQWxCLE1BQXdDdEUsK0NBQVEsQ0FBQyxLQUFELENBQXREO0FBQ0EsUUFBTTtBQUFBLE9BQUN1RSxnQkFBRDtBQUFBLE9BQW1CQztBQUFuQixNQUEwQ3hFLCtDQUFRLENBQUMsS0FBRCxDQUF4RDtBQUNBLFFBQU07QUFBQSxPQUFDeUUsYUFBRDtBQUFBLE9BQWdCQztBQUFoQixNQUFvQzFFLCtDQUFRLENBQUMsS0FBRCxDQUFsRDs7QUFDQSxRQUFNMkUsc0JBQXNCLEdBQUdyRSxDQUFDLElBQUk7QUFDaENBLElBQUFBLENBQUMsQ0FBQ3NFLGNBQUY7QUFDQU4sSUFBQUEsa0JBQWtCLENBQUMsQ0FBQ0QsZUFBRixDQUFsQjtBQUNBRyxJQUFBQSxtQkFBbUIsQ0FBQyxLQUFELENBQW5CO0FBQ0gsR0FKRDs7QUFLQSxRQUFNSyxlQUFlLEdBQUd2RSxDQUFDLElBQUk7QUFDekJBLElBQUFBLENBQUMsQ0FBQ3NFLGNBQUY7QUFDQUosSUFBQUEsbUJBQW1CLENBQUMsQ0FBQ0QsZ0JBQUYsQ0FBbkI7QUFDQUQsSUFBQUEsa0JBQWtCLENBQUMsS0FBRCxDQUFsQjtBQUNILEdBSkQ7O0FBS0EsUUFBTVEsb0JBQW9CLEdBQUd4RSxDQUFDLElBQUk7QUFDOUJBLElBQUFBLENBQUMsQ0FBQ3NFLGNBQUY7QUFDQUYsSUFBQUEsZ0JBQWdCLENBQUMsQ0FBQ0QsYUFBRixDQUFoQjtBQUNBSCxJQUFBQSxrQkFBa0IsQ0FBQyxLQUFELENBQWxCO0FBQ0FFLElBQUFBLG1CQUFtQixDQUFDLEtBQUQsQ0FBbkI7QUFDSCxHQUxEOztBQU1BLFFBQU1PLHVCQUF1QixHQUFHQyxLQUFLLElBQUk7QUFDckNWLElBQUFBLGtCQUFrQixDQUFDVSxLQUFELENBQWxCO0FBQ0gsR0FGRDs7QUFHQSxRQUFNQyxxQkFBcUIsR0FBR0QsS0FBSyxJQUFJO0FBQ25DTixJQUFBQSxnQkFBZ0IsQ0FBQ00sS0FBRCxDQUFoQjtBQUNILEdBRkQ7O0FBR0Esc0JBQ0ksK0RBQUMsK0NBQUQ7QUFBQSw0QkFDSSwrREFBQyw0REFBRDtBQUFVLG1CQUFhLEVBQUVYLGVBQXpCO0FBQTBDLGFBQU8sRUFBRU0sc0JBQW5EO0FBQTJFLGtCQUFZLEVBQUVJO0FBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFFSSwrREFBQyxrREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZKLGVBR0ksK0RBQUMsZ0VBQUQ7QUFBYyxVQUFJLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFISixlQUlJLCtEQUFDLGtEQUFEO0FBQVUsV0FBSyxFQUFDLHdEQUFoQjtBQUFBLDhCQUNJLCtEQUFDLDRDQUFEO0FBQUksWUFBSSxFQUFDLFNBQVQ7QUFBbUIsYUFBSyxFQUFDO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFFSSwrREFBQyw0Q0FBRDtBQUFJLFlBQUksRUFBQyxPQUFUO0FBQWlCLGFBQUssRUFBQztBQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZKLGVBR0ksK0RBQUMsNENBQUQ7QUFBSSxZQUFJLEVBQUMsVUFBVDtBQUFvQixhQUFLLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkosZUFTSSwrREFBQyw2Q0FBRDtBQUFTLFVBQUksRUFBQyxRQUFkO0FBQXVCLFdBQUssRUFBQztBQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVRKLGVBVUksK0RBQUMsNkNBQUQ7QUFBUyxVQUFJLEVBQUMsT0FBZDtBQUFzQixXQUFLLEVBQUM7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFWSixlQVdJLCtEQUFDLDZDQUFEO0FBQVMsVUFBSSxFQUFDLGVBQWQ7QUFBOEIsV0FBSyxFQUFDO0FBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWEosZUFZSSwrREFBQyxrREFBRDtBQUFVLFdBQUssRUFBQyxrREFBaEI7QUFBQSw4QkFDSSwrREFBQyw0Q0FBRDtBQUFJLFlBQUksRUFBQyxRQUFUO0FBQWtCLGFBQUssRUFBQztBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUksK0RBQUMsb0RBQUQ7QUFBWSxhQUFLLEVBQUM7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQUdJLCtEQUFDLDRDQUFEO0FBQUksWUFBSSxFQUFDLGlCQUFUO0FBQTJCLGFBQUssRUFBQztBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFaSixlQWlCSSwrREFBQyxrREFBRDtBQUFVLFdBQUssRUFBQyw0Q0FBaEI7QUFBQSw4QkFDSSwrREFBQyxvREFBRDtBQUFZLGFBQUssRUFBQztBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUksK0RBQUMsb0RBQUQ7QUFBWSxhQUFLLEVBQUM7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQUdJLCtEQUFDLG9EQUFEO0FBQVksYUFBSyxFQUFDO0FBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWpCSixlQXNCSSwrREFBQyxzREFBRDtBQUFVLFdBQUssRUFBQztBQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXRCSixlQXVCSSwrREFBQywrQ0FBRDtBQUFBLDhCQUNJLCtEQUFDLGdEQUFEO0FBQVksY0FBTSxFQUFFUixnQkFBcEI7QUFBc0MsZUFBTyxFQUFFTTtBQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUksK0RBQUMsZ0RBQUQ7QUFBWSxjQUFNLEVBQUVKLGFBQXBCO0FBQW1DLGVBQU8sRUFBRUssb0JBQTVDO0FBQWtFLG9CQUFZLEVBQUVHLHFCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBOEJILENBeEREOztBQTBEQSxpRUFBZWIsTUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JFQTs7O0FBRUEsTUFBTVIsVUFBVSxHQUFHLENBQUM7QUFBRTFFLEVBQUFBO0FBQUYsQ0FBRCxLQUFlO0FBQzlCLHNCQUNJLDhEQUFDLDREQUFEO0FBQUEsZUFDS0EsS0FETCxlQUVJLDhEQUFDLG1FQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFNSCxDQVBEOztBQVNBLGlFQUFlMEUsVUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWEE7QUFDQTs7O0FBRUEsTUFBTUMsRUFBRSxHQUFHLENBQUM7QUFBRTlFLEVBQUFBLElBQUY7QUFBUUcsRUFBQUE7QUFBUixDQUFELEtBQXFCO0FBQzVCLHNCQUNJLDhEQUFDLGtEQUFEO0FBQU0sUUFBSSxFQUFFSCxJQUFaO0FBQWtCLFlBQVEsTUFBMUI7QUFBQSwyQkFDSSw4REFBQyw0REFBRDtBQUFBLDZCQUNJO0FBQUEsa0JBQUlHO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFPSCxDQVJEOztBQVVBLGlFQUFlMkUsRUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNiQTtBQUNBOzs7QUFFQSxNQUFNRixRQUFRLEdBQUcsQ0FBQztBQUFFekUsRUFBQUEsS0FBRjtBQUFTekIsRUFBQUE7QUFBVCxDQUFELEtBQXlCO0FBQ3RDLHNCQUNJLDhEQUFDLGlFQUFEO0FBQUEsZUFDS3lCLEtBREwsZUFFSSw4REFBQyw2REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZKLGVBR0ksOERBQUMsbUNBQUQ7QUFBQSxnQkFDS3pCO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQVNILENBVkQ7O0FBWUEsaUVBQWVrRyxRQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmQTtBQUNBO0FBRU8sTUFBTTJCLEVBQUUsR0FBRzFJLDZEQUFVO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU13SSxpRUFBYztBQUNwQjtBQUNBO0FBQ0EsQ0FiTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIUDtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDREE7QUFDQTs7O0FBRUEsTUFBTUksWUFBWSxHQUFHLENBQUM7QUFBRXRHLEVBQUFBLEtBQUY7QUFBU3pCLEVBQUFBO0FBQVQsQ0FBRCxLQUF5QjtBQUMxQyxzQkFDSSw4REFBQyxpRUFBRDtBQUFBLGVBQ0t5QixLQURMLEVBRUt6QixRQUZMLGVBR0ksOERBQUMsOERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQU9ILENBUkQ7O0FBVUEsaUVBQWUrSCxZQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDYkE7QUFDQTs7O0FBRUEsTUFBTTlCLE9BQU8sR0FBRyxDQUFDO0FBQUUzRSxFQUFBQSxJQUFGO0FBQVFHLEVBQUFBLEtBQVI7QUFBZXpCLEVBQUFBO0FBQWYsQ0FBRCxLQUErQjtBQUMzQyxzQkFDSSw4REFBQyxrREFBRDtBQUFNLFFBQUksRUFBRXNCLElBQVo7QUFBa0IsWUFBUSxNQUExQjtBQUFBLDJCQUNJLDhEQUFDLDhEQUFEO0FBQUEsaUJBQWFHLEtBQWIsRUFBb0J6QixRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFLSCxDQU5EOztBQVFBLGlFQUFlaUcsT0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWEE7O0FBRUEsTUFBTWdDLEdBQUcsR0FBRzlJLDhEQUFXO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBVkE7O0FBWUEsTUFBTTZHLFNBQVMsR0FBRyxDQUFDO0FBQUVoRyxFQUFBQTtBQUFGLENBQUQsS0FBa0I7QUFDaEMsc0JBQ0k7QUFBQSwyQkFDSSw4REFBQyxHQUFEO0FBQUEsZ0JBQ0tBO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQU9ILENBUkQ7O0FBVUEsaUVBQWVnRyxTQUFmOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCQTtBQUVBLE1BQU1tQyxZQUFZLEdBQUdoSiw4REFBVztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBUkE7QUFVQSxpRUFBZWdKLFlBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1pBO0FBQ0E7OztBQUVBLE1BQU1wSSxNQUFNLEdBQUdaLGlFQUFjO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBYkE7O0FBZUEsTUFBTXNILFVBQVUsR0FBRyxDQUFDO0FBQUV6RyxFQUFBQSxRQUFGO0FBQVlxRixFQUFBQSxPQUFaO0FBQXFCRCxFQUFBQSxNQUFyQjtBQUE2QmlELEVBQUFBO0FBQTdCLENBQUQsS0FBaUQ7QUFDaEUsc0JBQ0k7QUFBQSw0QkFDSSw4REFBQyxNQUFEO0FBQVEsYUFBTyxFQUFFaEQsT0FBakI7QUFBQSxnQkFDS3JGO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQUlJLDhEQUFDLGlEQUFEO0FBQVcsWUFBTSxFQUFFb0YsTUFBbkI7QUFBMkIsa0JBQVksRUFBRWlEO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSko7QUFBQSxrQkFESjtBQVFILENBVEQ7O0FBV0EsaUVBQWU1QixVQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3QkE7QUFDQTs7O0FBRUEsTUFBTTZCLFlBQVksR0FBR25KLDhEQUFXO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlSyxLQUFLLElBQUlBLEtBQUssQ0FBQzRGLE1BQU4sR0FBZSxNQUFmLEdBQXdCLE1BQU87QUFDdkQ7QUFDQTtBQUNBLENBVEE7QUFXQSxNQUFNbUQsZ0JBQWdCLEdBQUdwSiw4REFBVztBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBUkE7QUFVQSxNQUFNcUosS0FBSyxHQUFHckosOERBQVc7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQWRBO0FBZ0JBLE1BQU1zSixpQkFBaUIsR0FBR3RKLDhEQUFXO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FYQTtBQWFBLE1BQU11SixrQkFBa0IsR0FBR3ZKLDhEQUFXO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5BO0FBUUEsTUFBTXdKLFdBQVcsR0FBR3hKLDREQUFTO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLENBSkE7QUFNQSxNQUFNbUIsYUFBYSxHQUFHbkIsOERBQVc7QUFDakM7QUFDQTtBQUNBO0FBQ0EsQ0FKQTtBQU1BLE1BQU15SixpQkFBaUIsR0FBR3pKLGlFQUFjO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVRBOztBQVdBLE1BQU0wSixVQUFVLEdBQUcsQ0FBQztBQUFFeEQsRUFBQUE7QUFBRixDQUFELEtBQWlCO0FBQ2hDLHNCQUNJLDhEQUFDLGlCQUFEO0FBQW1CLFdBQU8sRUFBRUEsT0FBNUI7QUFBQSwyQkFDSSw4REFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFLSCxDQU5EOztBQVFBLE1BQU15RCxPQUFPLEdBQUczSiw4REFBVztBQUMzQjtBQUNBO0FBQ0E7QUFDQSxNQUFNeUosaUJBQWtCO0FBQ3hCO0FBQ0E7QUFDQSxDQVBBOztBQVNBLE1BQU1HLGVBQWUsR0FBRyxtQkFDcEIsOERBQUMsT0FBRDtBQUFTLFNBQU8sRUFBQyxXQUFqQjtBQUFBLHlCQUNJO0FBQU0sUUFBSSxFQUFDLE1BQVg7QUFBa0IsVUFBTSxFQUFDLFNBQXpCO0FBQW1DLEtBQUMsRUFBQztBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURKOztBQU1PLE1BQU1YLFNBQVMsR0FBRyxDQUFDO0FBQUVoRCxFQUFBQSxNQUFGO0FBQVVpRCxFQUFBQTtBQUFWLENBQUQsS0FBOEI7QUFDbkQsc0JBQ0k7QUFBQSwyQkFDSSw4REFBQyxZQUFEO0FBQWMsWUFBTSxFQUFFakQsTUFBdEI7QUFBQSw4QkFDSSw4REFBQyxLQUFEO0FBQUEsZ0NBQ0ksOERBQUMsaUJBQUQ7QUFBQSxrQ0FDSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQUVJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZKLGVBR0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBTUksOERBQUMsa0JBQUQ7QUFBQSxrQ0FDSSw4REFBQyxhQUFEO0FBQUEsb0NBQ0ksOERBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUVJLDhEQUFDLDJDQUFEO0FBQVEscUJBQU8sTUFBZjtBQUFnQix3QkFBVSxNQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUFLSSw4REFBQyxhQUFEO0FBQUEsb0NBQ0ksOERBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUVJLDhEQUFDLDJDQUFEO0FBQVEsd0JBQVUsTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFOSixlQWdCSSw4REFBQyxVQUFEO0FBQVksaUJBQU8sRUFBRSxNQUFNaUQsWUFBWSxDQUFDLEtBQUQ7QUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBbUJJLDhEQUFDLGdCQUFEO0FBQWtCLGVBQU8sRUFBRSxNQUFNQSxZQUFZLENBQUMsS0FBRDtBQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQXlCSCxDQTFCTTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzR1A7QUFFTyxNQUFNM0IsUUFBUSxHQUFHdkgsOERBQVc7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVJPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQOztBQUVBLE1BQU02SixRQUFRLEdBQUc3Siw4REFBVztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FUQTtBQVdBLE1BQU1vSixnQkFBZ0IsR0FBR3BKLDhEQUFXO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBVkE7QUFZQSxNQUFNOEosZUFBZSxHQUFHOUosOERBQVc7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZUssS0FBSyxJQUFJQSxLQUFLLENBQUM0RixNQUFOLEdBQWUsT0FBZixHQUF5QixNQUFPO0FBQ3hELENBUkE7QUFVQSxNQUFNSyxnQkFBZ0IsR0FBR3RHLDhEQUFXO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5BO0FBUUEsTUFBTStKLGNBQWMsR0FBRy9KLDREQUFTO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FMQTs7QUFPQSxNQUFNdUcsVUFBVSxHQUFHLE1BQU07QUFDckIsc0JBQ0ksOERBQUMsZ0JBQUQ7QUFBa0IsV0FBTyxFQUFDLFdBQTFCO0FBQXNDLFFBQUksRUFBQyxNQUEzQztBQUFBLDJCQUNJO0FBQU0sY0FBUSxFQUFDLFNBQWY7QUFBeUIsT0FBQyxFQUFDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFLSCxDQU5EOztBQVFPLE1BQU15RCxZQUFZLEdBQUcsQ0FBQztBQUFFL0QsRUFBQUEsTUFBRjtBQUFVaUQsRUFBQUE7QUFBVixDQUFELEtBQTZCO0FBQ3JELHNCQUNJLDhEQUFDLGVBQUQ7QUFBaUIsVUFBTSxFQUFFakQsTUFBekI7QUFBQSw0QkFDSSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFFSSw4REFBQyxRQUFEO0FBQUEsNkJBQ0ksOERBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkosZUFLSSw4REFBQyxnQkFBRDtBQUFrQixhQUFPLEVBQUUsTUFBTWlELFlBQVksQ0FBQyxLQUFEO0FBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFTSCxDQVZNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMURQO0FBQ0E7OztBQUdBLE1BQU12RSxlQUFlLEdBQUczRSx1RUFBSDtBQUFBO0FBQUE7QUFBQSxzRUFBckI7QUFNQSxNQUFNMEUsR0FBRyxHQUFHMUUsd0VBQUg7QUFBQTtBQUFBO0FBQUEsZ0lBQVQ7O0FBU0EsTUFBTWtLLE1BQU0sR0FBRyxNQUFNO0FBQ2pCLHNCQUNJO0FBQUEsMkJBQ0EsOERBQUMsZUFBRDtBQUFBLDZCQUNJO0FBQUksaUJBQVMsRUFBR3RGLHVFQUFoQjtBQUFBLGdDQUNJLDhEQUFDLEdBQUQ7QUFBSyxtQkFBUyxFQUFHQSxnRkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFFSSw4REFBQyxHQUFEO0FBQUssbUJBQVMsRUFBR0EsZ0ZBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQSxtQkFESjtBQWFILENBZEQ7O0FBZUEsaUVBQWVzRixNQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQ0E7O0FBRUEsTUFBTUcsV0FBVyxHQUFHckssNERBQVM7QUFDN0I7QUFDQTtBQUNBO0FBQ0EsV0FBV0ssS0FBSyxJQUFJQSxLQUFLLENBQUM2QyxLQUFNO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBLENBUkE7QUFVQSxpRUFBZSxDQUFDO0FBQUVvSCxFQUFBQSxTQUFGO0FBQWF6SixFQUFBQTtBQUFiLENBQUQsS0FBNkI7QUFDeEMsc0JBQ0ksOERBQUMsV0FBRDtBQUFhLFNBQUssRUFBRXlKLFNBQXBCO0FBQUEsY0FDS3pKO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWkE7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ0hhOztBQUNiMkosOENBQTZDO0FBQ3pDM0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0E2RyxlQUFBLEdBQWtCLEtBQUssQ0FBdkI7O0FBQ0EsSUFBSUMsTUFBTSxHQUFHQyxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyxvQkFBRCxDQUFSLENBQW5DOztBQUNBLElBQUlDLE9BQU8sR0FBR0QsbUJBQU8sQ0FBQyx5RkFBRCxDQUFyQjs7QUFDQSxJQUFJRSxRQUFRLEdBQUdGLG1CQUFPLENBQUMsMkRBQUQsQ0FBdEI7O0FBQ0EsSUFBSUcsZ0JBQWdCLEdBQUdILG1CQUFPLENBQUMsK0VBQUQsQ0FBOUI7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NLLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ2pKLElBQUFBLE9BQU8sRUFBRWlKO0FBRHdCLEdBQXJDO0FBR0g7O0FBQ0QsTUFBTUUsVUFBVSxHQUFHLEVBQW5COztBQUVBLFNBQVNDLFFBQVQsQ0FBa0JySSxNQUFsQixFQUEwQlosSUFBMUIsRUFBZ0NrSixFQUFoQyxFQUFvQ0MsT0FBcEMsRUFBNkM7QUFDekMsTUFBSSxJQUFKLEVBQThDO0FBQzlDLE1BQUksQ0FBQyxDQUFDLEdBQUdSLE9BQUosRUFBYVMsVUFBYixDQUF3QnBKLElBQXhCLENBQUwsRUFBb0MsT0FGSyxDQUd6QztBQUNBO0FBQ0E7QUFDQTs7QUFDQVksRUFBQUEsTUFBTSxDQUFDcUksUUFBUCxDQUFnQmpKLElBQWhCLEVBQXNCa0osRUFBdEIsRUFBMEJDLE9BQTFCLEVBQW1DRSxLQUFuQyxDQUEwQ0MsR0FBRCxJQUFPO0FBQzVDLGNBQTJDO0FBQ3ZDO0FBQ0EsWUFBTUEsR0FBTjtBQUNIO0FBQ0osR0FMRDtBQU1BLFFBQU1DLFNBQVMsR0FBR0osT0FBTyxJQUFJLE9BQU9BLE9BQU8sQ0FBQzNILE1BQWYsS0FBMEIsV0FBckMsR0FBbUQySCxPQUFPLENBQUMzSCxNQUEzRCxHQUFvRVosTUFBTSxJQUFJQSxNQUFNLENBQUNZLE1BQXZHLENBYnlDLENBY3pDOztBQUNBd0gsRUFBQUEsVUFBVSxDQUFDaEosSUFBSSxHQUFHLEdBQVAsR0FBYWtKLEVBQWIsSUFBbUJLLFNBQVMsR0FBRyxNQUFNQSxTQUFULEdBQXFCLEVBQWpELENBQUQsQ0FBVixHQUFtRSxJQUFuRTtBQUNIOztBQUNELFNBQVNDLGVBQVQsQ0FBeUJDLEtBQXpCLEVBQWdDO0FBQzVCLFFBQU07QUFBRWhJLElBQUFBO0FBQUYsTUFBY2dJLEtBQUssQ0FBQ0MsYUFBMUI7QUFDQSxTQUFPakksTUFBTSxJQUFJQSxNQUFNLEtBQUssT0FBckIsSUFBZ0NnSSxLQUFLLENBQUNFLE9BQXRDLElBQWlERixLQUFLLENBQUNHLE9BQXZELElBQWtFSCxLQUFLLENBQUNJLFFBQXhFLElBQW9GSixLQUFLLENBQUNLLE1BQTFGLElBQW9HTCxLQUFLLENBQUNNLFdBQU4sSUFBcUJOLEtBQUssQ0FBQ00sV0FBTixDQUFrQkMsS0FBbEIsS0FBNEIsQ0FBNUo7QUFDSDs7QUFDRCxTQUFTQyxXQUFULENBQXFCMUksQ0FBckIsRUFBd0JYLE1BQXhCLEVBQWdDWixJQUFoQyxFQUFzQ2tKLEVBQXRDLEVBQTBDZ0IsT0FBMUMsRUFBbURDLE9BQW5ELEVBQTREckksTUFBNUQsRUFBb0VOLE1BQXBFLEVBQTRFO0FBQ3hFLFFBQU07QUFBRTRJLElBQUFBO0FBQUYsTUFBZ0I3SSxDQUFDLENBQUNtSSxhQUF4Qjs7QUFDQSxNQUFJVSxRQUFRLEtBQUssR0FBYixLQUFxQlosZUFBZSxDQUFDakksQ0FBRCxDQUFmLElBQXNCLENBQUMsQ0FBQyxHQUFHb0gsT0FBSixFQUFhUyxVQUFiLENBQXdCcEosSUFBeEIsQ0FBNUMsQ0FBSixFQUFnRjtBQUM1RTtBQUNBO0FBQ0g7O0FBQ0R1QixFQUFBQSxDQUFDLENBQUNzRSxjQUFGLEdBTndFLENBT3hFOztBQUNBLE1BQUkvRCxNQUFNLElBQUksSUFBVixJQUFrQm9ILEVBQUUsQ0FBQ21CLE9BQUgsQ0FBVyxHQUFYLEtBQW1CLENBQXpDLEVBQTRDO0FBQ3hDdkksSUFBQUEsTUFBTSxHQUFHLEtBQVQ7QUFDSCxHQVZ1RSxDQVd4RTs7O0FBQ0FsQixFQUFBQSxNQUFNLENBQUNzSixPQUFPLEdBQUcsU0FBSCxHQUFlLE1BQXZCLENBQU4sQ0FBcUNsSyxJQUFyQyxFQUEyQ2tKLEVBQTNDLEVBQStDO0FBQzNDaUIsSUFBQUEsT0FEMkM7QUFFM0MzSSxJQUFBQSxNQUYyQztBQUczQ00sSUFBQUE7QUFIMkMsR0FBL0M7QUFLSDs7QUFDRCxTQUFTMUIsSUFBVCxDQUFjbEMsS0FBZCxFQUFxQjtBQUNqQixZQUEyQztBQUN2QyxhQUFTb00sZUFBVCxDQUF5QkMsSUFBekIsRUFBK0I7QUFDM0IsYUFBTyxJQUFJQyxLQUFKLENBQVcsZ0NBQStCRCxJQUFJLENBQUNFLEdBQUksZ0JBQWVGLElBQUksQ0FBQ0csUUFBUyw2QkFBNEJILElBQUksQ0FBQ0ksTUFBTyxhQUE5RyxJQUE4SCxTQUFnQyxDQUFoQyxHQUFxRyxFQUFuTyxDQUFWLENBQVA7QUFDSCxLQUhzQyxDQUl2Qzs7O0FBQ0EsVUFBTUMsa0JBQWtCLEdBQUc7QUFDdkI1SyxNQUFBQSxJQUFJLEVBQUU7QUFEaUIsS0FBM0I7QUFHQSxVQUFNNkssYUFBYSxHQUFHeEMsTUFBTSxDQUFDeUMsSUFBUCxDQUFZRixrQkFBWixDQUF0QjtBQUNBQyxJQUFBQSxhQUFhLENBQUNFLE9BQWQsQ0FBdUJOLEdBQUQsSUFBTztBQUN6QixVQUFJQSxHQUFHLEtBQUssTUFBWixFQUFvQjtBQUNoQixZQUFJdk0sS0FBSyxDQUFDdU0sR0FBRCxDQUFMLElBQWMsSUFBZCxJQUFzQixPQUFPdk0sS0FBSyxDQUFDdU0sR0FBRCxDQUFaLEtBQXNCLFFBQXRCLElBQWtDLE9BQU92TSxLQUFLLENBQUN1TSxHQUFELENBQVosS0FBc0IsUUFBbEYsRUFBNEY7QUFDeEYsZ0JBQU1ILGVBQWUsQ0FBQztBQUNsQkcsWUFBQUEsR0FEa0I7QUFFbEJDLFlBQUFBLFFBQVEsRUFBRSxzQkFGUTtBQUdsQkMsWUFBQUEsTUFBTSxFQUFFek0sS0FBSyxDQUFDdU0sR0FBRCxDQUFMLEtBQWUsSUFBZixHQUFzQixNQUF0QixHQUErQixPQUFPdk0sS0FBSyxDQUFDdU0sR0FBRDtBQUhqQyxXQUFELENBQXJCO0FBS0g7QUFDSixPQVJELE1BUU87QUFDSDtBQUNBO0FBQ0EsY0FBTU8sQ0FBQyxHQUFHUCxHQUFWO0FBQ0g7QUFDSixLQWRELEVBVHVDLENBd0J2Qzs7QUFDQSxVQUFNUSxrQkFBa0IsR0FBRztBQUN2Qi9CLE1BQUFBLEVBQUUsRUFBRSxJQURtQjtBQUV2QmdCLE1BQUFBLE9BQU8sRUFBRSxJQUZjO0FBR3ZCcEksTUFBQUEsTUFBTSxFQUFFLElBSGU7QUFJdkJxSSxNQUFBQSxPQUFPLEVBQUUsSUFKYztBQUt2QmUsTUFBQUEsUUFBUSxFQUFFLElBTGE7QUFNdkJqQyxNQUFBQSxRQUFRLEVBQUUsSUFOYTtBQU92QnpILE1BQUFBLE1BQU0sRUFBRTtBQVBlLEtBQTNCO0FBU0EsVUFBTTJKLGFBQWEsR0FBRzlDLE1BQU0sQ0FBQ3lDLElBQVAsQ0FBWUcsa0JBQVosQ0FBdEI7QUFDQUUsSUFBQUEsYUFBYSxDQUFDSixPQUFkLENBQXVCTixHQUFELElBQU87QUFDekIsWUFBTVcsT0FBTyxHQUFHLE9BQU9sTixLQUFLLENBQUN1TSxHQUFELENBQTVCOztBQUNBLFVBQUlBLEdBQUcsS0FBSyxJQUFaLEVBQWtCO0FBQ2QsWUFBSXZNLEtBQUssQ0FBQ3VNLEdBQUQsQ0FBTCxJQUFjVyxPQUFPLEtBQUssUUFBMUIsSUFBc0NBLE9BQU8sS0FBSyxRQUF0RCxFQUFnRTtBQUM1RCxnQkFBTWQsZUFBZSxDQUFDO0FBQ2xCRyxZQUFBQSxHQURrQjtBQUVsQkMsWUFBQUEsUUFBUSxFQUFFLHNCQUZRO0FBR2xCQyxZQUFBQSxNQUFNLEVBQUVTO0FBSFUsV0FBRCxDQUFyQjtBQUtIO0FBQ0osT0FSRCxNQVFPLElBQUlYLEdBQUcsS0FBSyxRQUFaLEVBQXNCO0FBQ3pCLFlBQUl2TSxLQUFLLENBQUN1TSxHQUFELENBQUwsSUFBY1csT0FBTyxLQUFLLFFBQTlCLEVBQXdDO0FBQ3BDLGdCQUFNZCxlQUFlLENBQUM7QUFDbEJHLFlBQUFBLEdBRGtCO0FBRWxCQyxZQUFBQSxRQUFRLEVBQUUsVUFGUTtBQUdsQkMsWUFBQUEsTUFBTSxFQUFFUztBQUhVLFdBQUQsQ0FBckI7QUFLSDtBQUNKLE9BUk0sTUFRQSxJQUFJWCxHQUFHLEtBQUssU0FBUixJQUFxQkEsR0FBRyxLQUFLLFFBQTdCLElBQXlDQSxHQUFHLEtBQUssU0FBakQsSUFBOERBLEdBQUcsS0FBSyxVQUF0RSxJQUFvRkEsR0FBRyxLQUFLLFVBQWhHLEVBQTRHO0FBQy9HLFlBQUl2TSxLQUFLLENBQUN1TSxHQUFELENBQUwsSUFBYyxJQUFkLElBQXNCVyxPQUFPLEtBQUssU0FBdEMsRUFBaUQ7QUFDN0MsZ0JBQU1kLGVBQWUsQ0FBQztBQUNsQkcsWUFBQUEsR0FEa0I7QUFFbEJDLFlBQUFBLFFBQVEsRUFBRSxXQUZRO0FBR2xCQyxZQUFBQSxNQUFNLEVBQUVTO0FBSFUsV0FBRCxDQUFyQjtBQUtIO0FBQ0osT0FSTSxNQVFBO0FBQ0g7QUFDQTtBQUNBLGNBQU1KLENBQUMsR0FBR1AsR0FBVjtBQUNIO0FBQ0osS0EvQkQsRUFuQ3VDLENBbUV2QztBQUNBOztBQUNBLFVBQU1ZLFNBQVMsR0FBRzdDLE1BQU0sQ0FBQzNJLE9BQVAsQ0FBZXlMLE1BQWYsQ0FBc0IsS0FBdEIsQ0FBbEI7O0FBQ0EsUUFBSXBOLEtBQUssQ0FBQytLLFFBQU4sSUFBa0IsQ0FBQ29DLFNBQVMsQ0FBQ0UsT0FBakMsRUFBMEM7QUFDdENGLE1BQUFBLFNBQVMsQ0FBQ0UsT0FBVixHQUFvQixJQUFwQjtBQUNBckosTUFBQUEsT0FBTyxDQUFDc0osSUFBUixDQUFhLHNLQUFiO0FBQ0g7QUFDSjs7QUFDRCxRQUFNbk0sQ0FBQyxHQUFHbkIsS0FBSyxDQUFDK0ssUUFBTixLQUFtQixLQUE3QjtBQUNBLFFBQU1ySSxNQUFNLEdBQUcsQ0FBQyxHQUFHZ0ksUUFBSixFQUFjdEksU0FBZCxFQUFmOztBQUNBLFFBQU07QUFBRU4sSUFBQUEsSUFBRjtBQUFTa0osSUFBQUE7QUFBVCxNQUFpQlYsTUFBTSxDQUFDM0ksT0FBUCxDQUFlNEwsT0FBZixDQUF1QixNQUFJO0FBQzlDLFVBQU0sQ0FBQ0MsWUFBRCxFQUFlQyxVQUFmLElBQTZCLENBQUMsR0FBR2hELE9BQUosRUFBYWlELFdBQWIsQ0FBeUJoTCxNQUF6QixFQUFpQzFDLEtBQUssQ0FBQzhCLElBQXZDLEVBQTZDLElBQTdDLENBQW5DO0FBQ0EsV0FBTztBQUNIQSxNQUFBQSxJQUFJLEVBQUUwTCxZQURIO0FBRUh4QyxNQUFBQSxFQUFFLEVBQUVoTCxLQUFLLENBQUNnTCxFQUFOLEdBQVcsQ0FBQyxHQUFHUCxPQUFKLEVBQWFpRCxXQUFiLENBQXlCaEwsTUFBekIsRUFBaUMxQyxLQUFLLENBQUNnTCxFQUF2QyxDQUFYLEdBQXdEeUMsVUFBVSxJQUFJRDtBQUZ2RSxLQUFQO0FBSUgsR0FOc0IsRUFNcEIsQ0FDQzlLLE1BREQsRUFFQzFDLEtBQUssQ0FBQzhCLElBRlAsRUFHQzlCLEtBQUssQ0FBQ2dMLEVBSFAsQ0FOb0IsQ0FBdkI7O0FBV0EsTUFBSTtBQUFFeEssSUFBQUEsUUFBRjtBQUFhd0wsSUFBQUEsT0FBYjtBQUF1QkMsSUFBQUEsT0FBdkI7QUFBaUNySSxJQUFBQSxNQUFqQztBQUEwQ04sSUFBQUE7QUFBMUMsTUFBc0R0RCxLQUExRCxDQXpGaUIsQ0EwRmpCOztBQUNBLE1BQUksT0FBT1EsUUFBUCxLQUFvQixRQUF4QixFQUFrQztBQUM5QkEsSUFBQUEsUUFBUSxHQUFHLGFBQWM4SixNQUFNLENBQUMzSSxPQUFQLENBQWVnTSxhQUFmLENBQTZCLEdBQTdCLEVBQWtDLElBQWxDLEVBQXdDbk4sUUFBeEMsQ0FBekI7QUFDSCxHQTdGZ0IsQ0E4RmpCOzs7QUFDQSxNQUFJb04sS0FBSjs7QUFDQSxZQUE0QztBQUN4QyxRQUFJO0FBQ0FBLE1BQUFBLEtBQUssR0FBR3RELE1BQU0sQ0FBQzNJLE9BQVAsQ0FBZWtNLFFBQWYsQ0FBd0JDLElBQXhCLENBQTZCdE4sUUFBN0IsQ0FBUjtBQUNILEtBRkQsQ0FFRSxPQUFPNEssR0FBUCxFQUFZO0FBQ1YsWUFBTSxJQUFJa0IsS0FBSixDQUFXLDhEQUE2RHRNLEtBQUssQ0FBQzhCLElBQUssNEZBQXpFLElBQXdLLFNBQWdDLENBQWhDLEdBQXNHLEVBQTlRLENBQVYsQ0FBTjtBQUNIO0FBQ0osR0FORCxNQU1PLEVBRU47O0FBQ0QsUUFBTWlNLFFBQVEsR0FBR0gsS0FBSyxJQUFJLE9BQU9BLEtBQVAsS0FBaUIsUUFBMUIsSUFBc0NBLEtBQUssQ0FBQ0ksR0FBN0Q7QUFDQSxRQUFNLENBQUNDLGtCQUFELEVBQXFCQyxTQUFyQixJQUFrQyxDQUFDLEdBQUd2RCxnQkFBSixFQUFzQndELGVBQXRCLENBQXNDO0FBQzFFQyxJQUFBQSxVQUFVLEVBQUU7QUFEOEQsR0FBdEMsQ0FBeEM7O0FBR0EsUUFBTUMsTUFBTSxHQUFHL0QsTUFBTSxDQUFDM0ksT0FBUCxDQUFlMk0sV0FBZixDQUE0QkMsRUFBRCxJQUFNO0FBQzVDTixJQUFBQSxrQkFBa0IsQ0FBQ00sRUFBRCxDQUFsQjs7QUFDQSxRQUFJUixRQUFKLEVBQWM7QUFDVixVQUFJLE9BQU9BLFFBQVAsS0FBb0IsVUFBeEIsRUFBb0NBLFFBQVEsQ0FBQ1EsRUFBRCxDQUFSLENBQXBDLEtBQ0ssSUFBSSxPQUFPUixRQUFQLEtBQW9CLFFBQXhCLEVBQWtDO0FBQ25DQSxRQUFBQSxRQUFRLENBQUNWLE9BQVQsR0FBbUJrQixFQUFuQjtBQUNIO0FBQ0o7QUFDSixHQVJjLEVBUVosQ0FDQ1IsUUFERCxFQUVDRSxrQkFGRCxDQVJZLENBQWY7O0FBWUEzRCxFQUFBQSxNQUFNLENBQUMzSSxPQUFQLENBQWU2TSxTQUFmLENBQXlCLE1BQUk7QUFDekIsVUFBTUMsY0FBYyxHQUFHUCxTQUFTLElBQUkvTSxDQUFiLElBQWtCLENBQUMsR0FBR3NKLE9BQUosRUFBYVMsVUFBYixDQUF3QnBKLElBQXhCLENBQXpDO0FBQ0EsVUFBTXVKLFNBQVMsR0FBRyxPQUFPL0gsTUFBUCxLQUFrQixXQUFsQixHQUFnQ0EsTUFBaEMsR0FBeUNaLE1BQU0sSUFBSUEsTUFBTSxDQUFDWSxNQUE1RTtBQUNBLFVBQU1vTCxZQUFZLEdBQUc1RCxVQUFVLENBQUNoSixJQUFJLEdBQUcsR0FBUCxHQUFha0osRUFBYixJQUFtQkssU0FBUyxHQUFHLE1BQU1BLFNBQVQsR0FBcUIsRUFBakQsQ0FBRCxDQUEvQjs7QUFDQSxRQUFJb0QsY0FBYyxJQUFJLENBQUNDLFlBQXZCLEVBQXFDO0FBQ2pDM0QsTUFBQUEsUUFBUSxDQUFDckksTUFBRCxFQUFTWixJQUFULEVBQWVrSixFQUFmLEVBQW1CO0FBQ3ZCMUgsUUFBQUEsTUFBTSxFQUFFK0g7QUFEZSxPQUFuQixDQUFSO0FBR0g7QUFDSixHQVRELEVBU0csQ0FDQ0wsRUFERCxFQUVDbEosSUFGRCxFQUdDb00sU0FIRCxFQUlDNUssTUFKRCxFQUtDbkMsQ0FMRCxFQU1DdUIsTUFORCxDQVRIOztBQWlCQSxRQUFNaU0sVUFBVSxHQUFHO0FBQ2ZYLElBQUFBLEdBQUcsRUFBRUssTUFEVTtBQUVmeEksSUFBQUEsT0FBTyxFQUFHeEMsQ0FBRCxJQUFLO0FBQ1YsVUFBSXVLLEtBQUssQ0FBQzVOLEtBQU4sSUFBZSxPQUFPNE4sS0FBSyxDQUFDNU4sS0FBTixDQUFZNkYsT0FBbkIsS0FBK0IsVUFBbEQsRUFBOEQ7QUFDMUQrSCxRQUFBQSxLQUFLLENBQUM1TixLQUFOLENBQVk2RixPQUFaLENBQW9CeEMsQ0FBcEI7QUFDSDs7QUFDRCxVQUFJLENBQUNBLENBQUMsQ0FBQ3VMLGdCQUFQLEVBQXlCO0FBQ3JCN0MsUUFBQUEsV0FBVyxDQUFDMUksQ0FBRCxFQUFJWCxNQUFKLEVBQVlaLElBQVosRUFBa0JrSixFQUFsQixFQUFzQmdCLE9BQXRCLEVBQStCQyxPQUEvQixFQUF3Q3JJLE1BQXhDLEVBQWdETixNQUFoRCxDQUFYO0FBQ0g7QUFDSjtBQVRjLEdBQW5COztBQVdBcUwsRUFBQUEsVUFBVSxDQUFDRSxZQUFYLEdBQTJCeEwsQ0FBRCxJQUFLO0FBQzNCLFFBQUksQ0FBQyxDQUFDLEdBQUdvSCxPQUFKLEVBQWFTLFVBQWIsQ0FBd0JwSixJQUF4QixDQUFMLEVBQW9DOztBQUNwQyxRQUFJOEwsS0FBSyxDQUFDNU4sS0FBTixJQUFlLE9BQU80TixLQUFLLENBQUM1TixLQUFOLENBQVk2TyxZQUFuQixLQUFvQyxVQUF2RCxFQUFtRTtBQUMvRGpCLE1BQUFBLEtBQUssQ0FBQzVOLEtBQU4sQ0FBWTZPLFlBQVosQ0FBeUJ4TCxDQUF6QjtBQUNIOztBQUNEMEgsSUFBQUEsUUFBUSxDQUFDckksTUFBRCxFQUFTWixJQUFULEVBQWVrSixFQUFmLEVBQW1CO0FBQ3ZCOEQsTUFBQUEsUUFBUSxFQUFFO0FBRGEsS0FBbkIsQ0FBUjtBQUdILEdBUkQsQ0FySmlCLENBOEpqQjtBQUNBOzs7QUFDQSxNQUFJOU8sS0FBSyxDQUFDZ04sUUFBTixJQUFrQlksS0FBSyxDQUFDekssSUFBTixLQUFlLEdBQWYsSUFBc0IsRUFBRSxVQUFVeUssS0FBSyxDQUFDNU4sS0FBbEIsQ0FBNUMsRUFBc0U7QUFDbEUsVUFBTXFMLFNBQVMsR0FBRyxPQUFPL0gsTUFBUCxLQUFrQixXQUFsQixHQUFnQ0EsTUFBaEMsR0FBeUNaLE1BQU0sSUFBSUEsTUFBTSxDQUFDWSxNQUE1RSxDQURrRSxDQUVsRTtBQUNBOztBQUNBLFVBQU15TCxZQUFZLEdBQUdyTSxNQUFNLElBQUlBLE1BQU0sQ0FBQ3NNLGNBQWpCLElBQW1DLENBQUMsR0FBR3ZFLE9BQUosRUFBYXdFLGVBQWIsQ0FBNkJqRSxFQUE3QixFQUFpQ0ssU0FBakMsRUFBNEMzSSxNQUFNLElBQUlBLE1BQU0sQ0FBQ3dNLE9BQTdELEVBQXNFeE0sTUFBTSxJQUFJQSxNQUFNLENBQUN5TSxhQUF2RixDQUF4RDtBQUNBUixJQUFBQSxVQUFVLENBQUM3TSxJQUFYLEdBQWtCaU4sWUFBWSxJQUFJLENBQUMsR0FBR3RFLE9BQUosRUFBYTJFLFdBQWIsQ0FBeUIsQ0FBQyxHQUFHM0UsT0FBSixFQUFhNEUsU0FBYixDQUF1QnJFLEVBQXZCLEVBQTJCSyxTQUEzQixFQUFzQzNJLE1BQU0sSUFBSUEsTUFBTSxDQUFDNE0sYUFBdkQsQ0FBekIsQ0FBbEM7QUFDSDs7QUFDRCxTQUFPLGFBQWNoRixNQUFNLENBQUMzSSxPQUFQLENBQWU0TixZQUFmLENBQTRCM0IsS0FBNUIsRUFBbUNlLFVBQW5DLENBQXJCO0FBQ0g7O0FBQ0QsSUFBSWEsUUFBUSxHQUFHdE4sSUFBZjtBQUNBbUksZUFBQSxHQUFrQm1GLFFBQWxCOzs7Ozs7Ozs7OztBQ2pPYTs7QUFDYnJGLDhDQUE2QztBQUN6QzNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBNkcsK0JBQUEsR0FBa0NvRix1QkFBbEM7QUFDQXBGLGtDQUFBLEdBQXFDLEtBQUssQ0FBMUM7O0FBQ0EsU0FBU29GLHVCQUFULENBQWlDRSxJQUFqQyxFQUF1QztBQUNuQyxTQUFPQSxJQUFJLENBQUNDLFFBQUwsQ0FBYyxHQUFkLEtBQXNCRCxJQUFJLEtBQUssR0FBL0IsR0FBcUNBLElBQUksQ0FBQ0UsS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFDLENBQWYsQ0FBckMsR0FBeURGLElBQWhFO0FBQ0g7O0FBQ0QsTUFBTUQsMEJBQTBCLEdBQUdJLE1BQUEsR0FBcUNILENBQXJDLEdBUS9CRix1QkFSSjtBQVNBcEYsa0NBQUEsR0FBcUNxRiwwQkFBckM7Ozs7Ozs7Ozs7O0FDbEJhOztBQUNidkYsOENBQTZDO0FBQ3pDM0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0E2RywyQkFBQSxHQUE4QkEsMEJBQUEsR0FBNkIsS0FBSyxDQUFoRTs7QUFDQSxNQUFNNkYsbUJBQW1CLEdBQUcsT0FBT0UsSUFBUCxLQUFnQixXQUFoQixJQUErQkEsSUFBSSxDQUFDRixtQkFBcEMsSUFBMkRFLElBQUksQ0FBQ0YsbUJBQUwsQ0FBeUJHLElBQXpCLENBQThCQyxNQUE5QixDQUEzRCxJQUFvRyxVQUFTQyxFQUFULEVBQWE7QUFDekksTUFBSUMsS0FBSyxHQUFHQyxJQUFJLENBQUNDLEdBQUwsRUFBWjtBQUNBLFNBQU9DLFVBQVUsQ0FBQyxZQUFXO0FBQ3pCSixJQUFBQSxFQUFFLENBQUM7QUFDQ0ssTUFBQUEsVUFBVSxFQUFFLEtBRGI7QUFFQ0MsTUFBQUEsYUFBYSxFQUFFLFlBQVc7QUFDdEIsZUFBT0MsSUFBSSxDQUFDQyxHQUFMLENBQVMsQ0FBVCxFQUFZLE1BQU1OLElBQUksQ0FBQ0MsR0FBTCxLQUFhRixLQUFuQixDQUFaLENBQVA7QUFDSDtBQUpGLEtBQUQsQ0FBRjtBQU1ILEdBUGdCLEVBT2QsQ0FQYyxDQUFqQjtBQVFILENBVkQ7O0FBV0FuRywyQkFBQSxHQUE4QjZGLG1CQUE5Qjs7QUFDQSxNQUFNQyxrQkFBa0IsR0FBRyxPQUFPQyxJQUFQLEtBQWdCLFdBQWhCLElBQStCQSxJQUFJLENBQUNELGtCQUFwQyxJQUEwREMsSUFBSSxDQUFDRCxrQkFBTCxDQUF3QkUsSUFBeEIsQ0FBNkJDLE1BQTdCLENBQTFELElBQWtHLFVBQVNVLEVBQVQsRUFBYTtBQUN0SSxTQUFPQyxZQUFZLENBQUNELEVBQUQsQ0FBbkI7QUFDSCxDQUZEOztBQUdBM0csMEJBQUEsR0FBNkI4RixrQkFBN0I7Ozs7Ozs7Ozs7O0FDcEJhOztBQUNiaEcsOENBQTZDO0FBQ3pDM0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0E2RyxzQkFBQSxHQUF5QjZHLGNBQXpCO0FBQ0E3RyxvQkFBQSxHQUF1QjhHLFlBQXZCO0FBQ0E5Ryw4QkFBQSxHQUFpQytHLHNCQUFqQztBQUNBL0cseUJBQUEsR0FBNEJnSCxpQkFBNUI7O0FBQ0EsSUFBSUMsc0JBQXNCLEdBQUcvRyxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyxrSEFBRCxDQUFSLENBQW5EOztBQUNBLElBQUkrRyxvQkFBb0IsR0FBRy9HLG1CQUFPLENBQUMseUZBQUQsQ0FBbEM7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NLLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ2pKLElBQUFBLE9BQU8sRUFBRWlKO0FBRHdCLEdBQXJDO0FBR0gsRUFDRDtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTTRHLGlCQUFpQixHQUFHLElBQTFCOztBQUNBLFNBQVNDLFVBQVQsQ0FBb0JsRixHQUFwQixFQUF5QnJJLEdBQXpCLEVBQThCd04sU0FBOUIsRUFBeUM7QUFDckMsTUFBSUMsS0FBSyxHQUFHek4sR0FBRyxDQUFDME4sR0FBSixDQUFRckYsR0FBUixDQUFaOztBQUNBLE1BQUlvRixLQUFKLEVBQVc7QUFDUCxRQUFJLFlBQVlBLEtBQWhCLEVBQXVCO0FBQ25CLGFBQU9BLEtBQUssQ0FBQ0UsTUFBYjtBQUNIOztBQUNELFdBQU9DLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQkosS0FBaEIsQ0FBUDtBQUNIOztBQUNELE1BQUlLLFFBQUo7QUFDQSxRQUFNQyxJQUFJLEdBQUcsSUFBSUgsT0FBSixDQUFhQyxPQUFELElBQVc7QUFDaENDLElBQUFBLFFBQVEsR0FBR0QsT0FBWDtBQUNILEdBRlksQ0FBYjtBQUdBN04sRUFBQUEsR0FBRyxDQUFDZ08sR0FBSixDQUFRM0YsR0FBUixFQUFhb0YsS0FBSyxHQUFHO0FBQ2pCSSxJQUFBQSxPQUFPLEVBQUVDLFFBRFE7QUFFakJILElBQUFBLE1BQU0sRUFBRUk7QUFGUyxHQUFyQjtBQUlBLFNBQU9QLFNBQVMsR0FBR0EsU0FBUyxHQUFHUyxJQUFaLENBQWtCM08sS0FBRCxLQUFVd08sUUFBUSxDQUFDeE8sS0FBRCxDQUFSLEVBQWlCQSxLQUEzQixDQUFqQixDQUFILEdBQ1p5TyxJQURKO0FBRUg7O0FBQ0QsU0FBU0csV0FBVCxDQUFxQkMsSUFBckIsRUFBMkI7QUFDdkIsTUFBSTtBQUNBQSxJQUFBQSxJQUFJLEdBQUdDLFFBQVEsQ0FBQzNFLGFBQVQsQ0FBdUIsTUFBdkIsQ0FBUDtBQUNBLFdBQU87QUFDUDtBQUNDLE9BQUMsQ0FBQzJDLE1BQU0sQ0FBQ2lDLG9CQUFULElBQWlDLENBQUMsQ0FBQ0QsUUFBUSxDQUFDRSxZQUE3QyxJQUE4REgsSUFBSSxDQUFDSSxPQUFMLENBQWFDLFFBQWIsQ0FBc0IsVUFBdEI7QUFGOUQ7QUFHSCxHQUxELENBS0UsT0FBT3JQLENBQVAsRUFBVTtBQUNSLFdBQU8sS0FBUDtBQUNIO0FBQ0o7O0FBQ0QsTUFBTXNQLFdBQVcsR0FBR1AsV0FBVyxFQUEvQjs7QUFDQSxTQUFTUSxjQUFULENBQXdCOVEsSUFBeEIsRUFBOEJrSixFQUE5QixFQUFrQ3FILElBQWxDLEVBQXdDO0FBQ3BDLFNBQU8sSUFBSVAsT0FBSixDQUFZLENBQUNlLEdBQUQsRUFBTUMsR0FBTixLQUFZO0FBQzNCLFFBQUlSLFFBQVEsQ0FBQ1MsYUFBVCxDQUF3QiwrQkFBOEJqUixJQUFLLElBQTNELENBQUosRUFBcUU7QUFDakUsYUFBTytRLEdBQUcsRUFBVjtBQUNIOztBQUNEUixJQUFBQSxJQUFJLEdBQUdDLFFBQVEsQ0FBQzNFLGFBQVQsQ0FBdUIsTUFBdkIsQ0FBUCxDQUoyQixDQUszQjs7QUFDQSxRQUFJM0MsRUFBSixFQUFRcUgsSUFBSSxDQUFDckgsRUFBTCxHQUFVQSxFQUFWO0FBQ1JxSCxJQUFBQSxJQUFJLENBQUNXLEdBQUwsR0FBWSxVQUFaO0FBQ0FYLElBQUFBLElBQUksQ0FBQ1ksV0FBTCxHQUFtQm5ELFNBQW5CO0FBQ0F1QyxJQUFBQSxJQUFJLENBQUNjLE1BQUwsR0FBY04sR0FBZDtBQUNBUixJQUFBQSxJQUFJLENBQUNlLE9BQUwsR0FBZU4sR0FBZixDQVYyQixDQVczQjs7QUFDQVQsSUFBQUEsSUFBSSxDQUFDdlEsSUFBTCxHQUFZQSxJQUFaO0FBQ0F3USxJQUFBQSxRQUFRLENBQUNlLElBQVQsQ0FBY0MsV0FBZCxDQUEwQmpCLElBQTFCO0FBQ0gsR0FkTSxDQUFQO0FBZUg7O0FBQ0QsTUFBTWtCLGdCQUFnQixHQUFHQyxNQUFNLENBQUMsa0JBQUQsQ0FBL0I7O0FBQ0EsU0FBU3RDLGNBQVQsQ0FBd0I5RixHQUF4QixFQUE2QjtBQUN6QixTQUFPakIsTUFBTSxDQUFDQyxjQUFQLENBQXNCZ0IsR0FBdEIsRUFBMkJtSSxnQkFBM0IsRUFBNkMsRUFBN0MsQ0FBUDtBQUVIOztBQUNELFNBQVNwQyxZQUFULENBQXNCL0YsR0FBdEIsRUFBMkI7QUFDdkIsU0FBT0EsR0FBRyxJQUFJbUksZ0JBQWdCLElBQUluSSxHQUFsQztBQUNIOztBQUNELFNBQVNxSSxZQUFULENBQXNCQyxHQUF0QixFQUEyQkMsTUFBM0IsRUFBbUM7QUFDL0IsU0FBTyxJQUFJN0IsT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBVTZCLE1BQVYsS0FBbUI7QUFDbENELElBQUFBLE1BQU0sR0FBR3JCLFFBQVEsQ0FBQzNFLGFBQVQsQ0FBdUIsUUFBdkIsQ0FBVCxDQURrQyxDQUVsQztBQUNBO0FBQ0E7O0FBQ0FnRyxJQUFBQSxNQUFNLENBQUNSLE1BQVAsR0FBZ0JwQixPQUFoQjs7QUFDQTRCLElBQUFBLE1BQU0sQ0FBQ1AsT0FBUCxHQUFpQixNQUFJUSxNQUFNLENBQUMxQyxjQUFjLENBQUMsSUFBSTVFLEtBQUosQ0FBVywwQkFBeUJvSCxHQUFJLEVBQXhDLENBQUQsQ0FBZixDQUEzQixDQU5rQyxDQVFsQztBQUNBOzs7QUFDQUMsSUFBQUEsTUFBTSxDQUFDVixXQUFQLEdBQXFCbkQsU0FBckIsQ0FWa0MsQ0FXbEM7QUFDQTs7QUFDQTZELElBQUFBLE1BQU0sQ0FBQ0QsR0FBUCxHQUFhQSxHQUFiO0FBQ0FwQixJQUFBQSxRQUFRLENBQUN1QixJQUFULENBQWNQLFdBQWQsQ0FBMEJLLE1BQTFCO0FBQ0gsR0FmTSxDQUFQO0FBZ0JILEVBQ0Q7QUFDQTs7O0FBQ0EsSUFBSUcsZUFBSixFQUNBOztBQUNBLFNBQVNDLHlCQUFULENBQW1DNVMsQ0FBbkMsRUFBc0M2UyxFQUF0QyxFQUEwQzVJLEdBQTFDLEVBQStDO0FBQzNDLFNBQU8sSUFBSTBHLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVU2QixNQUFWLEtBQW1CO0FBQ2xDLFFBQUlLLFNBQVMsR0FBRyxLQUFoQjtBQUNBOVMsSUFBQUEsQ0FBQyxDQUFDZ1IsSUFBRixDQUFRK0IsQ0FBRCxJQUFLO0FBQ1I7QUFDQUQsTUFBQUEsU0FBUyxHQUFHLElBQVo7QUFDQWxDLE1BQUFBLE9BQU8sQ0FBQ21DLENBQUQsQ0FBUDtBQUNILEtBSkQsRUFJRy9JLEtBSkgsQ0FJU3lJLE1BSlQsRUFGa0MsQ0FPbEM7QUFDQTs7QUFDQSxjQUE0QztBQUN4QyxPQUFDRSxlQUFlLElBQUloQyxPQUFPLENBQUNDLE9BQVIsRUFBcEIsRUFBdUNJLElBQXZDLENBQTRDLE1BQUk7QUFDNUMsU0FBQyxHQUFHWixvQkFBSixFQUEwQnJCLG1CQUExQixDQUE4QyxNQUFJUyxVQUFVLENBQUMsTUFBSTtBQUN6RCxjQUFJLENBQUNzRCxTQUFMLEVBQWdCO0FBQ1pMLFlBQUFBLE1BQU0sQ0FBQ3hJLEdBQUQsQ0FBTjtBQUNIO0FBQ0osU0FKdUQsRUFJckQ0SSxFQUpxRCxDQUE1RDtBQU1ILE9BUEQ7QUFRSDs7QUFDRCxlQUE0QyxFQU8zQztBQUNKLEdBM0JNLENBQVA7QUE0Qkg7O0FBQ0QsU0FBUzVDLHNCQUFULEdBQWtDO0FBQzlCLE1BQUloQixJQUFJLENBQUMrRCxnQkFBVCxFQUEyQjtBQUN2QixXQUFPckMsT0FBTyxDQUFDQyxPQUFSLENBQWdCM0IsSUFBSSxDQUFDK0QsZ0JBQXJCLENBQVA7QUFDSDs7QUFDRCxRQUFNQyxlQUFlLEdBQUcsSUFBSXRDLE9BQUosQ0FBYUMsT0FBRCxJQUFXO0FBQzNDO0FBQ0EsVUFBTXhCLEVBQUUsR0FBR0gsSUFBSSxDQUFDaUUsbUJBQWhCOztBQUNBakUsSUFBQUEsSUFBSSxDQUFDaUUsbUJBQUwsR0FBMkIsTUFBSTtBQUMzQnRDLE1BQUFBLE9BQU8sQ0FBQzNCLElBQUksQ0FBQytELGdCQUFOLENBQVA7QUFDQTVELE1BQUFBLEVBQUUsSUFBSUEsRUFBRSxFQUFSO0FBQ0gsS0FIRDtBQUlILEdBUHVCLENBQXhCO0FBUUEsU0FBT3dELHlCQUF5QixDQUFDSyxlQUFELEVBQWtCNUMsaUJBQWxCLEVBQXFDTixjQUFjLENBQUMsSUFBSTVFLEtBQUosQ0FBVSxzQ0FBVixDQUFELENBQW5ELENBQWhDO0FBQ0g7O0FBQ0QsU0FBU2dJLGdCQUFULENBQTBCQyxXQUExQixFQUF1Q0MsS0FBdkMsRUFBOEM7QUFDMUMsWUFBNEM7QUFDeEMsV0FBTzFDLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQjtBQUNuQjBDLE1BQUFBLE9BQU8sRUFBRSxDQUNMRixXQUFXLEdBQUcsNEJBQWQsR0FBNkNHLFNBQVMsQ0FBQyxDQUFDLEdBQUdwRCxzQkFBSixFQUE0QjNQLE9BQTVCLENBQW9DNlMsS0FBcEMsRUFBMkMsS0FBM0MsQ0FBRCxDQURqRCxDQURVO0FBSW5CO0FBQ0E1SyxNQUFBQSxHQUFHLEVBQUU7QUFMYyxLQUFoQixDQUFQO0FBT0g7O0FBQ0QsU0FBT3dILHNCQUFzQixHQUFHZSxJQUF6QixDQUErQndDLFFBQUQsSUFBWTtBQUM3QyxRQUFJLEVBQUVILEtBQUssSUFBSUcsUUFBWCxDQUFKLEVBQTBCO0FBQ3RCLFlBQU16RCxjQUFjLENBQUMsSUFBSTVFLEtBQUosQ0FBVywyQkFBMEJrSSxLQUFNLEVBQTNDLENBQUQsQ0FBcEI7QUFDSDs7QUFDRCxVQUFNSSxRQUFRLEdBQUdELFFBQVEsQ0FBQ0gsS0FBRCxDQUFSLENBQWdCdFEsR0FBaEIsQ0FBcUJ5TixLQUFELElBQVM0QyxXQUFXLEdBQUcsU0FBZCxHQUEwQkcsU0FBUyxDQUFDL0MsS0FBRCxDQUFoRSxDQUFqQjtBQUVBLFdBQU87QUFDSDhDLE1BQUFBLE9BQU8sRUFBRUcsUUFBUSxDQUFDQyxNQUFULENBQWlCQyxDQUFELElBQUtBLENBQUMsQ0FBQ2xGLFFBQUYsQ0FBVyxLQUFYLENBQXJCLENBRE47QUFHSGhHLE1BQUFBLEdBQUcsRUFBRWdMLFFBQVEsQ0FBQ0MsTUFBVCxDQUFpQkMsQ0FBRCxJQUFLQSxDQUFDLENBQUNsRixRQUFGLENBQVcsTUFBWCxDQUFyQjtBQUhGLEtBQVA7QUFNSCxHQVpNLENBQVA7QUFhSDs7QUFDRCxTQUFTeUIsaUJBQVQsQ0FBMkJrRCxXQUEzQixFQUF3QztBQUNwQyxRQUFNUSxXQUFXLEdBQUcsSUFBSUMsR0FBSixFQUFwQjtBQUNBLFFBQU1DLGFBQWEsR0FBRyxJQUFJRCxHQUFKLEVBQXRCO0FBQ0EsUUFBTUUsV0FBVyxHQUFHLElBQUlGLEdBQUosRUFBcEI7QUFDQSxRQUFNRyxNQUFNLEdBQUcsSUFBSUgsR0FBSixFQUFmOztBQUNBLFdBQVNJLGtCQUFULENBQTRCMUIsR0FBNUIsRUFBaUM7QUFDN0IsUUFBSXpCLElBQUksR0FBR2dELGFBQWEsQ0FBQ3JELEdBQWQsQ0FBa0I4QixHQUFsQixDQUFYOztBQUNBLFFBQUl6QixJQUFKLEVBQVU7QUFDTixhQUFPQSxJQUFQO0FBQ0gsS0FKNEIsQ0FLN0I7OztBQUNBLFFBQUlLLFFBQVEsQ0FBQ1MsYUFBVCxDQUF3QixnQkFBZVcsR0FBSSxJQUEzQyxDQUFKLEVBQXFEO0FBQ2pELGFBQU81QixPQUFPLENBQUNDLE9BQVIsRUFBUDtBQUNIOztBQUNEa0QsSUFBQUEsYUFBYSxDQUFDL0MsR0FBZCxDQUFrQndCLEdBQWxCLEVBQXVCekIsSUFBSSxHQUFHd0IsWUFBWSxDQUFDQyxHQUFELENBQTFDO0FBQ0EsV0FBT3pCLElBQVA7QUFDSDs7QUFDRCxXQUFTb0QsZUFBVCxDQUF5QnZULElBQXpCLEVBQStCO0FBQzNCLFFBQUltUSxJQUFJLEdBQUdpRCxXQUFXLENBQUN0RCxHQUFaLENBQWdCOVAsSUFBaEIsQ0FBWDs7QUFDQSxRQUFJbVEsSUFBSixFQUFVO0FBQ04sYUFBT0EsSUFBUDtBQUNIOztBQUNEaUQsSUFBQUEsV0FBVyxDQUFDaEQsR0FBWixDQUFnQnBRLElBQWhCLEVBQXNCbVEsSUFBSSxHQUFHcUQsS0FBSyxDQUFDeFQsSUFBRCxDQUFMLENBQVlxUSxJQUFaLENBQWtCVSxHQUFELElBQU87QUFDakQsVUFBSSxDQUFDQSxHQUFHLENBQUMwQyxFQUFULEVBQWE7QUFDVCxjQUFNLElBQUlqSixLQUFKLENBQVcsOEJBQTZCeEssSUFBSyxFQUE3QyxDQUFOO0FBQ0g7O0FBQ0QsYUFBTytRLEdBQUcsQ0FBQzJDLElBQUosR0FBV3JELElBQVgsQ0FBaUJxRCxJQUFELEtBQVM7QUFDeEIxVCxRQUFBQSxJQUFJLEVBQUVBLElBRGtCO0FBRXhCMlQsUUFBQUEsT0FBTyxFQUFFRDtBQUZlLE9BQVQsQ0FBaEIsQ0FBUDtBQUtILEtBVDRCLEVBUzFCckssS0FUMEIsQ0FTbkJDLEdBQUQsSUFBTztBQUNaLFlBQU04RixjQUFjLENBQUM5RixHQUFELENBQXBCO0FBQ0gsS0FYNEIsQ0FBN0I7QUFZQSxXQUFPNkcsSUFBUDtBQUNIOztBQUNELFNBQU87QUFDSHlELElBQUFBLGNBQWMsQ0FBRWxCLEtBQUYsRUFBUztBQUNuQixhQUFPL0MsVUFBVSxDQUFDK0MsS0FBRCxFQUFRTyxXQUFSLENBQWpCO0FBQ0gsS0FIRTs7QUFJSFksSUFBQUEsWUFBWSxDQUFFbkIsS0FBRixFQUFTb0IsT0FBVCxFQUFrQjtBQUMxQjlELE1BQUFBLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQjZELE9BQWhCLEVBQXlCekQsSUFBekIsQ0FBK0IwRCxFQUFELElBQU1BLEVBQUUsRUFBdEMsRUFDRTFELElBREYsQ0FDUTlILE9BQUQsS0FBWTtBQUNYeUwsUUFBQUEsU0FBUyxFQUFFekwsT0FBTyxJQUFJQSxPQUFPLENBQUMxSSxPQUFuQixJQUE4QjBJLE9BRDlCO0FBRVhBLFFBQUFBLE9BQU8sRUFBRUE7QUFGRSxPQUFaLENBRFAsRUFLR2UsR0FBRCxLQUFRO0FBQ0YySyxRQUFBQSxLQUFLLEVBQUUzSztBQURMLE9BQVIsQ0FMRixFQVFFK0csSUFSRixDQVFRNkQsS0FBRCxJQUFTO0FBQ1osY0FBTUMsR0FBRyxHQUFHbEIsV0FBVyxDQUFDbkQsR0FBWixDQUFnQjRDLEtBQWhCLENBQVo7QUFDQU8sUUFBQUEsV0FBVyxDQUFDN0MsR0FBWixDQUFnQnNDLEtBQWhCLEVBQXVCd0IsS0FBdkI7QUFDQSxZQUFJQyxHQUFHLElBQUksYUFBYUEsR0FBeEIsRUFBNkJBLEdBQUcsQ0FBQ2xFLE9BQUosQ0FBWWlFLEtBQVo7QUFDaEMsT0FaRDtBQWFILEtBbEJFOztBQW1CSEUsSUFBQUEsU0FBUyxDQUFFMUIsS0FBRixFQUFTekosUUFBVCxFQUFtQjtBQUN4QixhQUFPMEcsVUFBVSxDQUFDK0MsS0FBRCxFQUFRVyxNQUFSLEVBQWdCLE1BQUk7QUFDakMsY0FBTWdCLGlCQUFpQixHQUFHN0IsZ0JBQWdCLENBQUNDLFdBQUQsRUFBY0MsS0FBZCxDQUFoQixDQUFxQ3JDLElBQXJDLENBQTBDLENBQUM7QUFBRXNDLFVBQUFBLE9BQUY7QUFBWTdLLFVBQUFBO0FBQVosU0FBRCxLQUFzQjtBQUN0RixpQkFBT2tJLE9BQU8sQ0FBQ3NFLEdBQVIsQ0FBWSxDQUNmckIsV0FBVyxDQUFDc0IsR0FBWixDQUFnQjdCLEtBQWhCLElBQXlCLEVBQXpCLEdBQThCMUMsT0FBTyxDQUFDc0UsR0FBUixDQUFZM0IsT0FBTyxDQUFDdlEsR0FBUixDQUFZa1Isa0JBQVosQ0FBWixDQURmLEVBRWZ0RCxPQUFPLENBQUNzRSxHQUFSLENBQVl4TSxHQUFHLENBQUMxRixHQUFKLENBQVFtUixlQUFSLENBQVosQ0FGZSxDQUFaLENBQVA7QUFJSCxTQUx5QixFQUt2QmxELElBTHVCLENBS2pCVSxHQUFELElBQU87QUFDWCxpQkFBTyxLQUFLNkMsY0FBTCxDQUFvQmxCLEtBQXBCLEVBQTJCckMsSUFBM0IsQ0FBaUNtRSxVQUFELEtBQWU7QUFDOUNBLFlBQUFBLFVBRDhDO0FBRTlDL1IsWUFBQUEsTUFBTSxFQUFFc08sR0FBRyxDQUFDLENBQUQ7QUFGbUMsV0FBZixDQUFoQyxDQUFQO0FBS0gsU0FYeUIsQ0FBMUI7O0FBWUEsa0JBQTRDO0FBQ3hDaUIsVUFBQUEsZUFBZSxHQUFHLElBQUloQyxPQUFKLENBQWFDLE9BQUQsSUFBVztBQUNyQyxnQkFBSW9FLGlCQUFKLEVBQXVCO0FBQ25CLHFCQUFPQSxpQkFBaUIsQ0FBQ0ksT0FBbEIsQ0FBMEIsTUFBSTtBQUNqQ3hFLGdCQUFBQSxPQUFPO0FBQ1YsZUFGTSxDQUFQO0FBR0g7QUFDSixXQU5pQixDQUFsQjtBQU9IOztBQUNELGVBQU9nQyx5QkFBeUIsQ0FBQ29DLGlCQUFELEVBQW9CM0UsaUJBQXBCLEVBQXVDTixjQUFjLENBQUMsSUFBSTVFLEtBQUosQ0FBVyxtQ0FBa0NrSSxLQUFNLEVBQW5ELENBQUQsQ0FBckQsQ0FBekIsQ0FBdUlyQyxJQUF2SSxDQUE0SSxDQUFDO0FBQUVtRSxVQUFBQSxVQUFGO0FBQWUvUixVQUFBQTtBQUFmLFNBQUQsS0FBNEI7QUFDM0ssZ0JBQU1zTyxHQUFHLEdBQUcxSSxNQUFNLENBQUNxTSxNQUFQLENBQWM7QUFDdEJqUyxZQUFBQSxNQUFNLEVBQUVBO0FBRGMsV0FBZCxFQUVUK1IsVUFGUyxDQUFaO0FBR0EsaUJBQU8sV0FBV0EsVUFBWCxHQUF3QkEsVUFBeEIsR0FBcUN6RCxHQUE1QztBQUNILFNBTE0sRUFLSjFILEtBTEksQ0FLR0MsR0FBRCxJQUFPO0FBQ1osY0FBSUwsUUFBSixFQUFjO0FBQ1Y7QUFDQSxrQkFBTUssR0FBTjtBQUNIOztBQUNELGlCQUFPO0FBQ0gySyxZQUFBQSxLQUFLLEVBQUUzSztBQURKLFdBQVA7QUFHSCxTQWJNLENBQVA7QUFjSCxPQXBDZ0IsQ0FBakI7QUFxQ0gsS0F6REU7O0FBMERITCxJQUFBQSxRQUFRLENBQUV5SixLQUFGLEVBQVM7QUFDYjtBQUNBO0FBQ0EsVUFBSWlDLEVBQUo7O0FBQ0EsVUFBSUEsRUFBRSxHQUFHQyxTQUFTLENBQUNDLFVBQW5CLEVBQStCO0FBQzNCO0FBQ0EsWUFBSUYsRUFBRSxDQUFDRyxRQUFILElBQWUsS0FBSzNHLElBQUwsQ0FBVXdHLEVBQUUsQ0FBQ0ksYUFBYixDQUFuQixFQUFnRCxPQUFPL0UsT0FBTyxDQUFDQyxPQUFSLEVBQVA7QUFDbkQ7O0FBQ0QsYUFBT3VDLGdCQUFnQixDQUFDQyxXQUFELEVBQWNDLEtBQWQsQ0FBaEIsQ0FBcUNyQyxJQUFyQyxDQUEyQzJFLE1BQUQsSUFBVWhGLE9BQU8sQ0FBQ3NFLEdBQVIsQ0FBWXpELFdBQVcsR0FBR21FLE1BQU0sQ0FBQ3JDLE9BQVAsQ0FBZXZRLEdBQWYsQ0FBb0J5UCxNQUFELElBQVVmLGNBQWMsQ0FBQ2UsTUFBRCxFQUFTLFFBQVQsQ0FBM0MsQ0FBSCxHQUMxRSxFQURtRCxDQUFwRCxFQUVMeEIsSUFGSyxDQUVBLE1BQUk7QUFDUCxTQUFDLEdBQUdaLG9CQUFKLEVBQTBCckIsbUJBQTFCLENBQThDLE1BQUksS0FBS2dHLFNBQUwsQ0FBZTFCLEtBQWYsRUFBc0IsSUFBdEIsRUFBNEJySixLQUE1QixDQUFrQyxNQUFJLENBQ25GLENBRDZDLENBQWxEO0FBR0gsT0FOTSxFQU1KQSxLQU5JLEVBTUU7QUFDVCxZQUFJLENBQ0gsQ0FSTSxDQUFQO0FBU0g7O0FBM0VFLEdBQVA7QUE2RUg7Ozs7Ozs7Ozs7O0FDdFJZOztBQUNiaEIsOENBQTZDO0FBQ3pDM0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0EyRywwQ0FBeUM7QUFDckM0TSxFQUFBQSxVQUFVLEVBQUUsSUFEeUI7QUFFckNuRixFQUFBQSxHQUFHLEVBQUUsWUFBVztBQUNaLFdBQU9uSCxPQUFPLENBQUM5SSxPQUFmO0FBQ0g7QUFKb0MsQ0FBekM7QUFNQXdJLDhDQUE2QztBQUN6QzRNLEVBQUFBLFVBQVUsRUFBRSxJQUQ2QjtBQUV6Q25GLEVBQUFBLEdBQUcsRUFBRSxZQUFXO0FBQ1osV0FBT29GLFdBQVcsQ0FBQ3JWLE9BQW5CO0FBQ0g7QUFKd0MsQ0FBN0M7QUFNQTBJLGlCQUFBLEdBQW9CakksU0FBcEI7QUFDQWlJLG9CQUFBLEdBQXVCNE0sWUFBdkI7QUFDQTVNLGdDQUFBLEdBQW1DNk0sd0JBQW5DO0FBQ0E3TSxlQUFBLEdBQWtCLEtBQUssQ0FBdkI7O0FBQ0EsSUFBSUMsTUFBTSxHQUFHQyxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyxvQkFBRCxDQUFSLENBQW5DOztBQUNBLElBQUlDLE9BQU8sR0FBR0Ysc0JBQXNCLENBQUNDLG1CQUFPLENBQUMseUZBQUQsQ0FBUixDQUFwQzs7QUFDQSxJQUFJMk0sY0FBYyxHQUFHM00sbUJBQU8sQ0FBQyxrRUFBRCxDQUE1Qjs7QUFDQSxJQUFJd00sV0FBVyxHQUFHek0sc0JBQXNCLENBQUNDLG1CQUFPLENBQUMscUVBQUQsQ0FBUixDQUF4Qzs7QUFDQSxTQUFTRCxzQkFBVCxDQUFnQ0ssR0FBaEMsRUFBcUM7QUFDakMsU0FBT0EsR0FBRyxJQUFJQSxHQUFHLENBQUNDLFVBQVgsR0FBd0JELEdBQXhCLEdBQThCO0FBQ2pDakosSUFBQUEsT0FBTyxFQUFFaUo7QUFEd0IsR0FBckM7QUFHSDs7QUFDRCxNQUFNd00sZUFBZSxHQUFHO0FBQ3BCMVUsRUFBQUEsTUFBTSxFQUFFLElBRFk7QUFFcEIyVSxFQUFBQSxjQUFjLEVBQUUsRUFGSTs7QUFHcEJDLEVBQUFBLEtBQUssQ0FBRS9HLEVBQUYsRUFBTTtBQUNQLFFBQUksS0FBSzdOLE1BQVQsRUFBaUIsT0FBTzZOLEVBQUUsRUFBVDs7QUFDakIsZUFBbUMsRUFFbEM7QUFDSjs7QUFSbUIsQ0FBeEIsRUFVQTs7QUFDQSxNQUFNZ0gsaUJBQWlCLEdBQUcsQ0FDdEIsVUFEc0IsRUFFdEIsT0FGc0IsRUFHdEIsT0FIc0IsRUFJdEIsUUFKc0IsRUFLdEIsWUFMc0IsRUFNdEIsWUFOc0IsRUFPdEIsVUFQc0IsRUFRdEIsUUFSc0IsRUFTdEIsU0FUc0IsRUFVdEIsZUFWc0IsRUFXdEIsU0FYc0IsRUFZdEIsV0Fac0IsRUFhdEIsZ0JBYnNCLEVBY3RCLGVBZHNCLENBQTFCO0FBZ0JBLE1BQU1DLFlBQVksR0FBRyxDQUNqQixrQkFEaUIsRUFFakIscUJBRmlCLEVBR2pCLHFCQUhpQixFQUlqQixrQkFKaUIsRUFLakIsaUJBTGlCLEVBTWpCLG9CQU5pQixDQUFyQjtBQVFBLE1BQU1DLGdCQUFnQixHQUFHLENBQ3JCLE1BRHFCLEVBRXJCLFNBRnFCLEVBR3JCLFFBSHFCLEVBSXJCLE1BSnFCLEVBS3JCLFVBTHFCLEVBTXJCLGdCQU5xQixDQUF6QixFQVFBOztBQUNBdE4sTUFBTSxDQUFDQyxjQUFQLENBQXNCZ04sZUFBdEIsRUFBdUMsUUFBdkMsRUFBaUQ7QUFDN0N4RixFQUFBQSxHQUFHLEdBQUk7QUFDSCxXQUFPbkgsT0FBTyxDQUFDOUksT0FBUixDQUFnQitWLE1BQXZCO0FBQ0g7O0FBSDRDLENBQWpEO0FBS0FILGlCQUFpQixDQUFDMUssT0FBbEIsQ0FBMkI4SyxLQUFELElBQVM7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQXhOLEVBQUFBLE1BQU0sQ0FBQ0MsY0FBUCxDQUFzQmdOLGVBQXRCLEVBQXVDTyxLQUF2QyxFQUE4QztBQUMxQy9GLElBQUFBLEdBQUcsR0FBSTtBQUNILFlBQU1sUCxNQUFNLEdBQUdrVixTQUFTLEVBQXhCO0FBQ0EsYUFBT2xWLE1BQU0sQ0FBQ2lWLEtBQUQsQ0FBYjtBQUNIOztBQUp5QyxHQUE5QztBQU1ILENBWEQ7QUFZQUYsZ0JBQWdCLENBQUM1SyxPQUFqQixDQUEwQjhLLEtBQUQsSUFBUztBQUM5QlAsRUFBQUEsZUFBZSxDQUFDTyxLQUFELENBQWYsR0FBeUIsQ0FBQyxHQUFHdEwsSUFBSixLQUFXO0FBQ2hDLFVBQU0zSixNQUFNLEdBQUdrVixTQUFTLEVBQXhCO0FBQ0EsV0FBT2xWLE1BQU0sQ0FBQ2lWLEtBQUQsQ0FBTixDQUFjLEdBQUd0TCxJQUFqQixDQUFQO0FBQ0gsR0FIRDtBQUlILENBTEQ7QUFNQW1MLFlBQVksQ0FBQzNLLE9BQWIsQ0FBc0J0QixLQUFELElBQVM7QUFDMUI2TCxFQUFBQSxlQUFlLENBQUNFLEtBQWhCLENBQXNCLE1BQUk7QUFDdEI3TSxJQUFBQSxPQUFPLENBQUM5SSxPQUFSLENBQWdCK1YsTUFBaEIsQ0FBdUJHLEVBQXZCLENBQTBCdE0sS0FBMUIsRUFBaUMsQ0FBQyxHQUFHYyxJQUFKLEtBQVc7QUFDeEMsWUFBTXlMLFVBQVUsR0FBSSxLQUFJdk0sS0FBSyxDQUFDd00sTUFBTixDQUFhLENBQWIsRUFBZ0JDLFdBQWhCLEVBQThCLEdBQUV6TSxLQUFLLENBQUMwTSxTQUFOLENBQWdCLENBQWhCLENBQW1CLEVBQTNFO0FBQ0EsWUFBTUMsZ0JBQWdCLEdBQUdkLGVBQXpCOztBQUNBLFVBQUljLGdCQUFnQixDQUFDSixVQUFELENBQXBCLEVBQWtDO0FBQzlCLFlBQUk7QUFDQUksVUFBQUEsZ0JBQWdCLENBQUNKLFVBQUQsQ0FBaEIsQ0FBNkIsR0FBR3pMLElBQWhDO0FBQ0gsU0FGRCxDQUVFLE9BQU9qQixHQUFQLEVBQVk7QUFDVnBILFVBQUFBLE9BQU8sQ0FBQytSLEtBQVIsQ0FBZSx3Q0FBdUMrQixVQUFXLEVBQWpFO0FBQ0E5VCxVQUFBQSxPQUFPLENBQUMrUixLQUFSLENBQWUsR0FBRTNLLEdBQUcsQ0FBQytNLE9BQVEsS0FBSS9NLEdBQUcsQ0FBQ2dOLEtBQU0sRUFBM0M7QUFDSDtBQUNKO0FBQ0osS0FYRDtBQVlILEdBYkQ7QUFjSCxDQWZEOztBQWdCQSxTQUFTUixTQUFULEdBQXFCO0FBQ2pCLE1BQUksQ0FBQ1IsZUFBZSxDQUFDMVUsTUFBckIsRUFBNkI7QUFDekIsVUFBTXlWLE9BQU8sR0FBRyxnQ0FBZ0MscUVBQWhEO0FBQ0EsVUFBTSxJQUFJN0wsS0FBSixDQUFVNkwsT0FBVixDQUFOO0FBQ0g7O0FBQ0QsU0FBT2YsZUFBZSxDQUFDMVUsTUFBdkI7QUFDSDs7QUFDRCxJQUFJOE0sUUFBUSxHQUFHNEgsZUFBZjtBQUNBL00sZUFBQSxHQUFrQm1GLFFBQWxCOztBQUNBLFNBQVNwTixTQUFULEdBQXFCO0FBQ2pCLFNBQU9rSSxNQUFNLENBQUMzSSxPQUFQLENBQWUwVyxVQUFmLENBQTBCbEIsY0FBYyxDQUFDbUIsYUFBekMsQ0FBUDtBQUNIOztBQUNELFNBQVNyQixZQUFULENBQXNCLEdBQUc1SyxJQUF6QixFQUErQjtBQUMzQitLLEVBQUFBLGVBQWUsQ0FBQzFVLE1BQWhCLEdBQXlCLElBQUkrSCxPQUFPLENBQUM5SSxPQUFaLENBQW9CLEdBQUcwSyxJQUF2QixDQUF6QjtBQUNBK0ssRUFBQUEsZUFBZSxDQUFDQyxjQUFoQixDQUErQnhLLE9BQS9CLENBQXdDMEQsRUFBRCxJQUFNQSxFQUFFLEVBQS9DO0FBRUE2RyxFQUFBQSxlQUFlLENBQUNDLGNBQWhCLEdBQWlDLEVBQWpDO0FBQ0EsU0FBT0QsZUFBZSxDQUFDMVUsTUFBdkI7QUFDSDs7QUFDRCxTQUFTd1Usd0JBQVQsQ0FBa0N4VSxNQUFsQyxFQUEwQztBQUN0QyxRQUFNZ0ksUUFBUSxHQUFHaEksTUFBakI7QUFDQSxRQUFNNlYsUUFBUSxHQUFHLEVBQWpCOztBQUVBLE9BQUssTUFBTUMsUUFBWCxJQUF1QmpCLGlCQUF2QixFQUF5QztBQUNyQyxRQUFJLE9BQU83TSxRQUFRLENBQUM4TixRQUFELENBQWYsS0FBOEIsUUFBbEMsRUFBNEM7QUFDeENELE1BQUFBLFFBQVEsQ0FBQ0MsUUFBRCxDQUFSLEdBQXFCck8sTUFBTSxDQUFDcU0sTUFBUCxDQUFjaUMsS0FBSyxDQUFDQyxPQUFOLENBQWNoTyxRQUFRLENBQUM4TixRQUFELENBQXRCLElBQW9DLEVBQXBDLEdBQXlDLEVBQXZELEVBQ2xCOU4sUUFBUSxDQUFDOE4sUUFBRCxDQURVLENBQXJCLENBQ3VCO0FBRHZCO0FBR0E7QUFDSDs7QUFDREQsSUFBQUEsUUFBUSxDQUFDQyxRQUFELENBQVIsR0FBcUI5TixRQUFRLENBQUM4TixRQUFELENBQTdCO0FBQ0gsR0FacUMsQ0FhdEM7OztBQUNBRCxFQUFBQSxRQUFRLENBQUNiLE1BQVQsR0FBa0JqTixPQUFPLENBQUM5SSxPQUFSLENBQWdCK1YsTUFBbEM7QUFDQUQsRUFBQUEsZ0JBQWdCLENBQUM1SyxPQUFqQixDQUEwQjhLLEtBQUQsSUFBUztBQUM5QlksSUFBQUEsUUFBUSxDQUFDWixLQUFELENBQVIsR0FBa0IsQ0FBQyxHQUFHdEwsSUFBSixLQUFXO0FBQ3pCLGFBQU8zQixRQUFRLENBQUNpTixLQUFELENBQVIsQ0FBZ0IsR0FBR3RMLElBQW5CLENBQVA7QUFDSCxLQUZEO0FBR0gsR0FKRDtBQUtBLFNBQU9rTSxRQUFQO0FBQ0g7Ozs7Ozs7Ozs7O0FDeEpZOztBQUNicE8sOENBQTZDO0FBQ3pDM0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0E2Ryx1QkFBQSxHQUEwQjhELGVBQTFCOztBQUNBLElBQUk3RCxNQUFNLEdBQUdFLG1CQUFPLENBQUMsb0JBQUQsQ0FBcEI7O0FBQ0EsSUFBSStHLG9CQUFvQixHQUFHL0csbUJBQU8sQ0FBQyx5RkFBRCxDQUFsQzs7QUFDQSxNQUFNbU8sdUJBQXVCLEdBQUcsT0FBT0Msb0JBQVAsS0FBZ0MsV0FBaEU7O0FBQ0EsU0FBU3pLLGVBQVQsQ0FBeUI7QUFBRUMsRUFBQUEsVUFBRjtBQUFleUssRUFBQUE7QUFBZixDQUF6QixFQUFxRDtBQUNqRCxRQUFNQyxVQUFVLEdBQUdELFFBQVEsSUFBSSxDQUFDRix1QkFBaEM7QUFDQSxRQUFNSSxTQUFTLEdBQUcsQ0FBQyxHQUFHek8sTUFBSixFQUFZOEMsTUFBWixFQUFsQjtBQUNBLFFBQU0sQ0FBQzRMLE9BQUQsRUFBVUMsVUFBVixJQUF3QixDQUFDLEdBQUczTyxNQUFKLEVBQVl2SCxRQUFaLENBQXFCLEtBQXJCLENBQTlCO0FBQ0EsUUFBTXNMLE1BQU0sR0FBRyxDQUFDLEdBQUcvRCxNQUFKLEVBQVlnRSxXQUFaLENBQXlCQyxFQUFELElBQU07QUFDekMsUUFBSXdLLFNBQVMsQ0FBQzFMLE9BQWQsRUFBdUI7QUFDbkIwTCxNQUFBQSxTQUFTLENBQUMxTCxPQUFWO0FBQ0EwTCxNQUFBQSxTQUFTLENBQUMxTCxPQUFWLEdBQW9CNkwsU0FBcEI7QUFDSDs7QUFDRCxRQUFJSixVQUFVLElBQUlFLE9BQWxCLEVBQTJCOztBQUMzQixRQUFJekssRUFBRSxJQUFJQSxFQUFFLENBQUM0SyxPQUFiLEVBQXNCO0FBQ2xCSixNQUFBQSxTQUFTLENBQUMxTCxPQUFWLEdBQW9CK0wsT0FBTyxDQUFDN0ssRUFBRCxFQUFNTCxTQUFELElBQWFBLFNBQVMsSUFBSStLLFVBQVUsQ0FBQy9LLFNBQUQsQ0FBekMsRUFDekI7QUFDRUUsUUFBQUE7QUFERixPQUR5QixDQUEzQjtBQUlIO0FBQ0osR0FaYyxFQVlaLENBQ0MwSyxVQURELEVBRUMxSyxVQUZELEVBR0M0SyxPQUhELENBWlksQ0FBZjtBQWlCQSxHQUFDLEdBQUcxTyxNQUFKLEVBQVlrRSxTQUFaLENBQXNCLE1BQUk7QUFDdEIsUUFBSSxDQUFDbUssdUJBQUwsRUFBOEI7QUFDMUIsVUFBSSxDQUFDSyxPQUFMLEVBQWM7QUFDVixjQUFNSyxZQUFZLEdBQUcsQ0FBQyxHQUFHOUgsb0JBQUosRUFBMEJyQixtQkFBMUIsQ0FBOEMsTUFBSStJLFVBQVUsQ0FBQyxJQUFELENBQTVELENBQXJCO0FBRUEsZUFBTyxNQUFJLENBQUMsR0FBRzFILG9CQUFKLEVBQTBCcEIsa0JBQTFCLENBQTZDa0osWUFBN0MsQ0FBWDtBQUVIO0FBQ0o7QUFDSixHQVRELEVBU0csQ0FDQ0wsT0FERCxDQVRIO0FBWUEsU0FBTyxDQUNIM0ssTUFERyxFQUVIMkssT0FGRyxDQUFQO0FBSUg7O0FBQ0QsU0FBU0ksT0FBVCxDQUFpQkUsT0FBakIsRUFBMEJDLFFBQTFCLEVBQW9DdE8sT0FBcEMsRUFBNkM7QUFDekMsUUFBTTtBQUFFK0YsSUFBQUEsRUFBRjtBQUFPd0ksSUFBQUEsUUFBUDtBQUFrQkMsSUFBQUE7QUFBbEIsTUFBZ0NDLGNBQWMsQ0FBQ3pPLE9BQUQsQ0FBcEQ7QUFDQXdPLEVBQUFBLFFBQVEsQ0FBQ3ZILEdBQVQsQ0FBYW9ILE9BQWIsRUFBc0JDLFFBQXRCO0FBQ0FDLEVBQUFBLFFBQVEsQ0FBQ0osT0FBVCxDQUFpQkUsT0FBakI7QUFDQSxTQUFPLFNBQVNQLFNBQVQsR0FBcUI7QUFDeEJVLElBQUFBLFFBQVEsQ0FBQ0UsTUFBVCxDQUFnQkwsT0FBaEI7QUFDQUUsSUFBQUEsUUFBUSxDQUFDVCxTQUFULENBQW1CTyxPQUFuQixFQUZ3QixDQUd4Qjs7QUFDQSxRQUFJRyxRQUFRLENBQUNHLElBQVQsS0FBa0IsQ0FBdEIsRUFBeUI7QUFDckJKLE1BQUFBLFFBQVEsQ0FBQ0ssVUFBVDtBQUNBQyxNQUFBQSxTQUFTLENBQUNILE1BQVYsQ0FBaUIzSSxFQUFqQjtBQUNIO0FBQ0osR0FSRDtBQVNIOztBQUNELE1BQU04SSxTQUFTLEdBQUcsSUFBSTlFLEdBQUosRUFBbEI7O0FBQ0EsU0FBUzBFLGNBQVQsQ0FBd0J6TyxPQUF4QixFQUFpQztBQUM3QixRQUFNK0YsRUFBRSxHQUFHL0YsT0FBTyxDQUFDbUQsVUFBUixJQUFzQixFQUFqQztBQUNBLE1BQUltSyxRQUFRLEdBQUd1QixTQUFTLENBQUNsSSxHQUFWLENBQWNaLEVBQWQsQ0FBZjs7QUFDQSxNQUFJdUgsUUFBSixFQUFjO0FBQ1YsV0FBT0EsUUFBUDtBQUNIOztBQUNELFFBQU1rQixRQUFRLEdBQUcsSUFBSXpFLEdBQUosRUFBakI7QUFDQSxRQUFNd0UsUUFBUSxHQUFHLElBQUlaLG9CQUFKLENBQTBCbUIsT0FBRCxJQUFXO0FBQ2pEQSxJQUFBQSxPQUFPLENBQUNsTixPQUFSLENBQWlCOEUsS0FBRCxJQUFTO0FBQ3JCLFlBQU00SCxRQUFRLEdBQUdFLFFBQVEsQ0FBQzdILEdBQVQsQ0FBYUQsS0FBSyxDQUFDcE8sTUFBbkIsQ0FBakI7QUFDQSxZQUFNMkssU0FBUyxHQUFHeUQsS0FBSyxDQUFDcUksY0FBTixJQUF3QnJJLEtBQUssQ0FBQ3NJLGlCQUFOLEdBQTBCLENBQXBFOztBQUNBLFVBQUlWLFFBQVEsSUFBSXJMLFNBQWhCLEVBQTJCO0FBQ3ZCcUwsUUFBQUEsUUFBUSxDQUFDckwsU0FBRCxDQUFSO0FBQ0g7QUFDSixLQU5EO0FBT0gsR0FSZ0IsRUFRZGpELE9BUmMsQ0FBakI7QUFTQTZPLEVBQUFBLFNBQVMsQ0FBQzVILEdBQVYsQ0FBY2xCLEVBQWQsRUFBa0J1SCxRQUFRLEdBQUc7QUFDekJ2SCxJQUFBQSxFQUR5QjtBQUV6QndJLElBQUFBLFFBRnlCO0FBR3pCQyxJQUFBQTtBQUh5QixHQUE3QjtBQUtBLFNBQU9sQixRQUFQO0FBQ0g7Ozs7Ozs7Ozs7O0FDbkZZOztBQUNicE8sOENBQTZDO0FBQ3pDM0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0E2RyxlQUFBLEdBQWtCNlAsVUFBbEI7O0FBQ0EsSUFBSTVQLE1BQU0sR0FBR0Msc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBUixDQUFuQzs7QUFDQSxJQUFJQyxPQUFPLEdBQUdELG1CQUFPLENBQUMsMkRBQUQsQ0FBckI7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NLLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ2pKLElBQUFBLE9BQU8sRUFBRWlKO0FBRHdCLEdBQXJDO0FBR0g7O0FBQ0QsU0FBU3NQLFVBQVQsQ0FBb0JDLGlCQUFwQixFQUF1QztBQUNuQyxXQUFTQyxpQkFBVCxDQUEyQnBhLEtBQTNCLEVBQWtDO0FBQzlCLFdBQU8sYUFBY3NLLE1BQU0sQ0FBQzNJLE9BQVAsQ0FBZWdNLGFBQWYsQ0FBNkJ3TSxpQkFBN0IsRUFBZ0RoUSxNQUFNLENBQUNxTSxNQUFQLENBQWM7QUFDL0U5VCxNQUFBQSxNQUFNLEVBQUUsQ0FBQyxHQUFHK0gsT0FBSixFQUFhckksU0FBYjtBQUR1RSxLQUFkLEVBRWxFcEMsS0FGa0UsQ0FBaEQsQ0FBckI7QUFHSDs7QUFDRG9hLEVBQUFBLGlCQUFpQixDQUFDQyxlQUFsQixHQUFvQ0YsaUJBQWlCLENBQUNFLGVBQXREO0FBQ0FELEVBQUFBLGlCQUFpQixDQUFDRSxtQkFBbEIsR0FBd0NILGlCQUFpQixDQUFDRyxtQkFBMUQ7O0FBQ0EsWUFBMkM7QUFDdkMsVUFBTUMsSUFBSSxHQUFHSixpQkFBaUIsQ0FBQ0ssV0FBbEIsSUFBaUNMLGlCQUFpQixDQUFDSSxJQUFuRCxJQUEyRCxTQUF4RTtBQUNBSCxJQUFBQSxpQkFBaUIsQ0FBQ0ksV0FBbEIsR0FBaUMsY0FBYUQsSUFBSyxHQUFuRDtBQUNIOztBQUNELFNBQU9ILGlCQUFQO0FBQ0g7Ozs7Ozs7Ozs7O0FDekJZOztBQUNialEsOENBQTZDO0FBQ3pDM0csRUFBQUEsS0FBSyxFQUFFO0FBRGtDLENBQTdDO0FBR0E2Ryx1QkFBQSxHQUEwQjRFLGVBQTFCO0FBQ0E1RSxpQkFBQSxHQUFvQmdGLFNBQXBCO0FBQ0FoRixpQkFBQSxHQUFvQm9RLFNBQXBCO0FBQ0FwUSxtQkFBQSxHQUFzQnFRLFdBQXRCO0FBQ0FyUSxtQkFBQSxHQUFzQitFLFdBQXRCO0FBQ0EvRSxtQkFBQSxHQUFzQnNRLFdBQXRCO0FBQ0F0USxrQkFBQSxHQUFxQmEsVUFBckI7QUFDQWIscUJBQUEsR0FBd0J1USxhQUF4QjtBQUNBdlEsbUJBQUEsR0FBc0JxRCxXQUF0QjtBQUNBckQsZUFBQSxHQUFrQixLQUFLLENBQXZCOztBQUNBLElBQUl3USx1QkFBdUIsR0FBR3JRLG1CQUFPLENBQUMsNkdBQUQsQ0FBckM7O0FBQ0EsSUFBSXNRLFlBQVksR0FBR3RRLG1CQUFPLENBQUMscUZBQUQsQ0FBMUI7O0FBQ0EsSUFBSXVRLG9CQUFvQixHQUFHdlEsbUJBQU8sQ0FBQyxvRkFBRCxDQUFsQzs7QUFDQSxJQUFJd1Esb0JBQW9CLEdBQUd4USxtQkFBTyxDQUFDLG9FQUFELENBQWxDOztBQUNBLElBQUl5USxLQUFLLEdBQUcxUSxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyx3QkFBRCxDQUFSLENBQWxDOztBQUNBLElBQUkwUSxNQUFNLEdBQUcxUSxtQkFBTyxDQUFDLHFDQUFELENBQXBCOztBQUNBLElBQUkyUSxVQUFVLEdBQUczUSxtQkFBTyxDQUFDLDhDQUFELENBQXhCOztBQUNBLElBQUk0USxpQkFBaUIsR0FBRzVRLG1CQUFPLENBQUMsOERBQUQsQ0FBL0I7O0FBQ0EsSUFBSTZRLFlBQVksR0FBRzdRLG1CQUFPLENBQUMsZ0RBQUQsQ0FBMUI7O0FBQ0EsSUFBSThRLGdCQUFnQixHQUFHL1Esc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsdUNBQUQsQ0FBUixDQUE3Qzs7QUFDQSxJQUFJK1EsYUFBYSxHQUFHL1EsbUJBQU8sQ0FBQyxvREFBRCxDQUEzQjs7QUFDQSxJQUFJZ1IsV0FBVyxHQUFHaFIsbUJBQU8sQ0FBQyxnREFBRCxDQUF6Qjs7QUFDQSxTQUFTRCxzQkFBVCxDQUFnQ0ssR0FBaEMsRUFBcUM7QUFDakMsU0FBT0EsR0FBRyxJQUFJQSxHQUFHLENBQUNDLFVBQVgsR0FBd0JELEdBQXhCLEdBQThCO0FBQ2pDakosSUFBQUEsT0FBTyxFQUFFaUo7QUFEd0IsR0FBckM7QUFHSDs7QUFDRCxJQUFJNlEsa0JBQUo7O0FBQ0EsSUFBSTNMLEtBQUosRUFBcUMsRUFFcEM7O0FBQ0QsTUFBTTZMLFFBQVEsR0FBRzdMLE1BQUEsSUFBc0MsRUFBdkQ7O0FBQ0EsU0FBUytMLHNCQUFULEdBQWtDO0FBQzlCLFNBQU8xUixNQUFNLENBQUNxTSxNQUFQLENBQWMsSUFBSWxLLEtBQUosQ0FBVSxpQkFBVixDQUFkLEVBQTRDO0FBQy9DMkgsSUFBQUEsU0FBUyxFQUFFO0FBRG9DLEdBQTVDLENBQVA7QUFHSDs7QUFDRCxTQUFTNkgsYUFBVCxDQUF1Qm5NLElBQXZCLEVBQTZCb00sTUFBN0IsRUFBcUM7QUFDakMsU0FBT0EsTUFBTSxJQUFJcE0sSUFBSSxDQUFDcU0sVUFBTCxDQUFnQixHQUFoQixDQUFWLEdBQWlDck0sSUFBSSxLQUFLLEdBQVQsR0FBZSxDQUFDLEdBQUdrTCx1QkFBSixFQUE2Qm5MLDBCQUE3QixDQUF3RHFNLE1BQXhELENBQWYsR0FBa0YsR0FBRUEsTUFBTyxHQUFFRSxlQUFlLENBQUN0TSxJQUFELENBQWYsS0FBMEIsR0FBMUIsR0FBZ0NBLElBQUksQ0FBQ3NJLFNBQUwsQ0FBZSxDQUFmLENBQWhDLEdBQW9EdEksSUFBSyxFQUF2TCxHQUEyTEEsSUFBbE07QUFDSDs7QUFDRCxTQUFTVixlQUFULENBQXlCVSxJQUF6QixFQUErQnJNLE1BQS9CLEVBQXVDNEwsT0FBdkMsRUFBZ0RDLGFBQWhELEVBQStEO0FBQzNELE1BQUlXLEtBQUosRUFBcUMsRUFBckMsTUFPTztBQUNILFdBQU8sS0FBUDtBQUNIO0FBQ0o7O0FBQ0QsU0FBU1QsU0FBVCxDQUFtQk0sSUFBbkIsRUFBeUJyTSxNQUF6QixFQUFpQ2dNLGFBQWpDLEVBQWdEO0FBQzVDLE1BQUlRLEtBQUosRUFBcUMsRUFLcEM7O0FBQ0QsU0FBT0gsSUFBUDtBQUNIOztBQUNELFNBQVM4SyxTQUFULENBQW1COUssSUFBbkIsRUFBeUJyTSxNQUF6QixFQUFpQztBQUM3QixNQUFJd00sS0FBSixFQUFxQyxFQUtwQzs7QUFDRCxTQUFPSCxJQUFQO0FBQ0g7O0FBQ0QsU0FBU3NNLGVBQVQsQ0FBeUJ0TSxJQUF6QixFQUErQjtBQUMzQixRQUFNaU4sVUFBVSxHQUFHak4sSUFBSSxDQUFDeEQsT0FBTCxDQUFhLEdBQWIsQ0FBbkI7QUFDQSxRQUFNMFEsU0FBUyxHQUFHbE4sSUFBSSxDQUFDeEQsT0FBTCxDQUFhLEdBQWIsQ0FBbEI7O0FBQ0EsTUFBSXlRLFVBQVUsR0FBRyxDQUFDLENBQWQsSUFBbUJDLFNBQVMsR0FBRyxDQUFDLENBQXBDLEVBQXVDO0FBQ25DbE4sSUFBQUEsSUFBSSxHQUFHQSxJQUFJLENBQUNzSSxTQUFMLENBQWUsQ0FBZixFQUFrQjJFLFVBQVUsR0FBRyxDQUFDLENBQWQsR0FBa0JBLFVBQWxCLEdBQStCQyxTQUFqRCxDQUFQO0FBQ0g7O0FBQ0QsU0FBT2xOLElBQVA7QUFDSDs7QUFDRCxTQUFTK0ssV0FBVCxDQUFxQi9LLElBQXJCLEVBQTJCO0FBQ3ZCQSxFQUFBQSxJQUFJLEdBQUdzTSxlQUFlLENBQUN0TSxJQUFELENBQXRCO0FBQ0EsU0FBT0EsSUFBSSxLQUFLZ00sUUFBVCxJQUFxQmhNLElBQUksQ0FBQ3FNLFVBQUwsQ0FBZ0JMLFFBQVEsR0FBRyxHQUEzQixDQUE1QjtBQUNIOztBQUNELFNBQVN2TSxXQUFULENBQXFCTyxJQUFyQixFQUEyQjtBQUN2QjtBQUNBLFNBQU9tTSxhQUFhLENBQUNuTSxJQUFELEVBQU9nTSxRQUFQLENBQXBCO0FBQ0g7O0FBQ0QsU0FBU2hCLFdBQVQsQ0FBcUJoTCxJQUFyQixFQUEyQjtBQUN2QkEsRUFBQUEsSUFBSSxHQUFHQSxJQUFJLENBQUNFLEtBQUwsQ0FBVzhMLFFBQVEsQ0FBQ2UsTUFBcEIsQ0FBUDtBQUNBLE1BQUksQ0FBQy9NLElBQUksQ0FBQ3FNLFVBQUwsQ0FBZ0IsR0FBaEIsQ0FBTCxFQUEyQnJNLElBQUksR0FBSSxJQUFHQSxJQUFLLEVBQWhCO0FBQzNCLFNBQU9BLElBQVA7QUFDSDs7QUFDRCxTQUFTekUsVUFBVCxDQUFvQjRSLEdBQXBCLEVBQXlCO0FBQ3JCO0FBQ0EsTUFBSUEsR0FBRyxDQUFDZCxVQUFKLENBQWUsR0FBZixLQUF1QmMsR0FBRyxDQUFDZCxVQUFKLENBQWUsR0FBZixDQUF2QixJQUE4Q2MsR0FBRyxDQUFDZCxVQUFKLENBQWUsR0FBZixDQUFsRCxFQUF1RSxPQUFPLElBQVA7O0FBQ3ZFLE1BQUk7QUFDQTtBQUNBLFVBQU1lLGNBQWMsR0FBRyxDQUFDLEdBQUc3QixNQUFKLEVBQVk4QixpQkFBWixFQUF2QjtBQUNBLFVBQU1DLFFBQVEsR0FBRyxJQUFJQyxHQUFKLENBQVFKLEdBQVIsRUFBYUMsY0FBYixDQUFqQjtBQUNBLFdBQU9FLFFBQVEsQ0FBQ0UsTUFBVCxLQUFvQkosY0FBcEIsSUFBc0NyQyxXQUFXLENBQUN1QyxRQUFRLENBQUN2WixRQUFWLENBQXhEO0FBQ0gsR0FMRCxDQUtFLE9BQU9vSixDQUFQLEVBQVU7QUFDUixXQUFPLEtBQVA7QUFDSDtBQUNKOztBQUNELFNBQVM4TixhQUFULENBQXVCcEcsS0FBdkIsRUFBOEI0SSxVQUE5QixFQUEwQ3hhLEtBQTFDLEVBQWlEO0FBQzdDLE1BQUl5YSxpQkFBaUIsR0FBRyxFQUF4QjtBQUNBLFFBQU1DLFlBQVksR0FBRyxDQUFDLEdBQUc5QixXQUFKLEVBQWlCK0IsYUFBakIsQ0FBK0IvSSxLQUEvQixDQUFyQjtBQUNBLFFBQU1nSixhQUFhLEdBQUdGLFlBQVksQ0FBQ0csTUFBbkM7QUFDQSxRQUFNQyxjQUFjLEdBQUc7QUFDdkIsR0FBQ04sVUFBVSxLQUFLNUksS0FBZixHQUF1QixDQUFDLEdBQUcrRyxhQUFKLEVBQW1Cb0MsZUFBbkIsQ0FBbUNMLFlBQW5DLEVBQWlERixVQUFqRCxDQUF2QixHQUFzRixFQUF2RixLQUE4RjtBQUM5RjtBQUNBeGEsRUFBQUEsS0FIQTtBQUlBeWEsRUFBQUEsaUJBQWlCLEdBQUc3SSxLQUFwQjtBQUNBLFFBQU1vSixNQUFNLEdBQUd6VCxNQUFNLENBQUN5QyxJQUFQLENBQVk0USxhQUFaLENBQWY7O0FBQ0EsTUFBSSxDQUFDSSxNQUFNLENBQUNDLEtBQVAsQ0FBY0MsS0FBRCxJQUFTO0FBQ3ZCLFFBQUl0YSxLQUFLLEdBQUdrYSxjQUFjLENBQUNJLEtBQUQsQ0FBZCxJQUF5QixFQUFyQztBQUNBLFVBQU07QUFBRUMsTUFBQUEsTUFBRjtBQUFXQyxNQUFBQTtBQUFYLFFBQXlCUixhQUFhLENBQUNNLEtBQUQsQ0FBNUMsQ0FGdUIsQ0FHdkI7QUFDQTs7QUFDQSxRQUFJRyxRQUFRLEdBQUksSUFBR0YsTUFBTSxHQUFHLEtBQUgsR0FBVyxFQUFHLEdBQUVELEtBQU0sR0FBL0M7O0FBQ0EsUUFBSUUsUUFBSixFQUFjO0FBQ1ZDLE1BQUFBLFFBQVEsR0FBSSxHQUFFLENBQUN6YSxLQUFELEdBQVMsR0FBVCxHQUFlLEVBQUcsSUFBR3lhLFFBQVMsR0FBNUM7QUFDSDs7QUFDRCxRQUFJRixNQUFNLElBQUksQ0FBQ3RGLEtBQUssQ0FBQ0MsT0FBTixDQUFjbFYsS0FBZCxDQUFmLEVBQXFDQSxLQUFLLEdBQUcsQ0FDekNBLEtBRHlDLENBQVI7QUFHckMsV0FBTyxDQUFDd2EsUUFBUSxJQUFJRixLQUFLLElBQUlKLGNBQXRCLE1BQ05MLGlCQUFpQixHQUFHQSxpQkFBaUIsQ0FBQ3JSLE9BQWxCLENBQTBCaVMsUUFBMUIsRUFBb0NGLE1BQU0sR0FBR3ZhLEtBQUssQ0FBQ1UsR0FBTixFQUFVO0FBQzVFO0FBQ0E7QUFDQTtBQUNDZ2EsSUFBQUEsT0FBRCxJQUFXQyxrQkFBa0IsQ0FBQ0QsT0FBRCxDQUpxQyxFQUtoRUUsSUFMZ0UsQ0FLM0QsR0FMMkQsQ0FBSCxHQUtqREQsa0JBQWtCLENBQUMzYSxLQUFELENBTFgsS0FLdUIsR0FOckMsQ0FBUDtBQU9ILEdBbkJJLENBQUwsRUFtQkk7QUFDQTZaLElBQUFBLGlCQUFpQixHQUFHLEVBQXBCLENBQXVCO0FBQXZCLEtBREEsQ0FHSjtBQUNBO0FBQ0M7O0FBQ0QsU0FBTztBQUNITyxJQUFBQSxNQURHO0FBRUhTLElBQUFBLE1BQU0sRUFBRWhCO0FBRkwsR0FBUDtBQUlIOztBQUNELFNBQVNpQixrQkFBVCxDQUE0QjFiLEtBQTVCLEVBQW1DZ2IsTUFBbkMsRUFBMkM7QUFDdkMsUUFBTVcsYUFBYSxHQUFHLEVBQXRCO0FBRUFwVSxFQUFBQSxNQUFNLENBQUN5QyxJQUFQLENBQVloSyxLQUFaLEVBQW1CaUssT0FBbkIsQ0FBNEJOLEdBQUQsSUFBTztBQUM5QixRQUFJLENBQUNxUixNQUFNLENBQUNZLFFBQVAsQ0FBZ0JqUyxHQUFoQixDQUFMLEVBQTJCO0FBQ3ZCZ1MsTUFBQUEsYUFBYSxDQUFDaFMsR0FBRCxDQUFiLEdBQXFCM0osS0FBSyxDQUFDMkosR0FBRCxDQUExQjtBQUNIO0FBQ0osR0FKRDtBQUtBLFNBQU9nUyxhQUFQO0FBQ0g7O0FBQ0QsU0FBUzdRLFdBQVQsQ0FBcUJoTCxNQUFyQixFQUE2QlosSUFBN0IsRUFBbUMyYyxTQUFuQyxFQUE4QztBQUMxQztBQUNBLE1BQUlDLElBQUo7QUFDQSxNQUFJQyxXQUFXLEdBQUcsT0FBTzdjLElBQVAsS0FBZ0IsUUFBaEIsR0FBMkJBLElBQTNCLEdBQWtDLENBQUMsR0FBR29aLE1BQUosRUFBWTBELG9CQUFaLENBQWlDOWMsSUFBakMsQ0FBcEQsQ0FIMEMsQ0FJMUM7QUFDQTs7QUFDQSxRQUFNK2MsYUFBYSxHQUFHRixXQUFXLENBQUNHLEtBQVosQ0FBa0Isb0JBQWxCLENBQXRCO0FBQ0EsUUFBTUMsa0JBQWtCLEdBQUdGLGFBQWEsR0FBR0YsV0FBVyxDQUFDaEMsTUFBWixDQUFtQmtDLGFBQWEsQ0FBQyxDQUFELENBQWIsQ0FBaUJuQyxNQUFwQyxDQUFILEdBQWlEaUMsV0FBekY7QUFDQSxRQUFNSyxRQUFRLEdBQUdELGtCQUFrQixDQUFDRSxLQUFuQixDQUF5QixHQUF6QixDQUFqQjs7QUFDQSxNQUFJLENBQUNELFFBQVEsQ0FBQyxDQUFELENBQVIsSUFBZSxFQUFoQixFQUFvQkYsS0FBcEIsQ0FBMEIsV0FBMUIsQ0FBSixFQUE0QztBQUN4QzlhLElBQUFBLE9BQU8sQ0FBQytSLEtBQVIsQ0FBZSx1Q0FBc0M0SSxXQUFZLDZFQUFqRTtBQUNBLFVBQU1PLGFBQWEsR0FBRyxDQUFDLEdBQUdoRSxNQUFKLEVBQVlpRSx3QkFBWixDQUFxQ0osa0JBQXJDLENBQXRCO0FBQ0FKLElBQUFBLFdBQVcsR0FBRyxDQUFDRSxhQUFhLEdBQUdBLGFBQWEsQ0FBQyxDQUFELENBQWhCLEdBQXNCLEVBQXBDLElBQTBDSyxhQUF4RDtBQUNILEdBYnlDLENBYzFDOzs7QUFDQSxNQUFJLENBQUNoVSxVQUFVLENBQUN5VCxXQUFELENBQWYsRUFBOEI7QUFDMUIsV0FBT0YsU0FBUyxHQUFHLENBQ2ZFLFdBRGUsQ0FBSCxHQUVaQSxXQUZKO0FBR0g7O0FBQ0QsTUFBSTtBQUNBRCxJQUFBQSxJQUFJLEdBQUcsSUFBSXhCLEdBQUosQ0FBUXlCLFdBQVcsQ0FBQzNDLFVBQVosQ0FBdUIsR0FBdkIsSUFBOEJ0WixNQUFNLENBQUNpQixNQUFyQyxHQUE4Q2pCLE1BQU0sQ0FBQ2dCLFFBQTdELEVBQXVFLFVBQXZFLENBQVA7QUFDSCxHQUZELENBRUUsT0FBT29KLENBQVAsRUFBVTtBQUNSO0FBQ0E0UixJQUFBQSxJQUFJLEdBQUcsSUFBSXhCLEdBQUosQ0FBUSxHQUFSLEVBQWEsVUFBYixDQUFQO0FBQ0g7O0FBQ0QsTUFBSTtBQUNBLFVBQU1rQyxRQUFRLEdBQUcsSUFBSWxDLEdBQUosQ0FBUXlCLFdBQVIsRUFBcUJELElBQXJCLENBQWpCO0FBQ0FVLElBQUFBLFFBQVEsQ0FBQzFiLFFBQVQsR0FBb0IsQ0FBQyxHQUFHbVgsdUJBQUosRUFBNkJuTCwwQkFBN0IsQ0FBd0QwUCxRQUFRLENBQUMxYixRQUFqRSxDQUFwQjtBQUNBLFFBQUkyYixjQUFjLEdBQUcsRUFBckI7O0FBQ0EsUUFBSSxDQUFDLEdBQUdsRSxVQUFKLEVBQWdCbUUsY0FBaEIsQ0FBK0JGLFFBQVEsQ0FBQzFiLFFBQXhDLEtBQXFEMGIsUUFBUSxDQUFDRyxZQUE5RCxJQUE4RWQsU0FBbEYsRUFBNkY7QUFDekYsWUFBTTdiLEtBQUssR0FBRyxDQUFDLEdBQUd5WSxZQUFKLEVBQWtCbUUsc0JBQWxCLENBQXlDSixRQUFRLENBQUNHLFlBQWxELENBQWQ7QUFDQSxZQUFNO0FBQUVsQixRQUFBQSxNQUFGO0FBQVdULFFBQUFBO0FBQVgsVUFBdUJoRCxhQUFhLENBQUN3RSxRQUFRLENBQUMxYixRQUFWLEVBQW9CMGIsUUFBUSxDQUFDMWIsUUFBN0IsRUFBdUNkLEtBQXZDLENBQTFDOztBQUNBLFVBQUl5YixNQUFKLEVBQVk7QUFDUmdCLFFBQUFBLGNBQWMsR0FBRyxDQUFDLEdBQUduRSxNQUFKLEVBQVkwRCxvQkFBWixDQUFpQztBQUM5Q2xiLFVBQUFBLFFBQVEsRUFBRTJhLE1BRG9DO0FBRTlDb0IsVUFBQUEsSUFBSSxFQUFFTCxRQUFRLENBQUNLLElBRitCO0FBRzlDN2MsVUFBQUEsS0FBSyxFQUFFMGIsa0JBQWtCLENBQUMxYixLQUFELEVBQVFnYixNQUFSO0FBSHFCLFNBQWpDLENBQWpCO0FBS0g7QUFDSixLQWRELENBZUE7OztBQUNBLFVBQU1wUSxZQUFZLEdBQUc0UixRQUFRLENBQUNqQyxNQUFULEtBQW9CdUIsSUFBSSxDQUFDdkIsTUFBekIsR0FBa0NpQyxRQUFRLENBQUN0ZCxJQUFULENBQWMrTixLQUFkLENBQW9CdVAsUUFBUSxDQUFDakMsTUFBVCxDQUFnQlQsTUFBcEMsQ0FBbEMsR0FBZ0YwQyxRQUFRLENBQUN0ZCxJQUE5RztBQUNBLFdBQU8yYyxTQUFTLEdBQUcsQ0FDZmpSLFlBRGUsRUFFZjZSLGNBQWMsSUFBSTdSLFlBRkgsQ0FBSCxHQUdaQSxZQUhKO0FBSUgsR0FyQkQsQ0FxQkUsT0FBT1YsQ0FBUCxFQUFVO0FBQ1IsV0FBTzJSLFNBQVMsR0FBRyxDQUNmRSxXQURlLENBQUgsR0FFWkEsV0FGSjtBQUdIO0FBQ0o7O0FBQ0QsU0FBU2UsV0FBVCxDQUFxQjVDLEdBQXJCLEVBQTBCO0FBQ3RCLFFBQU1LLE1BQU0sR0FBRyxDQUFDLEdBQUdqQyxNQUFKLEVBQVk4QixpQkFBWixFQUFmO0FBQ0EsU0FBT0YsR0FBRyxDQUFDZCxVQUFKLENBQWVtQixNQUFmLElBQXlCTCxHQUFHLENBQUM3RSxTQUFKLENBQWNrRixNQUFNLENBQUNULE1BQXJCLENBQXpCLEdBQXdESSxHQUEvRDtBQUNIOztBQUNELFNBQVM2QyxZQUFULENBQXNCamQsTUFBdEIsRUFBOEJvYSxHQUE5QixFQUFtQzlSLEVBQW5DLEVBQXVDO0FBQ25DO0FBQ0E7QUFDQSxNQUFJLENBQUN3QyxZQUFELEVBQWVDLFVBQWYsSUFBNkJDLFdBQVcsQ0FBQ2hMLE1BQUQsRUFBU29hLEdBQVQsRUFBYyxJQUFkLENBQTVDO0FBQ0EsUUFBTUssTUFBTSxHQUFHLENBQUMsR0FBR2pDLE1BQUosRUFBWThCLGlCQUFaLEVBQWY7QUFDQSxRQUFNNEMsYUFBYSxHQUFHcFMsWUFBWSxDQUFDd08sVUFBYixDQUF3Qm1CLE1BQXhCLENBQXRCO0FBQ0EsUUFBTTBDLFdBQVcsR0FBR3BTLFVBQVUsSUFBSUEsVUFBVSxDQUFDdU8sVUFBWCxDQUFzQm1CLE1BQXRCLENBQWxDO0FBQ0EzUCxFQUFBQSxZQUFZLEdBQUdrUyxXQUFXLENBQUNsUyxZQUFELENBQTFCO0FBQ0FDLEVBQUFBLFVBQVUsR0FBR0EsVUFBVSxHQUFHaVMsV0FBVyxDQUFDalMsVUFBRCxDQUFkLEdBQTZCQSxVQUFwRDtBQUNBLFFBQU1xUyxXQUFXLEdBQUdGLGFBQWEsR0FBR3BTLFlBQUgsR0FBa0I0QixXQUFXLENBQUM1QixZQUFELENBQTlEO0FBQ0EsUUFBTXVTLFVBQVUsR0FBRy9VLEVBQUUsR0FBRzBVLFdBQVcsQ0FBQ2hTLFdBQVcsQ0FBQ2hMLE1BQUQsRUFBU3NJLEVBQVQsQ0FBWixDQUFkLEdBQTBDeUMsVUFBVSxJQUFJRCxZQUE3RTtBQUNBLFNBQU87QUFDSHNQLElBQUFBLEdBQUcsRUFBRWdELFdBREY7QUFFSDlVLElBQUFBLEVBQUUsRUFBRTZVLFdBQVcsR0FBR0UsVUFBSCxHQUFnQjNRLFdBQVcsQ0FBQzJRLFVBQUQ7QUFGdkMsR0FBUDtBQUlIOztBQUNELFNBQVNDLG1CQUFULENBQTZCdGMsUUFBN0IsRUFBdUN1YyxLQUF2QyxFQUE4QztBQUMxQyxRQUFNQyxhQUFhLEdBQUcsQ0FBQyxHQUFHckYsdUJBQUosRUFBNkJwTCx1QkFBN0IsQ0FBcUQsQ0FBQyxHQUFHc0wsb0JBQUosRUFBMEJvRixtQkFBMUIsQ0FBOEN6YyxRQUE5QyxDQUFyRCxDQUF0Qjs7QUFDQSxNQUFJd2MsYUFBYSxLQUFLLE1BQWxCLElBQTRCQSxhQUFhLEtBQUssU0FBbEQsRUFBNkQ7QUFDekQsV0FBT3hjLFFBQVA7QUFDSCxHQUp5QyxDQUsxQzs7O0FBQ0EsTUFBSSxDQUFDdWMsS0FBSyxDQUFDekIsUUFBTixDQUFlMEIsYUFBZixDQUFMLEVBQW9DO0FBQ2hDO0FBQ0FELElBQUFBLEtBQUssQ0FBQ0csSUFBTixDQUFZQyxJQUFELElBQVE7QUFDZixVQUFJLENBQUMsR0FBR2xGLFVBQUosRUFBZ0JtRSxjQUFoQixDQUErQmUsSUFBL0IsS0FBd0MsQ0FBQyxHQUFHN0UsV0FBSixFQUFpQitCLGFBQWpCLENBQStCOEMsSUFBL0IsRUFBcUNDLEVBQXJDLENBQXdDclEsSUFBeEMsQ0FBNkNpUSxhQUE3QyxDQUE1QyxFQUF5RztBQUNyR3hjLFFBQUFBLFFBQVEsR0FBRzJjLElBQVg7QUFDQSxlQUFPLElBQVA7QUFDSDtBQUNKLEtBTEQ7QUFNSDs7QUFDRCxTQUFPLENBQUMsR0FBR3hGLHVCQUFKLEVBQTZCcEwsdUJBQTdCLENBQXFEL0wsUUFBckQsQ0FBUDtBQUNIOztBQUNELE1BQU02Yyx1QkFBdUIsR0FBR3pRLE1BQUEsSUFBbUgsQ0FBbko7QUFRQSxNQUFNZ1Isa0JBQWtCLEdBQUd0TixNQUFNLENBQUMsb0JBQUQsQ0FBakM7O0FBQ0EsU0FBU3VOLFVBQVQsQ0FBb0JqRSxHQUFwQixFQUF5QmtFLFFBQXpCLEVBQW1DO0FBQy9CLFNBQU8xTCxLQUFLLENBQUN3SCxHQUFELEVBQU07QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FtRSxJQUFBQSxXQUFXLEVBQUU7QUFaQyxHQUFOLENBQUwsQ0FhSjlPLElBYkksQ0FhRVUsR0FBRCxJQUFPO0FBQ1gsUUFBSSxDQUFDQSxHQUFHLENBQUMwQyxFQUFULEVBQWE7QUFDVCxVQUFJeUwsUUFBUSxHQUFHLENBQVgsSUFBZ0JuTyxHQUFHLENBQUNxTyxNQUFKLElBQWMsR0FBbEMsRUFBdUM7QUFDbkMsZUFBT0gsVUFBVSxDQUFDakUsR0FBRCxFQUFNa0UsUUFBUSxHQUFHLENBQWpCLENBQWpCO0FBQ0g7O0FBQ0QsVUFBSW5PLEdBQUcsQ0FBQ3FPLE1BQUosS0FBZSxHQUFuQixFQUF3QjtBQUNwQixlQUFPck8sR0FBRyxDQUFDc08sSUFBSixHQUFXaFAsSUFBWCxDQUFpQmlQLElBQUQsSUFBUTtBQUMzQixjQUFJQSxJQUFJLENBQUNDLFFBQVQsRUFBbUI7QUFDZixtQkFBTztBQUNIQSxjQUFBQSxRQUFRLEVBQUVQO0FBRFAsYUFBUDtBQUdIOztBQUNELGdCQUFNLElBQUl4VSxLQUFKLENBQVcsNkJBQVgsQ0FBTjtBQUNILFNBUE0sQ0FBUDtBQVFIOztBQUNELFlBQU0sSUFBSUEsS0FBSixDQUFXLDZCQUFYLENBQU47QUFDSDs7QUFDRCxXQUFPdUcsR0FBRyxDQUFDc08sSUFBSixFQUFQO0FBQ0gsR0EvQk0sQ0FBUDtBQWdDSDs7QUFDRCxTQUFTRyxhQUFULENBQXVCQyxRQUF2QixFQUFpQ0MsY0FBakMsRUFBaUQ7QUFDN0MsU0FBT1QsVUFBVSxDQUFDUSxRQUFELEVBQVdDLGNBQWMsR0FBRyxDQUFILEdBQU8sQ0FBaEMsQ0FBVixDQUE2Q3JXLEtBQTdDLENBQW9EQyxHQUFELElBQU87QUFDN0Q7QUFDQTtBQUNBO0FBQ0EsUUFBSSxDQUFDb1csY0FBTCxFQUFxQjtBQUNqQixPQUFDLEdBQUcxRyxZQUFKLEVBQWtCNUosY0FBbEIsQ0FBaUM5RixHQUFqQztBQUNIOztBQUNELFVBQU1BLEdBQU47QUFDSCxHQVJNLENBQVA7QUFTSDs7QUFDRCxNQUFNcVcsTUFBTixDQUFhO0FBQ1RDLEVBQUFBLFdBQVcsQ0FBQ0MsU0FBRCxFQUFZQyxNQUFaLEVBQW9CQyxHQUFwQixFQUF5QjtBQUFFQyxJQUFBQSxZQUFGO0FBQWlCQyxJQUFBQSxVQUFqQjtBQUE4QkMsSUFBQUEsR0FBOUI7QUFBb0NDLElBQUFBLE9BQXBDO0FBQThDQyxJQUFBQSxTQUFTLEVBQUVDLFVBQXpEO0FBQXNFL1csSUFBQUEsR0FBRyxFQUFFZ1gsSUFBM0U7QUFBa0ZDLElBQUFBLFlBQWxGO0FBQWlHQyxJQUFBQSxVQUFqRztBQUE4R2hmLElBQUFBLE1BQTlHO0FBQXVINEwsSUFBQUEsT0FBdkg7QUFBaUlJLElBQUFBLGFBQWpJO0FBQWlKSCxJQUFBQSxhQUFqSjtBQUFpS29ULElBQUFBO0FBQWpLLEdBQXpCLEVBQXVNO0FBQzlNO0FBQ0EsU0FBS0MsR0FBTCxHQUFXLEVBQVgsQ0FGOE0sQ0FJOU07O0FBQ0EsU0FBS0MsR0FBTCxHQUFXLEVBQVg7QUFFQSxTQUFLQyxJQUFMLEdBQVksQ0FBWjs7QUFDQSxTQUFLQyxVQUFMLEdBQW1CdGYsQ0FBRCxJQUFLO0FBQ25CLFlBQU0wRSxLQUFLLEdBQUcxRSxDQUFDLENBQUMwRSxLQUFoQjs7QUFDQSxVQUFJLENBQUNBLEtBQUwsRUFBWTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQU07QUFBRXJFLFVBQUFBLFFBQVEsRUFBRWllLFNBQVo7QUFBd0IvZSxVQUFBQSxLQUFLLEVBQUVnZjtBQUEvQixZQUEyQyxJQUFqRDtBQUNBLGFBQUtnQixXQUFMLENBQWlCLGNBQWpCLEVBQWlDLENBQUMsR0FBRzFILE1BQUosRUFBWTBELG9CQUFaLENBQWlDO0FBQzlEbGIsVUFBQUEsUUFBUSxFQUFFMEwsV0FBVyxDQUFDdVMsU0FBRCxDQUR5QztBQUU5RC9lLFVBQUFBLEtBQUssRUFBRWdmO0FBRnVELFNBQWpDLENBQWpDLEVBR0ksQ0FBQyxHQUFHMUcsTUFBSixFQUFZMkgsTUFBWixFQUhKO0FBSUE7QUFDSDs7QUFDRCxVQUFJLENBQUM5YSxLQUFLLENBQUMrYSxHQUFYLEVBQWdCO0FBQ1o7QUFDSDs7QUFDRCxVQUFJQyxZQUFKO0FBQ0EsWUFBTTtBQUFFakcsUUFBQUEsR0FBRjtBQUFROVIsUUFBQUEsRUFBRSxFQUFFNlcsR0FBWjtBQUFrQjVXLFFBQUFBLE9BQWxCO0FBQTRCK1gsUUFBQUE7QUFBNUIsVUFBcUNqYixLQUEzQzs7QUFDQSxVQUFJK0gsS0FBSixFQUEyQyxFQXVCMUM7O0FBQ0QsV0FBSzRTLElBQUwsR0FBWU0sR0FBWjtBQUNBLFlBQU07QUFBRXRmLFFBQUFBLFFBQVEsRUFBRWllO0FBQVosVUFBMkIsQ0FBQyxHQUFHdkcsaUJBQUosRUFBdUJxSSxnQkFBdkIsQ0FBd0MzRyxHQUF4QyxDQUFqQyxDQWpEbUIsQ0FrRG5CO0FBQ0E7O0FBQ0EsVUFBSSxLQUFLNEcsS0FBTCxJQUFjN0IsR0FBRyxLQUFLLEtBQUtsZSxNQUEzQixJQUFxQ2dlLFNBQVMsS0FBSyxLQUFLamUsUUFBNUQsRUFBc0U7QUFDbEU7QUFDSCxPQXREa0IsQ0F1RG5CO0FBQ0E7OztBQUNBLFVBQUksS0FBS2lnQixJQUFMLElBQWEsQ0FBQyxLQUFLQSxJQUFMLENBQVU1YixLQUFWLENBQWxCLEVBQW9DO0FBQ2hDO0FBQ0g7O0FBQ0QsV0FBSzZiLE1BQUwsQ0FBWSxjQUFaLEVBQTRCOUcsR0FBNUIsRUFBaUMrRSxHQUFqQyxFQUFzQzFYLE1BQU0sQ0FBQ3FNLE1BQVAsQ0FBYyxFQUFkLEVBQ25DdkwsT0FEbUMsRUFDMUI7QUFDUmdCLFFBQUFBLE9BQU8sRUFBRWhCLE9BQU8sQ0FBQ2dCLE9BQVIsSUFBbUIsS0FBSzRYLFFBRHpCO0FBRVJ2Z0IsUUFBQUEsTUFBTSxFQUFFMkgsT0FBTyxDQUFDM0gsTUFBUixJQUFrQixLQUFLZ007QUFGdkIsT0FEMEIsQ0FBdEMsRUFJSXlULFlBSko7QUFLSCxLQWpFRCxDQVI4TSxDQTBFOU07OztBQUNBLFNBQUt2TyxLQUFMLEdBQWEsQ0FBQyxHQUFHcUcsdUJBQUosRUFBNkJwTCx1QkFBN0IsQ0FBcURrUyxTQUFyRCxDQUFiLENBM0U4TSxDQTRFOU07O0FBQ0EsU0FBS21DLFVBQUwsR0FBa0IsRUFBbEIsQ0E3RThNLENBK0U5TTtBQUNBO0FBQ0E7O0FBQ0EsUUFBSW5DLFNBQVMsS0FBSyxTQUFsQixFQUE2QjtBQUN6QixXQUFLbUMsVUFBTCxDQUFnQixLQUFLdFAsS0FBckIsSUFBOEI7QUFDMUIwTixRQUFBQSxTQUFTLEVBQUVDLFVBRGU7QUFFMUI0QixRQUFBQSxPQUFPLEVBQUUsSUFGaUI7QUFHMUIvakIsUUFBQUEsS0FBSyxFQUFFOGhCLFlBSG1CO0FBSTFCMVcsUUFBQUEsR0FBRyxFQUFFZ1gsSUFKcUI7QUFLMUI0QixRQUFBQSxPQUFPLEVBQUVsQyxZQUFZLElBQUlBLFlBQVksQ0FBQ2tDLE9BTFo7QUFNMUJDLFFBQUFBLE9BQU8sRUFBRW5DLFlBQVksSUFBSUEsWUFBWSxDQUFDbUM7QUFOWixPQUE5QjtBQVFIOztBQUNELFNBQUtILFVBQUwsQ0FBZ0IsT0FBaEIsSUFBMkI7QUFDdkI1QixNQUFBQSxTQUFTLEVBQUVGLEdBRFk7QUFFdkI5TSxNQUFBQSxXQUFXLEVBQUU7QUFGVSxLQUEzQixDQTVGOE0sQ0FnRzlNO0FBQ0E7O0FBQ0EsU0FBS3dDLE1BQUwsR0FBYytKLE1BQU0sQ0FBQy9KLE1BQXJCO0FBQ0EsU0FBS3FLLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EsU0FBS3JlLFFBQUwsR0FBZ0JpZSxTQUFoQjtBQUNBLFNBQUsvZSxLQUFMLEdBQWFnZixNQUFiLENBckc4TSxDQXNHOU07QUFDQTs7QUFDQSxVQUFNc0MsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHL0ksVUFBSixFQUFnQm1FLGNBQWhCLENBQStCcUMsU0FBL0IsS0FBNkN2UixJQUFJLENBQUMrVCxhQUFMLENBQW1CQyxVQUExRjs7QUFDQSxTQUFLemdCLE1BQUwsR0FBY3VnQixpQkFBaUIsR0FBR3ZDLFNBQUgsR0FBZUUsR0FBOUM7QUFDQSxTQUFLbEcsUUFBTCxHQUFnQkEsUUFBaEI7QUFDQSxTQUFLMEksR0FBTCxHQUFXaEMsWUFBWDtBQUNBLFNBQUtpQyxHQUFMLEdBQVcsSUFBWDtBQUNBLFNBQUtDLFFBQUwsR0FBZ0J0QyxPQUFoQixDQTdHOE0sQ0E4RzlNO0FBQ0E7O0FBQ0EsU0FBS3lCLEtBQUwsR0FBYSxJQUFiO0FBQ0EsU0FBS3BCLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EsU0FBS2tDLE9BQUwsR0FBZSxDQUFDLEVBQUVwVSxJQUFJLENBQUMrVCxhQUFMLENBQW1CTSxJQUFuQixJQUEyQnJVLElBQUksQ0FBQytULGFBQUwsQ0FBbUJPLEdBQTlDLElBQXFEdFUsSUFBSSxDQUFDK1QsYUFBTCxDQUFtQlEsTUFBbkIsSUFBNkIsQ0FBQ3ZVLElBQUksQ0FBQytULGFBQUwsQ0FBbUJTLEdBQXRHLElBQTZHLENBQUNWLGlCQUFELElBQXNCLENBQUM5VCxJQUFJLENBQUN5VSxRQUFMLENBQWNDLE1BQXJDLElBQStDLENBQUNoVixLQUEvSixDQUFoQjtBQUNBLFNBQUt5UyxTQUFMLEdBQWlCLENBQUMsQ0FBQ0EsU0FBbkI7QUFDQSxTQUFLdlQsY0FBTCxHQUFzQixLQUF0Qjs7QUFDQSxRQUFJYyxLQUFKLEVBQXFDLEVBTXBDOztBQUNELGVBQW1DLEVBdUJsQztBQUNKOztBQUNEc1YsRUFBQUEsTUFBTSxHQUFHO0FBQ0w5VSxJQUFBQSxNQUFNLENBQUN1VSxRQUFQLENBQWdCTyxNQUFoQjtBQUNIO0FBQ0Q7QUFDSjtBQUNBOzs7QUFBTUMsRUFBQUEsSUFBSSxHQUFHO0FBQ0wvVSxJQUFBQSxNQUFNLENBQUNtUSxPQUFQLENBQWU0RSxJQUFmO0FBQ0g7QUFDRDtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUFNNWhCLEVBQUFBLElBQUksQ0FBQ3FaLEdBQUQsRUFBTTlSLEVBQU4sRUFBVUMsT0FBTyxHQUFHLEVBQXBCLEVBQ0g7QUFDQyxRQUFJNkUsS0FBSixFQUEyQyxFQWExQzs7QUFDRCxLQUFDO0FBQUVnTixNQUFBQSxHQUFGO0FBQVE5UixNQUFBQTtBQUFSLFFBQWdCMlUsWUFBWSxDQUFDLElBQUQsRUFBTzdDLEdBQVAsRUFBWTlSLEVBQVosQ0FBN0I7QUFDQSxXQUFPLEtBQUs0WSxNQUFMLENBQVksV0FBWixFQUF5QjlHLEdBQXpCLEVBQThCOVIsRUFBOUIsRUFBa0NDLE9BQWxDLENBQVA7QUFDSDtBQUNEO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQU1lLEVBQUFBLE9BQU8sQ0FBQzhRLEdBQUQsRUFBTTlSLEVBQU4sRUFBVUMsT0FBTyxHQUFHLEVBQXBCLEVBQ047QUFDQyxLQUFDO0FBQUU2UixNQUFBQSxHQUFGO0FBQVE5UixNQUFBQTtBQUFSLFFBQWdCMlUsWUFBWSxDQUFDLElBQUQsRUFBTzdDLEdBQVAsRUFBWTlSLEVBQVosQ0FBN0I7QUFDQSxXQUFPLEtBQUs0WSxNQUFMLENBQVksY0FBWixFQUE0QjlHLEdBQTVCLEVBQWlDOVIsRUFBakMsRUFBcUNDLE9BQXJDLENBQVA7QUFDSDs7QUFDVyxRQUFOMlksTUFBTSxDQUFDMEIsTUFBRCxFQUFTeEksR0FBVCxFQUFjOVIsRUFBZCxFQUFrQkMsT0FBbEIsRUFBMkI4WCxZQUEzQixFQUF5QztBQUNqRCxRQUFJLENBQUM3WCxVQUFVLENBQUM0UixHQUFELENBQWYsRUFBc0I7QUFDbEJ4TSxNQUFBQSxNQUFNLENBQUN1VSxRQUFQLENBQWdCL2lCLElBQWhCLEdBQXVCZ2IsR0FBdkI7QUFDQSxhQUFPLEtBQVA7QUFDSDs7QUFDRCxVQUFNeUksaUJBQWlCLEdBQUd6SSxHQUFHLEtBQUs5UixFQUFSLElBQWNDLE9BQU8sQ0FBQ3VhLEVBQXRCLElBQTRCdmEsT0FBTyxDQUFDZ2Esa0JBQTlELENBTGlELENBTWpEO0FBQ0E7O0FBQ0EsUUFBSWhhLE9BQU8sQ0FBQ3VhLEVBQVosRUFBZ0I7QUFDWixXQUFLaEIsT0FBTCxHQUFlLElBQWY7QUFDSDs7QUFDRCxVQUFNaUIsVUFBVSxHQUFHLEtBQUtuaUIsTUFBeEI7O0FBQ0EsUUFBSXdNLEtBQUosRUFBcUMsWUE2Q3BDOztBQUNELFFBQUksQ0FBQzdFLE9BQU8sQ0FBQ3VhLEVBQWIsRUFBaUI7QUFDYixXQUFLOUIsS0FBTCxHQUFhLEtBQWI7QUFDSCxLQTVEZ0QsQ0E2RGpEOzs7QUFDQSxRQUFJeEksTUFBTSxDQUFDNEssRUFBWCxFQUFlO0FBQ1hDLE1BQUFBLFdBQVcsQ0FBQ0MsSUFBWixDQUFpQixhQUFqQjtBQUNIOztBQUNELFVBQU07QUFBRS9aLE1BQUFBLE9BQU8sR0FBRTtBQUFYLFFBQXNCaEIsT0FBNUI7QUFDQSxVQUFNZ2IsVUFBVSxHQUFHO0FBQ2ZoYSxNQUFBQTtBQURlLEtBQW5COztBQUdBLFFBQUksS0FBS2lhLGNBQVQsRUFBeUI7QUFDckIsV0FBS0Msa0JBQUwsQ0FBd0IsS0FBS0QsY0FBN0IsRUFBNkNELFVBQTdDO0FBQ0g7O0FBQ0RqYixJQUFBQSxFQUFFLEdBQUdvRSxXQUFXLENBQUNDLFNBQVMsQ0FBQ3FMLFdBQVcsQ0FBQzFQLEVBQUQsQ0FBWCxHQUFrQjJQLFdBQVcsQ0FBQzNQLEVBQUQsQ0FBN0IsR0FBb0NBLEVBQXJDLEVBQXlDQyxPQUFPLENBQUMzSCxNQUFqRCxFQUF5RCxLQUFLZ00sYUFBOUQsQ0FBVixDQUFoQjtBQUNBLFVBQU04VyxTQUFTLEdBQUczTCxTQUFTLENBQUNDLFdBQVcsQ0FBQzFQLEVBQUQsQ0FBWCxHQUFrQjJQLFdBQVcsQ0FBQzNQLEVBQUQsQ0FBN0IsR0FBb0NBLEVBQXJDLEVBQXlDLEtBQUsxSCxNQUE5QyxDQUEzQjtBQUNBLFNBQUs0aUIsY0FBTCxHQUFzQmxiLEVBQXRCO0FBQ0EsUUFBSXFiLFlBQVksR0FBR1osVUFBVSxLQUFLLEtBQUtuaUIsTUFBdkMsQ0EzRWlELENBNEVqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUksQ0FBQzJILE9BQU8sQ0FBQ3VhLEVBQVQsSUFBZSxLQUFLYyxlQUFMLENBQXFCRixTQUFyQixDQUFmLElBQWtELENBQUNDLFlBQXZELEVBQXFFO0FBQ2pFLFdBQUsxaUIsTUFBTCxHQUFjeWlCLFNBQWQ7QUFDQTNFLE1BQUFBLE1BQU0sQ0FBQy9KLE1BQVAsQ0FBYzZPLElBQWQsQ0FBbUIsaUJBQW5CLEVBQXNDdmIsRUFBdEMsRUFBMENpYixVQUExQyxFQUZpRSxDQUdqRTs7QUFDQSxXQUFLckQsV0FBTCxDQUFpQjBDLE1BQWpCLEVBQXlCeEksR0FBekIsRUFBOEI5UixFQUE5QixFQUFrQ0MsT0FBbEM7QUFDQSxXQUFLdWIsWUFBTCxDQUFrQkosU0FBbEI7QUFDQSxXQUFLSyxNQUFMLENBQVksS0FBSzNDLFVBQUwsQ0FBZ0IsS0FBS3RQLEtBQXJCLENBQVosRUFBeUMsSUFBekM7QUFDQWlOLE1BQUFBLE1BQU0sQ0FBQy9KLE1BQVAsQ0FBYzZPLElBQWQsQ0FBbUIsb0JBQW5CLEVBQXlDdmIsRUFBekMsRUFBNkNpYixVQUE3QztBQUNBLGFBQU8sSUFBUDtBQUNIOztBQUNELFFBQUlTLE1BQU0sR0FBRyxDQUFDLEdBQUd0TCxpQkFBSixFQUF1QnFJLGdCQUF2QixDQUF3QzNHLEdBQXhDLENBQWI7QUFDQSxRQUFJO0FBQUVwWixNQUFBQSxRQUFRLEVBQUVpZSxTQUFaO0FBQXdCL2UsTUFBQUEsS0FBSyxFQUFFZ2Y7QUFBL0IsUUFBMkM4RSxNQUEvQyxDQTVGaUQsQ0E2RmpEO0FBQ0E7QUFDQTs7QUFDQSxRQUFJekcsS0FBSixFQUFXMEcsUUFBWDs7QUFDQSxRQUFJO0FBQ0ExRyxNQUFBQSxLQUFLLEdBQUcsTUFBTSxLQUFLOEIsVUFBTCxDQUFnQjZFLFdBQWhCLEVBQWQ7QUFDQSxPQUFDO0FBQUVDLFFBQUFBLFVBQVUsRUFBRUY7QUFBZCxVQUE0QixNQUFNLENBQUMsR0FBRzdMLFlBQUosRUFBa0IxSixzQkFBbEIsRUFBbkM7QUFDSCxLQUhELENBR0UsT0FBT2dSLElBQVAsRUFBYTtBQUNYO0FBQ0E7QUFDQTlSLE1BQUFBLE1BQU0sQ0FBQ3VVLFFBQVAsQ0FBZ0IvaUIsSUFBaEIsR0FBdUJrSixFQUF2QjtBQUNBLGFBQU8sS0FBUDtBQUNILEtBekdnRCxDQTBHakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsUUFBSSxDQUFDLEtBQUs4YixRQUFMLENBQWNWLFNBQWQsQ0FBRCxJQUE2QixDQUFDQyxZQUFsQyxFQUFnRDtBQUM1Q2YsTUFBQUEsTUFBTSxHQUFHLGNBQVQ7QUFDSCxLQWpIZ0QsQ0FrSGpEO0FBQ0E7OztBQUNBLFFBQUk3WCxVQUFVLEdBQUd6QyxFQUFqQixDQXBIaUQsQ0FxSGpEO0FBQ0E7QUFDQTs7QUFDQTJXLElBQUFBLFNBQVMsR0FBR0EsU0FBUyxHQUFHLENBQUMsR0FBRzlHLHVCQUFKLEVBQTZCcEwsdUJBQTdCLENBQXFEa0wsV0FBVyxDQUFDZ0gsU0FBRCxDQUFoRSxDQUFILEdBQWtGQSxTQUF2Rzs7QUFDQSxRQUFJNEQsaUJBQWlCLElBQUk1RCxTQUFTLEtBQUssU0FBdkMsRUFBa0Q7QUFDOUMxVyxNQUFBQSxPQUFPLENBQUNnYSxrQkFBUixHQUE2QixJQUE3Qjs7QUFDQSxVQUFJblYsS0FBSixFQUEyRCxFQUEzRCxNQVdPO0FBQ0g0VyxRQUFBQSxNQUFNLENBQUNoakIsUUFBUCxHQUFrQnNjLG1CQUFtQixDQUFDMkIsU0FBRCxFQUFZMUIsS0FBWixDQUFyQzs7QUFDQSxZQUFJeUcsTUFBTSxDQUFDaGpCLFFBQVAsS0FBb0JpZSxTQUF4QixFQUFtQztBQUMvQkEsVUFBQUEsU0FBUyxHQUFHK0UsTUFBTSxDQUFDaGpCLFFBQW5CO0FBQ0FnakIsVUFBQUEsTUFBTSxDQUFDaGpCLFFBQVAsR0FBa0IwTCxXQUFXLENBQUN1UyxTQUFELENBQTdCO0FBQ0E3RSxVQUFBQSxHQUFHLEdBQUcsQ0FBQyxHQUFHNUIsTUFBSixFQUFZMEQsb0JBQVosQ0FBaUM4SCxNQUFqQyxDQUFOO0FBQ0g7QUFDSjtBQUNKOztBQUNELFVBQU1sUyxLQUFLLEdBQUcsQ0FBQyxHQUFHcUcsdUJBQUosRUFBNkJwTCx1QkFBN0IsQ0FBcURrUyxTQUFyRCxDQUFkOztBQUNBLFFBQUksQ0FBQ3pXLFVBQVUsQ0FBQ0YsRUFBRCxDQUFmLEVBQXFCO0FBQ2pCLGdCQUEyQztBQUN2QyxjQUFNLElBQUlzQixLQUFKLENBQVcsa0JBQWlCd1EsR0FBSSxjQUFhOVIsRUFBRywyQ0FBdEMsR0FBb0Ysb0ZBQTlGLENBQU47QUFDSDs7QUFDRHNGLE1BQUFBLE1BQU0sQ0FBQ3VVLFFBQVAsQ0FBZ0IvaUIsSUFBaEIsR0FBdUJrSixFQUF2QjtBQUNBLGFBQU8sS0FBUDtBQUNIOztBQUNEeUMsSUFBQUEsVUFBVSxHQUFHZ04sU0FBUyxDQUFDRSxXQUFXLENBQUNsTixVQUFELENBQVosRUFBMEIsS0FBS25LLE1BQS9CLENBQXRCOztBQUNBLFFBQUksQ0FBQyxHQUFHNlgsVUFBSixFQUFnQm1FLGNBQWhCLENBQStCOUssS0FBL0IsQ0FBSixFQUEyQztBQUN2QyxZQUFNa1IsUUFBUSxHQUFHLENBQUMsR0FBR3RLLGlCQUFKLEVBQXVCcUksZ0JBQXZCLENBQXdDaFcsVUFBeEMsQ0FBakI7QUFDQSxZQUFNMlAsVUFBVSxHQUFHc0ksUUFBUSxDQUFDaGlCLFFBQTVCO0FBQ0EsWUFBTXVqQixVQUFVLEdBQUcsQ0FBQyxHQUFHekwsV0FBSixFQUFpQitCLGFBQWpCLENBQStCL0ksS0FBL0IsQ0FBbkI7QUFDQSxZQUFNMFMsVUFBVSxHQUFHLENBQUMsR0FBRzNMLGFBQUosRUFBbUJvQyxlQUFuQixDQUFtQ3NKLFVBQW5DLEVBQStDN0osVUFBL0MsQ0FBbkI7QUFDQSxZQUFNK0osaUJBQWlCLEdBQUczUyxLQUFLLEtBQUs0SSxVQUFwQztBQUNBLFlBQU1pQyxjQUFjLEdBQUc4SCxpQkFBaUIsR0FBR3ZNLGFBQWEsQ0FBQ3BHLEtBQUQsRUFBUTRJLFVBQVIsRUFBb0J3RSxNQUFwQixDQUFoQixHQUE4QyxFQUF0Rjs7QUFFQSxVQUFJLENBQUNzRixVQUFELElBQWVDLGlCQUFpQixJQUFJLENBQUM5SCxjQUFjLENBQUNoQixNQUF4RCxFQUFnRTtBQUM1RCxjQUFNK0ksYUFBYSxHQUFHamQsTUFBTSxDQUFDeUMsSUFBUCxDQUFZcWEsVUFBVSxDQUFDeEosTUFBdkIsRUFBK0I1SSxNQUEvQixDQUF1Q2lKLEtBQUQsSUFBUyxDQUFDOEQsTUFBTSxDQUFDOUQsS0FBRCxDQUF0RCxDQUF0Qjs7QUFFQSxZQUFJc0osYUFBYSxDQUFDMUssTUFBZCxHQUF1QixDQUEzQixFQUE4QjtBQUMxQixvQkFBMkM7QUFDdkMxWSxZQUFBQSxPQUFPLENBQUNzSixJQUFSLENBQWMsR0FBRTZaLGlCQUFpQixHQUFJLG9CQUFKLEdBQTJCLGlDQUFpQyw4QkFBaEYsR0FBaUgsZUFBY0MsYUFBYSxDQUFDaEosSUFBZCxDQUFtQixJQUFuQixDQUF5Qiw4QkFBcks7QUFDSDs7QUFDRCxnQkFBTSxJQUFJOVIsS0FBSixDQUFVLENBQUM2YSxpQkFBaUIsR0FBSSwwQkFBeUJySyxHQUFJLG9DQUFtQ3NLLGFBQWEsQ0FBQ2hKLElBQWQsQ0FBbUIsSUFBbkIsQ0FBeUIsaUNBQTdGLEdBQWlJLDhCQUE2QmhCLFVBQVcsOENBQTZDNUksS0FBTSxLQUE5TyxJQUF1UCwrQ0FBOEMyUyxpQkFBaUIsR0FBRywyQkFBSCxHQUFpQyxzQkFBdUIsRUFBeFgsQ0FBTjtBQUNIO0FBQ0osT0FURCxNQVNPLElBQUlBLGlCQUFKLEVBQXVCO0FBQzFCbmMsUUFBQUEsRUFBRSxHQUFHLENBQUMsR0FBR2tRLE1BQUosRUFBWTBELG9CQUFaLENBQWlDelUsTUFBTSxDQUFDcU0sTUFBUCxDQUFjLEVBQWQsRUFDbkNrUCxRQURtQyxFQUN6QjtBQUNUaGlCLFVBQUFBLFFBQVEsRUFBRTJiLGNBQWMsQ0FBQ2hCLE1BRGhCO0FBRVR6YixVQUFBQSxLQUFLLEVBQUUwYixrQkFBa0IsQ0FBQ3NELE1BQUQsRUFBU3ZDLGNBQWMsQ0FBQ3pCLE1BQXhCO0FBRmhCLFNBRHlCLENBQWpDLENBQUw7QUFLSCxPQU5NLE1BTUE7QUFDSDtBQUNBelQsUUFBQUEsTUFBTSxDQUFDcU0sTUFBUCxDQUFjb0wsTUFBZCxFQUFzQnNGLFVBQXRCO0FBQ0g7QUFDSjs7QUFDRHpGLElBQUFBLE1BQU0sQ0FBQy9KLE1BQVAsQ0FBYzZPLElBQWQsQ0FBbUIsa0JBQW5CLEVBQXVDdmIsRUFBdkMsRUFBMkNpYixVQUEzQzs7QUFDQSxRQUFJO0FBQ0EsVUFBSWpZLEdBQUosRUFBU3FaLElBQVQ7QUFDQSxVQUFJQyxTQUFTLEdBQUcsTUFBTSxLQUFLQyxZQUFMLENBQWtCL1MsS0FBbEIsRUFBeUJtTixTQUF6QixFQUFvQ0MsTUFBcEMsRUFBNEM1VyxFQUE1QyxFQUFnRHlDLFVBQWhELEVBQTREd1ksVUFBNUQsQ0FBdEI7QUFDQSxVQUFJO0FBQUVsUSxRQUFBQSxLQUFGO0FBQVUvVixRQUFBQSxLQUFWO0FBQWtCZ2tCLFFBQUFBLE9BQWxCO0FBQTRCQyxRQUFBQTtBQUE1QixVQUF5Q3FELFNBQTdDLENBSEEsQ0FJQTs7QUFDQSxVQUFJLENBQUN0RCxPQUFPLElBQUlDLE9BQVosS0FBd0Jqa0IsS0FBNUIsRUFBbUM7QUFDL0IsWUFBSUEsS0FBSyxDQUFDd25CLFNBQU4sSUFBbUJ4bkIsS0FBSyxDQUFDd25CLFNBQU4sQ0FBZ0JDLFlBQXZDLEVBQXFEO0FBQ2pELGdCQUFNQyxXQUFXLEdBQUcxbkIsS0FBSyxDQUFDd25CLFNBQU4sQ0FBZ0JDLFlBQXBDLENBRGlELENBRWpEO0FBQ0E7QUFDQTs7QUFDQSxjQUFJQyxXQUFXLENBQUMxTCxVQUFaLENBQXVCLEdBQXZCLENBQUosRUFBaUM7QUFDN0Isa0JBQU0yTCxVQUFVLEdBQUcsQ0FBQyxHQUFHdk0saUJBQUosRUFBdUJxSSxnQkFBdkIsQ0FBd0NpRSxXQUF4QyxDQUFuQjtBQUNBQyxZQUFBQSxVQUFVLENBQUNqa0IsUUFBWCxHQUFzQnNjLG1CQUFtQixDQUFDMkgsVUFBVSxDQUFDamtCLFFBQVosRUFBc0J1YyxLQUF0QixDQUF6QztBQUNBLGtCQUFNO0FBQUVuRCxjQUFBQSxHQUFHLEVBQUU4SyxNQUFQO0FBQWdCNWMsY0FBQUEsRUFBRSxFQUFFNmM7QUFBcEIsZ0JBQStCbEksWUFBWSxDQUFDLElBQUQsRUFBTytILFdBQVAsRUFBb0JBLFdBQXBCLENBQWpEO0FBQ0EsbUJBQU8sS0FBSzlELE1BQUwsQ0FBWTBCLE1BQVosRUFBb0JzQyxNQUFwQixFQUE0QkMsS0FBNUIsRUFBbUM1YyxPQUFuQyxDQUFQO0FBQ0g7O0FBQ0RxRixVQUFBQSxNQUFNLENBQUN1VSxRQUFQLENBQWdCL2lCLElBQWhCLEdBQXVCNGxCLFdBQXZCO0FBQ0EsaUJBQU8sSUFBSTVWLE9BQUosQ0FBWSxNQUFJLENBQ3RCLENBRE0sQ0FBUDtBQUVIOztBQUNELGFBQUt5USxTQUFMLEdBQWlCLENBQUMsQ0FBQ3ZpQixLQUFLLENBQUM4bkIsV0FBekIsQ0FoQitCLENBaUIvQjs7QUFDQSxZQUFJOW5CLEtBQUssQ0FBQ3FoQixRQUFOLEtBQW1CUCxrQkFBdkIsRUFBMkM7QUFDdkMsY0FBSWlILGFBQUo7O0FBQ0EsY0FBSTtBQUNBLGtCQUFNLEtBQUtDLGNBQUwsQ0FBb0IsTUFBcEIsQ0FBTjtBQUNBRCxZQUFBQSxhQUFhLEdBQUcsTUFBaEI7QUFDSCxXQUhELENBR0UsT0FBT2piLENBQVAsRUFBVTtBQUNSaWIsWUFBQUEsYUFBYSxHQUFHLFNBQWhCO0FBQ0g7O0FBQ0RULFVBQUFBLFNBQVMsR0FBRyxNQUFNLEtBQUtDLFlBQUwsQ0FBa0JRLGFBQWxCLEVBQWlDQSxhQUFqQyxFQUFnRG5HLE1BQWhELEVBQXdENVcsRUFBeEQsRUFBNER5QyxVQUE1RCxFQUF3RTtBQUN0RnhCLFlBQUFBLE9BQU8sRUFBRTtBQUQ2RSxXQUF4RSxDQUFsQjtBQUdIO0FBQ0o7O0FBQ0R3VixNQUFBQSxNQUFNLENBQUMvSixNQUFQLENBQWM2TyxJQUFkLENBQW1CLHFCQUFuQixFQUEwQ3ZiLEVBQTFDLEVBQThDaWIsVUFBOUM7QUFDQSxXQUFLckQsV0FBTCxDQUFpQjBDLE1BQWpCLEVBQXlCeEksR0FBekIsRUFBOEI5UixFQUE5QixFQUFrQ0MsT0FBbEM7O0FBQ0EsZ0JBQTJDO0FBQ3ZDLGNBQU1nZCxPQUFPLEdBQUcsS0FBS25FLFVBQUwsQ0FBZ0IsT0FBaEIsRUFBeUI1QixTQUF6QztBQUNBNVIsUUFBQUEsTUFBTSxDQUFDNFgsSUFBUCxDQUFZQyxhQUFaLEdBQTRCRixPQUFPLENBQUM1TixlQUFSLEtBQTRCNE4sT0FBTyxDQUFDM04sbUJBQXBDLElBQTJELENBQUNnTixTQUFTLENBQUNwRixTQUFWLENBQW9CN0gsZUFBNUc7QUFDSDs7QUFDRCxVQUFJcFAsT0FBTyxDQUFDdWEsRUFBUixJQUFjN0QsU0FBUyxLQUFLLFNBQTVCLElBQXlDLENBQUMsQ0FBQzNULEdBQUcsR0FBR29DLElBQUksQ0FBQytULGFBQUwsQ0FBbUJua0IsS0FBMUIsTUFBcUMsSUFBckMsSUFBNkNnTyxHQUFHLEtBQUssS0FBSyxDQUExRCxHQUE4RCxLQUFLLENBQW5FLEdBQXVFLENBQUNxWixJQUFJLEdBQUdyWixHQUFHLENBQUN3WixTQUFaLE1BQTJCLElBQTNCLElBQW1DSCxJQUFJLEtBQUssS0FBSyxDQUFqRCxHQUFxRCxLQUFLLENBQTFELEdBQThEQSxJQUFJLENBQUNlLFVBQTNJLE1BQTJKLEdBQXBNLEtBQTRNcG9CLEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLEtBQUssS0FBSyxDQUFqQyxHQUFxQyxLQUFLLENBQTFDLEdBQThDQSxLQUFLLENBQUN3bkIsU0FBaFEsQ0FBSixFQUFnUjtBQUM1UTtBQUNBO0FBQ0F4bkIsUUFBQUEsS0FBSyxDQUFDd25CLFNBQU4sQ0FBZ0JZLFVBQWhCLEdBQTZCLEdBQTdCO0FBQ0gsT0E5Q0QsQ0ErQ0E7OztBQUNBLFlBQU1DLG1CQUFtQixHQUFHcGQsT0FBTyxDQUFDZ0IsT0FBUixJQUFtQixLQUFLdUksS0FBTCxLQUFlQSxLQUE5RDs7QUFDQSxVQUFJOFQsT0FBSjs7QUFDQSxZQUFNQyxZQUFZLEdBQUcsQ0FBQ0QsT0FBTyxHQUFHcmQsT0FBTyxDQUFDckgsTUFBbkIsTUFBK0IsSUFBL0IsSUFBdUMwa0IsT0FBTyxLQUFLLEtBQUssQ0FBeEQsR0FBNERBLE9BQTVELEdBQXNFLENBQUNELG1CQUE1RjtBQUNBLFlBQU1HLFdBQVcsR0FBR0QsWUFBWSxHQUFHO0FBQy9CcEYsUUFBQUEsQ0FBQyxFQUFFLENBRDRCO0FBRS9CRSxRQUFBQSxDQUFDLEVBQUU7QUFGNEIsT0FBSCxHQUc1QixJQUhKO0FBSUEsWUFBTSxLQUFLblIsR0FBTCxDQUFTc0MsS0FBVCxFQUFnQm1OLFNBQWhCLEVBQTJCQyxNQUEzQixFQUFtQ3dFLFNBQW5DLEVBQThDa0IsU0FBOUMsRUFBeUR2RSxZQUFZLEtBQUssSUFBakIsSUFBeUJBLFlBQVksS0FBSyxLQUFLLENBQS9DLEdBQW1EQSxZQUFuRCxHQUFrRXlGLFdBQTNILEVBQXdJcmQsS0FBeEksQ0FBK0k5SCxDQUFELElBQUs7QUFDckosWUFBSUEsQ0FBQyxDQUFDNFEsU0FBTixFQUFpQjhCLEtBQUssR0FBR0EsS0FBSyxJQUFJMVMsQ0FBakIsQ0FBakIsS0FDSyxNQUFNQSxDQUFOO0FBQ1IsT0FISyxDQUFOOztBQUlBLFVBQUkwUyxLQUFKLEVBQVc7QUFDUDBMLFFBQUFBLE1BQU0sQ0FBQy9KLE1BQVAsQ0FBYzZPLElBQWQsQ0FBbUIsa0JBQW5CLEVBQXVDeFEsS0FBdkMsRUFBOENxUSxTQUE5QyxFQUF5REgsVUFBekQ7QUFDQSxjQUFNbFEsS0FBTjtBQUNIOztBQUNELFVBQUlqRyxLQUFKLEVBQXFDLEVBSXBDOztBQUNEMlIsTUFBQUEsTUFBTSxDQUFDL0osTUFBUCxDQUFjNk8sSUFBZCxDQUFtQixxQkFBbkIsRUFBMEN2YixFQUExQyxFQUE4Q2liLFVBQTlDO0FBQ0EsYUFBTyxJQUFQO0FBQ0gsS0F0RUQsQ0FzRUUsT0FBTzdELElBQVAsRUFBYTtBQUNYLFVBQUlBLElBQUksQ0FBQ25PLFNBQVQsRUFBb0I7QUFDaEIsZUFBTyxLQUFQO0FBQ0g7O0FBQ0QsWUFBTW1PLElBQU47QUFDSDtBQUNKOztBQUNEUSxFQUFBQSxXQUFXLENBQUMwQyxNQUFELEVBQVN4SSxHQUFULEVBQWM5UixFQUFkLEVBQWtCQyxPQUFPLEdBQUcsRUFBNUIsRUFDUjtBQUNDLGNBQTJDO0FBQ3ZDLFVBQUksT0FBT3FGLE1BQU0sQ0FBQ21RLE9BQWQsS0FBMEIsV0FBOUIsRUFBMkM7QUFDdkN6YyxRQUFBQSxPQUFPLENBQUMrUixLQUFSLENBQWUsMkNBQWY7QUFDQTtBQUNIOztBQUNELFVBQUksT0FBT3pGLE1BQU0sQ0FBQ21RLE9BQVAsQ0FBZTZFLE1BQWYsQ0FBUCxLQUFrQyxXQUF0QyxFQUFtRDtBQUMvQ3RoQixRQUFBQSxPQUFPLENBQUMrUixLQUFSLENBQWUsMkJBQTBCdVAsTUFBTyxtQkFBaEQ7QUFDQTtBQUNIO0FBQ0o7O0FBQ0QsUUFBSUEsTUFBTSxLQUFLLFdBQVgsSUFBMEIsQ0FBQyxHQUFHcEssTUFBSixFQUFZMkgsTUFBWixPQUF5QjdYLEVBQXZELEVBQTJEO0FBQ3ZELFdBQUs2WSxRQUFMLEdBQWdCNVksT0FBTyxDQUFDZ0IsT0FBeEI7QUFDQXFFLE1BQUFBLE1BQU0sQ0FBQ21RLE9BQVAsQ0FBZTZFLE1BQWYsRUFBdUI7QUFDbkJ4SSxRQUFBQSxHQURtQjtBQUVuQjlSLFFBQUFBLEVBRm1CO0FBR25CQyxRQUFBQSxPQUhtQjtBQUluQjZYLFFBQUFBLEdBQUcsRUFBRSxJQUpjO0FBS25CRSxRQUFBQSxHQUFHLEVBQUUsS0FBS04sSUFBTCxHQUFZNEMsTUFBTSxLQUFLLFdBQVgsR0FBeUIsS0FBSzVDLElBQTlCLEdBQXFDLEtBQUtBLElBQUwsR0FBWTtBQUwvQyxPQUF2QixFQU1HO0FBQ0g7QUFDQTtBQUNBLFFBVEEsRUFTSTFYLEVBVEo7QUFVSDtBQUNKOztBQUN5QixRQUFwQjJkLG9CQUFvQixDQUFDdmQsR0FBRCxFQUFNMUgsUUFBTixFQUFnQmQsS0FBaEIsRUFBdUJvSSxFQUF2QixFQUEyQmliLFVBQTNCLEVBQXVDMkMsYUFBdkMsRUFBc0Q7QUFDNUUsUUFBSXhkLEdBQUcsQ0FBQzZJLFNBQVIsRUFBbUI7QUFDZjtBQUNBLFlBQU03SSxHQUFOO0FBQ0g7O0FBQ0QsUUFBSSxDQUFDLEdBQUcwUCxZQUFKLEVBQWtCM0osWUFBbEIsQ0FBK0IvRixHQUEvQixLQUF1Q3dkLGFBQTNDLEVBQTBEO0FBQ3REbkgsTUFBQUEsTUFBTSxDQUFDL0osTUFBUCxDQUFjNk8sSUFBZCxDQUFtQixrQkFBbkIsRUFBdUNuYixHQUF2QyxFQUE0Q0osRUFBNUMsRUFBZ0RpYixVQUFoRCxFQURzRCxDQUV0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBM1YsTUFBQUEsTUFBTSxDQUFDdVUsUUFBUCxDQUFnQi9pQixJQUFoQixHQUF1QmtKLEVBQXZCLENBUHNELENBUXREO0FBQ0E7O0FBQ0EsWUFBTTZRLHNCQUFzQixFQUE1QjtBQUNIOztBQUNELFFBQUk7QUFDQSxVQUFJc0csVUFBSjtBQUNBLFVBQUlqTixXQUFKO0FBQ0EsVUFBSWxWLEtBQUo7O0FBQ0EsVUFBSSxPQUFPbWlCLFVBQVAsS0FBc0IsV0FBdEIsSUFBcUMsT0FBT2pOLFdBQVAsS0FBdUIsV0FBaEUsRUFBNkU7QUFDekUsU0FBQztBQUFFbUwsVUFBQUEsSUFBSSxFQUFFOEIsVUFBUjtBQUFxQmpOLFVBQUFBO0FBQXJCLFlBQXNDLE1BQU0sS0FBSzhTLGNBQUwsQ0FBb0IsU0FBcEIsQ0FBN0M7QUFDSDs7QUFDRCxZQUFNVixTQUFTLEdBQUc7QUFDZHRuQixRQUFBQSxLQURjO0FBRWRraUIsUUFBQUEsU0FBUyxFQUFFQyxVQUZHO0FBR2RqTixRQUFBQSxXQUhjO0FBSWQ5SixRQUFBQSxHQUpjO0FBS2QySyxRQUFBQSxLQUFLLEVBQUUzSztBQUxPLE9BQWxCOztBQU9BLFVBQUksQ0FBQ2tjLFNBQVMsQ0FBQ3RuQixLQUFmLEVBQXNCO0FBQ2xCLFlBQUk7QUFDQXNuQixVQUFBQSxTQUFTLENBQUN0bkIsS0FBVixHQUFrQixNQUFNLEtBQUtxYSxlQUFMLENBQXFCOEgsVUFBckIsRUFBaUM7QUFDckQvVyxZQUFBQSxHQURxRDtBQUVyRDFILFlBQUFBLFFBRnFEO0FBR3JEZCxZQUFBQTtBQUhxRCxXQUFqQyxDQUF4QjtBQUtILFNBTkQsQ0FNRSxPQUFPaW1CLE1BQVAsRUFBZTtBQUNiN2tCLFVBQUFBLE9BQU8sQ0FBQytSLEtBQVIsQ0FBYyx5Q0FBZCxFQUF5RDhTLE1BQXpEO0FBQ0F2QixVQUFBQSxTQUFTLENBQUN0bkIsS0FBVixHQUFrQixFQUFsQjtBQUVIO0FBQ0o7O0FBQ0QsYUFBT3NuQixTQUFQO0FBQ0gsS0E1QkQsQ0E0QkUsT0FBT3dCLFlBQVAsRUFBcUI7QUFDbkIsYUFBTyxLQUFLSCxvQkFBTCxDQUEwQkcsWUFBMUIsRUFBd0NwbEIsUUFBeEMsRUFBa0RkLEtBQWxELEVBQXlEb0ksRUFBekQsRUFBNkRpYixVQUE3RCxFQUF5RSxJQUF6RSxDQUFQO0FBQ0g7QUFDSjs7QUFDaUIsUUFBWnNCLFlBQVksQ0FBQy9TLEtBQUQsRUFBUTlRLFFBQVIsRUFBa0JkLEtBQWxCLEVBQXlCb0ksRUFBekIsRUFBNkJ5QyxVQUE3QixFQUF5Q3dZLFVBQXpDLEVBQXFEO0FBQ25FLFFBQUk7QUFDQSxZQUFNOEMsaUJBQWlCLEdBQUcsS0FBS2pGLFVBQUwsQ0FBZ0J0UCxLQUFoQixDQUExQjs7QUFDQSxVQUFJeVIsVUFBVSxDQUFDaGEsT0FBWCxJQUFzQjhjLGlCQUF0QixJQUEyQyxLQUFLdlUsS0FBTCxLQUFlQSxLQUE5RCxFQUFxRTtBQUNqRSxlQUFPdVUsaUJBQVA7QUFDSDs7QUFDRCxZQUFNQyxlQUFlLEdBQUdELGlCQUFpQixJQUFJLGFBQWFBLGlCQUFsQyxHQUFzRDdQLFNBQXRELEdBQWtFNlAsaUJBQTFGO0FBQ0EsWUFBTXpCLFNBQVMsR0FBRzBCLGVBQWUsR0FBR0EsZUFBSCxHQUFxQixNQUFNLEtBQUtoQixjQUFMLENBQW9CeFQsS0FBcEIsRUFBMkJyQyxJQUEzQixDQUFpQ1UsR0FBRCxLQUFRO0FBQzVGcVAsUUFBQUEsU0FBUyxFQUFFclAsR0FBRyxDQUFDd04sSUFENkU7QUFFNUZuTCxRQUFBQSxXQUFXLEVBQUVyQyxHQUFHLENBQUNxQyxXQUYyRTtBQUc1RjhPLFFBQUFBLE9BQU8sRUFBRW5SLEdBQUcsQ0FBQ29XLEdBQUosQ0FBUWpGLE9BSDJFO0FBSTVGQyxRQUFBQSxPQUFPLEVBQUVwUixHQUFHLENBQUNvVyxHQUFKLENBQVFoRjtBQUoyRSxPQUFSLENBQWhDLENBQTVEO0FBT0EsWUFBTTtBQUFFL0IsUUFBQUEsU0FBUyxFQUFFQyxVQUFiO0FBQTBCNkIsUUFBQUEsT0FBMUI7QUFBb0NDLFFBQUFBO0FBQXBDLFVBQWlEcUQsU0FBdkQ7O0FBQ0EsZ0JBQTJDO0FBQ3ZDLGNBQU07QUFBRTRCLFVBQUFBO0FBQUYsWUFBMEIxZSxtQkFBTyxDQUFDLDBCQUFELENBQXZDOztBQUNBLFlBQUksQ0FBQzBlLGtCQUFrQixDQUFDL0csVUFBRCxDQUF2QixFQUFxQztBQUNqQyxnQkFBTSxJQUFJN1YsS0FBSixDQUFXLHlEQUF3RDVJLFFBQVMsR0FBNUUsQ0FBTjtBQUNIO0FBQ0o7O0FBQ0QsVUFBSTZkLFFBQUo7O0FBQ0EsVUFBSXlDLE9BQU8sSUFBSUMsT0FBZixFQUF3QjtBQUNwQjFDLFFBQUFBLFFBQVEsR0FBRyxLQUFLUSxVQUFMLENBQWdCb0gsV0FBaEIsQ0FBNEIsQ0FBQyxHQUFHak8sTUFBSixFQUFZMEQsb0JBQVosQ0FBaUM7QUFDcEVsYixVQUFBQSxRQURvRTtBQUVwRWQsVUFBQUE7QUFGb0UsU0FBakMsQ0FBNUIsRUFHUDZLLFVBSE8sRUFHS3VXLE9BSEwsRUFHYyxLQUFLMWdCLE1BSG5CLENBQVg7QUFJSDs7QUFDRCxZQUFNdEQsS0FBSyxHQUFHLE1BQU0sS0FBS29wQixRQUFMLENBQWMsTUFBSXBGLE9BQU8sR0FBRyxLQUFLcUYsY0FBTCxDQUFvQjlILFFBQXBCLENBQUgsR0FBbUMwQyxPQUFPLEdBQUcsS0FBS3FGLGNBQUwsQ0FBb0IvSCxRQUFwQixDQUFILEdBQW1DLEtBQUtsSCxlQUFMLENBQXFCOEgsVUFBckIsRUFBaUM7QUFDdko7QUFDSXplLFFBQUFBLFFBREo7QUFFSWQsUUFBQUEsS0FGSjtBQUdJZSxRQUFBQSxNQUFNLEVBQUVxSCxFQUhaO0FBSUkxSCxRQUFBQSxNQUFNLEVBQUUsS0FBS0EsTUFKakI7QUFLSTRMLFFBQUFBLE9BQU8sRUFBRSxLQUFLQSxPQUxsQjtBQU1JSSxRQUFBQSxhQUFhLEVBQUUsS0FBS0E7QUFOeEIsT0FEc0gsQ0FBdEcsQ0FBcEI7QUFVQWdZLE1BQUFBLFNBQVMsQ0FBQ3RuQixLQUFWLEdBQWtCQSxLQUFsQjtBQUNBLFdBQUs4akIsVUFBTCxDQUFnQnRQLEtBQWhCLElBQXlCOFMsU0FBekI7QUFDQSxhQUFPQSxTQUFQO0FBQ0gsS0F4Q0QsQ0F3Q0UsT0FBT2lDLElBQVAsRUFBYTtBQUNYLGFBQU8sS0FBS1osb0JBQUwsQ0FBMEJZLElBQTFCLEVBQWdDN2xCLFFBQWhDLEVBQTBDZCxLQUExQyxFQUFpRG9JLEVBQWpELEVBQXFEaWIsVUFBckQsQ0FBUDtBQUNIO0FBQ0o7O0FBQ0QvVCxFQUFBQSxHQUFHLENBQUNzQyxLQUFELEVBQVE5USxRQUFSLEVBQWtCZCxLQUFsQixFQUF5Qm9JLEVBQXpCLEVBQTZCb1csSUFBN0IsRUFBbUNvSCxXQUFuQyxFQUFnRDtBQUMvQyxTQUFLbEcsVUFBTCxHQUFrQixLQUFsQjtBQUNBLFNBQUs5TixLQUFMLEdBQWFBLEtBQWI7QUFDQSxTQUFLOVEsUUFBTCxHQUFnQkEsUUFBaEI7QUFDQSxTQUFLZCxLQUFMLEdBQWFBLEtBQWI7QUFDQSxTQUFLZSxNQUFMLEdBQWNxSCxFQUFkO0FBQ0EsV0FBTyxLQUFLeWIsTUFBTCxDQUFZckYsSUFBWixFQUFrQm9ILFdBQWxCLENBQVA7QUFDSDtBQUNEO0FBQ0o7QUFDQTtBQUNBOzs7QUFBTWdCLEVBQUFBLGNBQWMsQ0FBQ2paLEVBQUQsRUFBSztBQUNqQixTQUFLb1QsSUFBTCxHQUFZcFQsRUFBWjtBQUNIOztBQUNEK1YsRUFBQUEsZUFBZSxDQUFDdGIsRUFBRCxFQUFLO0FBQ2hCLFFBQUksQ0FBQyxLQUFLckgsTUFBVixFQUFrQixPQUFPLEtBQVA7QUFDbEIsVUFBTSxDQUFDOGxCLFlBQUQsRUFBZUMsT0FBZixJQUEwQixLQUFLL2xCLE1BQUwsQ0FBWXNiLEtBQVosQ0FBa0IsR0FBbEIsQ0FBaEM7QUFDQSxVQUFNLENBQUMwSyxZQUFELEVBQWVDLE9BQWYsSUFBMEI1ZSxFQUFFLENBQUNpVSxLQUFILENBQVMsR0FBVCxDQUFoQyxDQUhnQixDQUloQjs7QUFDQSxRQUFJMkssT0FBTyxJQUFJSCxZQUFZLEtBQUtFLFlBQTVCLElBQTRDRCxPQUFPLEtBQUtFLE9BQTVELEVBQXFFO0FBQ2pFLGFBQU8sSUFBUDtBQUNILEtBUGUsQ0FRaEI7OztBQUNBLFFBQUlILFlBQVksS0FBS0UsWUFBckIsRUFBbUM7QUFDL0IsYUFBTyxLQUFQO0FBQ0gsS0FYZSxDQVloQjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsV0FBT0QsT0FBTyxLQUFLRSxPQUFuQjtBQUNIOztBQUNEcEQsRUFBQUEsWUFBWSxDQUFDeGIsRUFBRCxFQUFLO0FBQ2IsVUFBTSxHQUFHeVUsSUFBSCxJQUFXelUsRUFBRSxDQUFDaVUsS0FBSCxDQUFTLEdBQVQsQ0FBakIsQ0FEYSxDQUViO0FBQ0E7O0FBQ0EsUUFBSVEsSUFBSSxLQUFLLEVBQVQsSUFBZUEsSUFBSSxLQUFLLEtBQTVCLEVBQW1DO0FBQy9CblAsTUFBQUEsTUFBTSxDQUFDdVosUUFBUCxDQUFnQixDQUFoQixFQUFtQixDQUFuQjtBQUNBO0FBQ0gsS0FQWSxDQVFiOzs7QUFDQSxVQUFNQyxJQUFJLEdBQUd4WCxRQUFRLENBQUN5WCxjQUFULENBQXdCdEssSUFBeEIsQ0FBYjs7QUFDQSxRQUFJcUssSUFBSixFQUFVO0FBQ05BLE1BQUFBLElBQUksQ0FBQ0UsY0FBTDtBQUNBO0FBQ0gsS0FiWSxDQWNiO0FBQ0E7OztBQUNBLFVBQU1DLE1BQU0sR0FBRzNYLFFBQVEsQ0FBQzRYLGlCQUFULENBQTJCekssSUFBM0IsRUFBaUMsQ0FBakMsQ0FBZjs7QUFDQSxRQUFJd0ssTUFBSixFQUFZO0FBQ1JBLE1BQUFBLE1BQU0sQ0FBQ0QsY0FBUDtBQUNIO0FBQ0o7O0FBQ0RsRCxFQUFBQSxRQUFRLENBQUNuakIsTUFBRCxFQUFTO0FBQ2IsV0FBTyxLQUFLQSxNQUFMLEtBQWdCQSxNQUF2QjtBQUNIO0FBQ0Q7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFBb0IsUUFBUm9ILFFBQVEsQ0FBQytSLEdBQUQsRUFBTW5aLE1BQU0sR0FBR21aLEdBQWYsRUFBb0I3UixPQUFPLEdBQUcsRUFBOUIsRUFDYjtBQUNDLFFBQUl5YixNQUFNLEdBQUcsQ0FBQyxHQUFHdEwsaUJBQUosRUFBdUJxSSxnQkFBdkIsQ0FBd0MzRyxHQUF4QyxDQUFiO0FBQ0EsUUFBSTtBQUFFcFosTUFBQUEsUUFBUSxFQUFFeW1CO0FBQVosUUFBMkJ6RCxNQUEvQjs7QUFDQSxRQUFJNVcsS0FBSixFQUFxQyxFQVdwQzs7QUFDRCxVQUFNbVEsS0FBSyxHQUFHLE1BQU0sS0FBSzhCLFVBQUwsQ0FBZ0I2RSxXQUFoQixFQUFwQjtBQUNBLFFBQUluWixVQUFVLEdBQUc5SixNQUFqQjs7QUFDQSxRQUFJbU0sS0FBSixFQUErRCxFQUEvRCxNQWFPO0FBQ0g0VyxNQUFBQSxNQUFNLENBQUNoakIsUUFBUCxHQUFrQnNjLG1CQUFtQixDQUFDMEcsTUFBTSxDQUFDaGpCLFFBQVIsRUFBa0J1YyxLQUFsQixDQUFyQzs7QUFDQSxVQUFJeUcsTUFBTSxDQUFDaGpCLFFBQVAsS0FBb0J5bUIsU0FBeEIsRUFBbUM7QUFDL0JBLFFBQUFBLFNBQVMsR0FBR3pELE1BQU0sQ0FBQ2hqQixRQUFuQjtBQUNBZ2pCLFFBQUFBLE1BQU0sQ0FBQ2hqQixRQUFQLEdBQWtCeW1CLFNBQWxCO0FBQ0FyTixRQUFBQSxHQUFHLEdBQUcsQ0FBQyxHQUFHNUIsTUFBSixFQUFZMEQsb0JBQVosQ0FBaUM4SCxNQUFqQyxDQUFOO0FBQ0g7QUFDSjs7QUFDRCxVQUFNbFMsS0FBSyxHQUFHLENBQUMsR0FBR3FHLHVCQUFKLEVBQTZCcEwsdUJBQTdCLENBQXFEMGEsU0FBckQsQ0FBZCxDQXRDRCxDQXVDQzs7QUFDQSxjQUEyQztBQUN2QztBQUNIOztBQUNELFVBQU1yWSxPQUFPLENBQUNzRSxHQUFSLENBQVksQ0FDZCxLQUFLMkwsVUFBTCxDQUFnQnFJLE1BQWhCLENBQXVCNVYsS0FBdkIsRUFBOEJyQyxJQUE5QixDQUFvQ2tZLEtBQUQsSUFBUztBQUN4QyxhQUFPQSxLQUFLLEdBQUcsS0FBS2hCLGNBQUwsQ0FBb0IsS0FBS3RILFVBQUwsQ0FBZ0JvSCxXQUFoQixDQUE0QnJNLEdBQTVCLEVBQWlDclAsVUFBakMsRUFBNkMsSUFBN0MsRUFBbUQsT0FBT3hDLE9BQU8sQ0FBQzNILE1BQWYsS0FBMEIsV0FBMUIsR0FBd0MySCxPQUFPLENBQUMzSCxNQUFoRCxHQUF5RCxLQUFLQSxNQUFqSCxDQUFwQixDQUFILEdBQW1KLEtBQS9KO0FBQ0gsS0FGRCxDQURjLEVBSWQsS0FBS3llLFVBQUwsQ0FBZ0I5VyxPQUFPLENBQUM2RCxRQUFSLEdBQW1CLFVBQW5CLEdBQWdDLFVBQWhELEVBQTREMEYsS0FBNUQsQ0FKYyxDQUFaLENBQU47QUFNSDs7QUFDbUIsUUFBZHdULGNBQWMsQ0FBQ3hULEtBQUQsRUFBUTtBQUN4QixRQUFJUCxTQUFTLEdBQUcsS0FBaEI7O0FBQ0EsVUFBTXFXLE1BQU0sR0FBRyxLQUFLaEcsR0FBTCxHQUFXLE1BQUk7QUFDMUJyUSxNQUFBQSxTQUFTLEdBQUcsSUFBWjtBQUNILEtBRkQ7O0FBR0EsVUFBTXNXLGVBQWUsR0FBRyxNQUFNLEtBQUt4SSxVQUFMLENBQWdCeUksUUFBaEIsQ0FBeUJoVyxLQUF6QixDQUE5Qjs7QUFDQSxRQUFJUCxTQUFKLEVBQWU7QUFDWCxZQUFNOEIsS0FBSyxHQUFHLElBQUl6SixLQUFKLENBQVcsd0NBQXVDa0ksS0FBTSxHQUF4RCxDQUFkO0FBQ0F1QixNQUFBQSxLQUFLLENBQUM5QixTQUFOLEdBQWtCLElBQWxCO0FBQ0EsWUFBTThCLEtBQU47QUFDSDs7QUFDRCxRQUFJdVUsTUFBTSxLQUFLLEtBQUtoRyxHQUFwQixFQUF5QjtBQUNyQixXQUFLQSxHQUFMLEdBQVcsSUFBWDtBQUNIOztBQUNELFdBQU9pRyxlQUFQO0FBQ0g7O0FBQ0RuQixFQUFBQSxRQUFRLENBQUN2VCxFQUFELEVBQUs7QUFDVCxRQUFJNUIsU0FBUyxHQUFHLEtBQWhCOztBQUNBLFVBQU1xVyxNQUFNLEdBQUcsTUFBSTtBQUNmclcsTUFBQUEsU0FBUyxHQUFHLElBQVo7QUFDSCxLQUZEOztBQUdBLFNBQUtxUSxHQUFMLEdBQVdnRyxNQUFYO0FBQ0EsV0FBT3pVLEVBQUUsR0FBRzFELElBQUwsQ0FBV2lQLElBQUQsSUFBUTtBQUNyQixVQUFJa0osTUFBTSxLQUFLLEtBQUtoRyxHQUFwQixFQUF5QjtBQUNyQixhQUFLQSxHQUFMLEdBQVcsSUFBWDtBQUNIOztBQUNELFVBQUlyUSxTQUFKLEVBQWU7QUFDWCxjQUFNc1YsSUFBSSxHQUFHLElBQUlqZCxLQUFKLENBQVUsaUNBQVYsQ0FBYjtBQUNBaWQsUUFBQUEsSUFBSSxDQUFDdFYsU0FBTCxHQUFpQixJQUFqQjtBQUNBLGNBQU1zVixJQUFOO0FBQ0g7O0FBQ0QsYUFBT25JLElBQVA7QUFDSCxLQVZNLENBQVA7QUFXSDs7QUFDRGlJLEVBQUFBLGNBQWMsQ0FBQzlILFFBQUQsRUFBVztBQUNyQixVQUFNO0FBQUV6ZixNQUFBQSxJQUFJLEVBQUUyb0I7QUFBUixRQUFzQixJQUFJdk4sR0FBSixDQUFRcUUsUUFBUixFQUFrQmpSLE1BQU0sQ0FBQ3VVLFFBQVAsQ0FBZ0IvaUIsSUFBbEMsQ0FBNUI7O0FBQ0EsUUFBSSxLQUFKLEVBQW9GLEVBRW5GOztBQUNELFdBQU93ZixhQUFhLENBQUNDLFFBQUQsRUFBVyxLQUFLbUMsS0FBaEIsQ0FBYixDQUFvQ3ZSLElBQXBDLENBQTBDaVAsSUFBRCxJQUFRO0FBQ3BELFdBQUtvQixHQUFMLENBQVNpSSxRQUFULElBQXFCckosSUFBckI7QUFDQSxhQUFPQSxJQUFQO0FBQ0gsS0FITSxDQUFQO0FBSUg7O0FBQ0RrSSxFQUFBQSxjQUFjLENBQUMvSCxRQUFELEVBQVc7QUFDckIsVUFBTTtBQUFFemYsTUFBQUEsSUFBSSxFQUFFNG9CO0FBQVIsUUFBeUIsSUFBSXhOLEdBQUosQ0FBUXFFLFFBQVIsRUFBa0JqUixNQUFNLENBQUN1VSxRQUFQLENBQWdCL2lCLElBQWxDLENBQS9COztBQUNBLFFBQUksS0FBSzJnQixHQUFMLENBQVNpSSxXQUFULENBQUosRUFBMkI7QUFDdkIsYUFBTyxLQUFLakksR0FBTCxDQUFTaUksV0FBVCxDQUFQO0FBQ0g7O0FBQ0QsV0FBTyxLQUFLakksR0FBTCxDQUFTaUksV0FBVCxJQUF3QnBKLGFBQWEsQ0FBQ0MsUUFBRCxFQUFXLEtBQUttQyxLQUFoQixDQUFiLENBQW9DdlIsSUFBcEMsQ0FBMENpUCxJQUFELElBQVE7QUFDNUUsYUFBTyxLQUFLcUIsR0FBTCxDQUFTaUksV0FBVCxDQUFQO0FBQ0EsYUFBT3RKLElBQVA7QUFDSCxLQUg4QixFQUc1QmpXLEtBSDRCLENBR3JCb2UsSUFBRCxJQUFRO0FBQ2IsYUFBTyxLQUFLOUcsR0FBTCxDQUFTaUksV0FBVCxDQUFQO0FBQ0EsWUFBTW5CLElBQU47QUFDSCxLQU44QixDQUEvQjtBQU9IOztBQUNEbFAsRUFBQUEsZUFBZSxDQUFDNkgsU0FBRCxFQUFZeUksR0FBWixFQUFpQjtBQUM1QixVQUFNO0FBQUV6SSxNQUFBQSxTQUFTLEVBQUUwSTtBQUFiLFFBQXVCLEtBQUs5RyxVQUFMLENBQWdCLE9BQWhCLENBQTdCOztBQUNBLFVBQU0rRyxPQUFPLEdBQUcsS0FBS3RHLFFBQUwsQ0FBY3FHLElBQWQsQ0FBaEI7O0FBQ0FELElBQUFBLEdBQUcsQ0FBQ0UsT0FBSixHQUFjQSxPQUFkO0FBQ0EsV0FBTyxDQUFDLEdBQUczUCxNQUFKLEVBQVk0UCxtQkFBWixDQUFnQ0YsSUFBaEMsRUFBc0M7QUFDekNDLE1BQUFBLE9BRHlDO0FBRXpDM0ksTUFBQUEsU0FGeUM7QUFHekN4ZixNQUFBQSxNQUFNLEVBQUUsSUFIaUM7QUFJekNpb0IsTUFBQUE7QUFKeUMsS0FBdEMsQ0FBUDtBQU1IOztBQUNEeEUsRUFBQUEsa0JBQWtCLENBQUNuYixFQUFELEVBQUtpYixVQUFMLEVBQWlCO0FBQy9CLFFBQUksS0FBSzNCLEdBQVQsRUFBYztBQUNWN0MsTUFBQUEsTUFBTSxDQUFDL0osTUFBUCxDQUFjNk8sSUFBZCxDQUFtQixrQkFBbkIsRUFBdUMxSyxzQkFBc0IsRUFBN0QsRUFBaUU3USxFQUFqRSxFQUFxRWliLFVBQXJFO0FBQ0EsV0FBSzNCLEdBQUw7QUFDQSxXQUFLQSxHQUFMLEdBQVcsSUFBWDtBQUNIO0FBQ0o7O0FBQ0RtQyxFQUFBQSxNQUFNLENBQUNyRixJQUFELEVBQU9vSCxXQUFQLEVBQW9CO0FBQ3RCLFdBQU8sS0FBS25FLEdBQUwsQ0FBU2pELElBQVQsRUFBZSxLQUFLMEMsVUFBTCxDQUFnQixPQUFoQixFQUF5QjVCLFNBQXhDLEVBQW1Ec0csV0FBbkQsQ0FBUDtBQUNIOztBQXZ2QlE7O0FBeXZCYi9HLE1BQU0sQ0FBQy9KLE1BQVAsR0FBZ0IsQ0FBQyxHQUFHdUQsS0FBSixFQUFXdFosT0FBWCxFQUFoQjtBQUNBMEksZUFBQSxHQUFrQm9YLE1BQWxCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZpQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsTUFBTXZlLEdBQUcsR0FBR3ZELDhEQUFXO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBUEE7QUFRQSxNQUFNcXJCLFNBQVMsR0FBR3BoQixrREFBSTtBQUN0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBdkJBO0FBd0JBLE1BQU1xaEIsTUFBTSxHQUFHcmhCLGtEQUFJO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBaEJBO0FBaUJBLE1BQU1zaEIsUUFBUSxHQUFHdnJCLDZEQUFVO0FBQzNCO0FBQ0E7QUFDQTtBQUNBLENBSkE7O0FBS0EsTUFBTXdyQixhQUFhLEdBQUcsTUFBTTtBQUN4QixNQUFJL0osSUFBSSxHQUFHNVcsbUJBQU8sQ0FBQyx5RkFBRCxDQUFsQjs7QUFDQSxRQUFNOUgsTUFBTSxHQUFHTixzREFBUyxFQUF4QjtBQUNBLFFBQU07QUFBRU8sSUFBQUE7QUFBRixNQUFlRCxNQUFNLENBQUNFLEtBQTVCO0FBQ0EsUUFBTWdYLElBQUksR0FBRyxDQUFDLENBQUMsTUFBRCxFQUFRLE1BQVIsQ0FBRCxFQUFtQixDQUFDLE1BQUQsRUFBUyxNQUFULENBQW5CLEVBQXFDLENBQUMsTUFBRCxFQUFTLE1BQVQsQ0FBckMsQ0FBYjs7QUFDQSxNQUFHbFgsTUFBTSxDQUFDaUIsTUFBUCxJQUFpQixrQkFBcEIsRUFBdUM7QUFDbkN5ZCxJQUFBQSxJQUFJLEdBQUdBLElBQUksQ0FBQ2dLLFNBQVo7QUFDSCxHQUZELE1BR0ssSUFBRzFvQixNQUFNLENBQUNpQixNQUFQLElBQWlCLGNBQXBCLEVBQW1DO0FBQ3BDeWQsSUFBQUEsSUFBSSxHQUFHQSxJQUFJLENBQUNpSyxLQUFaO0FBQ0gsR0FGSSxNQUdBLElBQUczb0IsTUFBTSxDQUFDaUIsTUFBUCxJQUFpQixtQkFBcEIsRUFBd0M7QUFDekN5ZCxJQUFBQSxJQUFJLEdBQUdBLElBQUksQ0FBQ2tLLFVBQVo7QUFDSCxHQUZJLE1BR0EsSUFBRzVvQixNQUFNLENBQUNpQixNQUFQLElBQWlCLGdCQUFwQixFQUFxQztBQUN0Q3lkLElBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDbUssT0FBWjtBQUNILEdBRkksTUFHQSxJQUFHN29CLE1BQU0sQ0FBQ2lCLE1BQVAsSUFBaUIsYUFBcEIsRUFBa0M7QUFDbkN5ZCxJQUFBQSxJQUFJLEdBQUdBLElBQUksQ0FBQ29LLElBQVo7QUFDSCxHQUZJLE1BR0EsSUFBRzlvQixNQUFNLENBQUNpQixNQUFQLElBQWlCLHdCQUFwQixFQUE2QztBQUM5Q3lkLElBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDcUssZUFBWjtBQUNILEdBRkksTUFHRDtBQUNBckssSUFBQUEsSUFBSSxHQUFHQSxJQUFJLENBQUNnSyxTQUFMLENBQWVNLE1BQWYsQ0FBc0J0SyxJQUFJLENBQUNpSyxLQUEzQixFQUFrQ2pLLElBQUksQ0FBQ2tLLFVBQXZDLEVBQW1EbEssSUFBSSxDQUFDbUssT0FBeEQsRUFBaUVuSyxJQUFJLENBQUNvSyxJQUF0RSxFQUE0RXBLLElBQUksQ0FBQ3FLLGVBQWpGLENBQVA7QUFFSDs7QUFFRCxzQkFDSTtBQUFBLDRCQUNJLDhEQUFDLDZDQUFEO0FBQU0sV0FBSyxFQUFDO0FBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQUVJLDhEQUFDLCtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkosZUFHSTtBQUFBLGdCQUFTVDtBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEosZUFJSTtBQUFBLGdCQUFTQztBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkosZUFLSSw4REFBQyxpRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUxKLGVBTUksOERBQUMsR0FBRDtBQUFBLDhCQUVJLDhEQUFDLG1FQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkosZUFHSTtBQUFLLGlCQUFTLEVBQUMsY0FBZjtBQUFBLG1CQUVRN0osSUFBSSxDQUFDbGQsR0FBTCxDQUFTLENBQUV5bkIsS0FBRixFQUFTdm5CLEtBQVQsS0FBa0I7QUFDdkIsY0FBSXduQixPQUFPLEdBQUdoUyxJQUFJLENBQUM5SSxJQUFJLENBQUMrYSxLQUFMLENBQVcvYSxJQUFJLENBQUNnYixNQUFMLEtBQWMsQ0FBekIsQ0FBRCxDQUFsQjtBQUNBLDhCQUFRO0FBQW1CLHFCQUFTLEVBQUMsWUFBN0I7QUFBMEMsaUJBQUssRUFBRTtBQUFFMW1CLGNBQUFBLFVBQVUsRUFBRyxPQUFNdW1CLEtBQUssQ0FBQ2hjLElBQUssR0FBaEM7QUFBb0NvYyxjQUFBQSxLQUFLLEVBQUcsR0FBRUgsT0FBTyxDQUFDLENBQUQsQ0FBSSxFQUF6RDtBQUE0RDFtQixjQUFBQSxNQUFNLEVBQUcsR0FBRTBtQixPQUFPLENBQUMsQ0FBRCxDQUFJO0FBQWxGO0FBQWpELGFBQVd4bkIsS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFSO0FBQ0gsU0FIRCxDQUZSLGVBT0ksOERBQUMsUUFBRDtBQUFVLGVBQUssRUFBRTtBQUFFNG5CLFlBQUFBLE9BQU8sRUFBRyxHQUFFNUssSUFBSSxDQUFDMUUsTUFBTCxJQUFlLENBQWYsR0FBaUIsT0FBakIsR0FBMEIsTUFBTztBQUEvQyxXQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5KLGVBb0JJLDhEQUFDLCtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcEJKO0FBQUEsa0JBREo7QUF3QkgsQ0FwREQ7O0FBc0RBLGlFQUFleU8sYUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakhBO0FBQ0E7O0FBRUEsTUFBTWMsZUFBZSxHQUFHdHNCLDhEQUFXO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU13SSx5REFBYztBQUNwQjtBQUNBO0FBQ0EsQ0FWQTs7QUFZQSxNQUFNQyxTQUFTLEdBQUcsTUFBTTtBQUNwQixzQkFDSSw4REFBQyxlQUFEO0FBQWlCLFdBQU8sRUFBQyxXQUF6QjtBQUFBLDJCQUNJO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsaUVBQWVBLFNBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZCQTtBQUNBOztBQUVBLE1BQU04akIsYUFBYSxHQUFHdnNCLDhEQUFXO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU11SSwrQ0FBUztBQUNmO0FBQ0E7QUFDQSxDQVZBOztBQVlBLE1BQU1ELGVBQWUsR0FBRyxNQUFNO0FBQzFCLHNCQUNJLDhEQUFDLGFBQUQ7QUFBZSxXQUFPLEVBQUMsV0FBdkI7QUFBQSwyQkFDSTtBQUFNLGNBQVEsRUFBQyxTQUFmO0FBQXlCLE9BQUMsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxpRUFBZUEsZUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkJBO0FBQ0E7O0FBRUEsTUFBTWlrQixhQUFhLEdBQUd2c0IsOERBQVc7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTXdJLHlEQUFjO0FBQ3BCO0FBQ0E7QUFDQSxDQVZBOztBQVlBLE1BQU1HLFVBQVUsR0FBRyxNQUFNO0FBQ3JCLHNCQUNJLDhEQUFDLGFBQUQ7QUFBZSxXQUFPLEVBQUMsV0FBdkI7QUFBQSwyQkFDSTtBQUFNLGNBQVEsRUFBQyxTQUFmO0FBQXlCLE9BQUMsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxpRUFBZUEsVUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2QkE7QUFFTyxNQUFNSCxhQUFhLEdBQUd4SSw4REFBVztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FmTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRlA7QUFDQTs7O0FBRUEsTUFBTWMsVUFBVSxHQUFHZCw4REFBVztBQUM5QjtBQUNBO0FBQ0EsQ0FIQTtBQUtBLE1BQU13c0IsZUFBZSxHQUFHeHNCLGlFQUFjO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5BO0FBUUEsTUFBTXNzQixlQUFlLEdBQUd0c0IsOERBQVc7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNd3NCLGVBQWdCO0FBQ3RCO0FBQ0E7QUFDQSxDQVhBOztBQWFBLE1BQU0vakIsU0FBUyxHQUFHLE1BQU07QUFDcEIsc0JBQ0ksOERBQUMsZUFBRDtBQUFpQixXQUFPLEVBQUMsV0FBekI7QUFBQSwyQkFDSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFLSCxDQU5EOztBQVFBLE1BQU1yQixRQUFRLEdBQUcsQ0FBQztBQUFFcWxCLEVBQUFBLGFBQUY7QUFBaUJ2bUIsRUFBQUEsT0FBakI7QUFBMEJnRCxFQUFBQTtBQUExQixDQUFELEtBQThDO0FBQzNELHNCQUNJO0FBQUEsNEJBQ0ksOERBQUMsZUFBRDtBQUFpQixhQUFPLEVBQUVoRCxPQUExQjtBQUFBLDhCQUNJLDhEQUFDLFVBQUQ7QUFBWSxlQUFPLEVBQUMsV0FBcEI7QUFBZ0MsWUFBSSxFQUFDLE1BQXJDO0FBQUEsK0JBQ0k7QUFBTSxXQUFDLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUlJLDhEQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFPSSw4REFBQyxzRUFBRDtBQUFjLFlBQU0sRUFBRXVtQixhQUF0QjtBQUFxQyxrQkFBWSxFQUFFdmpCO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUEo7QUFBQSxrQkFESjtBQVdILENBWkQ7O0FBY0EsaUVBQWU5QixRQUFmOzs7Ozs7Ozs7Ozs7Ozs7OztBQ25EQTtBQUVPLE1BQU1tQixRQUFRLEdBQUd2SSw2REFBVTtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOTzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGUDtBQUVPLE1BQU02SSxVQUFVLEdBQUc3SSw0REFBUztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FaTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQO0FBQ0E7O0FBRUEsTUFBTWMsVUFBVSxHQUFHZCw4REFBVztBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTs7QUFRQSxNQUFNbUgsWUFBWSxHQUFHLENBQUM7QUFBRWhGLEVBQUFBO0FBQUYsQ0FBRCxLQUFjO0FBQy9CLHNCQUNJLDhEQUFDLGtEQUFEO0FBQU0sUUFBSSxFQUFFQSxJQUFaO0FBQWtCLFlBQVEsTUFBMUI7QUFBQSwyQkFDSTtBQUFBLDZCQUNJLDhEQUFDLFVBQUQ7QUFBWSxlQUFPLEVBQUMsYUFBcEI7QUFBa0MsWUFBSSxFQUFDLE1BQXZDO0FBQUEsK0JBQ0k7QUFBTSxXQUFDLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFTSCxDQVZEOztBQVlBLGlFQUFlZ0YsWUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ0hBLHlHQUE4Qzs7Ozs7Ozs7Ozs7O0FDQTlDOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9CdXR0b24vQnV0dG9uLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9Gb290ZXIvRmlzdExvZ28uanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL0Zvb3Rlci9Gb290ZXIuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL0Zvb3Rlci9Gb290ZXJMYXlvdXQuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL0Zvb3Rlci9JY29uL0ZhY2Vib29rSWNvbi5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvRm9vdGVyL0ljb24vSW5zdGFncmFtSWNvbi5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvRm9vdGVyL0ljb24vWW91dHViZUljb24uanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL0Zvb3Rlci9JY29uL2luZGV4LmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL0Zvb3Rlci9MaW5rSG92ZXIuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL0Zvb3Rlci9SaW90R2FtZXNMb2dvLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9IZWFkLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9NZWRpYUNvbXBvbmVudC9DYXRlZ29yeUJhci5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTWVkaWFDb21wb25lbnQvRmlsdGVyRHJvcGJveC5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTWVkaWFDb21wb25lbnQvTWVkaWFIZWFkLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9NZWRpYUNvbXBvbmVudC9pbmRleC5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9OYXYvTGFuZ0J1dHRvbi5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L0xhbmdTZWxlY3Rvci5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L05hdkJhci5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L05hdkRyb3Bkb3duL0V4dGVybmFsTGkuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9OYXZEcm9wZG93bi9MaS5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L05hdkRyb3Bkb3duL05hdkRyb3Bkb3duLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9OYXYvTmF2RHJvcGRvd24vVWwuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9OYXZEcm9wZG93bi9pbmRleC5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9OYXYvTmF2RXh0ZXJuYWxMaW5rL05hdkV4dGVybmFsTGluay5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L05hdkl0ZW0vTmF2SXRlbS5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L05hdkxheW91dC5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L05hdlNlcGFyYXRvci5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L1BsYXlCdXR0b24uanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9QbGF5UG9wdXAuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9SaWdodE5hdi5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L1Jpb3RHYW1lc0Jhci5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvVGV4dEJnLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9UZXh0VGl0bGUuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL2luZGV4LmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9saW5rLmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9ub3JtYWxpemUtdHJhaWxpbmctc2xhc2guanMiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3JlcXVlc3QtaWRsZS1jYWxsYmFjay5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvcm91dGUtbG9hZGVyLmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9yb3V0ZXIuanMiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3VzZS1pbnRlcnNlY3Rpb24uanMiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3dpdGgtcm91dGVyLmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3JvdXRlci5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vcGFnZXMvbWVkaWEvW2NhdGVnb3J5XS9pbmRleC5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL3N0eWxlcy9uYXZfY29tcG9uZW50cy9DYXJldERvd24uanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9zdHlsZXMvbmF2X2NvbXBvbmVudHMvRHJvcGRvd25BcnJvd1VwLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL25hdl9jb21wb25lbnRzL05hdkFycm93VXAuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9zdHlsZXMvbmF2X2NvbXBvbmVudHMvTmF2SXRlbUxheW91dC5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL3N0eWxlcy9uYXZfY29tcG9uZW50cy9SaW90TG9nby5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL3N0eWxlcy9uYXZfY29tcG9uZW50cy9TdHlsZWRMaS5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL3N0eWxlcy9uYXZfY29tcG9uZW50cy9TdHlsZWRMaW5rLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL25hdl9jb21wb25lbnRzL1ZhbG9yYW50TG9nby5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL3N0eWxlcy9uYXZfY29tcG9uZW50cy9pbmRleC5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL05ld3MubW9kdWxlLmNzcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL21lZGlhLm1vZHVsZS5jc3MiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL25vZGVfbW9kdWxlcy9uZXh0L2xpbmsuanMiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcIm5leHQvZGlzdC9zZXJ2ZXIvZGVub3JtYWxpemUtcGFnZS1wYXRoLmpzXCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL2kxOG4vbm9ybWFsaXplLWxvY2FsZS1wYXRoLmpzXCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL21pdHQuanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyLWNvbnRleHQuanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2dldC1hc3NldC1wYXRoLWZyb20tcm91dGUuanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2lzLWR5bmFtaWMuanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3BhcnNlLXJlbGF0aXZlLXVybC5qc1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcXVlcnlzdHJpbmcuanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3JvdXRlLW1hdGNoZXIuanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3JvdXRlLXJlZ2V4LmpzXCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3V0aWxzLmpzXCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJuZXh0L3JvdXRlclwiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJyZWFjdC1pc1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwic3R5bGVkLWNvbXBvbmVudHNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2lnbm9yZWR8QzpcXFVzZXJzXFxVc2VyXFxEZXNrdG9wXFx2YWxvcmFudFxcdmFsb3JhbnRfd2ViXFxteW5leHRhcHBcXG5vZGVfbW9kdWxlc1xcbmV4dFxcZGlzdFxcc2hhcmVkXFxsaWJcXHJvdXRlcnwuL3V0aWxzL3Jlc29sdmUtcmV3cml0ZXMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmNvbnN0IFN0eWxlZEJ1dHRvbldyYXBwZXIgPSBzdHlsZWQuYnV0dG9uYFxyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgd2lkdGg6IDI3MHB4O1xyXG4gICAgaGVpZ2h0OiA2OHB4O1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIHBhZGRpbmc6IDZweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuYFxyXG5cclxuY29uc3QgQ29udGVudCA9IHN0eWxlZC5kaXZgXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAke3Byb3BzID0+IHByb3BzLmlzV2hpdGUgPyBcIiNlY2U4ZTFcIiA6IFwiI2ZmNDY1NVwifTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC1mYW1pbHk6ICdCYWkgSmFtanVyZWUnLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLmlzV2hpdGUgPyBcIiMwZjE5MjNcIiA6IFwid2hpdGVcIn07XHJcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIGVhc2UtaW4gLjJzLCBib3JkZXIgLjJzO1xyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogIzBmMTkyMztcclxuICAgICAgICBvdXRsaW5lOiAke3Byb3BzID0+IHByb3BzLmlzQm9yZGVyZWQgPyBgc29saWQgJHtwcm9wcy5pc1doaXRlID8gXCIjZWNlOGUxNDRcIiA6IFwiI2ZmNDY1NTQ0XCJ9IDFweGAgOiBcIm5vbmVcIn07XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgfVxyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuYFxyXG5cclxuY29uc3QgV2hpdGVCb3ggPSBzdHlsZWQuZGl2YFxyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzBmMTkyMztcclxuICAgIHdpZHRoOiA1cHg7XHJcbiAgICBoZWlnaHQ6IDVweDtcclxuICAgIHJpZ2h0OiAwO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCBlYXNlLWluIC4zcztcclxuICAgICR7Q29udGVudH06aG92ZXIgJiB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcbmBcclxuXHJcbmNvbnN0IEJ1dHRvbkJvcmRlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBib3JkZXItbGVmdDogc29saWQgI2JkYmNiNyAxcHg7XHJcbiAgICBib3JkZXItcmlnaHQ6IHNvbGlkICNiZGJjYjcgMXB4O1xyXG4gICAgbGVmdDogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAyOXB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG5gXHJcblxyXG5jb25zdCBUb3BCb3JkZXIgPSBzdHlsZWQoQnV0dG9uQm9yZGVyKWBcclxuICAgIGJvcmRlci10b3A6IHNvbGlkICNiZGJjYjcgMXB4O1xyXG4gICAgdG9wOiAwO1xyXG5gXHJcblxyXG5jb25zdCBCb3R0b21Cb3JkZXIgPSBzdHlsZWQoQnV0dG9uQm9yZGVyKWBcclxuICAgIGJvcmRlci1ib3R0b206IHNvbGlkICNiZGJjYjcgMXB4O1xyXG4gICAgYm90dG9tOiAwO1xyXG5gXHJcblxyXG5jb25zdCBCdXR0b24gPSAoeyBjaGlsZHJlbiwgaXNXaGl0ZSwgaXNCb3JkZXJlZCB9KSA9PiAoXHJcbiAgICA8U3R5bGVkQnV0dG9uV3JhcHBlcj5cclxuICAgICAgICA8VG9wQm9yZGVyIC8+XHJcbiAgICAgICAgPEJvdHRvbUJvcmRlciAvPlxyXG4gICAgICAgIDxDb250ZW50IGlzV2hpdGU9e2lzV2hpdGV9IGlzQm9yZGVyZWQ9e2lzQm9yZGVyZWR9PlxyXG4gICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICAgIDxXaGl0ZUJveCAvPlxyXG4gICAgICAgIDwvQ29udGVudD5cclxuICAgIDwvU3R5bGVkQnV0dG9uV3JhcHBlcj5cclxuKVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQnV0dG9uO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiXHJcblxyXG5jb25zdCBTdHlsZWRMb2dvID0gc3R5bGVkLnN2Z2BcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA2cHg7XHJcbmBcclxuXHJcbmNvbnN0IEZpc3RMb2dvID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkTG9nbyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIiNFNkU2RTZcIj5cclxuICAgICAgICAgICAgPHBhdGggZD1cIk0xMi41MzQgMjEuNzdsLTEuMDktMi44MSAxMC41Mi41NC0uNDUxIDQuNXpNMTUuMDYgMEwuMzA3IDYuOTY5IDIuNTkgMTcuNDcxSDUuNmwtLjUyLTcuNTEyLjQ2MS0uMTQ0IDEuODEgNy42NTZoMy4xMjZsLS4xMTYtOS4xNS40NjItLjE0NCAxLjU4MiA5LjI5NGgzLjMxbC43OC0xMS4wNTMuNDYyLS4xNDQuODIgMTEuMTk3aDQuMzc2bDEuNTQtMTUuMzdaXCIgLz5cclxuICAgICAgICA8L1N0eWxlZExvZ28+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZpc3RMb2dvO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgeyBGb290ZXJMYXlvdXQgfSBmcm9tIFwiLi9Gb290ZXJMYXlvdXRcIjtcclxuaW1wb3J0IFJpb3RHYW1lc0xvZ28gZnJvbSBcIi4vUmlvdEdhbWVzTG9nb1wiO1xyXG5pbXBvcnQgRmlzdExvZ28gZnJvbSBcIi4vRmlzdExvZ29cIjtcclxuaW1wb3J0IEJ1dHRvbldyYXBwZXIgZnJvbSBcIi4vTGlua0hvdmVyXCI7XHJcbmltcG9ydCB7IEZhY2Vib29rSWNvbiwgSW5zdGFncmFtSWNvbiwgWW91dHViZUljb24gfSBmcm9tICcuL0ljb24nXHJcblxyXG5jb25zdCBQID0gc3R5bGVkLnBgXHJcbiAgICB1c2VyLXNlbGVjdDogbm9uZTtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuYFxyXG5cclxuY29uc3QgUmVzZXJ2ZWQgPSBzdHlsZWQoUClgXHJcbiAgICBtYXgtd2lkdGg6IDUwMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY3Vyc29yOiBkZWZhdWx0O1xyXG5gXHJcblxyXG5jb25zdCBMb2dvV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG5gXHJcblxyXG5jb25zdCBVbmRlcmxpbmUgPSBzdHlsZWQoUClgXHJcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuYFxyXG5cclxuY29uc3QgTGlua1dyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGNvbHVtbi1nYXA6IDEycHg7XHJcbmBcclxuXHJcbmNvbnN0IFNvY2lhbFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGNvbHVtbi1nYXA6IDI0cHg7XHJcbmBcclxuXHJcbmNvbnN0IEZvb3RlciA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEZvb3RlckxheW91dD5cclxuICAgICAgICAgICAgPEJ1dHRvbldyYXBwZXI+XHJcbiAgICAgICAgICAgICAgICA8UD7guJTguLLguKfguJnguYzguYLguKvguKXguJTguYDguIHguKE8L1A+XHJcbiAgICAgICAgICAgIDwvQnV0dG9uV3JhcHBlcj5cclxuICAgICAgICAgICAgPExvZ29XcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgPEZpc3RMb2dvIC8+XHJcbiAgICAgICAgICAgICAgICA8UmlvdEdhbWVzTG9nbyAvPlxyXG4gICAgICAgICAgICA8L0xvZ29XcmFwcGVyPlxyXG4gICAgICAgICAgICA8U29jaWFsV3JhcHBlcj5cclxuICAgICAgICAgICAgICAgIDxGYWNlYm9va0ljb24vPlxyXG4gICAgICAgICAgICAgICAgPFlvdXR1YmVJY29uLz5cclxuICAgICAgICAgICAgICAgIDxJbnN0YWdyYW1JY29uLz5cclxuICAgICAgICAgICAgPC9Tb2NpYWxXcmFwcGVyPlxyXG4gICAgICAgICAgICA8UmVzZXJ2ZWQ+wqkg4Liq4LiH4Lin4LiZ4Lil4Li04LiC4Liq4Li04LiX4LiY4Li04LmM4LiV4Liy4Lih4LiB4LiP4Lir4Lih4Liy4LiiIOC4ni7guKguIDI1NjMg4Lia4Lij4Li04Lip4Lix4LiXIFJpb3QsIFZBTE9SQU5UIOC5geC4peC4sOC5guC4peC5guC4geC5ieC5gOC4hOC4o+C4t+C5iOC4reC4h+C4q+C4oeC4suC4ouC4geC4suC4o+C4hOC5ieC4siDguYDguITguKPguLfguYjguK3guIfguKvguKHguLLguKLguJrguKPguLTguIHguLLguKPguYHguKXguLAv4Lir4Lij4Li34LitIOC5gOC4hOC4o+C4t+C5iOC4reC4h+C4q+C4oeC4suC4ouC4geC4suC4o+C4hOC5ieC4suC4iOC4lOC4l+C4sOC5gOC4muC4teC4ouC4meC4l+C4teC5iOC5gOC4geC4teC5iOC4ouC4p+C4guC5ieC4reC4hyDguJbguLfguK3guYDguJvguYfguJnguIHguKPguKPguKHguKrguLTguJfguJjguLTguYzguILguK3guIcgUmlvdCBHYW1lcywgSW5jLjwvUmVzZXJ2ZWQ+XHJcbiAgICAgICAgICAgIDxMaW5rV3JhcHBlcj5cclxuICAgICAgICAgICAgICAgIDxVbmRlcmxpbmU+4LiZ4LmC4Lii4Lia4Liy4Lii4LiE4Lin4Liy4Lih4LmA4Lib4LmH4LiZ4Liq4LmI4Lin4LiZ4LiV4Lix4LinPC9VbmRlcmxpbmU+XHJcbiAgICAgICAgICAgICAgICA8VW5kZXJsaW5lPuC4guC5ieC4reC4geC4s+C4q+C4meC4lOC4geC4suC4o+C5g+C4iuC5iTwvVW5kZXJsaW5lPlxyXG4gICAgICAgICAgICAgICAgPFVuZGVybGluZT7guIHguLLguKPguJXguLHguYnguIfguITguYjguLLguITguLjguIHguIHguLXguYk8L1VuZGVybGluZT5cclxuICAgICAgICAgICAgPC9MaW5rV3JhcHBlcj5cclxuICAgICAgICA8L0Zvb3RlckxheW91dD5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiXHJcblxyXG5leHBvcnQgY29uc3QgRm9vdGVyTGF5b3V0ID0gc3R5bGVkLmZvb3RlcmBcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA1NzBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMxMTE7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogIzdlN2U3ZTtcclxuICAgIGZpbGw6ICM3ZTdlN2U7XHJcbiAgICByb3ctZ2FwOiAzMnB4O1xyXG4gICAgcGFkZGluZzogMjhweDtcclxuICAgIGZvbnQtZmFtaWx5OiAnQmFpIEphbWp1cmVlJywgc2Fucy1zZXJpZjtcclxuYCIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcblxyXG5jb25zdCBTdHlsZWRMb2dvID0gc3R5bGVkLnN2Z2BcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgaGVpZ2h0OiAyNHB4O1xyXG4gICAgdHJhbnNpdGlvbjogZmlsbCAuM3M7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBmaWxsOiB3aGl0ZTtcclxuICAgIH1cclxuYFxyXG5cclxuY29uc3QgRmFjZWJvb2tJY29uID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkTG9nbyB2aWV3Qm94PVwiMCAwIDE2IDE2XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTYgOC4wNDljMC00LjQ0Ni0zLjU4Mi04LjA1LTgtOC4wNUMzLjU4IDAtLjAwMiAzLjYwMy0uMDAyIDguMDVjMCA0LjAxNyAyLjkyNiA3LjM0NyA2Ljc1IDcuOTUxdi01LjYyNWgtMi4wM1Y4LjA1SDYuNzVWNi4yNzVjMC0yLjAxNyAxLjE5NS0zLjEzMSAzLjAyMi0zLjEzMS44NzYgMCAxLjc5MS4xNTcgMS43OTEuMTU3djEuOThoLTEuMDA5Yy0uOTkzIDAtMS4zMDMuNjIxLTEuMzAzIDEuMjU4djEuNTFoMi4yMThsLS4zNTQgMi4zMjZIOS4yNVYxNmMzLjgyNC0uNjA0IDYuNzUtMy45MzQgNi43NS03Ljk1MXpcIi8+XHJcbiAgICAgICAgPC9TdHlsZWRMb2dvPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGYWNlYm9va0ljb247XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcblxyXG5jb25zdCBTdHlsZWRMb2dvID0gc3R5bGVkLnN2Z2BcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgaGVpZ2h0OiAyNHB4O1xyXG4gICAgdHJhbnNpdGlvbjogZmlsbCAuM3M7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBmaWxsOiB3aGl0ZTtcclxuICAgIH1cclxuYFxyXG5cclxuY29uc3QgSW5zdGFncmFtSWNvbiA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFN0eWxlZExvZ28gdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICA8cGF0aCBmaWxsUnVsZT1cImV2ZW5vZGRcIiBjbGlwUnVsZT1cImV2ZW5vZGRcIiBkPVwiTTEyIDI0YzYuNjI3IDAgMTItNS4zNzMgMTItMTJTMTguNjI3IDAgMTIgMCAwIDUuMzczIDAgMTJzNS4zNzMgMTIgMTIgMTJ6bTIuODI5LTE3LjY5OGMtLjczOS0uMDM0LS45Ni0uMDQtMi44MjktLjA0LTEuODcgMC0yLjA5LjAwNi0yLjgyOS4wNC0uNjgyLjAzMS0xLjA1My4xNDUtMS4zLjI0MS0uMzI2LjEyNy0uNTYuMjc4LS44MDUuNTIzYTIuMTcxIDIuMTcxIDAgMDAtLjUyMy44MDVjLS4wOTYuMjQ3LS4yMS42MTgtLjI0IDEuMy0uMDM1LjczOS0uMDQyLjk2LS4wNDIgMi44MjkgMCAxLjg3LjAwNyAyLjA5LjA0MSAyLjgyOS4wMzEuNjgyLjE0NSAxLjA1My4yNDEgMS4zLjEyNy4zMjYuMjc4LjU2LjUyMy44MDQuMjQ2LjI0NS40NzkuMzk3LjgwNS41MjQuMjQ3LjA5Ni42MTguMjEgMS4zLjI0LjczOC4wMzUuOTYuMDQyIDIuODI5LjA0MiAxLjg3IDAgMi4wOS0uMDA4IDIuODI5LS4wNDEuNjgyLS4wMzEgMS4wNTMtLjE0NSAxLjMtLjI0MS4zMjYtLjEyNy41Ni0uMjc4LjgwNC0uNTI0LjI0NS0uMjQ1LjM5Ny0uNDc4LjUyNC0uODA1LjA5Ni0uMjQ2LjIxLS42MTcuMjQtMS4zLjAzNS0uNzM4LjA0Mi0uOTU5LjA0Mi0yLjgyOCAwLTEuODctLjAwOC0yLjA5LS4wNDEtMi44MjktLjAzMS0uNjgyLS4xNDUtMS4wNTMtLjI0MS0xLjNhMi4xNjQgMi4xNjQgMCAwMC0uNTI0LS44MDUgMi4xNzIgMi4xNzIgMCAwMC0uODA1LS41MjNjLS4yNDYtLjA5Ni0uNjE3LS4yMS0xLjMtLjI0em0tNS43MTUtMS4yNkM5Ljg2IDUuMDA4IDEwLjA5OSA1IDEyIDVjMS45MDEgMCAyLjE0LjAwOCAyLjg4Ni4wNDIuNzQ1LjAzNCAxLjI1NC4xNTMgMS43LjMyNS40Ni4xOC44NS40MTkgMS4yNC44MDguMzg5LjM4OS42MjguNzguODA3IDEuMjQuMTczLjQ0NS4yOTEuOTU0LjMyNSAxLjY5OS4wMzUuNzQ2LjA0My45ODUuMDQzIDIuODg2IDAgMS45MDEtLjAwOSAyLjE0LS4wNDMgMi44ODYtLjAzNC43NDUtLjE1MiAxLjI1NC0uMzI1IDEuN2EzLjQzIDMuNDMgMCAwMS0uODA3IDEuMjRjLS4zOS4zODktLjc4LjYyOC0xLjI0LjgwNy0uNDQ1LjE3My0uOTU1LjI5MS0xLjcuMzI1LS43NDYuMDM0LS45ODUuMDQyLTIuODg2LjA0Mi0xLjkgMC0yLjE0LS4wMDgtMi44ODYtLjA0Mi0uNzQ1LS4wMzQtMS4yNTQtLjE1Mi0xLjctLjMyNWEzLjQzIDMuNDMgMCAwMS0xLjIzOS0uODA4IDMuNDI4IDMuNDI4IDAgMDEtLjgwNy0xLjI0Yy0uMTczLS40NDUtLjI5Mi0uOTU0LS4zMjYtMS42OTlDNS4wMDggMTQuMTQgNSAxMy45MDEgNSAxMmMwLTEuOTAxLjAwOC0yLjE0LjA0Mi0yLjg4Ni4wMzQtLjc0NS4xNTMtMS4yNTQuMzI2LTEuNy4xNzgtLjQ2LjQxOC0uODUuODA3LTEuMjM5LjM4OS0uMzkuNzgtLjYyOCAxLjI0LS44MDcuNDQ1LS4xNzMuOTU0LS4yOTIgMS42OTktLjMyNnpNMTIgOC40MDVhMy41OTQgMy41OTQgMCAxMDAgNy4xOSAzLjU5NCAzLjU5NCAwIDAwMC03LjE5em0wIDUuOTI4YTIuMzMzIDIuMzMzIDAgMTEwLTQuNjY2IDIuMzMzIDIuMzMzIDAgMDEwIDQuNjY2em00LjU3Ny02LjA3YS44NC44NCAwIDExLTEuNjggMCAuODQuODQgMCAwMTEuNjggMHpcIiAvPlxyXG4gICAgICAgIDwvU3R5bGVkTG9nbz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSW5zdGFncmFtSWNvbjtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmNvbnN0IFN0eWxlZExvZ28gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IDI0cHg7XHJcbiAgICB0cmFuc2l0aW9uOiBmaWxsIC4zcztcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICY6aG92ZXIge1xyXG4gICAgICAgIGZpbGw6IHdoaXRlO1xyXG4gICAgfVxyXG5gXHJcblxyXG5jb25zdCBZb3V0dWJlSWNvbiA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFN0eWxlZExvZ28gdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICA8cGF0aCBmaWxsUnVsZT1cImV2ZW5vZGRcIiBjbGlwUnVsZT1cImV2ZW5vZGRcIiBkPVwiTTEyIDI0YzYuNjI3IDAgMTItNS4zNzMgMTItMTJTMTguNjI3IDAgMTIgMCAwIDUuMzczIDAgMTJzNS4zNzMgMTIgMTIgMTJ6bTUuNDctMTYuMjMxYy42MDIuMTQ4IDEuMDc3LjU4MyAxLjIzNyAxLjEzNkMxOSA5LjkwOCAxOSAxMiAxOSAxMnMwIDIuMDkyLS4yOTMgMy4wOTVjLS4xNi41NTMtLjYzNS45ODgtMS4yMzggMS4xMzZDMTYuMzggMTYuNSAxMiAxNi41IDEyIDE2LjVzLTQuMzc4IDAtNS40Ny0uMjY4Yy0uNjAyLS4xNDktMS4wNzctLjU4NC0xLjIzNy0xLjEzN0M1IDE0LjA5MiA1IDEyIDUgMTJzMC0yLjA5Mi4yOTMtMy4wOTVjLjE2LS41NTMuNjM1LS45ODggMS4yMzctMS4xMzZDNy42MjIgNy41IDEyIDcuNSAxMiA3LjVzNC4zNzggMCA1LjQ3LjI2OXpNMTQuMjI2IDEybC0zLjY1OS0xLjl2My44bDMuNjYtMS45elwiIC8+XHJcbiAgICAgICAgPC9TdHlsZWRMb2dvPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBZb3V0dWJlSWNvbjtcclxuIiwiZXhwb3J0IHtkZWZhdWx0IGFzIEZhY2Vib29rSWNvbn0gZnJvbSAnLi9GYWNlYm9va0ljb24nXHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBJbnN0YWdyYW1JY29ufSBmcm9tICcuL0luc3RhZ3JhbUljb24nXHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBZb3V0dWJlSWNvbn0gZnJvbSAnLi9Zb3V0dWJlSWNvbiciLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5hYFxyXG4gICAgdHJhbnNpdGlvbjogY29sb3IgLjNzO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgfVxyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuYFxyXG5cclxuY29uc3QgQnV0dG9uV3JhcHBlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFdyYXBwZXI+XHJcbiAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICA8L1dyYXBwZXI+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJ1dHRvbldyYXBwZXI7XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcblxyXG5jb25zdCBTdHlsZWRMb2dvID0gc3R5bGVkLnN2Z2BcclxuICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG5gXHJcblxyXG5jb25zdCBSaW90R2FtZXNMb2dvID0gKHsgaHJlZiB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRMb2dvIHZpZXdCb3g9XCIwIDAgNjAwIDMwNS40MVwiIGZpbGw9XCIjRTZFNkU2XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJtNDA0LjgyIDI5MC42MS0uMzkyMjUtMTEuMjkxIDM5LjAzMi0uNDYxMjguMzU4MTQtMTIuMzA1LTM5Ljg1MS0uNDk1MzgtLjM5NzkzLTExLjQzMSA1Mi41MDMtMS4yMjkxLjQzMjg1LTEzLjVoLTcwLjgzM2wtMi4xMTE1IDY1LjUxaDc0LjI1MWwtLjUyMTM4LTEzLjUyNXptLTM1My4xOC0yNC4wODYtLjgzMzcyIDEyLjI1NiAxOS42OTkuNjU4NjItLjI0OTMyIDEyLjQ0Mi00MS4yMzItMS4yMDkgMS43OTYzLTM1LjkzOCA1Ni42OTItMS4zMTIxLS44MTkzNC0xMy41MjVoLTczLjIyOGwtNi41NjY1IDY1LjUxaDgzLjQzNmwtMi4xNjMxLTM5LjUxOXptNTE2LjgxIDUuMDY4MS01NC4xMTYtOS4xNDc4LjIzNDctNy4wOTA3IDUxLjc3LTEuOTMxLTEuMzA2NC0xMy41MjVoLTY2LjU0N2wtMy40MDM2IDMzLjk1NSA1NS4wMTYgOS41NjYuMjQ5MzIgNi4yMzk5LTU3LjI0MiAyLjIyMzItMS40MDM4IDEzLjUyNWg4MC4xMTV6XCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwibTM0Ny42MyAzMDUuNDEtNi41NjY0LTY1LjUxaC0xOC44NTFsLTI3LjA4MiAzMS4yMjgtMjcuMDg1LTMxLjIyOGgtMTguODUxbC02LjU2NjQgNjUuNTFoMjIuMTQ2bDIuMTIwMS00Mi40OTkgMjguMjM3IDI4Ljk3MyAyOC4yMzEtMjguOTczIDIuMTI1OCA0Mi40OTl6XCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwibTI1NC41NSAwaC00NC4zMjRsLTQuMDMzOCAyMDIuNTloNTMuNTUyelwiLz5cclxuICAgICAgICAgICAgPHBhdGggZD1cIm0zOTEuODkgMTU4LjUyLTQ4LjkwNyAxLjU3ODYtMS42MjE1LTExOS4xNSA1MS4xNTEgMS41NDk5em00Mi44NjItMTU4LjQzaC0xMzguMTlsLTUuMzgwNCAyMDIuNWgxNTMuMzh6XCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwibTYwMCA0NC4zMzYtNC45MzYzLTQ0LjMzNWgtMTM2LjE1bDEuMTUxNyAzOS40OTMgNDMuNTQ3IDEuNTA3IDQuNDYzNSAxNjEuNTloNTMuNjZsLTE2LjA1Mi0xNjAuMTR6XCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwibTczLjY0IDQxLjQ0NCA0Mi43MTEtMS40Mjk2IDQuODY3NSA0MC4zNjQtNDkuMjk3IDIzLjI4NnptNDkuODk5IDE2MS4xNWg1OC4xNjdsLTM3LjkwOS05MC45MjUgMzAuMjUxLTE2LjUyOC0yMC42NjgtOTUuMTM5aC0xNDguNDhsLTQuODg3NSA0My45MDUgMzMuMjE2LTEuMTA4OC0xNi4wMTggMTU5LjhoNTEuOTg0bDEuNDA2Ny01MC45MzkgMzcuNDU2LTIwLjQ2MnpcIi8+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJtMTUxLjgyIDI3NS44OSA0LjUwMzctMjEuNDMzIDIxLjYyNS0uOTc2OTggNC41MTggMjEuNTA3em0zNy4wNDQgMjkuNTI2aDIyLjQyNGwtMTcuNzQzLTY1LjUxM2gtNTIuNjE1bC0xNy43NCA2NS41MTNoMjIuNDI0bDMuNDcyMy0xNi41MjggMzYuNDAyLjQ3MDIxelwiLz5cclxuICAgICAgICA8L1N0eWxlZExvZ28+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJpb3RHYW1lc0xvZ287IiwiaW1wb3J0IE5leHRIZWFkIGZyb20gJ25leHQvaGVhZCc7XHJcblxyXG5jb25zdCBIZWFkID0gKHsgdGl0bGUgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8TmV4dEhlYWQ+XHJcbiAgICAgICAgICAgIDxtZXRhIGNoYXJTZXQ9XCJVVEYtOFwiIC8+XHJcbiAgICAgICAgICAgIDxtZXRhIGh0dHBFcXVpdj1cIlgtVUEtQ29tcGF0aWJsZVwiIGNvbnRlbnQ9XCJJRT1lZGdlXCIgLz5cclxuICAgICAgICAgICAgPG1ldGEgbmFtZT1cInZpZXdwb3J0XCIgY29udGVudD1cIndpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xLjBcIiAvPlxyXG4gICAgICAgICAgICA8bGluayByZWw9XCJzaG9ydGN1dCBpY29uXCIgaHJlZj1cImZhdmljb24uc3ZnXCIgdHlwZT1cImltYWdlL3gtc3ZnXCIgLz5cclxuICAgICAgICAgICAgPHRpdGxlPnt0aXRsZX08L3RpdGxlPlxyXG4gICAgICAgIDwvTmV4dEhlYWQ+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhlYWQ7IiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQgeyBGaWx0ZXJEcm9wYm94IH0gZnJvbSAnLidcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInXHJcbmNvbnN0IEJhciA9IHN0eWxlZC51bGBcclxuICAgIGhlaWdodDogMTB2aDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgfVxyXG5gXHJcbmNvbnN0IENhdGVnb3J5ID0gc3R5bGVkLmxpYFxyXG5mbG9hdDogbGVmdDtcclxubWFyZ2luLWxlZnQ6IDUwcHg7XHJcbmxpc3Qtc3R5bGUtdHlwZTogbm9uZTsgXHJcbmhlaWdodDogNXZoO1xyXG5gXHJcbmNvbnN0IENhdGVnb3J5QmFyID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgICBjb25zdCB7IGNhdGVnb3J5IH0gPSByb3V0ZXIucXVlcnk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgICAgPEJhcj5cclxuICAgICAgICAgICAgPENhdGVnb3J5IHN0eWxlPXt7IGNvbG9yOiBgJHsgY2F0ZWdvcnkgPT0gXCJhbGxcIj9cImJsYWNrXCI6IFwiIzhiOTc4ZlwifWAsIGJvcmRlckJvdHRvbTogYCR7IGNhdGVnb3J5ID09IFwiYWxsXCI/XCIxcHggc29saWQgYmxhY2tcIjogXCJub25lXCJ9YCB9fSA+PExpbmsgaHJlZj1cIi9tZWRpYS9hbGxcIiBzY3JvbGw9e2ZhbHNlfT7guJfguLHguYnguIfguKvguKHguJQ8L0xpbms+PC9DYXRlZ29yeT5cclxuICAgICAgICAgICAgPENhdGVnb3J5IHN0eWxlPXt7IGNvbG9yOiBgJHsgY2F0ZWdvcnkgPT0gXCJ3YWxscGFwZXJcIj9cImJsYWNrXCI6IFwiIzhiOTc4ZlwifWAsIGJvcmRlckJvdHRvbTogYCR7IGNhdGVnb3J5ID09IFwid2FsbHBhcGVyXCI/XCIxcHggc29saWQgYmxhY2tcIjogXCJub25lXCJ9YCB9fSA+PExpbmsgaHJlZj1cIi9tZWRpYS93YWxscGFwZXJcIiBzY3JvbGw9e2ZhbHNlfT7guKfguK3guKXguYDguJvguYDguJvguK3guKPguYw8L0xpbms+PC9DYXRlZ29yeT5cclxuICAgICAgICAgICAgPENhdGVnb3J5IHN0eWxlPXt7IGNvbG9yOiBgJHsgY2F0ZWdvcnkgPT0gXCJ2aWRlb1wiP1wiYmxhY2tcIjogXCIjOGI5NzhmXCJ9YCwgYm9yZGVyQm90dG9tOiBgJHsgY2F0ZWdvcnkgPT0gXCJ2aWRlb1wiP1wiMXB4IHNvbGlkIGJsYWNrXCI6IFwibm9uZVwifWAgfX0gPjxMaW5rIGhyZWY9XCIvbWVkaWEvdmlkZW9cIiBzY3JvbGw9e2ZhbHNlfT7guKfguLTguJTguLXguYLguK08L0xpbms+PC9DYXRlZ29yeT5cclxuICAgICAgICAgICAgPENhdGVnb3J5IHN0eWxlPXt7IGNvbG9yOiBgJHsgY2F0ZWdvcnkgPT0gXCJzY3JlZW5zaG90XCI/XCJibGFja1wiOiBcIiM4Yjk3OGZcIn1gLCBib3JkZXJCb3R0b206IGAkeyBjYXRlZ29yeSA9PSBcInNjcmVlbnNob3RcIj9cIjFweCBzb2xpZCBibGFja1wiOiBcIm5vbmVcIn1gIH19ID48TGluayBocmVmPVwiL21lZGlhL3NjcmVlbnNob3RcIiBzY3JvbGw9e2ZhbHNlfT7guKrguIHguKPguLXguJnguIrguYfguK3guJU8L0xpbms+PC9DYXRlZ29yeT5cclxuICAgICAgICAgICAgPENhdGVnb3J5IHN0eWxlPXt7IGNvbG9yOiBgJHsgY2F0ZWdvcnkgPT0gXCJhcnR3b3JrXCI/XCJibGFja1wiOiBcIiM4Yjk3OGZcIn1gLCBib3JkZXJCb3R0b206IGAkeyBjYXRlZ29yeSA9PSBcImFydHdvcmtcIj9cIjFweCBzb2xpZCBibGFja1wiOiBcIm5vbmVcIn1gIH19ID48TGluayBocmVmPVwiL21lZGlhL2FydHdvcmtcIiBzY3JvbGw9e2ZhbHNlfT7guK3guLLguKPguYzguJfguYDguKfguLTguKPguYzguIE8L0xpbms+PC9DYXRlZ29yeT5cclxuICAgICAgICAgICAgPENhdGVnb3J5IHN0eWxlPXt7IGNvbG9yOiBgJHsgY2F0ZWdvcnkgPT0gXCJsb2dvXCI/XCJibGFja1wiOiBcIiM4Yjk3OGZcIn1gLCBib3JkZXJCb3R0b206IGAkeyBjYXRlZ29yeSA9PSBcImxvZ29cIj9cIjFweCBzb2xpZCBibGFja1wiOiBcIm5vbmVcIn1gIH19ID48TGluayBocmVmPVwiL21lZGlhL2xvZ29cIiBzY3JvbGw9e2ZhbHNlfT7guYLguKXguYLguIHguYk8L0xpbms+PC9DYXRlZ29yeT5cclxuICAgICAgICAgICAgPENhdGVnb3J5IHN0eWxlPXt7IGNvbG9yOiBgJHsgY2F0ZWdvcnkgPT0gXCJjb250ZW50X2NyZWF0b3JcIj9cImJsYWNrXCI6IFwiIzhiOTc4ZlwifWAsIGJvcmRlckJvdHRvbTogYCR7IGNhdGVnb3J5ID09IFwiY29udGVudF9jcmVhdG9yXCI/XCIxcHggc29saWQgYmxhY2tcIjogXCJub25lXCJ9YCB9fSA+PExpbmsgaHJlZj1cIi9tZWRpYS9jb250ZW50X2NyZWF0b3JcIiBzY3JvbGw9e2ZhbHNlfT7guITguK3guJnguYDguJfguJnguJXguYzguITguKPguLXguYDguK3guYDguJXguK3guKPguYw8L0xpbms+PC9DYXRlZ29yeT5cclxuICAgICAgICAgICAgPEZpbHRlckRyb3Bib3g+PC9GaWx0ZXJEcm9wYm94PlxyXG4gICAgICAgIDwvQmFyPlxyXG5cclxuICAgIDwvPilcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2F0ZWdvcnlCYXI7IiwiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxuY29uc3QgVGV4dCA9IHN0eWxlZC5kaXZgXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBiYWNrZ3JvdW5kOiBhbnRpcXVld2hpdGU7XHJcbiAgICB3aWR0aDogMTB2dztcclxuICAgIGhlaWdodDogMTB2aDtcclxuYFxyXG5cclxuXHJcbmNvbnN0IEJveCA9IHN0eWxlZC5kaXZgXHJcbiAgICB3aWR0aDogMTB2dztcclxuICAgIGhlaWdodDogMTB2aDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAxMHZ3O1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIHRvcDogMDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICM4Yjk3OGY7XHJcblxyXG5gXHJcblxyXG5jb25zdCBGaWx0ZXJEcm9wYm94ID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgICBsZXQgeyBjYXRlZ29yeSwgdHlwZSB9ID0gcm91dGVyLnF1ZXJ5O1xyXG4gICAgaWYodHlwZW9mIHR5cGUgPT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICB0eXBlID0gYGFsbGBcclxuICAgIH1cclxuICAgIGNvbnN0IG9uU2VsZWN0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgICAgICBsZXQgbG9jYWxlID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICAgICAgaWYodHlwZW9mIGNhdGVnb3J5ID09PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgIGNhdGVnb3J5ID0gYGFsbGA7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IGBtZWRpYS8keyBjYXRlZ29yeSB9LyR7IGxvY2FsZSB9YFxyXG4gICAgICAgICAgICByb3V0ZXIucHVzaChsb2NhbGUpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmKHR5cGVvZiB0eXBlID09PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IGAkeyBjYXRlZ29yeSB9LyR7IGxvY2FsZSB9YFxyXG4gICAgICAgICAgICByb3V0ZXIucHVzaChsb2NhbGUpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgIGxvY2FsZSA9IHtcclxuICAgICAgICAgICAgICAgIHBhdGhuYW1lOiAnL21lZGlhL1tjYXRlZ29yeV0vW3R5cGVdJyxcclxuICAgICAgICAgICAgICAgIHF1ZXJ5OiB7Y2F0ZWdvcnk6IGAkeyBjYXRlZ29yeSB9YCwgXCJ0eXBlXCI6IGAkeyBsb2NhbGUgfWB9LFxyXG4gICAgICAgICAgICAgICAgYXNQYXRoOiBgL21lZGlhLyR7IGNhdGVnb3J5IH0vJHsgbG9jYWxlIH1gXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcm91dGVyLnB1c2gobG9jYWxlLmFzUGF0aCwgbG9jYWxlLmFzUGF0aCx7XHJcbiAgICAgICAgICAgICAgICBzY3JvbGw6IGZhbHNlXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgbGV0IGNvbnZlcnQgPSB7XHJcbiAgICAgICAgXCJhbGxcIjogXCLguJfguLHguYnguIfguKvguKHguJRcIixcclxuICAgICAgICBcImFnZW50c1wiOiBcIuC5gOC4reC5gOC4iOC4meC4l+C5jFwiLFxyXG4gICAgICAgIFwibWFwc1wiOiBcIuC5geC4nOC4meC4l+C4teC5iFwiLFxyXG4gICAgICAgIFwiYXJzZW5hbHNcIjogXCLguITguKXguLHguIfguYHguKrguIdcIixcclxuICAgIH1cclxuICAgIGxldCBpdGVtTGlzdCA9IFt7XCJ0eXBlXCIgOiBcIuC4l+C4seC5ieC4h+C4q+C4oeC4lFwiLCBcInZhbHVlXCIgOiBgYWxsYH0sXHJcbiAgICAge1widHlwZVwiIDogXCLguYDguK3guYDguIjguJnguJfguYxcIiwgXCJ2YWx1ZVwiIDogYGFnZW50c2B9LFxyXG4gICAgIHtcInR5cGVcIiA6IFwi4LmB4Lic4LiZ4LiX4Li14LmIXCIsIFwidmFsdWVcIiA6IGBtYXBzYH0sXHJcbiAgICAge1widHlwZVwiIDogXCLguITguKXguLHguIfguYHguKrguIdcIiwgXCJ2YWx1ZVwiIDogYGFyc2VuYWxzYH1dXHJcbiAgICBjb25zdCBvcGVuRHJvcGJveCA9IChlKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZS50YXJnZXQpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxCb3ggb25DbGljaz17IG9wZW5Ecm9wYm94IH0+XHJcbiAgICAgICAgICAgICAgICA8VGV4dCB2YWx1ZT17YC8ke3R5cGV9YH0+eyBjb252ZXJ0W3R5cGVdIH08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbUxpc3QubWFwKChpdGVtLCBpbmRleCk9PntcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYoaXRlbS50eXBlICE9IGNvbnZlcnRbdHlwZV0pe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDxUZXh0IGtleT17IGluZGV4IH0gdmFsdWU9e2l0ZW0udmFsdWV9PntpdGVtLnR5cGV9PC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICA8Lz5cclxuXHJcbiAgICApXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgRmlsdGVyRHJvcGJveDsiLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiXHJcbmltcG9ydCB7VHh0LCBUZXh0QmdDb250YWluZXJ9IGZyb20gJy4uL1RleHRCZydcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi8uLi9zdHlsZXMvbWVkaWEubW9kdWxlLmNzcydcclxuXHJcbmNvbnN0IEJveCA9IHN0eWxlZC5kaXZgXHJcbnBvc2l0aW9uOiByZWxhdGl2ZTtcclxud2lkdGg6IDEwMHZ3O1xyXG5kaXNwbGF5OiBibG9jaztcclxuYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuYFxyXG5jb25zdCBNZWRpYUhlYWRlciA9IHN0eWxlZC5kaXZgXHJcbndpZHRoOiA2MHZ3O1xyXG5oZWlnaHQ6IDkwdmg7XHJcbmJhY2tncm91bmQ6ICNmZjQ2NTU7XHJcbnBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiY6YWZ0ZXJ7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgd2lkdGg6IDkwJTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGhlaWdodDogNy41dmg7XHJcbiAgICBiYWNrZ3JvdW5kOiBhbnRpcXVld2hpdGU7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTEwJSkgc2tld1goNTBkZWcpO1xyXG59XHJcbmBcclxuY29uc3QgTWVkaWFUb3BpY0NvbnRpYW5lciA9IHN0eWxlZC5kaXZgXHJcbnBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuaGVpZ2h0OiA2MCU7XHJcbndpZHRoOiA5MCU7XHJcbnJpZ2h0OiAwO1xyXG5ib3R0b206IDIwJTtcclxuYm9yZGVyLXRvcDogMXB4IHNvbGlkIHdoaXRlO1xyXG56LWluZGV4OiAxO1xyXG4mOmJlZm9yZXtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIGhlaWdodDogMjAlO1xyXG4gICAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCB3aGl0ZTtcclxuICAgIGJvdHRvbTogLTIwJTtcclxufVxyXG5cclxuYFxyXG5jb25zdCBNZWRpYVRvcGljID0gc3R5bGVkLmgxYFxyXG5mb250LXNpemU6IDEwdmg7XHJcbmNvbG9yOiB3aGl0ZTtcclxucG9zaXRpb246IHJlbGF0aXZlO1xyXG5tYXJnaW4tdG9wOiAzMHB4O1xyXG5tYXJnaW4tYm90dG9tOiAzMHB4O1xyXG5vdmVyZmxvdzogaGlkZGVuO1xyXG5gXHJcbmNvbnN0IE1lZGlhVG9waWNDb250ZW50ID0gc3R5bGVkLmRpdmBcclxud2lkdGg6IDU1JTtcclxuY29sb3I6IHdoaXRlO1xyXG5mb250LXNpemU6IDIuNXZoO1xyXG5tYXJnaW4tYm90dG9tOiAzdmg7XHJcbm92ZXJmbG93OiBoaWRkZW47XHJcbmBcclxuY29uc3QgTWVkaWFIZWFkZXJJbWcgPSBzdHlsZWQuc3BhbmBcclxuYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vLi4vLi4vbWVkaWFfY29udGVudC9waWMvTWVkaWFfSGVhZGVyLmpwZ1wiKTtcclxuYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcclxud2lkdGg6IDUyLjc1dnc7XHJcbmhlaWdodDogNzQuNXZoO1xyXG5wb3NpdGlvbjogYWJzb2x1dGU7XHJcbnJpZ2h0OiA3LjUlO1xyXG5ib3R0b206IC0xcHg7XHJcbnotaW5kZXg6IDE7XHJcbnRyYW5zZm9ybS1vcmlnaW46IGJvdHRvbTtcclxuJjpiZWZvcmV7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgd2lkdGg6IDUwcHg7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmY0NjU1O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG59XHJcbiY6YWZ0ZXJ7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYmFja2dyb3VuZDogYW50aXF1ZXdoaXRlO1xyXG4gICAgd2lkdGg6IDZ2dztcclxuICAgIGhlaWdodDogMTB2aDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHRyYW5zZm9ybTogc2tld1goNDBkZWcpIHRyYW5zbGF0ZVgoLTR2dyk7XHJcbn1cclxuYFxyXG5jb25zdCBCb3RMZWZ0SW1nID0gc3R5bGVkLmRpdmBcclxucG9zaXRpb246IGFic29sdXRlO1xyXG53aWR0aDogMTAwcHg7XHJcbmhlaWdodDogMTAwcHg7XHJcbmJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xyXG5vcGFjaXR5OiAuNTtcclxuYm90dG9tOiAwO1xyXG5yaWdodDogMDtcclxuJjpiZWZvcmV7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGhlaWdodDogNTAlO1xyXG4gICAgcmlnaHQ6IC03LjVweDtcclxuICAgIHRvcDogMjUlO1xyXG4gICAgdHJhbnNmb3JtOiBza2V3WCgtNDVkZWcpO1xyXG4gICAgYm9yZGVyLWxlZnQ6IDNweCBzb2xpZCB3aGl0ZTtcclxufVxyXG4mOmFmdGVye1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHdpZHRoOiA1cHg7XHJcbiAgICBoZWlnaHQ6IDVweDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG59XHJcbmBcclxuY29uc3QgTGluZSA9IHN0eWxlZC5kaXZgXHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB3aWR0aDogMzMuNjMxM3Z3O1xyXG4gICAgaGVpZ2h0OiAxMHB4O1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHdoaXRlO1xyXG4gICAgJjphZnRlcntcclxuICAgICAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB3aWR0aDogMjAlO1xyXG4gICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjZmY0NjU1O1xyXG4gICAgICAgIGJvdHRvbTogLTFweDtcclxuICAgICAgICBsZWZ0OiAxMCU7XHJcbiAgICB9XHJcblxyXG5gXHJcblxyXG5jb25zdCBNZWRpYUhlYWQgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxCb3ggc3R5bGU9e3sgaGVpZ2h0OiBcIjkyLjV2aFwiLCBvdmVyZmxvdzogXCJoaWRkZW5cIn19PlxyXG4gICAgICAgICAgICA8VGV4dEJnQ29udGFpbmVyIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwibm9uZVwiLCB6SW5kZXg6IDEsIHRvcDogXCIzNXZoXCJ9fT5cclxuICAgICAgICAgICAgICAgIDxUeHQgY2xhc3NOYW1lPXsgc3R5bGVzLnRleHRCYWNrZ3JvdW5kLCBzdHlsZXMuc3Ryb2tlIH0gc3R5bGU9e3sgZm9udFNpemU6IFwiMTV2d1wifX0+VkFMT1JBTlQ8L1R4dD5cclxuICAgICAgICAgICAgPC9UZXh0QmdDb250YWluZXI+XHJcbiAgICAgICAgICAgIDxNZWRpYUhlYWRlcj5cclxuICAgICAgICAgICAgICAgIDxNZWRpYVRvcGljQ29udGlhbmVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxNZWRpYVRvcGljPjxkaXYgY2xhc3NOYW1lPVwiTW92ZVVwXCI+4Liq4Li34LmI4LitPC9kaXY+PC9NZWRpYVRvcGljPlxyXG4gICAgICAgICAgICAgICAgICAgIDxNZWRpYVRvcGljQ29udGVudD48ZGl2IGNsYXNzTmFtZT1cIk1vdmVVcFwiPuC4h+C4suC4meC4guC4reC4h+C5gOC4o+C4suC4hOC4t+C4reC4geC4suC4o+C5gOC4peC5iOC4meC4guC4reC4h+C4hOC4uOC4kyDguYTguKHguYjguKfguYjguLLguITguLjguJPguIjguLDguYDguJvguYfguJnguKrguLfguYjguK0g4LiE4Lit4LiZ4LmA4LiX4LiZ4LiV4LmM4LiE4Lij4Li14LmA4Lit4LmA4LiV4Lit4Lij4LmMIOC4q+C4o+C4t+C4reC4l+C4seC5ieC4h+C4quC4reC4hyDguITguLjguJPguKrguLLguKHguLLguKPguJbguYPguIrguYnguJfguLjguIHguK3guKLguYjguLLguIfguJfguLXguYjguITguLjguJPguYDguKvguYfguJnguJfguLXguYjguJnguLXguYjguYTguJTguYnguYDguKXguKI8L2Rpdj48L01lZGlhVG9waWNDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICAgIDxNZWRpYVRvcGljQ29udGVudD48ZGl2IGNsYXNzTmFtZT1cIk1vdmVVcFwiPuC5guC4m+C4o+C4lOC4reC4ouC5iOC4suC4peC4t+C4oeC5geC4l+C5h+C4gSBAUGxheVZBTE9SQU5UIOC4muC4meC5guC4i+C5gOC4iuC4teC4ouC4peC4oeC4teC5gOC4lOC4teC4ouC4q+C4suC4geC4hOC4uOC4k+C5hOC4lOC5ieC4quC4o+C5ieC4suC4h+C4nOC4peC4h+C4suC4meC4lOC5ieC4p+C4ouC5hOC4n+C4peC5jOC4meC4teC5iSDguYDguKPguLLguK3guJTguYPguIjguKPguK3guYHguJfguJrguYTguKHguYjguYTguKvguKfguJfguLXguYjguIjguLDguYTguJTguYnguKPguLHguJrguIrguKHguKrguLTguYjguIfguJfguLXguYjguITguLjguJPguKrguKPguYnguLLguIfguILguLbguYnguJnguKHguLIg4LmB4LiV4LmI4Lit4Lii4LmI4Liy4Lil4Li34Lih4LmA4LiB4Li14LmI4Lii4Lin4LiB4Lix4LiaPGEgY2xhc3NOYW1lPVwiY29uZGl0aW9uXCIgaHJlZj1cIiNcIj7guYDguIfguLfguYjguK3guJnguYTguILguIHguLLguKPguYPguIrguYnguIfguLLguJkg4LiC4Lit4LiH4LmA4Lij4Liy4Lil4LmI4LiwPC9hPjwvZGl2PjwvTWVkaWFUb3BpY0NvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmUvPlxyXG4gICAgICAgICAgICAgICAgPC9NZWRpYVRvcGljQ29udGlhbmVyPlxyXG4gICAgICAgICAgICA8L01lZGlhSGVhZGVyPlxyXG4gICAgICAgICAgICA8TWVkaWFIZWFkZXJJbWcgY2xhc3NOYW1lPVwiTW92ZVVwXCI+PEJvdExlZnRJbWcvPjwvTWVkaWFIZWFkZXJJbWc+XHJcblxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgPC8+XHJcblxyXG4gICAgKVxyXG59XHJcbmV4cG9ydCBkZWZhdWx0IE1lZGlhSGVhZDsiLCJleHBvcnQge2RlZmF1bHQgYXMgRmlsdGVyRHJvcGJveCB9IGZyb20gJy4vRmlsdGVyRHJvcGJveCc7XHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBNZWRpYUhlYWQgfSBmcm9tICcuL01lZGlhSGVhZCc7XHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBDYXRlZ29yeUJhciB9IGZyb20gJy4vQ2F0ZWdvcnlCYXInO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBMYW5nU2VsZWN0b3IgfSBmcm9tICcuL0xhbmdTZWxlY3RvcidcclxuXHJcbmNvbnN0IFN0eWxlZExvZ28gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDMycHg7XHJcbiAgICBoZWlnaHQ6IDMycHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMTJweDtcclxuICAgIG1hcmdpbi1yaWdodDogMTJweDtcclxuICAgIHBhZGRpbmc6IDhweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMzMzMzMzM3NztcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHJpZ2h0OiAxNjRweDtcclxuYFxyXG5cclxuY29uc3QgQnV0dG9uV3JhcHBlciA9IHN0eWxlZC5idXR0b25gXHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuYFxyXG5cclxuY29uc3QgTGFuZ0J1dHRvbiA9ICh7IGlzT3Blbiwgb25DbGljayB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxCdXR0b25XcmFwcGVyIG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICAgICAgICAgICAgPFN0eWxlZExvZ28gdmlld0JveD1cIjAgMCAxNiAxNlwiIGZpbGw9XCIjZmZmXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0wIDhhOCA4IDAgMSAxIDE2IDBBOCA4IDAgMCAxIDAgOHptNy41LTYuOTIzYy0uNjcuMjA0LTEuMzM1LjgyLTEuODg3IDEuODU1QTcuOTcgNy45NyAwIDAgMCA1LjE0NSA0SDcuNVYxLjA3N3pNNC4wOSA0YTkuMjY3IDkuMjY3IDAgMCAxIC42NC0xLjUzOSA2LjcgNi43IDAgMCAxIC41OTctLjkzM0E3LjAyNSA3LjAyNSAwIDAgMCAyLjI1NSA0SDQuMDl6bS0uNTgyIDMuNWMuMDMtLjg3Ny4xMzgtMS43MTguMzEyLTIuNUgxLjY3NGE2Ljk1OCA2Ljk1OCAwIDAgMC0uNjU2IDIuNWgyLjQ5ek00Ljg0NyA1YTEyLjUgMTIuNSAwIDAgMC0uMzM4IDIuNUg3LjVWNUg0Ljg0N3pNOC41IDV2Mi41aDIuOTlhMTIuNDk1IDEyLjQ5NSAwIDAgMC0uMzM3LTIuNUg4LjV6TTQuNTEgOC41YTEyLjUgMTIuNSAwIDAgMCAuMzM3IDIuNUg3LjVWOC41SDQuNTF6bTMuOTkgMFYxMWgyLjY1M2MuMTg3LS43NjUuMzA2LTEuNjA4LjMzOC0yLjVIOC41ek01LjE0NSAxMmMuMTM4LjM4Ni4yOTUuNzQ0LjQ2OCAxLjA2OC41NTIgMS4wMzUgMS4yMTggMS42NSAxLjg4NyAxLjg1NVYxMkg1LjE0NXptLjE4MiAyLjQ3MmE2LjY5NiA2LjY5NiAwIDAgMS0uNTk3LS45MzNBOS4yNjggOS4yNjggMCAwIDEgNC4wOSAxMkgyLjI1NWE3LjAyNCA3LjAyNCAwIDAgMCAzLjA3MiAyLjQ3MnpNMy44MiAxMWExMy42NTIgMTMuNjUyIDAgMCAxLS4zMTItMi41aC0yLjQ5Yy4wNjIuODkuMjkxIDEuNzMzLjY1NiAyLjVIMy44MnptNi44NTMgMy40NzJBNy4wMjQgNy4wMjQgMCAwIDAgMTMuNzQ1IDEySDExLjkxYTkuMjcgOS4yNyAwIDAgMS0uNjQgMS41MzkgNi42ODggNi42ODggMCAwIDEtLjU5Ny45MzN6TTguNSAxMnYyLjkyM2MuNjctLjIwNCAxLjMzNS0uODIgMS44ODctMS44NTUuMTczLS4zMjQuMzMtLjY4Mi40NjgtMS4wNjhIOC41em0zLjY4LTFoMi4xNDZjLjM2NS0uNzY3LjU5NC0xLjYxLjY1Ni0yLjVoLTIuNDlhMTMuNjUgMTMuNjUgMCAwIDEtLjMxMiAyLjV6bTIuODAyLTMuNWE2Ljk1OSA2Ljk1OSAwIDAgMC0uNjU2LTIuNUgxMi4xOGMuMTc0Ljc4Mi4yODIgMS42MjMuMzEyIDIuNWgyLjQ5ek0xMS4yNyAyLjQ2MWMuMjQ3LjQ2NC40NjIuOTguNjQgMS41MzloMS44MzVhNy4wMjQgNy4wMjQgMCAwIDAtMy4wNzItMi40NzJjLjIxOC4yODQuNDE4LjU5OC41OTcuOTMzek0xMC44NTUgNGE3Ljk2NiA3Ljk2NiAwIDAgMC0uNDY4LTEuMDY4QzkuODM1IDEuODk3IDkuMTcgMS4yODIgOC41IDEuMDc3VjRoMi4zNTV6XCIvPlxyXG4gICAgICAgICAgICAgICAgPC9TdHlsZWRMb2dvPlxyXG4gICAgICAgICAgICA8L0J1dHRvbldyYXBwZXI+XHJcbiAgICAgICAgICAgIDxMYW5nU2VsZWN0b3IgaXNPcGVuPXtpc09wZW59IC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IExhbmdCdXR0b247IiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmNvbnN0IFN0eWxlZExheW91dCA9IHN0eWxlZC5kaXZgXHJcbiAgICB3aWR0aDogMjQwcHg7XHJcbiAgICBoZWlnaHQ6IDM2MHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICByaWdodDogNzBweDtcclxuICAgIHRvcDogOTRweDtcclxuICAgIHotaW5kZXg6IDUwMDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBkaXNwbGF5OiAke3Byb3BzID0+IHByb3BzLmlzT3BlbiA/IFwiYmxvY2tcIiA6IFwibm9uZVwifTtcclxuYFxyXG5cclxuY29uc3QgU3R5bGVkQ2hlY2tlZEljb24gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICBmaWxsOiAjYzQyMDJiO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDE2cHg7XHJcbmBcclxuXHJcbmNvbnN0IENoZWNrZWRJY29uID0gKCkgPT4gKFxyXG4gICAgPFN0eWxlZENoZWNrZWRJY29uIHZpZXdCb3g9XCIwIDAgMTYgMTZcIj5cclxuICAgICAgICA8cGF0aCBkPVwiTTEyLjczNiAzLjk3YS43MzMuNzMzIDAgMCAxIDEuMDQ3IDBjLjI4Ni4yODkuMjkuNzU2LjAxIDEuMDVMNy44OCAxMi4wMWEuNzMzLjczMyAwIDAgMS0xLjA2NS4wMkwzLjIxNyA4LjM4NGEuNzU3Ljc1NyAwIDAgMSAwLTEuMDYuNzMzLjczMyAwIDAgMSAxLjA0NyAwbDMuMDUyIDMuMDkzIDUuNC02LjQyNWEuMjQ3LjI0NyAwIDAgMSAuMDItLjAyMlpcIi8+XHJcbiAgICA8L1N0eWxlZENoZWNrZWRJY29uPlxyXG4pXHJcblxyXG5jb25zdCBTdHlsZWRUcmlhbmdsZVVwID0gc3R5bGVkLnN2Z2BcclxuICAgIHdpZHRoOiAzMnB4O1xyXG4gICAgaGVpZ2h0OiAzMnB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAtMTRweDtcclxuICAgIGxlZnQ6IDEwNHB4O1xyXG5gXHJcblxyXG5jb25zdCBUcmlhbmdsZVVwID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkVHJpYW5nbGVVcCB2aWV3Qm94PVwiMCAwIDE2IDE2XCIgZmlsbD1cIiNmZmZcIj5cclxuICAgICAgICAgICAgPHBhdGggZmlsbFJ1bGU9XCJldmVub2RkXCIgZD1cIk03LjAyMiAxLjU2NmExLjEzIDEuMTMgMCAwIDEgMS45NiAwbDYuODU3IDExLjY2N2MuNDU3Ljc3OC0uMDkyIDEuNzY3LS45OCAxLjc2N0gxLjE0NGMtLjg4OSAwLTEuNDM3LS45OS0uOTgtMS43NjdMNy4wMjIgMS41NjZ6XCIvPlxyXG4gICAgICAgIDwvU3R5bGVkVHJpYW5nbGVVcD5cclxuICAgIClcclxufVxyXG5cclxuY29uc3QgTGFuZ3VhZ2VTdXBwb3J0ID0gW1xyXG4gICAgXCJFTkdMSVNIIChOQSlcIixcclxuICAgIFwiRU5HTElTSCAoRVVXKVwiLFxyXG4gICAgXCJERVVUU0NIXCIsXHJcbiAgICBcIkVTUEHDkU9MIChFVVcpXCIsXHJcbiAgICBcIkZSQU7Dh0FJU1wiLFxyXG4gICAgXCJJVEFMSUFOT1wiLFxyXG4gICAgXCJQT0xTS0lcIixcclxuICAgIFwi0KDQo9Ch0KHQmtCY0JlcIixcclxuICAgIFwiVMOcUkvDh0VcIixcclxuICAgIFwiRVNQQcORT0wgKExBVEFNKVwiLFxyXG4gICAgXCJJTkRPTkVTSUFOXCIsXHJcbiAgICBcIuaXpeacrOiqnlwiLFxyXG4gICAgXCLtlZzqta3slrRcIixcclxuICAgIFwiUE9SVFVHVcOKU1wiLFxyXG4gICAgXCLguKDguLLguKnguLLguYTguJfguKJcIixcclxuICAgIFwiVGnhur9uZyBWaeG7h3RcIixcclxuICAgIFwi57mB6auU5Lit5paHXCIsXHJcbiAgICBcItin2YTYudix2KjZitipXCJcclxuXVxyXG5cclxuY29uc3QgU3R5bGVMYW5nSXRlbSA9IHN0eWxlZC5kaXZgXHJcbiAgICBmb250LWZhbWlseTogJ0thbml0Jywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBwYWRkaW5nOiAxMHB4IDI0cHg7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGNvbG9yOiAke3Byb3BzID0+IHByb3BzLnNlbGVjdGVkID8gXCIjYzQyMDJiXCIgOiBcIiM5OTlcIn07XHJcbiAgICB0cmFuc2l0aW9uOiBjb2xvciAuNHM7XHJcbiAgICBjdXJzb3I6ICR7cHJvcHMgPT4gcHJvcHMuc2VsZWN0ZWQgPyBcImRlZmF1bHRcIiA6IFwicG9pbnRlclwifTtcclxuICAgICY6aG92ZXIge1xyXG4gICAgICAgIGNvbG9yOiAjMTExO1xyXG4gICAgfVxyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LWVuZDtcclxuYFxyXG5cclxuY29uc3QgTGFuZ0l0ZW0gPSAoeyBjaGlsZHJlbiwgc2VsZWN0ZWQgfSkgPT4gKFxyXG4gICAgPFN0eWxlTGFuZ0l0ZW0gc2VsZWN0ZWQ9e2NoaWxkcmVuID09PSBzZWxlY3RlZH0+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgIHtjaGlsZHJlbiA9PT0gc2VsZWN0ZWQgPyAoPENoZWNrZWRJY29uLz4pIDogbnVsbH1cclxuICAgIDwvU3R5bGVMYW5nSXRlbT5cclxuKVxyXG5cclxuY29uc3QgQ29udGVudCA9IHN0eWxlZC5kaXZgXHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMTBweCAwO1xyXG5gXHJcblxyXG5leHBvcnQgY29uc3QgTGFuZ1NlbGVjdG9yID0gKHsgaXNPcGVuIH0pID0+IChcclxuICAgIDw+XHJcbiAgICAgICAgPFN0eWxlZExheW91dCBpc09wZW49e2lzT3Blbn0+XHJcbiAgICAgICAgICAgIDxDb250ZW50PlxyXG4gICAgICAgICAgICAgICAge0xhbmd1YWdlU3VwcG9ydC5tYXAoKGUsIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8TGFuZ0l0ZW0gc2VsZWN0ZWQ9XCLguKDguLLguKnguLLguYTguJfguKJcIiBrZXk9e2l9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L0xhbmdJdGVtPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvQ29udGVudD5cclxuICAgICAgICAgICAgPFRyaWFuZ2xlVXAgLz5cclxuICAgICAgICA8L1N0eWxlZExheW91dD5cclxuICAgIDwvPlxyXG4pIiwiaW1wb3J0IE5hdkxheW91dCBmcm9tIFwiLi9OYXZMYXlvdXRcIjtcclxuaW1wb3J0IHsgTmF2SXRlbSB9IGZyb20gXCIuL05hdkl0ZW1cIjtcclxuaW1wb3J0IHsgRHJvcGRvd24sIEV4dGVybmFsTGksIExpIH0gZnJvbSBcIi4vTmF2RHJvcGRvd25cIjtcclxuaW1wb3J0IHsgRXh0ZXJuYWwgfSBmcm9tIFwiLi9OYXZFeHRlcm5hbExpbmtcIjtcclxuaW1wb3J0IHsgVmFsb3JhbnRMb2dvLCBSaW90TG9nbyB9IGZyb20gXCIuLi8uLi9zdHlsZXMvbmF2X2NvbXBvbmVudHNcIjtcclxuaW1wb3J0IFNlcGFyYXRvciBmcm9tICcuL05hdlNlcGFyYXRvcidcclxuaW1wb3J0IExhbmdCdXR0b24gZnJvbSBcIi4vTGFuZ0J1dHRvblwiO1xyXG5pbXBvcnQgUGxheUJ1dHRvbiBmcm9tIFwiLi9QbGF5QnV0dG9uXCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IFJpZ2h0TmF2IH0gZnJvbSAnLi9SaWdodE5hdidcclxuXHJcbmNvbnN0IE5hdkJhciA9ICgpID0+IHtcclxuICAgIGNvbnN0IFtvcGVuUmlvdEdhbWVCYXIsIHNldE9wZW5SaW90R2FtZUJhcl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtvcGVuTGFuZ1NlbGVjdG9yLCBzZXRPcGVuTGFuZ1NlbGVjdG9yXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW29wZW5QbGF5UG9wdXAsIHNldE9wZW5QbGF5UG9wdXBdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBoYW5kbGVSaW90R2FtZUJhckNsaWNrID0gZSA9PiB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIHNldE9wZW5SaW90R2FtZUJhcighb3BlblJpb3RHYW1lQmFyKVxyXG4gICAgICAgIHNldE9wZW5MYW5nU2VsZWN0b3IoZmFsc2UpXHJcbiAgICB9XHJcbiAgICBjb25zdCBoYW5kbGVMYW5nQ2xpY2sgPSBlID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgc2V0T3BlbkxhbmdTZWxlY3Rvcighb3BlbkxhbmdTZWxlY3RvcilcclxuICAgICAgICBzZXRPcGVuUmlvdEdhbWVCYXIoZmFsc2UpXHJcbiAgICB9XHJcbiAgICBjb25zdCBoYW5kbGVQbGF5UG9wdXBDbGljayA9IGUgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBzZXRPcGVuUGxheVBvcHVwKCFvcGVuUGxheVBvcHVwKVxyXG4gICAgICAgIHNldE9wZW5SaW90R2FtZUJhcihmYWxzZSlcclxuICAgICAgICBzZXRPcGVuTGFuZ1NlbGVjdG9yKGZhbHNlKVxyXG4gICAgfVxyXG4gICAgY29uc3QgUmlvdEdhbWVCYXJTdGF0ZUNvbnRyb2wgPSBzdGF0ZSA9PiB7XHJcbiAgICAgICAgc2V0T3BlblJpb3RHYW1lQmFyKHN0YXRlKVxyXG4gICAgfVxyXG4gICAgY29uc3QgUGxheVBvcHVwU3RhdGVDb250cm9sID0gc3RhdGUgPT4ge1xyXG4gICAgICAgIHNldE9wZW5QbGF5UG9wdXAoc3RhdGUpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxOYXZMYXlvdXQ+XHJcbiAgICAgICAgICAgIDxSaW90TG9nbyBpc0dhbWVCYXJPcGVuPXtvcGVuUmlvdEdhbWVCYXJ9IG9uQ2xpY2s9e2hhbmRsZVJpb3RHYW1lQmFyQ2xpY2t9IHN0YXRlQ29udHJvbD17UmlvdEdhbWVCYXJTdGF0ZUNvbnRyb2x9IC8+XHJcbiAgICAgICAgICAgIDxTZXBhcmF0b3IgLz5cclxuICAgICAgICAgICAgPFZhbG9yYW50TG9nbyBocmVmPVwiL1wiIC8+XHJcbiAgICAgICAgICAgIDxEcm9wZG93biB0aXRsZT1cIuC4guC5ieC4reC4oeC4ueC4peC5gOC4geC4oVwiPlxyXG4gICAgICAgICAgICAgICAgPExpIGhyZWY9XCIvYWdlbnRzXCIgdGl0bGU9XCLguYDguK3guYDguIjguJnguJfguYxcIiAvPlxyXG4gICAgICAgICAgICAgICAgPExpIGhyZWY9XCIvbWFwc1wiIHRpdGxlPVwi4LmB4Lic4LiZ4LiX4Li14LmIXCIgLz5cclxuICAgICAgICAgICAgICAgIDxMaSBocmVmPVwiL2Fyc2VuYWxcIiB0aXRsZT1cIuC4hOC4peC4seC4h+C5geC4quC4h1wiIC8+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgIDxOYXZJdGVtIGhyZWY9XCIvbWVkaWFcIiB0aXRsZT1cIuC4quC4t+C5iOC4rVwiIC8+XHJcbiAgICAgICAgICAgIDxOYXZJdGVtIGhyZWY9XCIvbmV3c1wiIHRpdGxlPVwi4LiC4LmI4Liy4Lin4Liq4Liy4LijXCIgLz5cclxuICAgICAgICAgICAgPE5hdkl0ZW0gaHJlZj1cIi9sZWFkZXJib2FyZHNcIiB0aXRsZT1cIuC4geC4o+C4sOC4lOC4suC4meC4nOC4ueC5ieC4meC4s1wiIC8+XHJcbiAgICAgICAgICAgIDxEcm9wZG93biB0aXRsZT1cIuC4i+C4seC4nuC4nuC4reC4o+C5jOC4lVwiPlxyXG4gICAgICAgICAgICAgICAgPExpIGhyZWY9XCIvc3BlY3NcIiB0aXRsZT1cIuC4quC5gOC4m+C4hFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaSB0aXRsZT1cIuC4i+C4seC4nuC4nuC4reC4o+C5jOC4lVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8TGkgaHJlZj1cIi9jb21tdW5pdHktY29kZVwiIHRpdGxlPVwi4LiB4LiP4Lij4Liw4LmA4Lia4Li14Lii4LiaXCIgLz5cclxuICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPERyb3Bkb3duIHRpdGxlPVwi4LmC4LiL4LmA4LiK4Li14Lii4LilXCI+XHJcbiAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaSB0aXRsZT1cIkZBQ0VCT09LXCIgLz5cclxuICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpIHRpdGxlPVwiWU9VVFVCRVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaSB0aXRsZT1cIklOU1RBR1JBTVwiIC8+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgIDxFeHRlcm5hbCB0aXRsZT1cIuC4reC4teC4quC4m+C4reC4o+C5jOC4lVwiIC8+XHJcbiAgICAgICAgICAgIDxSaWdodE5hdj5cclxuICAgICAgICAgICAgICAgIDxMYW5nQnV0dG9uIGlzT3Blbj17b3BlbkxhbmdTZWxlY3Rvcn0gb25DbGljaz17aGFuZGxlTGFuZ0NsaWNrfSAvPlxyXG4gICAgICAgICAgICAgICAgPFBsYXlCdXR0b24gaXNPcGVuPXtvcGVuUGxheVBvcHVwfSBvbkNsaWNrPXtoYW5kbGVQbGF5UG9wdXBDbGlja30gc3RhdGVDb250cm9sPXtQbGF5UG9wdXBTdGF0ZUNvbnRyb2x9PuC5gOC4peC5iOC4meC5gOC4peC4ojwvUGxheUJ1dHRvbj5cclxuICAgICAgICAgICAgPC9SaWdodE5hdj5cclxuICAgICAgICA8L05hdkxheW91dD5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2QmFyO1xyXG4iLCJpbXBvcnQgeyBEcm9wZG93bkFycm93VXAsIFN0eWxlZExpIH0gZnJvbSBcIi4uLy4uLy4uL3N0eWxlcy9uYXZfY29tcG9uZW50c1wiO1xyXG5cclxuY29uc3QgRXh0ZXJuYWxMaSA9ICh7IHRpdGxlIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFN0eWxlZExpPlxyXG4gICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgIDxEcm9wZG93bkFycm93VXAgLz5cclxuICAgICAgICA8L1N0eWxlZExpPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFeHRlcm5hbExpO1xyXG4iLCJpbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB7IFN0eWxlZExpIH0gZnJvbSAnLi4vLi4vLi4vc3R5bGVzL25hdl9jb21wb25lbnRzJztcclxuXHJcbmNvbnN0IExpID0gKHsgaHJlZiwgdGl0bGUgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8TGluayBocmVmPXtocmVmfSBwYXNzSHJlZj5cclxuICAgICAgICAgICAgPFN0eWxlZExpPlxyXG4gICAgICAgICAgICAgICAgPGE+e3RpdGxlfTwvYT5cclxuICAgICAgICAgICAgPC9TdHlsZWRMaT5cclxuICAgICAgICA8L0xpbms+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IExpO1xyXG4iLCJpbXBvcnQgeyBOYXZJdGVtTGF5b3V0LCBDYXJldERvd24gfSBmcm9tICcuLi8uLi8uLi9zdHlsZXMvbmF2X2NvbXBvbmVudHMnXHJcbmltcG9ydCB7IFVsIH0gZnJvbSAnLi9VbCc7XHJcblxyXG5jb25zdCBEcm9wZG93biA9ICh7IHRpdGxlLCBjaGlsZHJlbiB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxOYXZJdGVtTGF5b3V0PlxyXG4gICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgIDxDYXJldERvd24gLz5cclxuICAgICAgICAgICAgPFVsPlxyXG4gICAgICAgICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgICAgICA8L1VsPlxyXG4gICAgICAgIDwvTmF2SXRlbUxheW91dD5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRHJvcGRvd247XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcclxuaW1wb3J0IHsgTmF2SXRlbUxheW91dCB9IGZyb20gXCIuLi8uLi8uLi9zdHlsZXMvbmF2X2NvbXBvbmVudHNcIlxyXG5cclxuZXhwb3J0IGNvbnN0IFVsID0gc3R5bGVkLnVsYFxyXG4gICAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG4gICAgbWluLXdpZHRoOiAyMDBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMxMTE7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDgwcHg7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAke05hdkl0ZW1MYXlvdXR9OmhvdmVyICYge1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgfVxyXG5gIiwiZXhwb3J0IHtkZWZhdWx0IGFzIExpfSBmcm9tICcuL0xpJ1xyXG5leHBvcnQge2RlZmF1bHQgYXMgRHJvcGRvd259IGZyb20gJy4vTmF2RHJvcGRvd24nXHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBFeHRlcm5hbExpfSBmcm9tICcuL0V4dGVybmFsTGknXHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCB7IE5hdkl0ZW1MYXlvdXQsIE5hdkFycm93VXAgfSBmcm9tIFwiLi4vLi4vLi4vc3R5bGVzL25hdl9jb21wb25lbnRzXCI7XHJcblxyXG5jb25zdCBFeHRlcm5hbExpbmsgPSAoeyB0aXRsZSwgY2hpbGRyZW4gfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8TmF2SXRlbUxheW91dD5cclxuICAgICAgICAgICAge3RpdGxlfVxyXG4gICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICAgIDxOYXZBcnJvd1VwIC8+XHJcbiAgICAgICAgPC9OYXZJdGVtTGF5b3V0PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFeHRlcm5hbExpbms7XHJcbiIsImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHtTdHlsZWRMaW5rfSBmcm9tICcuLi8uLi8uLi9zdHlsZXMvbmF2X2NvbXBvbmVudHMnXHJcblxyXG5jb25zdCBOYXZJdGVtID0gKHsgaHJlZiwgdGl0bGUsIGNoaWxkcmVuIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPExpbmsgaHJlZj17aHJlZn0gcGFzc0hyZWY+XHJcbiAgICAgICAgICAgIDxTdHlsZWRMaW5rPnt0aXRsZX17Y2hpbGRyZW59PC9TdHlsZWRMaW5rPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2SXRlbTtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIlxyXG5cclxuY29uc3QgTmF2ID0gc3R5bGVkLm5hdmBcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzExMTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB6LWluZGV4OiA0MDAwO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyNnB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMjZweDtcclxuYFxyXG5cclxuY29uc3QgTmF2TGF5b3V0ID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8aGVhZGVyPlxyXG4gICAgICAgICAgICA8TmF2PlxyXG4gICAgICAgICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgICAgICA8L05hdj5cclxuICAgICAgICA8L2hlYWRlcj5cclxuICAgICkgICAgXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5hdkxheW91dDtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmNvbnN0IE5hdlNlcGFyYXRvciA9IHN0eWxlZC5kaXZgXHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICB3aWR0aDogMnB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzdlN2U3ZTtcclxuICAgIG1hcmdpbi10b3A6IDI1cHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMTJweDtcclxuICAgIG1hcmdpbi1yaWdodDogMTJweDtcclxuICAgIG9wYWNpdHk6IC40O1xyXG5gXHJcblxyXG5leHBvcnQgZGVmYXVsdCBOYXZTZXBhcmF0b3I7XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCB7IFBsYXlQb3B1cCB9IGZyb20gXCIuL1BsYXlQb3B1cFwiO1xyXG5cclxuY29uc3QgQnV0dG9uID0gc3R5bGVkLmJ1dHRvbmBcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDcwLCA4NSk7XHJcbiAgICBtYXJnaW4tbGVmdDogNHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICB3aWR0aDogMTMwcHg7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAycHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LWZhbWlseTogJ0JhaSBKYW1qdXJlZScsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgcmlnaHQ6IDI2cHg7XHJcbmBcclxuXHJcbmNvbnN0IFBsYXlCdXR0b24gPSAoeyBjaGlsZHJlbiwgb25DbGljaywgaXNPcGVuLCBzdGF0ZUNvbnRyb2wgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICAgICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPFBsYXlQb3B1cCBpc09wZW49e2lzT3Blbn0gc3RhdGVDb250cm9sPXtzdGF0ZUNvbnRyb2x9IC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBsYXlCdXR0b247XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnLi4vQnV0dG9uJ1xyXG5cclxuY29uc3QgUG9wdXBXcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICAgIHdpZHRoOiAxMDB2dztcclxuICAgIGhlaWdodDogMTAwdmg7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgZGlzcGxheTogJHtwcm9wcyA9PiBwcm9wcy5pc09wZW4gPyBcImZsZXhcIiA6IFwibm9uZVwifTtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuYFxyXG5cclxuY29uc3QgRGltbWVkQmFja2dyb3VuZCA9IHN0eWxlZC5kaXZgXHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMxMTE7XHJcbiAgICBvcGFjaXR5OiAuNztcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHotaW5kZXg6IDQwMDA7XHJcbiAgICB0b3A6IDA7XHJcbmBcclxuXHJcbmNvbnN0IFBvcHVwID0gc3R5bGVkLmRpdmBcclxuICAgIHdpZHRoOiAxMDBweDtcclxuICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICBib3JkZXItdG9wOiAxcHggc29saWQgIzk2OGQ4YztcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjOTY4ZDhjO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzBmMTkyMztcclxuICAgIHotaW5kZXg6IDYwMDA7XHJcbiAgICBoZWlnaHQ6IDQwdmg7XHJcbiAgICB3aWR0aDogY2FsYygyLzMqMTAwJSk7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuYFxyXG5cclxuY29uc3QgUG9wdXBUaXRsZVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgaGVpZ2h0OiA3MCU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtZmFtaWx5OiAnS2FuaXQnLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zaXplOiAzMnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBjb2x1bW4tZ2FwOiAyNHB4O1xyXG5gXHJcblxyXG5jb25zdCBQb3B1cEJ1dHRvbldyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBjb2x1bW4tZ2FwOiA0MHB4O1xyXG5gXHJcblxyXG5jb25zdCBCdXR0b25MYWJlbCA9IHN0eWxlZC5wYFxyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcclxuYFxyXG5cclxuY29uc3QgQnV0dG9uV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbmBcclxuXHJcbmNvbnN0IEV4aXRCdXR0b25XcmFwcGVyID0gc3R5bGVkLmJ1dHRvbmBcclxuICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgYm9yZGVyOiBzb2xpZCB3aGl0ZSAxcHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDE1cHg7XHJcbiAgICByaWdodDogMTVweDtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG5gXHJcblxyXG5jb25zdCBFeGl0QnV0dG9uID0gKHsgb25DbGljayB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxFeGl0QnV0dG9uV3JhcHBlciBvbkNsaWNrPXtvbkNsaWNrfT5cclxuICAgICAgICAgICAgPEV4aXRCdXR0b25TdHlsZSAvPlxyXG4gICAgICAgIDwvRXhpdEJ1dHRvbldyYXBwZXI+XHJcbiAgICApXHJcbn1cclxuXHJcbmNvbnN0IFN2Z0V4aXQgPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDQ4cHg7XHJcbiAgICBoZWlnaHQ6IDQ4cHg7XHJcbiAgICB0cmFuc2l0aW9uOiBzY2FsZSAuMnM7XHJcbiAgICAke0V4aXRCdXR0b25XcmFwcGVyfTpob3ZlciAmIHtcclxuICAgICAgICBzY2FsZTogMS4xNTtcclxuICAgIH1cclxuYFxyXG5cclxuY29uc3QgRXhpdEJ1dHRvblN0eWxlID0gKCkgPT4gKFxyXG4gICAgPFN2Z0V4aXQgdmlld0JveD1cIjAgMCA3MiA3MlwiPlxyXG4gICAgICAgIDxwYXRoIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiI2VjZThlMVwiIGQ9XCJNNjEuNSA5LjVsLTcgN20tMzggMzhsLTcgN00zMC4zIDQybDIuOC0zbTguNiAzTDMwLjMgMzBtMTEuNCAwbC0yLjYgMi44XCIgLz5cclxuICAgIDwvU3ZnRXhpdD5cclxuKVxyXG5cclxuZXhwb3J0IGNvbnN0IFBsYXlQb3B1cCA9ICh7IGlzT3Blbiwgc3RhdGVDb250cm9sIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPFBvcHVwV3JhcHBlciBpc09wZW49e2lzT3Blbn0+XHJcbiAgICAgICAgICAgICAgICA8UG9wdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBvcHVwVGl0bGVXcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5cXDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+4LmA4LiV4Lij4Li14Lii4Lih4LiV4Lix4Lin4LmD4Lir4LmJ4Lie4Lij4LmJ4Lit4LihPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5cXDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L1BvcHVwVGl0bGVXcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxQb3B1cEJ1dHRvbldyYXBwZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25XcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbkxhYmVsPuC4ieC4seC4meC4ouC4seC4h+C5hOC4oeC5iOC4oeC4teC4muC4seC4jeC4iuC4tSBSaW90PC9CdXR0b25MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gaXNXaGl0ZSBpc0JvcmRlcmVkPuC4quC4o+C5ieC4suC4h+C4l+C4seC4meC4l+C4tTwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbldyYXBwZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25XcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbkxhYmVsPuC4ieC4seC4meC4oeC4teC4muC4seC4jeC4iuC4tSBSaW90IOC5geC4peC5ieC4pzwvQnV0dG9uTGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGlzQm9yZGVyZWQ+4Lil4LiH4LiK4Li34LmI4Lit4LmA4LiC4LmJ4Liy4LmD4LiK4LmJPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uV3JhcHBlcj5cclxuICAgICAgICAgICAgICAgICAgICA8L1BvcHVwQnV0dG9uV3JhcHBlcj5cclxuICAgICAgICAgICAgICAgICAgICA8RXhpdEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzdGF0ZUNvbnRyb2woZmFsc2UpfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9Qb3B1cD5cclxuICAgICAgICAgICAgICAgIDxEaW1tZWRCYWNrZ3JvdW5kIG9uQ2xpY2s9eygpID0+IHN0YXRlQ29udHJvbChmYWxzZSl9IC8+XHJcbiAgICAgICAgICAgIDwvUG9wdXBXcmFwcGVyPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKVxyXG59IiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBSaWdodE5hdiA9IHN0eWxlZC5kaXZgXHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgbWFyZ2luOiAwIDI0cHggMCAwO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGhlaWdodDogODBweDtcclxuYFxyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuY29uc3QgR2FtZXNCYXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgbGVmdDogMDtcclxuICAgIGhlaWdodDogMzcwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgei1pbmRleDogMTAwMDA7XHJcbiAgICBvcGFjaXR5OiAxO1xyXG4gICAgcGFkZGluZzogMjRweCA0MHB4O1xyXG5gXHJcblxyXG5jb25zdCBEaW1tZWRCYWNrZ3JvdW5kID0gc3R5bGVkLmRpdmBcclxuICAgIHotaW5kZXg6IDkwMDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTExO1xyXG4gICAgb3BhY2l0eTogLjc7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgbWFyZ2luLXRvcDogODBweDtcclxuICAgIHdpZHRoOiAxMDB2dztcclxuICAgIGhlaWdodDogMTAwdmg7XHJcbmBcclxuXHJcbmNvbnN0IEdhbWVzQmFyV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgbWFyZ2luLXRvcDogODBweDtcclxuICAgIHdpZHRoOiAxMDB2dztcclxuICAgIGhlaWdodDogMTAwdmg7XHJcbiAgICBkaXNwbGF5OiAke3Byb3BzID0+IHByb3BzLmlzT3BlbiA/IFwiYmxvY2tcIiA6IFwibm9uZVwifTtcclxuYFxyXG5cclxuY29uc3QgU3R5bGVkVHJpYW5nbGVVcCA9IHN0eWxlZC5zdmdgXHJcbiAgICB3aWR0aDogMzJweDtcclxuICAgIGhlaWdodDogMzJweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogLTE0cHg7XHJcbiAgICBsZWZ0OiAzOHB4O1xyXG5gXHJcblxyXG5jb25zdCBUaXRsZVJpb3RHYW1lcyA9IHN0eWxlZC5wYFxyXG4gICAgZm9udC1mYW1pbHk6ICdLYW5pdCcsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG5gXHJcblxyXG5jb25zdCBUcmlhbmdsZVVwID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkVHJpYW5nbGVVcCB2aWV3Qm94PVwiMCAwIDE2IDE2XCIgZmlsbD1cIiNmZmZcIj5cclxuICAgICAgICAgICAgPHBhdGggZmlsbFJ1bGU9XCJldmVub2RkXCIgZD1cIk03LjAyMiAxLjU2NmExLjEzIDEuMTMgMCAwIDEgMS45NiAwbDYuODU3IDExLjY2N2MuNDU3Ljc3OC0uMDkyIDEuNzY3LS45OCAxLjc2N0gxLjE0NGMtLjg4OSAwLTEuNDM3LS45OS0uOTgtMS43NjdMNy4wMjIgMS41NjZ6XCIvPlxyXG4gICAgICAgIDwvU3R5bGVkVHJpYW5nbGVVcD5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFJpb3RHYW1lc0JhciA9ICh7IGlzT3Blbiwgc3RhdGVDb250cm9sfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8R2FtZXNCYXJXcmFwcGVyIGlzT3Blbj17aXNPcGVufT5cclxuICAgICAgICAgICAgPFRyaWFuZ2xlVXAgLz5cclxuICAgICAgICAgICAgPEdhbWVzQmFyPlxyXG4gICAgICAgICAgICAgICAgPFRpdGxlUmlvdEdhbWVzPlJJT1QgR0FNRVM8L1RpdGxlUmlvdEdhbWVzPlxyXG4gICAgICAgICAgICA8L0dhbWVzQmFyPlxyXG4gICAgICAgICAgICA8RGltbWVkQmFja2dyb3VuZCBvbkNsaWNrPXsoKSA9PiBzdGF0ZUNvbnRyb2woZmFsc2UpfSAvPlxyXG4gICAgICAgIDwvR2FtZXNCYXJXcmFwcGVyPlxyXG4gICAgKVxyXG59XHJcbiIsImltcG9ydCBzdHlsZWQsIHsgY3NzIH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL05ld3MubW9kdWxlLmNzcydcclxuXHJcblxyXG5jb25zdCBUZXh0QmdDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG4gICAgaGVpZ2h0OiAxNTB2aDtcclxuICAgIGJhY2tncm91bmQ6ICMwZjE5MjM7XHJcbmBcclxuY29uc3QgVHh0ID0gc3R5bGVkLnNwYW5gXHJcbiAgICBmb250LWZhbWlseTogRElOTmV4dExUVzA0LU1lZGl1bTtcclxuICAgIGZvbnQtc2l6ZTogMjIuNjV2dztcclxuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICBaLWluZGV4OiAxO1xyXG4gICAgQG1lZGlhIChtYXgtd2lkdGg6IDgwMHB4KXtcclxuICAgICAgICBmb250LXNpemU6IDI3LjY1dnc7XHJcbiAgICB9XHJcbmBcclxuY29uc3QgVGV4dEJHID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgIDxUZXh0QmdDb250YWluZXI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9eyBzdHlsZXMuc3Ryb2tlIH0+XHJcbiAgICAgICAgICAgICAgICA8VHh0IGNsYXNzTmFtZT17IHN0eWxlcy50ZXh0QmFja2dyb3VuZDEgfT5XRSBBUkU8L1R4dD5cclxuICAgICAgICAgICAgICAgIDxUeHQgY2xhc3NOYW1lPXsgc3R5bGVzLnRleHRCYWNrZ3JvdW5kMiB9PlZBTE9SQU5UPC9UeHQ+XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgPC9UZXh0QmdDb250YWluZXI+XHJcbiAgICAgICAgPC8+XHJcblxyXG4gICAgKVxyXG4gICAgXHJcblxyXG59XHJcbmV4cG9ydCBkZWZhdWx0IFRleHRCRztcclxuZXhwb3J0IHtUeHQsIFRleHRCZ0NvbnRhaW5lcn07XHJcblxyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5cclxuY29uc3QgU3R5bGVkVGl0bGUgPSBzdHlsZWQucGBcclxuICBmb250LXNpemU6IDQuMjVyZW07XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1mYW1pbHk6ICdLYW5pdCcsIHNhbnMtc2VyaWY7XHJcbiAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMuY29sb3J9O1xyXG4gIG1hcmdpbjogMDtcclxuICB3aWR0aDogNjAlO1xyXG4gIGxpbmUtaGVpZ2h0OiAxLjM7XHJcbmBcclxuXHJcbmV4cG9ydCBkZWZhdWx0ICh7IHRleHRDb2xvciwgY2hpbGRyZW4gfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkVGl0bGUgY29sb3I9e3RleHRDb2xvcn0+XHJcbiAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICA8L1N0eWxlZFRpdGxlPlxyXG4gICAgKVxyXG59XHJcbiIsImV4cG9ydCB7ZGVmYXVsdCBhcyBIZWFkfSBmcm9tICcuL0hlYWQnXHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBUaXRsZX0gZnJvbSAnLi9UZXh0VGl0bGUnXHJcbmV4cG9ydCB7TmF2QmFyfSBmcm9tICcuL05hdidcclxuZXhwb3J0IHtGb290ZXJ9IGZyb20gJy4vRm9vdGVyJ1xyXG5leHBvcnQge0J1dHRvbn0gZnJvbSAnLi9CdXR0b24nXHJcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5kZWZhdWx0ID0gdm9pZCAwO1xudmFyIF9yZWFjdCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcInJlYWN0XCIpKTtcbnZhciBfcm91dGVyID0gcmVxdWlyZShcIi4uL3NoYXJlZC9saWIvcm91dGVyL3JvdXRlclwiKTtcbnZhciBfcm91dGVyMSA9IHJlcXVpcmUoXCIuL3JvdXRlclwiKTtcbnZhciBfdXNlSW50ZXJzZWN0aW9uID0gcmVxdWlyZShcIi4vdXNlLWludGVyc2VjdGlvblwiKTtcbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmNvbnN0IHByZWZldGNoZWQgPSB7XG59O1xuZnVuY3Rpb24gcHJlZmV0Y2gocm91dGVyLCBocmVmLCBhcywgb3B0aW9ucykge1xuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJyB8fCAhcm91dGVyKSByZXR1cm47XG4gICAgaWYgKCEoMCwgX3JvdXRlcikuaXNMb2NhbFVSTChocmVmKSkgcmV0dXJuO1xuICAgIC8vIFByZWZldGNoIHRoZSBKU09OIHBhZ2UgaWYgYXNrZWQgKG9ubHkgaW4gdGhlIGNsaWVudClcbiAgICAvLyBXZSBuZWVkIHRvIGhhbmRsZSBhIHByZWZldGNoIGVycm9yIGhlcmUgc2luY2Ugd2UgbWF5IGJlXG4gICAgLy8gbG9hZGluZyB3aXRoIHByaW9yaXR5IHdoaWNoIGNhbiByZWplY3QgYnV0IHdlIGRvbid0XG4gICAgLy8gd2FudCB0byBmb3JjZSBuYXZpZ2F0aW9uIHNpbmNlIHRoaXMgaXMgb25seSBhIHByZWZldGNoXG4gICAgcm91dGVyLnByZWZldGNoKGhyZWYsIGFzLCBvcHRpb25zKS5jYXRjaCgoZXJyKT0+e1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgLy8gcmV0aHJvdyB0byBzaG93IGludmFsaWQgVVJMIGVycm9yc1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgY3VyTG9jYWxlID0gb3B0aW9ucyAmJiB0eXBlb2Ygb3B0aW9ucy5sb2NhbGUgIT09ICd1bmRlZmluZWQnID8gb3B0aW9ucy5sb2NhbGUgOiByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZTtcbiAgICAvLyBKb2luIG9uIGFuIGludmFsaWQgVVJJIGNoYXJhY3RlclxuICAgIHByZWZldGNoZWRbaHJlZiArICclJyArIGFzICsgKGN1ckxvY2FsZSA/ICclJyArIGN1ckxvY2FsZSA6ICcnKV0gPSB0cnVlO1xufVxuZnVuY3Rpb24gaXNNb2RpZmllZEV2ZW50KGV2ZW50KSB7XG4gICAgY29uc3QgeyB0YXJnZXQgIH0gPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgIHJldHVybiB0YXJnZXQgJiYgdGFyZ2V0ICE9PSAnX3NlbGYnIHx8IGV2ZW50Lm1ldGFLZXkgfHwgZXZlbnQuY3RybEtleSB8fCBldmVudC5zaGlmdEtleSB8fCBldmVudC5hbHRLZXkgfHwgZXZlbnQubmF0aXZlRXZlbnQgJiYgZXZlbnQubmF0aXZlRXZlbnQud2hpY2ggPT09IDI7XG59XG5mdW5jdGlvbiBsaW5rQ2xpY2tlZChlLCByb3V0ZXIsIGhyZWYsIGFzLCByZXBsYWNlLCBzaGFsbG93LCBzY3JvbGwsIGxvY2FsZSkge1xuICAgIGNvbnN0IHsgbm9kZU5hbWUgIH0gPSBlLmN1cnJlbnRUYXJnZXQ7XG4gICAgaWYgKG5vZGVOYW1lID09PSAnQScgJiYgKGlzTW9kaWZpZWRFdmVudChlKSB8fCAhKDAsIF9yb3V0ZXIpLmlzTG9jYWxVUkwoaHJlZikpKSB7XG4gICAgICAgIC8vIGlnbm9yZSBjbGljayBmb3IgYnJvd3NlcuKAmXMgZGVmYXVsdCBiZWhhdmlvclxuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAvLyAgYXZvaWQgc2Nyb2xsIGZvciB1cmxzIHdpdGggYW5jaG9yIHJlZnNcbiAgICBpZiAoc2Nyb2xsID09IG51bGwgJiYgYXMuaW5kZXhPZignIycpID49IDApIHtcbiAgICAgICAgc2Nyb2xsID0gZmFsc2U7XG4gICAgfVxuICAgIC8vIHJlcGxhY2Ugc3RhdGUgaW5zdGVhZCBvZiBwdXNoIGlmIHByb3AgaXMgcHJlc2VudFxuICAgIHJvdXRlcltyZXBsYWNlID8gJ3JlcGxhY2UnIDogJ3B1c2gnXShocmVmLCBhcywge1xuICAgICAgICBzaGFsbG93LFxuICAgICAgICBsb2NhbGUsXG4gICAgICAgIHNjcm9sbFxuICAgIH0pO1xufVxuZnVuY3Rpb24gTGluayhwcm9wcykge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGZ1bmN0aW9uIGNyZWF0ZVByb3BFcnJvcihhcmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IEVycm9yKGBGYWlsZWQgcHJvcCB0eXBlOiBUaGUgcHJvcCBcXGAke2FyZ3Mua2V5fVxcYCBleHBlY3RzIGEgJHthcmdzLmV4cGVjdGVkfSBpbiBcXGA8TGluaz5cXGAsIGJ1dCBnb3QgXFxgJHthcmdzLmFjdHVhbH1cXGAgaW5zdGVhZC5gICsgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gXCJcXG5PcGVuIHlvdXIgYnJvd3NlcidzIGNvbnNvbGUgdG8gdmlldyB0aGUgQ29tcG9uZW50IHN0YWNrIHRyYWNlLlwiIDogJycpKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICBjb25zdCByZXF1aXJlZFByb3BzR3VhcmQgPSB7XG4gICAgICAgICAgICBocmVmOiB0cnVlXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHJlcXVpcmVkUHJvcHMgPSBPYmplY3Qua2V5cyhyZXF1aXJlZFByb3BzR3VhcmQpO1xuICAgICAgICByZXF1aXJlZFByb3BzLmZvckVhY2goKGtleSk9PntcbiAgICAgICAgICAgIGlmIChrZXkgPT09ICdocmVmJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldID09IG51bGwgfHwgdHlwZW9mIHByb3BzW2tleV0gIT09ICdzdHJpbmcnICYmIHR5cGVvZiBwcm9wc1trZXldICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBjcmVhdGVQcm9wRXJyb3Ioe1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0ZWQ6ICdgc3RyaW5nYCBvciBgb2JqZWN0YCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3R1YWw6IHByb3BzW2tleV0gPT09IG51bGwgPyAnbnVsbCcgOiB0eXBlb2YgcHJvcHNba2V5XVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgICAgICAgICAgICAgIGNvbnN0IF8gPSBrZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICBjb25zdCBvcHRpb25hbFByb3BzR3VhcmQgPSB7XG4gICAgICAgICAgICBhczogdHJ1ZSxcbiAgICAgICAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICAgICAgICBzY3JvbGw6IHRydWUsXG4gICAgICAgICAgICBzaGFsbG93OiB0cnVlLFxuICAgICAgICAgICAgcGFzc0hyZWY6IHRydWUsXG4gICAgICAgICAgICBwcmVmZXRjaDogdHJ1ZSxcbiAgICAgICAgICAgIGxvY2FsZTogdHJ1ZVxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBvcHRpb25hbFByb3BzID0gT2JqZWN0LmtleXMob3B0aW9uYWxQcm9wc0d1YXJkKTtcbiAgICAgICAgb3B0aW9uYWxQcm9wcy5mb3JFYWNoKChrZXkpPT57XG4gICAgICAgICAgICBjb25zdCB2YWxUeXBlID0gdHlwZW9mIHByb3BzW2tleV07XG4gICAgICAgICAgICBpZiAoa2V5ID09PSAnYXMnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzW2tleV0gJiYgdmFsVHlwZSAhPT0gJ3N0cmluZycgJiYgdmFsVHlwZSAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgY3JlYXRlUHJvcEVycm9yKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkOiAnYHN0cmluZ2Agb3IgYG9iamVjdGAnLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0dWFsOiB2YWxUeXBlXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSAnbG9jYWxlJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldICYmIHZhbFR5cGUgIT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogJ2BzdHJpbmdgJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdHVhbDogdmFsVHlwZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGtleSA9PT0gJ3JlcGxhY2UnIHx8IGtleSA9PT0gJ3Njcm9sbCcgfHwga2V5ID09PSAnc2hhbGxvdycgfHwga2V5ID09PSAncGFzc0hyZWYnIHx8IGtleSA9PT0gJ3ByZWZldGNoJykge1xuICAgICAgICAgICAgICAgIGlmIChwcm9wc1trZXldICE9IG51bGwgJiYgdmFsVHlwZSAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogJ2Bib29sZWFuYCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3R1YWw6IHZhbFR5cGVcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgICAgICAgICAgICAgICBjb25zdCBfID0ga2V5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgLy8gVGhpcyBob29rIGlzIGluIGEgY29uZGl0aW9uYWwgYnV0IHRoYXQgaXMgb2sgYmVjYXVzZSBgcHJvY2Vzcy5lbnYuTk9ERV9FTlZgIG5ldmVyIGNoYW5nZXNcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgICAgIGNvbnN0IGhhc1dhcm5lZCA9IF9yZWFjdC5kZWZhdWx0LnVzZVJlZihmYWxzZSk7XG4gICAgICAgIGlmIChwcm9wcy5wcmVmZXRjaCAmJiAhaGFzV2FybmVkLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGhhc1dhcm5lZC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignTmV4dC5qcyBhdXRvLXByZWZldGNoZXMgYXV0b21hdGljYWxseSBiYXNlZCBvbiB2aWV3cG9ydC4gVGhlIHByZWZldGNoIGF0dHJpYnV0ZSBpcyBubyBsb25nZXIgbmVlZGVkLiBNb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9wcmVmZXRjaC10cnVlLWRlcHJlY2F0ZWQnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBwID0gcHJvcHMucHJlZmV0Y2ggIT09IGZhbHNlO1xuICAgIGNvbnN0IHJvdXRlciA9ICgwLCBfcm91dGVyMSkudXNlUm91dGVyKCk7XG4gICAgY29uc3QgeyBocmVmICwgYXMgIH0gPSBfcmVhY3QuZGVmYXVsdC51c2VNZW1vKCgpPT57XG4gICAgICAgIGNvbnN0IFtyZXNvbHZlZEhyZWYsIHJlc29sdmVkQXNdID0gKDAsIF9yb3V0ZXIpLnJlc29sdmVIcmVmKHJvdXRlciwgcHJvcHMuaHJlZiwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBocmVmOiByZXNvbHZlZEhyZWYsXG4gICAgICAgICAgICBhczogcHJvcHMuYXMgPyAoMCwgX3JvdXRlcikucmVzb2x2ZUhyZWYocm91dGVyLCBwcm9wcy5hcykgOiByZXNvbHZlZEFzIHx8IHJlc29sdmVkSHJlZlxuICAgICAgICB9O1xuICAgIH0sIFtcbiAgICAgICAgcm91dGVyLFxuICAgICAgICBwcm9wcy5ocmVmLFxuICAgICAgICBwcm9wcy5hc1xuICAgIF0pO1xuICAgIGxldCB7IGNoaWxkcmVuICwgcmVwbGFjZSAsIHNoYWxsb3cgLCBzY3JvbGwgLCBsb2NhbGUgIH0gPSBwcm9wcztcbiAgICAvLyBEZXByZWNhdGVkLiBXYXJuaW5nIHNob3duIGJ5IHByb3BUeXBlIGNoZWNrLiBJZiB0aGUgY2hpbGRyZW4gcHJvdmlkZWQgaXMgYSBzdHJpbmcgKDxMaW5rPmV4YW1wbGU8L0xpbms+KSB3ZSB3cmFwIGl0IGluIGFuIDxhPiB0YWdcbiAgICBpZiAodHlwZW9mIGNoaWxkcmVuID09PSAnc3RyaW5nJykge1xuICAgICAgICBjaGlsZHJlbiA9IC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImFcIiwgbnVsbCwgY2hpbGRyZW4pO1xuICAgIH1cbiAgICAvLyBUaGlzIHdpbGwgcmV0dXJuIHRoZSBmaXJzdCBjaGlsZCwgaWYgbXVsdGlwbGUgYXJlIHByb3ZpZGVkIGl0IHdpbGwgdGhyb3cgYW4gZXJyb3JcbiAgICBsZXQgY2hpbGQ7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjaGlsZCA9IF9yZWFjdC5kZWZhdWx0LkNoaWxkcmVuLm9ubHkoY2hpbGRyZW4pO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgTXVsdGlwbGUgY2hpbGRyZW4gd2VyZSBwYXNzZWQgdG8gPExpbms+IHdpdGggXFxgaHJlZlxcYCBvZiBcXGAke3Byb3BzLmhyZWZ9XFxgIGJ1dCBvbmx5IG9uZSBjaGlsZCBpcyBzdXBwb3J0ZWQgaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvbGluay1tdWx0aXBsZS1jaGlsZHJlbmAgKyAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyBcIiBcXG5PcGVuIHlvdXIgYnJvd3NlcidzIGNvbnNvbGUgdG8gdmlldyB0aGUgQ29tcG9uZW50IHN0YWNrIHRyYWNlLlwiIDogJycpKTtcbiAgICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAgIGNoaWxkID0gX3JlYWN0LmRlZmF1bHQuQ2hpbGRyZW4ub25seShjaGlsZHJlbik7XG4gICAgfVxuICAgIGNvbnN0IGNoaWxkUmVmID0gY2hpbGQgJiYgdHlwZW9mIGNoaWxkID09PSAnb2JqZWN0JyAmJiBjaGlsZC5yZWY7XG4gICAgY29uc3QgW3NldEludGVyc2VjdGlvblJlZiwgaXNWaXNpYmxlXSA9ICgwLCBfdXNlSW50ZXJzZWN0aW9uKS51c2VJbnRlcnNlY3Rpb24oe1xuICAgICAgICByb290TWFyZ2luOiAnMjAwcHgnXG4gICAgfSk7XG4gICAgY29uc3Qgc2V0UmVmID0gX3JlYWN0LmRlZmF1bHQudXNlQ2FsbGJhY2soKGVsKT0+e1xuICAgICAgICBzZXRJbnRlcnNlY3Rpb25SZWYoZWwpO1xuICAgICAgICBpZiAoY2hpbGRSZWYpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY2hpbGRSZWYgPT09ICdmdW5jdGlvbicpIGNoaWxkUmVmKGVsKTtcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjaGlsZFJlZiA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgICBjaGlsZFJlZi5jdXJyZW50ID0gZWw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIGNoaWxkUmVmLFxuICAgICAgICBzZXRJbnRlcnNlY3Rpb25SZWZcbiAgICBdKTtcbiAgICBfcmVhY3QuZGVmYXVsdC51c2VFZmZlY3QoKCk9PntcbiAgICAgICAgY29uc3Qgc2hvdWxkUHJlZmV0Y2ggPSBpc1Zpc2libGUgJiYgcCAmJiAoMCwgX3JvdXRlcikuaXNMb2NhbFVSTChocmVmKTtcbiAgICAgICAgY29uc3QgY3VyTG9jYWxlID0gdHlwZW9mIGxvY2FsZSAhPT0gJ3VuZGVmaW5lZCcgPyBsb2NhbGUgOiByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZTtcbiAgICAgICAgY29uc3QgaXNQcmVmZXRjaGVkID0gcHJlZmV0Y2hlZFtocmVmICsgJyUnICsgYXMgKyAoY3VyTG9jYWxlID8gJyUnICsgY3VyTG9jYWxlIDogJycpXTtcbiAgICAgICAgaWYgKHNob3VsZFByZWZldGNoICYmICFpc1ByZWZldGNoZWQpIHtcbiAgICAgICAgICAgIHByZWZldGNoKHJvdXRlciwgaHJlZiwgYXMsIHtcbiAgICAgICAgICAgICAgICBsb2NhbGU6IGN1ckxvY2FsZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIGFzLFxuICAgICAgICBocmVmLFxuICAgICAgICBpc1Zpc2libGUsXG4gICAgICAgIGxvY2FsZSxcbiAgICAgICAgcCxcbiAgICAgICAgcm91dGVyXG4gICAgXSk7XG4gICAgY29uc3QgY2hpbGRQcm9wcyA9IHtcbiAgICAgICAgcmVmOiBzZXRSZWYsXG4gICAgICAgIG9uQ2xpY2s6IChlKT0+e1xuICAgICAgICAgICAgaWYgKGNoaWxkLnByb3BzICYmIHR5cGVvZiBjaGlsZC5wcm9wcy5vbkNsaWNrID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgY2hpbGQucHJvcHMub25DbGljayhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghZS5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICAgICAgbGlua0NsaWNrZWQoZSwgcm91dGVyLCBocmVmLCBhcywgcmVwbGFjZSwgc2hhbGxvdywgc2Nyb2xsLCBsb2NhbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjaGlsZFByb3BzLm9uTW91c2VFbnRlciA9IChlKT0+e1xuICAgICAgICBpZiAoISgwLCBfcm91dGVyKS5pc0xvY2FsVVJMKGhyZWYpKSByZXR1cm47XG4gICAgICAgIGlmIChjaGlsZC5wcm9wcyAmJiB0eXBlb2YgY2hpbGQucHJvcHMub25Nb3VzZUVudGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBjaGlsZC5wcm9wcy5vbk1vdXNlRW50ZXIoZSk7XG4gICAgICAgIH1cbiAgICAgICAgcHJlZmV0Y2gocm91dGVyLCBocmVmLCBhcywge1xuICAgICAgICAgICAgcHJpb3JpdHk6IHRydWVcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyBJZiBjaGlsZCBpcyBhbiA8YT4gdGFnIGFuZCBkb2Vzbid0IGhhdmUgYSBocmVmIGF0dHJpYnV0ZSwgb3IgaWYgdGhlICdwYXNzSHJlZicgcHJvcGVydHkgaXNcbiAgICAvLyBkZWZpbmVkLCB3ZSBzcGVjaWZ5IHRoZSBjdXJyZW50ICdocmVmJywgc28gdGhhdCByZXBldGl0aW9uIGlzIG5vdCBuZWVkZWQgYnkgdGhlIHVzZXJcbiAgICBpZiAocHJvcHMucGFzc0hyZWYgfHwgY2hpbGQudHlwZSA9PT0gJ2EnICYmICEoJ2hyZWYnIGluIGNoaWxkLnByb3BzKSkge1xuICAgICAgICBjb25zdCBjdXJMb2NhbGUgPSB0eXBlb2YgbG9jYWxlICE9PSAndW5kZWZpbmVkJyA/IGxvY2FsZSA6IHJvdXRlciAmJiByb3V0ZXIubG9jYWxlO1xuICAgICAgICAvLyB3ZSBvbmx5IHJlbmRlciBkb21haW4gbG9jYWxlcyBpZiB3ZSBhcmUgY3VycmVudGx5IG9uIGEgZG9tYWluIGxvY2FsZVxuICAgICAgICAvLyBzbyB0aGF0IGxvY2FsZSBsaW5rcyBhcmUgc3RpbGwgdmlzaXRhYmxlIGluIGRldmVsb3BtZW50L3ByZXZpZXcgZW52c1xuICAgICAgICBjb25zdCBsb2NhbGVEb21haW4gPSByb3V0ZXIgJiYgcm91dGVyLmlzTG9jYWxlRG9tYWluICYmICgwLCBfcm91dGVyKS5nZXREb21haW5Mb2NhbGUoYXMsIGN1ckxvY2FsZSwgcm91dGVyICYmIHJvdXRlci5sb2NhbGVzLCByb3V0ZXIgJiYgcm91dGVyLmRvbWFpbkxvY2FsZXMpO1xuICAgICAgICBjaGlsZFByb3BzLmhyZWYgPSBsb2NhbGVEb21haW4gfHwgKDAsIF9yb3V0ZXIpLmFkZEJhc2VQYXRoKCgwLCBfcm91dGVyKS5hZGRMb2NhbGUoYXMsIGN1ckxvY2FsZSwgcm91dGVyICYmIHJvdXRlci5kZWZhdWx0TG9jYWxlKSk7XG4gICAgfVxuICAgIHJldHVybigvKiNfX1BVUkVfXyovIF9yZWFjdC5kZWZhdWx0LmNsb25lRWxlbWVudChjaGlsZCwgY2hpbGRQcm9wcykpO1xufVxudmFyIF9kZWZhdWx0ID0gTGluaztcbmV4cG9ydHMuZGVmYXVsdCA9IF9kZWZhdWx0O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1saW5rLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoO1xuZXhwb3J0cy5ub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaCA9IHZvaWQgMDtcbmZ1bmN0aW9uIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGgpIHtcbiAgICByZXR1cm4gcGF0aC5lbmRzV2l0aCgnLycpICYmIHBhdGggIT09ICcvJyA/IHBhdGguc2xpY2UoMCwgLTEpIDogcGF0aDtcbn1cbmNvbnN0IG5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoID0gcHJvY2Vzcy5lbnYuX19ORVhUX1RSQUlMSU5HX1NMQVNIID8gKHBhdGgpPT57XG4gICAgaWYgKC9cXC5bXi9dK1xcLz8kLy50ZXN0KHBhdGgpKSB7XG4gICAgICAgIHJldHVybiByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRoKTtcbiAgICB9IGVsc2UgaWYgKHBhdGguZW5kc1dpdGgoJy8nKSkge1xuICAgICAgICByZXR1cm4gcGF0aDtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gcGF0aCArICcvJztcbiAgICB9XG59IDogcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2g7XG5leHBvcnRzLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoID0gbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2g7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vcm1hbGl6ZS10cmFpbGluZy1zbGFzaC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMucmVxdWVzdElkbGVDYWxsYmFjayA9IGV4cG9ydHMuY2FuY2VsSWRsZUNhbGxiYWNrID0gdm9pZCAwO1xuY29uc3QgcmVxdWVzdElkbGVDYWxsYmFjayA9IHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLnJlcXVlc3RJZGxlQ2FsbGJhY2sgJiYgc2VsZi5yZXF1ZXN0SWRsZUNhbGxiYWNrLmJpbmQod2luZG93KSB8fCBmdW5jdGlvbihjYikge1xuICAgIGxldCBzdGFydCA9IERhdGUubm93KCk7XG4gICAgcmV0dXJuIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgIGNiKHtcbiAgICAgICAgICAgIGRpZFRpbWVvdXQ6IGZhbHNlLFxuICAgICAgICAgICAgdGltZVJlbWFpbmluZzogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIDUwIC0gKERhdGUubm93KCkgLSBzdGFydCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LCAxKTtcbn07XG5leHBvcnRzLnJlcXVlc3RJZGxlQ2FsbGJhY2sgPSByZXF1ZXN0SWRsZUNhbGxiYWNrO1xuY29uc3QgY2FuY2VsSWRsZUNhbGxiYWNrID0gdHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnICYmIHNlbGYuY2FuY2VsSWRsZUNhbGxiYWNrICYmIHNlbGYuY2FuY2VsSWRsZUNhbGxiYWNrLmJpbmQod2luZG93KSB8fCBmdW5jdGlvbihpZCkge1xuICAgIHJldHVybiBjbGVhclRpbWVvdXQoaWQpO1xufTtcbmV4cG9ydHMuY2FuY2VsSWRsZUNhbGxiYWNrID0gY2FuY2VsSWRsZUNhbGxiYWNrO1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZXF1ZXN0LWlkbGUtY2FsbGJhY2suanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLm1hcmtBc3NldEVycm9yID0gbWFya0Fzc2V0RXJyb3I7XG5leHBvcnRzLmlzQXNzZXRFcnJvciA9IGlzQXNzZXRFcnJvcjtcbmV4cG9ydHMuZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCA9IGdldENsaWVudEJ1aWxkTWFuaWZlc3Q7XG5leHBvcnRzLmNyZWF0ZVJvdXRlTG9hZGVyID0gY3JlYXRlUm91dGVMb2FkZXI7XG52YXIgX2dldEFzc2V0UGF0aEZyb21Sb3V0ZSA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4uL3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2dldC1hc3NldC1wYXRoLWZyb20tcm91dGVcIikpO1xudmFyIF9yZXF1ZXN0SWRsZUNhbGxiYWNrID0gcmVxdWlyZShcIi4vcmVxdWVzdC1pZGxlLWNhbGxiYWNrXCIpO1xuZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgICAgICBkZWZhdWx0OiBvYmpcbiAgICB9O1xufVxuLy8gMy44cyB3YXMgYXJiaXRyYXJpbHkgY2hvc2VuIGFzIGl0J3Mgd2hhdCBodHRwczovL3dlYi5kZXYvaW50ZXJhY3RpdmVcbi8vIGNvbnNpZGVycyBhcyBcIkdvb2RcIiB0aW1lLXRvLWludGVyYWN0aXZlLiBXZSBtdXN0IGFzc3VtZSBzb21ldGhpbmcgd2VudFxuLy8gd3JvbmcgYmV5b25kIHRoaXMgcG9pbnQsIGFuZCB0aGVuIGZhbGwtYmFjayB0byBhIGZ1bGwgcGFnZSB0cmFuc2l0aW9uIHRvXG4vLyBzaG93IHRoZSB1c2VyIHNvbWV0aGluZyBvZiB2YWx1ZS5cbmNvbnN0IE1TX01BWF9JRExFX0RFTEFZID0gMzgwMDtcbmZ1bmN0aW9uIHdpdGhGdXR1cmUoa2V5LCBtYXAsIGdlbmVyYXRvcikge1xuICAgIGxldCBlbnRyeSA9IG1hcC5nZXQoa2V5KTtcbiAgICBpZiAoZW50cnkpIHtcbiAgICAgICAgaWYgKCdmdXR1cmUnIGluIGVudHJ5KSB7XG4gICAgICAgICAgICByZXR1cm4gZW50cnkuZnV0dXJlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZW50cnkpO1xuICAgIH1cbiAgICBsZXQgcmVzb2x2ZXI7XG4gICAgY29uc3QgcHJvbSA9IG5ldyBQcm9taXNlKChyZXNvbHZlKT0+e1xuICAgICAgICByZXNvbHZlciA9IHJlc29sdmU7XG4gICAgfSk7XG4gICAgbWFwLnNldChrZXksIGVudHJ5ID0ge1xuICAgICAgICByZXNvbHZlOiByZXNvbHZlcixcbiAgICAgICAgZnV0dXJlOiBwcm9tXG4gICAgfSk7XG4gICAgcmV0dXJuIGdlbmVyYXRvciA/IGdlbmVyYXRvcigpLnRoZW4oKHZhbHVlKT0+KHJlc29sdmVyKHZhbHVlKSwgdmFsdWUpXG4gICAgKSA6IHByb207XG59XG5mdW5jdGlvbiBoYXNQcmVmZXRjaChsaW5rKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKTtcbiAgICAgICAgcmV0dXJuKC8vIGRldGVjdCBJRTExIHNpbmNlIGl0IHN1cHBvcnRzIHByZWZldGNoIGJ1dCBpc24ndCBkZXRlY3RlZFxuICAgICAgICAvLyB3aXRoIHJlbExpc3Quc3VwcG9ydFxuICAgICAgICAoISF3aW5kb3cuTVNJbnB1dE1ldGhvZENvbnRleHQgJiYgISFkb2N1bWVudC5kb2N1bWVudE1vZGUpIHx8IGxpbmsucmVsTGlzdC5zdXBwb3J0cygncHJlZmV0Y2gnKSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuY29uc3QgY2FuUHJlZmV0Y2ggPSBoYXNQcmVmZXRjaCgpO1xuZnVuY3Rpb24gcHJlZmV0Y2hWaWFEb20oaHJlZiwgYXMsIGxpbmspIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlcywgcmVqKT0+e1xuICAgICAgICBpZiAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgbGlua1tyZWw9XCJwcmVmZXRjaFwiXVtocmVmXj1cIiR7aHJlZn1cIl1gKSkge1xuICAgICAgICAgICAgcmV0dXJuIHJlcygpO1xuICAgICAgICB9XG4gICAgICAgIGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaW5rJyk7XG4gICAgICAgIC8vIFRoZSBvcmRlciBvZiBwcm9wZXJ0eSBhc3NpZ25tZW50IGhlcmUgaXMgaW50ZW50aW9uYWw6XG4gICAgICAgIGlmIChhcykgbGluay5hcyA9IGFzO1xuICAgICAgICBsaW5rLnJlbCA9IGBwcmVmZXRjaGA7XG4gICAgICAgIGxpbmsuY3Jvc3NPcmlnaW4gPSBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOO1xuICAgICAgICBsaW5rLm9ubG9hZCA9IHJlcztcbiAgICAgICAgbGluay5vbmVycm9yID0gcmVqO1xuICAgICAgICAvLyBgaHJlZmAgc2hvdWxkIGFsd2F5cyBiZSBsYXN0OlxuICAgICAgICBsaW5rLmhyZWYgPSBocmVmO1xuICAgICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGxpbmspO1xuICAgIH0pO1xufVxuY29uc3QgQVNTRVRfTE9BRF9FUlJPUiA9IFN5bWJvbCgnQVNTRVRfTE9BRF9FUlJPUicpO1xuZnVuY3Rpb24gbWFya0Fzc2V0RXJyb3IoZXJyKSB7XG4gICAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlcnIsIEFTU0VUX0xPQURfRVJST1IsIHtcbiAgICB9KTtcbn1cbmZ1bmN0aW9uIGlzQXNzZXRFcnJvcihlcnIpIHtcbiAgICByZXR1cm4gZXJyICYmIEFTU0VUX0xPQURfRVJST1IgaW4gZXJyO1xufVxuZnVuY3Rpb24gYXBwZW5kU2NyaXB0KHNyYywgc2NyaXB0KSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpPT57XG4gICAgICAgIHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgICAgICAvLyBUaGUgb3JkZXIgb2YgcHJvcGVydHkgYXNzaWdubWVudCBoZXJlIGlzIGludGVudGlvbmFsLlxuICAgICAgICAvLyAxLiBTZXR1cCBzdWNjZXNzL2ZhaWx1cmUgaG9va3MgaW4gY2FzZSB0aGUgYnJvd3NlciBzeW5jaHJvbm91c2x5XG4gICAgICAgIC8vICAgIGV4ZWN1dGVzIHdoZW4gYHNyY2AgaXMgc2V0LlxuICAgICAgICBzY3JpcHQub25sb2FkID0gcmVzb2x2ZTtcbiAgICAgICAgc2NyaXB0Lm9uZXJyb3IgPSAoKT0+cmVqZWN0KG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc2NyaXB0OiAke3NyY31gKSkpXG4gICAgICAgIDtcbiAgICAgICAgLy8gMi4gQ29uZmlndXJlIHRoZSBjcm9zcy1vcmlnaW4gYXR0cmlidXRlIGJlZm9yZSBzZXR0aW5nIGBzcmNgIGluIGNhc2UgdGhlXG4gICAgICAgIC8vICAgIGJyb3dzZXIgYmVnaW5zIHRvIGZldGNoLlxuICAgICAgICBzY3JpcHQuY3Jvc3NPcmlnaW4gPSBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOO1xuICAgICAgICAvLyAzLiBGaW5hbGx5LCBzZXQgdGhlIHNvdXJjZSBhbmQgaW5qZWN0IGludG8gdGhlIERPTSBpbiBjYXNlIHRoZSBjaGlsZFxuICAgICAgICAvLyAgICBtdXN0IGJlIGFwcGVuZGVkIGZvciBmZXRjaGluZyB0byBzdGFydC5cbiAgICAgICAgc2NyaXB0LnNyYyA9IHNyYztcbiAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgIH0pO1xufVxuLy8gV2Ugd2FpdCBmb3IgcGFnZXMgdG8gYmUgYnVpbHQgaW4gZGV2IGJlZm9yZSB3ZSBzdGFydCB0aGUgcm91dGUgdHJhbnNpdGlvblxuLy8gdGltZW91dCB0byBwcmV2ZW50IGFuIHVuLW5lY2Vzc2FyeSBoYXJkIG5hdmlnYXRpb24gaW4gZGV2ZWxvcG1lbnQuXG5sZXQgZGV2QnVpbGRQcm9taXNlO1xuLy8gUmVzb2x2ZSBhIHByb21pc2UgdGhhdCB0aW1lcyBvdXQgYWZ0ZXIgZ2l2ZW4gYW1vdW50IG9mIG1pbGxpc2Vjb25kcy5cbmZ1bmN0aW9uIHJlc29sdmVQcm9taXNlV2l0aFRpbWVvdXQocCwgbXMsIGVycikge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KT0+e1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIHAudGhlbigocik9PntcbiAgICAgICAgICAgIC8vIFJlc29sdmVkLCBjYW5jZWwgdGhlIHRpbWVvdXRcbiAgICAgICAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgICAgICByZXNvbHZlKHIpO1xuICAgICAgICB9KS5jYXRjaChyZWplY3QpO1xuICAgICAgICAvLyBXZSB3cmFwIHRoZXNlIGNoZWNrcyBzZXBhcmF0ZWx5IGZvciBiZXR0ZXIgZGVhZC1jb2RlIGVsaW1pbmF0aW9uIGluXG4gICAgICAgIC8vIHByb2R1Y3Rpb24gYnVuZGxlcy5cbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgICAgICAoZGV2QnVpbGRQcm9taXNlIHx8IFByb21pc2UucmVzb2x2ZSgpKS50aGVuKCgpPT57XG4gICAgICAgICAgICAgICAgKDAsIF9yZXF1ZXN0SWRsZUNhbGxiYWNrKS5yZXF1ZXN0SWRsZUNhbGxiYWNrKCgpPT5zZXRUaW1lb3V0KCgpPT57XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LCBtcylcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgICAgICAoMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLnJlcXVlc3RJZGxlQ2FsbGJhY2soKCk9PnNldFRpbWVvdXQoKCk9PntcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwgbXMpXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5mdW5jdGlvbiBnZXRDbGllbnRCdWlsZE1hbmlmZXN0KCkge1xuICAgIGlmIChzZWxmLl9fQlVJTERfTUFOSUZFU1QpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShzZWxmLl9fQlVJTERfTUFOSUZFU1QpO1xuICAgIH1cbiAgICBjb25zdCBvbkJ1aWxkTWFuaWZlc3QgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSk9PntcbiAgICAgICAgLy8gTWFuZGF0b3J5IGJlY2F1c2UgdGhpcyBpcyBub3QgY29uY3VycmVudCBzYWZlOlxuICAgICAgICBjb25zdCBjYiA9IHNlbGYuX19CVUlMRF9NQU5JRkVTVF9DQjtcbiAgICAgICAgc2VsZi5fX0JVSUxEX01BTklGRVNUX0NCID0gKCk9PntcbiAgICAgICAgICAgIHJlc29sdmUoc2VsZi5fX0JVSUxEX01BTklGRVNUKTtcbiAgICAgICAgICAgIGNiICYmIGNiKCk7XG4gICAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIHJlc29sdmVQcm9taXNlV2l0aFRpbWVvdXQob25CdWlsZE1hbmlmZXN0LCBNU19NQVhfSURMRV9ERUxBWSwgbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKCdGYWlsZWQgdG8gbG9hZCBjbGllbnQgYnVpbGQgbWFuaWZlc3QnKSkpO1xufVxuZnVuY3Rpb24gZ2V0RmlsZXNGb3JSb3V0ZShhc3NldFByZWZpeCwgcm91dGUpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7XG4gICAgICAgICAgICBzY3JpcHRzOiBbXG4gICAgICAgICAgICAgICAgYXNzZXRQcmVmaXggKyAnL19uZXh0L3N0YXRpYy9jaHVua3MvcGFnZXMnICsgZW5jb2RlVVJJKCgwLCBfZ2V0QXNzZXRQYXRoRnJvbVJvdXRlKS5kZWZhdWx0KHJvdXRlLCAnLmpzJykpLCBcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAvLyBTdHlsZXMgYXJlIGhhbmRsZWQgYnkgYHN0eWxlLWxvYWRlcmAgaW4gZGV2ZWxvcG1lbnQ6XG4gICAgICAgICAgICBjc3M6IFtdXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCgpLnRoZW4oKG1hbmlmZXN0KT0+e1xuICAgICAgICBpZiAoIShyb3V0ZSBpbiBtYW5pZmVzdCkpIHtcbiAgICAgICAgICAgIHRocm93IG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvb2t1cCByb3V0ZTogJHtyb3V0ZX1gKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYWxsRmlsZXMgPSBtYW5pZmVzdFtyb3V0ZV0ubWFwKChlbnRyeSk9PmFzc2V0UHJlZml4ICsgJy9fbmV4dC8nICsgZW5jb2RlVVJJKGVudHJ5KVxuICAgICAgICApO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2NyaXB0czogYWxsRmlsZXMuZmlsdGVyKCh2KT0+di5lbmRzV2l0aCgnLmpzJylcbiAgICAgICAgICAgICksXG4gICAgICAgICAgICBjc3M6IGFsbEZpbGVzLmZpbHRlcigodik9PnYuZW5kc1dpdGgoJy5jc3MnKVxuICAgICAgICAgICAgKVxuICAgICAgICB9O1xuICAgIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlUm91dGVMb2FkZXIoYXNzZXRQcmVmaXgpIHtcbiAgICBjb25zdCBlbnRyeXBvaW50cyA9IG5ldyBNYXAoKTtcbiAgICBjb25zdCBsb2FkZWRTY3JpcHRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IHN0eWxlU2hlZXRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IHJvdXRlcyA9IG5ldyBNYXAoKTtcbiAgICBmdW5jdGlvbiBtYXliZUV4ZWN1dGVTY3JpcHQoc3JjKSB7XG4gICAgICAgIGxldCBwcm9tID0gbG9hZGVkU2NyaXB0cy5nZXQoc3JjKTtcbiAgICAgICAgaWYgKHByb20pIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9tO1xuICAgICAgICB9XG4gICAgICAgIC8vIFNraXAgZXhlY3V0aW5nIHNjcmlwdCBpZiBpdCdzIGFscmVhZHkgaW4gdGhlIERPTTpcbiAgICAgICAgaWYgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYHNjcmlwdFtzcmNePVwiJHtzcmN9XCJdYCkpIHtcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgfVxuICAgICAgICBsb2FkZWRTY3JpcHRzLnNldChzcmMsIHByb20gPSBhcHBlbmRTY3JpcHQoc3JjKSk7XG4gICAgICAgIHJldHVybiBwcm9tO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmZXRjaFN0eWxlU2hlZXQoaHJlZikge1xuICAgICAgICBsZXQgcHJvbSA9IHN0eWxlU2hlZXRzLmdldChocmVmKTtcbiAgICAgICAgaWYgKHByb20pIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9tO1xuICAgICAgICB9XG4gICAgICAgIHN0eWxlU2hlZXRzLnNldChocmVmLCBwcm9tID0gZmV0Y2goaHJlZikudGhlbigocmVzKT0+e1xuICAgICAgICAgICAgaWYgKCFyZXMub2spIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBsb2FkIHN0eWxlc2hlZXQ6ICR7aHJlZn1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXMudGV4dCgpLnRoZW4oKHRleHQpPT4oe1xuICAgICAgICAgICAgICAgICAgICBocmVmOiBocmVmLFxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiB0ZXh0XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0pLmNhdGNoKChlcnIpPT57XG4gICAgICAgICAgICB0aHJvdyBtYXJrQXNzZXRFcnJvcihlcnIpO1xuICAgICAgICB9KSk7XG4gICAgICAgIHJldHVybiBwcm9tO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICB3aGVuRW50cnlwb2ludCAocm91dGUpIHtcbiAgICAgICAgICAgIHJldHVybiB3aXRoRnV0dXJlKHJvdXRlLCBlbnRyeXBvaW50cyk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uRW50cnlwb2ludCAocm91dGUsIGV4ZWN1dGUpIHtcbiAgICAgICAgICAgIFByb21pc2UucmVzb2x2ZShleGVjdXRlKS50aGVuKChmbik9PmZuKClcbiAgICAgICAgICAgICkudGhlbigoZXhwb3J0cyk9Pih7XG4gICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudDogZXhwb3J0cyAmJiBleHBvcnRzLmRlZmF1bHQgfHwgZXhwb3J0cyxcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0czogZXhwb3J0c1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAsIChlcnIpPT4oe1xuICAgICAgICAgICAgICAgICAgICBlcnJvcjogZXJyXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICkudGhlbigoaW5wdXQpPT57XG4gICAgICAgICAgICAgICAgY29uc3Qgb2xkID0gZW50cnlwb2ludHMuZ2V0KHJvdXRlKTtcbiAgICAgICAgICAgICAgICBlbnRyeXBvaW50cy5zZXQocm91dGUsIGlucHV0KTtcbiAgICAgICAgICAgICAgICBpZiAob2xkICYmICdyZXNvbHZlJyBpbiBvbGQpIG9sZC5yZXNvbHZlKGlucHV0KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBsb2FkUm91dGUgKHJvdXRlLCBwcmVmZXRjaCkge1xuICAgICAgICAgICAgcmV0dXJuIHdpdGhGdXR1cmUocm91dGUsIHJvdXRlcywgKCk9PntcbiAgICAgICAgICAgICAgICBjb25zdCByb3V0ZUZpbGVzUHJvbWlzZSA9IGdldEZpbGVzRm9yUm91dGUoYXNzZXRQcmVmaXgsIHJvdXRlKS50aGVuKCh7IHNjcmlwdHMgLCBjc3MgIH0pPT57XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICAgICAgICAgICAgICBlbnRyeXBvaW50cy5oYXMocm91dGUpID8gW10gOiBQcm9taXNlLmFsbChzY3JpcHRzLm1hcChtYXliZUV4ZWN1dGVTY3JpcHQpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFByb21pc2UuYWxsKGNzcy5tYXAoZmV0Y2hTdHlsZVNoZWV0KSksIFxuICAgICAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICB9KS50aGVuKChyZXMpPT57XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndoZW5FbnRyeXBvaW50KHJvdXRlKS50aGVuKChlbnRyeXBvaW50KT0+KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeXBvaW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlczogcmVzWzFdXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50Jykge1xuICAgICAgICAgICAgICAgICAgICBkZXZCdWlsZFByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSk9PntcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyb3V0ZUZpbGVzUHJvbWlzZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByb3V0ZUZpbGVzUHJvbWlzZS5maW5hbGx5KCgpPT57XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiByZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0KHJvdXRlRmlsZXNQcm9taXNlLCBNU19NQVhfSURMRV9ERUxBWSwgbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKGBSb3V0ZSBkaWQgbm90IGNvbXBsZXRlIGxvYWRpbmc6ICR7cm91dGV9YCkpKS50aGVuKCh7IGVudHJ5cG9pbnQgLCBzdHlsZXMgIH0pPT57XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IE9iamVjdC5hc3NpZ24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGVzOiBzdHlsZXNcbiAgICAgICAgICAgICAgICAgICAgfSwgZW50cnlwb2ludCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAnZXJyb3InIGluIGVudHJ5cG9pbnQgPyBlbnRyeXBvaW50IDogcmVzO1xuICAgICAgICAgICAgICAgIH0pLmNhdGNoKChlcnIpPT57XG4gICAgICAgICAgICAgICAgICAgIGlmIChwcmVmZXRjaCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2UgZG9uJ3Qgd2FudCB0byBjYWNoZSBlcnJvcnMgZHVyaW5nIHByZWZldGNoXG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yOiBlcnJcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBwcmVmZXRjaCAocm91dGUpIHtcbiAgICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWVMYWJzL3F1aWNrbGluay9ibG9iLzQ1M2E2NjFmYTFmYTk0MGUyZDJlMDQ0NDUyMzk4ZTM4YzY3YTk4ZmIvc3JjL2luZGV4Lm1qcyNMMTE1LUwxMThcbiAgICAgICAgICAgIC8vIExpY2Vuc2U6IEFwYWNoZSAyLjBcbiAgICAgICAgICAgIGxldCBjbjtcbiAgICAgICAgICAgIGlmIChjbiA9IG5hdmlnYXRvci5jb25uZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgLy8gRG9uJ3QgcHJlZmV0Y2ggaWYgdXNpbmcgMkcgb3IgaWYgU2F2ZS1EYXRhIGlzIGVuYWJsZWQuXG4gICAgICAgICAgICAgICAgaWYgKGNuLnNhdmVEYXRhIHx8IC8yZy8udGVzdChjbi5lZmZlY3RpdmVUeXBlKSkgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGdldEZpbGVzRm9yUm91dGUoYXNzZXRQcmVmaXgsIHJvdXRlKS50aGVuKChvdXRwdXQpPT5Qcm9taXNlLmFsbChjYW5QcmVmZXRjaCA/IG91dHB1dC5zY3JpcHRzLm1hcCgoc2NyaXB0KT0+cHJlZmV0Y2hWaWFEb20oc2NyaXB0LCAnc2NyaXB0JylcbiAgICAgICAgICAgICAgICApIDogW10pXG4gICAgICAgICAgICApLnRoZW4oKCk9PntcbiAgICAgICAgICAgICAgICAoMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLnJlcXVlc3RJZGxlQ2FsbGJhY2soKCk9PnRoaXMubG9hZFJvdXRlKHJvdXRlLCB0cnVlKS5jYXRjaCgoKT0+e1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KS5jYXRjaCgvLyBzd2FsbG93IHByZWZldGNoIGVycm9yc1xuICAgICAgICAgICAgKCk9PntcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGUtbG9hZGVyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiUm91dGVyXCIsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBfcm91dGVyLmRlZmF1bHQ7XG4gICAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJ3aXRoUm91dGVyXCIsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBfd2l0aFJvdXRlci5kZWZhdWx0O1xuICAgIH1cbn0pO1xuZXhwb3J0cy51c2VSb3V0ZXIgPSB1c2VSb3V0ZXI7XG5leHBvcnRzLmNyZWF0ZVJvdXRlciA9IGNyZWF0ZVJvdXRlcjtcbmV4cG9ydHMubWFrZVB1YmxpY1JvdXRlckluc3RhbmNlID0gbWFrZVB1YmxpY1JvdXRlckluc3RhbmNlO1xuZXhwb3J0cy5kZWZhdWx0ID0gdm9pZCAwO1xudmFyIF9yZWFjdCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcInJlYWN0XCIpKTtcbnZhciBfcm91dGVyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vc2hhcmVkL2xpYi9yb3V0ZXIvcm91dGVyXCIpKTtcbnZhciBfcm91dGVyQ29udGV4dCA9IHJlcXVpcmUoXCIuLi9zaGFyZWQvbGliL3JvdXRlci1jb250ZXh0XCIpO1xudmFyIF93aXRoUm91dGVyID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi93aXRoLXJvdXRlclwiKSk7XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG5jb25zdCBzaW5nbGV0b25Sb3V0ZXIgPSB7XG4gICAgcm91dGVyOiBudWxsLFxuICAgIHJlYWR5Q2FsbGJhY2tzOiBbXSxcbiAgICByZWFkeSAoY2IpIHtcbiAgICAgICAgaWYgKHRoaXMucm91dGVyKSByZXR1cm4gY2IoKTtcbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICB0aGlzLnJlYWR5Q2FsbGJhY2tzLnB1c2goY2IpO1xuICAgICAgICB9XG4gICAgfVxufTtcbi8vIENyZWF0ZSBwdWJsaWMgcHJvcGVydGllcyBhbmQgbWV0aG9kcyBvZiB0aGUgcm91dGVyIGluIHRoZSBzaW5nbGV0b25Sb3V0ZXJcbmNvbnN0IHVybFByb3BlcnR5RmllbGRzID0gW1xuICAgICdwYXRobmFtZScsXG4gICAgJ3JvdXRlJyxcbiAgICAncXVlcnknLFxuICAgICdhc1BhdGgnLFxuICAgICdjb21wb25lbnRzJyxcbiAgICAnaXNGYWxsYmFjaycsXG4gICAgJ2Jhc2VQYXRoJyxcbiAgICAnbG9jYWxlJyxcbiAgICAnbG9jYWxlcycsXG4gICAgJ2RlZmF1bHRMb2NhbGUnLFxuICAgICdpc1JlYWR5JyxcbiAgICAnaXNQcmV2aWV3JyxcbiAgICAnaXNMb2NhbGVEb21haW4nLFxuICAgICdkb21haW5Mb2NhbGVzJywgXG5dO1xuY29uc3Qgcm91dGVyRXZlbnRzID0gW1xuICAgICdyb3V0ZUNoYW5nZVN0YXJ0JyxcbiAgICAnYmVmb3JlSGlzdG9yeUNoYW5nZScsXG4gICAgJ3JvdXRlQ2hhbmdlQ29tcGxldGUnLFxuICAgICdyb3V0ZUNoYW5nZUVycm9yJyxcbiAgICAnaGFzaENoYW5nZVN0YXJ0JyxcbiAgICAnaGFzaENoYW5nZUNvbXBsZXRlJywgXG5dO1xuY29uc3QgY29yZU1ldGhvZEZpZWxkcyA9IFtcbiAgICAncHVzaCcsXG4gICAgJ3JlcGxhY2UnLFxuICAgICdyZWxvYWQnLFxuICAgICdiYWNrJyxcbiAgICAncHJlZmV0Y2gnLFxuICAgICdiZWZvcmVQb3BTdGF0ZScsIFxuXTtcbi8vIEV2ZW50cyBpcyBhIHN0YXRpYyBwcm9wZXJ0eSBvbiB0aGUgcm91dGVyLCB0aGUgcm91dGVyIGRvZXNuJ3QgaGF2ZSB0byBiZSBpbml0aWFsaXplZCB0byB1c2UgaXRcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShzaW5nbGV0b25Sb3V0ZXIsICdldmVudHMnLCB7XG4gICAgZ2V0ICgpIHtcbiAgICAgICAgcmV0dXJuIF9yb3V0ZXIuZGVmYXVsdC5ldmVudHM7XG4gICAgfVxufSk7XG51cmxQcm9wZXJ0eUZpZWxkcy5mb3JFYWNoKChmaWVsZCk9PntcbiAgICAvLyBIZXJlIHdlIG5lZWQgdG8gdXNlIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSBiZWNhdXNlIHdlIG5lZWQgdG8gcmV0dXJuXG4gICAgLy8gdGhlIHByb3BlcnR5IGFzc2lnbmVkIHRvIHRoZSBhY3R1YWwgcm91dGVyXG4gICAgLy8gVGhlIHZhbHVlIG1pZ2h0IGdldCBjaGFuZ2VkIGFzIHdlIGNoYW5nZSByb3V0ZXMgYW5kIHRoaXMgaXMgdGhlXG4gICAgLy8gcHJvcGVyIHdheSB0byBhY2Nlc3MgaXRcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoc2luZ2xldG9uUm91dGVyLCBmaWVsZCwge1xuICAgICAgICBnZXQgKCkge1xuICAgICAgICAgICAgY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCk7XG4gICAgICAgICAgICByZXR1cm4gcm91dGVyW2ZpZWxkXTtcbiAgICAgICAgfVxuICAgIH0pO1xufSk7XG5jb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKT0+e1xuICAgIHNpbmdsZXRvblJvdXRlcltmaWVsZF0gPSAoLi4uYXJncyk9PntcbiAgICAgICAgY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCk7XG4gICAgICAgIHJldHVybiByb3V0ZXJbZmllbGRdKC4uLmFyZ3MpO1xuICAgIH07XG59KTtcbnJvdXRlckV2ZW50cy5mb3JFYWNoKChldmVudCk9PntcbiAgICBzaW5nbGV0b25Sb3V0ZXIucmVhZHkoKCk9PntcbiAgICAgICAgX3JvdXRlci5kZWZhdWx0LmV2ZW50cy5vbihldmVudCwgKC4uLmFyZ3MpPT57XG4gICAgICAgICAgICBjb25zdCBldmVudEZpZWxkID0gYG9uJHtldmVudC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKX0ke2V2ZW50LnN1YnN0cmluZygxKX1gO1xuICAgICAgICAgICAgY29uc3QgX3NpbmdsZXRvblJvdXRlciA9IHNpbmdsZXRvblJvdXRlcjtcbiAgICAgICAgICAgIGlmIChfc2luZ2xldG9uUm91dGVyW2V2ZW50RmllbGRdKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgX3NpbmdsZXRvblJvdXRlcltldmVudEZpZWxkXSguLi5hcmdzKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3Igd2hlbiBydW5uaW5nIHRoZSBSb3V0ZXIgZXZlbnQ6ICR7ZXZlbnRGaWVsZH1gKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgJHtlcnIubWVzc2FnZX1cXG4ke2Vyci5zdGFja31gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufSk7XG5mdW5jdGlvbiBnZXRSb3V0ZXIoKSB7XG4gICAgaWYgKCFzaW5nbGV0b25Sb3V0ZXIucm91dGVyKSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSAnTm8gcm91dGVyIGluc3RhbmNlIGZvdW5kLlxcbicgKyAnWW91IHNob3VsZCBvbmx5IHVzZSBcIm5leHQvcm91dGVyXCIgb24gdGhlIGNsaWVudCBzaWRlIG9mIHlvdXIgYXBwLlxcbic7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgICB9XG4gICAgcmV0dXJuIHNpbmdsZXRvblJvdXRlci5yb3V0ZXI7XG59XG52YXIgX2RlZmF1bHQgPSBzaW5nbGV0b25Sb3V0ZXI7XG5leHBvcnRzLmRlZmF1bHQgPSBfZGVmYXVsdDtcbmZ1bmN0aW9uIHVzZVJvdXRlcigpIHtcbiAgICByZXR1cm4gX3JlYWN0LmRlZmF1bHQudXNlQ29udGV4dChfcm91dGVyQ29udGV4dC5Sb3V0ZXJDb250ZXh0KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlciguLi5hcmdzKSB7XG4gICAgc2luZ2xldG9uUm91dGVyLnJvdXRlciA9IG5ldyBfcm91dGVyLmRlZmF1bHQoLi4uYXJncyk7XG4gICAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzLmZvckVhY2goKGNiKT0+Y2IoKVxuICAgICk7XG4gICAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzID0gW107XG4gICAgcmV0dXJuIHNpbmdsZXRvblJvdXRlci5yb3V0ZXI7XG59XG5mdW5jdGlvbiBtYWtlUHVibGljUm91dGVySW5zdGFuY2Uocm91dGVyKSB7XG4gICAgY29uc3QgX3JvdXRlcjEgPSByb3V0ZXI7XG4gICAgY29uc3QgaW5zdGFuY2UgPSB7XG4gICAgfTtcbiAgICBmb3IgKGNvbnN0IHByb3BlcnR5IG9mIHVybFByb3BlcnR5RmllbGRzKXtcbiAgICAgICAgaWYgKHR5cGVvZiBfcm91dGVyMVtwcm9wZXJ0eV0gPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICBpbnN0YW5jZVtwcm9wZXJ0eV0gPSBPYmplY3QuYXNzaWduKEFycmF5LmlzQXJyYXkoX3JvdXRlcjFbcHJvcGVydHldKSA/IFtdIDoge1xuICAgICAgICAgICAgfSwgX3JvdXRlcjFbcHJvcGVydHldKSAvLyBtYWtlcyBzdXJlIHF1ZXJ5IGlzIG5vdCBzdGF0ZWZ1bFxuICAgICAgICAgICAgO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaW5zdGFuY2VbcHJvcGVydHldID0gX3JvdXRlcjFbcHJvcGVydHldO1xuICAgIH1cbiAgICAvLyBFdmVudHMgaXMgYSBzdGF0aWMgcHJvcGVydHkgb24gdGhlIHJvdXRlciwgdGhlIHJvdXRlciBkb2Vzbid0IGhhdmUgdG8gYmUgaW5pdGlhbGl6ZWQgdG8gdXNlIGl0XG4gICAgaW5zdGFuY2UuZXZlbnRzID0gX3JvdXRlci5kZWZhdWx0LmV2ZW50cztcbiAgICBjb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKT0+e1xuICAgICAgICBpbnN0YW5jZVtmaWVsZF0gPSAoLi4uYXJncyk9PntcbiAgICAgICAgICAgIHJldHVybiBfcm91dGVyMVtmaWVsZF0oLi4uYXJncyk7XG4gICAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIGluc3RhbmNlO1xufVxuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLnVzZUludGVyc2VjdGlvbiA9IHVzZUludGVyc2VjdGlvbjtcbnZhciBfcmVhY3QgPSByZXF1aXJlKFwicmVhY3RcIik7XG52YXIgX3JlcXVlc3RJZGxlQ2FsbGJhY2sgPSByZXF1aXJlKFwiLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2tcIik7XG5jb25zdCBoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciA9IHR5cGVvZiBJbnRlcnNlY3Rpb25PYnNlcnZlciAhPT0gJ3VuZGVmaW5lZCc7XG5mdW5jdGlvbiB1c2VJbnRlcnNlY3Rpb24oeyByb290TWFyZ2luICwgZGlzYWJsZWQgIH0pIHtcbiAgICBjb25zdCBpc0Rpc2FibGVkID0gZGlzYWJsZWQgfHwgIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyO1xuICAgIGNvbnN0IHVub2JzZXJ2ZSA9ICgwLCBfcmVhY3QpLnVzZVJlZigpO1xuICAgIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9ICgwLCBfcmVhY3QpLnVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBzZXRSZWYgPSAoMCwgX3JlYWN0KS51c2VDYWxsYmFjaygoZWwpPT57XG4gICAgICAgIGlmICh1bm9ic2VydmUuY3VycmVudCkge1xuICAgICAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQoKTtcbiAgICAgICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0Rpc2FibGVkIHx8IHZpc2libGUpIHJldHVybjtcbiAgICAgICAgaWYgKGVsICYmIGVsLnRhZ05hbWUpIHtcbiAgICAgICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gb2JzZXJ2ZShlbCwgKGlzVmlzaWJsZSk9PmlzVmlzaWJsZSAmJiBzZXRWaXNpYmxlKGlzVmlzaWJsZSlcbiAgICAgICAgICAgICwge1xuICAgICAgICAgICAgICAgIHJvb3RNYXJnaW5cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSwgW1xuICAgICAgICBpc0Rpc2FibGVkLFxuICAgICAgICByb290TWFyZ2luLFxuICAgICAgICB2aXNpYmxlXG4gICAgXSk7XG4gICAgKDAsIF9yZWFjdCkudXNlRWZmZWN0KCgpPT57XG4gICAgICAgIGlmICghaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIpIHtcbiAgICAgICAgICAgIGlmICghdmlzaWJsZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkbGVDYWxsYmFjayA9ICgwLCBfcmVxdWVzdElkbGVDYWxsYmFjaykucmVxdWVzdElkbGVDYWxsYmFjaygoKT0+c2V0VmlzaWJsZSh0cnVlKVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgcmV0dXJuICgpPT4oMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLmNhbmNlbElkbGVDYWxsYmFjayhpZGxlQ2FsbGJhY2spXG4gICAgICAgICAgICAgICAgO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW1xuICAgICAgICB2aXNpYmxlXG4gICAgXSk7XG4gICAgcmV0dXJuIFtcbiAgICAgICAgc2V0UmVmLFxuICAgICAgICB2aXNpYmxlXG4gICAgXTtcbn1cbmZ1bmN0aW9uIG9ic2VydmUoZWxlbWVudCwgY2FsbGJhY2ssIG9wdGlvbnMpIHtcbiAgICBjb25zdCB7IGlkICwgb2JzZXJ2ZXIgLCBlbGVtZW50cyAgfSA9IGNyZWF0ZU9ic2VydmVyKG9wdGlvbnMpO1xuICAgIGVsZW1lbnRzLnNldChlbGVtZW50LCBjYWxsYmFjayk7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KTtcbiAgICByZXR1cm4gZnVuY3Rpb24gdW5vYnNlcnZlKCkge1xuICAgICAgICBlbGVtZW50cy5kZWxldGUoZWxlbWVudCk7XG4gICAgICAgIG9ic2VydmVyLnVub2JzZXJ2ZShlbGVtZW50KTtcbiAgICAgICAgLy8gRGVzdHJveSBvYnNlcnZlciB3aGVuIHRoZXJlJ3Mgbm90aGluZyBsZWZ0IHRvIHdhdGNoOlxuICAgICAgICBpZiAoZWxlbWVudHMuc2l6ZSA9PT0gMCkge1xuICAgICAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICAgICAgb2JzZXJ2ZXJzLmRlbGV0ZShpZCk7XG4gICAgICAgIH1cbiAgICB9O1xufVxuY29uc3Qgb2JzZXJ2ZXJzID0gbmV3IE1hcCgpO1xuZnVuY3Rpb24gY3JlYXRlT2JzZXJ2ZXIob3B0aW9ucykge1xuICAgIGNvbnN0IGlkID0gb3B0aW9ucy5yb290TWFyZ2luIHx8ICcnO1xuICAgIGxldCBpbnN0YW5jZSA9IG9ic2VydmVycy5nZXQoaWQpO1xuICAgIGlmIChpbnN0YW5jZSkge1xuICAgICAgICByZXR1cm4gaW5zdGFuY2U7XG4gICAgfVxuICAgIGNvbnN0IGVsZW1lbnRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKChlbnRyaWVzKT0+e1xuICAgICAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5KT0+e1xuICAgICAgICAgICAgY29uc3QgY2FsbGJhY2sgPSBlbGVtZW50cy5nZXQoZW50cnkudGFyZ2V0KTtcbiAgICAgICAgICAgIGNvbnN0IGlzVmlzaWJsZSA9IGVudHJ5LmlzSW50ZXJzZWN0aW5nIHx8IGVudHJ5LmludGVyc2VjdGlvblJhdGlvID4gMDtcbiAgICAgICAgICAgIGlmIChjYWxsYmFjayAmJiBpc1Zpc2libGUpIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayhpc1Zpc2libGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LCBvcHRpb25zKTtcbiAgICBvYnNlcnZlcnMuc2V0KGlkLCBpbnN0YW5jZSA9IHtcbiAgICAgICAgaWQsXG4gICAgICAgIG9ic2VydmVyLFxuICAgICAgICBlbGVtZW50c1xuICAgIH0pO1xuICAgIHJldHVybiBpbnN0YW5jZTtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlLWludGVyc2VjdGlvbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMuZGVmYXVsdCA9IHdpdGhSb3V0ZXI7XG52YXIgX3JlYWN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3RcIikpO1xudmFyIF9yb3V0ZXIgPSByZXF1aXJlKFwiLi9yb3V0ZXJcIik7XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG5mdW5jdGlvbiB3aXRoUm91dGVyKENvbXBvc2VkQ29tcG9uZW50KSB7XG4gICAgZnVuY3Rpb24gV2l0aFJvdXRlcldyYXBwZXIocHJvcHMpIHtcbiAgICAgICAgcmV0dXJuKC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChDb21wb3NlZENvbXBvbmVudCwgT2JqZWN0LmFzc2lnbih7XG4gICAgICAgICAgICByb3V0ZXI6ICgwLCBfcm91dGVyKS51c2VSb3V0ZXIoKVxuICAgICAgICB9LCBwcm9wcykpKTtcbiAgICB9XG4gICAgV2l0aFJvdXRlcldyYXBwZXIuZ2V0SW5pdGlhbFByb3BzID0gQ29tcG9zZWRDb21wb25lbnQuZ2V0SW5pdGlhbFByb3BzO1xuICAgIFdpdGhSb3V0ZXJXcmFwcGVyLm9yaWdHZXRJbml0aWFsUHJvcHMgPSBDb21wb3NlZENvbXBvbmVudC5vcmlnR2V0SW5pdGlhbFByb3BzO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSBDb21wb3NlZENvbXBvbmVudC5kaXNwbGF5TmFtZSB8fCBDb21wb3NlZENvbXBvbmVudC5uYW1lIHx8ICdVbmtub3duJztcbiAgICAgICAgV2l0aFJvdXRlcldyYXBwZXIuZGlzcGxheU5hbWUgPSBgd2l0aFJvdXRlcigke25hbWV9KWA7XG4gICAgfVxuICAgIHJldHVybiBXaXRoUm91dGVyV3JhcHBlcjtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9d2l0aC1yb3V0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLmdldERvbWFpbkxvY2FsZSA9IGdldERvbWFpbkxvY2FsZTtcbmV4cG9ydHMuYWRkTG9jYWxlID0gYWRkTG9jYWxlO1xuZXhwb3J0cy5kZWxMb2NhbGUgPSBkZWxMb2NhbGU7XG5leHBvcnRzLmhhc0Jhc2VQYXRoID0gaGFzQmFzZVBhdGg7XG5leHBvcnRzLmFkZEJhc2VQYXRoID0gYWRkQmFzZVBhdGg7XG5leHBvcnRzLmRlbEJhc2VQYXRoID0gZGVsQmFzZVBhdGg7XG5leHBvcnRzLmlzTG9jYWxVUkwgPSBpc0xvY2FsVVJMO1xuZXhwb3J0cy5pbnRlcnBvbGF0ZUFzID0gaW50ZXJwb2xhdGVBcztcbmV4cG9ydHMucmVzb2x2ZUhyZWYgPSByZXNvbHZlSHJlZjtcbmV4cG9ydHMuZGVmYXVsdCA9IHZvaWQgMDtcbnZhciBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCA9IHJlcXVpcmUoXCIuLi8uLi8uLi9jbGllbnQvbm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoXCIpO1xudmFyIF9yb3V0ZUxvYWRlciA9IHJlcXVpcmUoXCIuLi8uLi8uLi9jbGllbnQvcm91dGUtbG9hZGVyXCIpO1xudmFyIF9kZW5vcm1hbGl6ZVBhZ2VQYXRoID0gcmVxdWlyZShcIi4uLy4uLy4uL3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGhcIik7XG52YXIgX25vcm1hbGl6ZUxvY2FsZVBhdGggPSByZXF1aXJlKFwiLi4vaTE4bi9ub3JtYWxpemUtbG9jYWxlLXBhdGhcIik7XG52YXIgX21pdHQgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuLi9taXR0XCIpKTtcbnZhciBfdXRpbHMgPSByZXF1aXJlKFwiLi4vdXRpbHNcIik7XG52YXIgX2lzRHluYW1pYyA9IHJlcXVpcmUoXCIuL3V0aWxzL2lzLWR5bmFtaWNcIik7XG52YXIgX3BhcnNlUmVsYXRpdmVVcmwgPSByZXF1aXJlKFwiLi91dGlscy9wYXJzZS1yZWxhdGl2ZS11cmxcIik7XG52YXIgX3F1ZXJ5c3RyaW5nID0gcmVxdWlyZShcIi4vdXRpbHMvcXVlcnlzdHJpbmdcIik7XG52YXIgX3Jlc29sdmVSZXdyaXRlcyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vdXRpbHMvcmVzb2x2ZS1yZXdyaXRlc1wiKSk7XG52YXIgX3JvdXRlTWF0Y2hlciA9IHJlcXVpcmUoXCIuL3V0aWxzL3JvdXRlLW1hdGNoZXJcIik7XG52YXIgX3JvdXRlUmVnZXggPSByZXF1aXJlKFwiLi91dGlscy9yb3V0ZS1yZWdleFwiKTtcbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmxldCBkZXRlY3REb21haW5Mb2NhbGU7XG5pZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgIGRldGVjdERvbWFpbkxvY2FsZSA9IHJlcXVpcmUoJy4uL2kxOG4vZGV0ZWN0LWRvbWFpbi1sb2NhbGUnKS5kZXRlY3REb21haW5Mb2NhbGU7XG59XG5jb25zdCBiYXNlUGF0aCA9IHByb2Nlc3MuZW52Ll9fTkVYVF9ST1VURVJfQkFTRVBBVEggfHwgJyc7XG5mdW5jdGlvbiBidWlsZENhbmNlbGxhdGlvbkVycm9yKCkge1xuICAgIHJldHVybiBPYmplY3QuYXNzaWduKG5ldyBFcnJvcignUm91dGUgQ2FuY2VsbGVkJyksIHtcbiAgICAgICAgY2FuY2VsbGVkOiB0cnVlXG4gICAgfSk7XG59XG5mdW5jdGlvbiBhZGRQYXRoUHJlZml4KHBhdGgsIHByZWZpeCkge1xuICAgIHJldHVybiBwcmVmaXggJiYgcGF0aC5zdGFydHNXaXRoKCcvJykgPyBwYXRoID09PSAnLycgPyAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKHByZWZpeCkgOiBgJHtwcmVmaXh9JHtwYXRoTm9RdWVyeUhhc2gocGF0aCkgPT09ICcvJyA/IHBhdGguc3Vic3RyaW5nKDEpIDogcGF0aH1gIDogcGF0aDtcbn1cbmZ1bmN0aW9uIGdldERvbWFpbkxvY2FsZShwYXRoLCBsb2NhbGUsIGxvY2FsZXMsIGRvbWFpbkxvY2FsZXMpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICBsb2NhbGUgPSBsb2NhbGUgfHwgKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhdGgsIGxvY2FsZXMpLmRldGVjdGVkTG9jYWxlO1xuICAgICAgICBjb25zdCBkZXRlY3RlZERvbWFpbiA9IGRldGVjdERvbWFpbkxvY2FsZShkb21haW5Mb2NhbGVzLCB1bmRlZmluZWQsIGxvY2FsZSk7XG4gICAgICAgIGlmIChkZXRlY3RlZERvbWFpbikge1xuICAgICAgICAgICAgcmV0dXJuIGBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwID8gJycgOiAncyd9Oi8vJHtkZXRlY3RlZERvbWFpbi5kb21haW59JHtiYXNlUGF0aCB8fCAnJ30ke2xvY2FsZSA9PT0gZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZSA/ICcnIDogYC8ke2xvY2FsZX1gfSR7cGF0aH1gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuZnVuY3Rpb24gYWRkTG9jYWxlKHBhdGgsIGxvY2FsZSwgZGVmYXVsdExvY2FsZSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgIGNvbnN0IHBhdGhuYW1lID0gcGF0aE5vUXVlcnlIYXNoKHBhdGgpO1xuICAgICAgICBjb25zdCBwYXRoTG93ZXIgPSBwYXRobmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBjb25zdCBsb2NhbGVMb3dlciA9IGxvY2FsZSAmJiBsb2NhbGUudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgcmV0dXJuIGxvY2FsZSAmJiBsb2NhbGUgIT09IGRlZmF1bHRMb2NhbGUgJiYgIXBhdGhMb3dlci5zdGFydHNXaXRoKCcvJyArIGxvY2FsZUxvd2VyICsgJy8nKSAmJiBwYXRoTG93ZXIgIT09ICcvJyArIGxvY2FsZUxvd2VyID8gYWRkUGF0aFByZWZpeChwYXRoLCAnLycgKyBsb2NhbGUpIDogcGF0aDtcbiAgICB9XG4gICAgcmV0dXJuIHBhdGg7XG59XG5mdW5jdGlvbiBkZWxMb2NhbGUocGF0aCwgbG9jYWxlKSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgICAgY29uc3QgcGF0aG5hbWUgPSBwYXRoTm9RdWVyeUhhc2gocGF0aCk7XG4gICAgICAgIGNvbnN0IHBhdGhMb3dlciA9IHBhdGhuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGNvbnN0IGxvY2FsZUxvd2VyID0gbG9jYWxlICYmIGxvY2FsZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gbG9jYWxlICYmIChwYXRoTG93ZXIuc3RhcnRzV2l0aCgnLycgKyBsb2NhbGVMb3dlciArICcvJykgfHwgcGF0aExvd2VyID09PSAnLycgKyBsb2NhbGVMb3dlcikgPyAocGF0aG5hbWUubGVuZ3RoID09PSBsb2NhbGUubGVuZ3RoICsgMSA/ICcvJyA6ICcnKSArIHBhdGguc3Vic3RyKGxvY2FsZS5sZW5ndGggKyAxKSA6IHBhdGg7XG4gICAgfVxuICAgIHJldHVybiBwYXRoO1xufVxuZnVuY3Rpb24gcGF0aE5vUXVlcnlIYXNoKHBhdGgpIHtcbiAgICBjb25zdCBxdWVyeUluZGV4ID0gcGF0aC5pbmRleE9mKCc/Jyk7XG4gICAgY29uc3QgaGFzaEluZGV4ID0gcGF0aC5pbmRleE9mKCcjJyk7XG4gICAgaWYgKHF1ZXJ5SW5kZXggPiAtMSB8fCBoYXNoSW5kZXggPiAtMSkge1xuICAgICAgICBwYXRoID0gcGF0aC5zdWJzdHJpbmcoMCwgcXVlcnlJbmRleCA+IC0xID8gcXVlcnlJbmRleCA6IGhhc2hJbmRleCk7XG4gICAgfVxuICAgIHJldHVybiBwYXRoO1xufVxuZnVuY3Rpb24gaGFzQmFzZVBhdGgocGF0aCkge1xuICAgIHBhdGggPSBwYXRoTm9RdWVyeUhhc2gocGF0aCk7XG4gICAgcmV0dXJuIHBhdGggPT09IGJhc2VQYXRoIHx8IHBhdGguc3RhcnRzV2l0aChiYXNlUGF0aCArICcvJyk7XG59XG5mdW5jdGlvbiBhZGRCYXNlUGF0aChwYXRoKSB7XG4gICAgLy8gd2Ugb25seSBhZGQgdGhlIGJhc2VwYXRoIG9uIHJlbGF0aXZlIHVybHNcbiAgICByZXR1cm4gYWRkUGF0aFByZWZpeChwYXRoLCBiYXNlUGF0aCk7XG59XG5mdW5jdGlvbiBkZWxCYXNlUGF0aChwYXRoKSB7XG4gICAgcGF0aCA9IHBhdGguc2xpY2UoYmFzZVBhdGgubGVuZ3RoKTtcbiAgICBpZiAoIXBhdGguc3RhcnRzV2l0aCgnLycpKSBwYXRoID0gYC8ke3BhdGh9YDtcbiAgICByZXR1cm4gcGF0aDtcbn1cbmZ1bmN0aW9uIGlzTG9jYWxVUkwodXJsKSB7XG4gICAgLy8gcHJldmVudCBhIGh5ZHJhdGlvbiBtaXNtYXRjaCBvbiBocmVmIGZvciB1cmwgd2l0aCBhbmNob3IgcmVmc1xuICAgIGlmICh1cmwuc3RhcnRzV2l0aCgnLycpIHx8IHVybC5zdGFydHNXaXRoKCcjJykgfHwgdXJsLnN0YXJ0c1dpdGgoJz8nKSkgcmV0dXJuIHRydWU7XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gYWJzb2x1dGUgdXJscyBjYW4gYmUgbG9jYWwgaWYgdGhleSBhcmUgb24gdGhlIHNhbWUgb3JpZ2luXG4gICAgICAgIGNvbnN0IGxvY2F0aW9uT3JpZ2luID0gKDAsIF91dGlscykuZ2V0TG9jYXRpb25PcmlnaW4oKTtcbiAgICAgICAgY29uc3QgcmVzb2x2ZWQgPSBuZXcgVVJMKHVybCwgbG9jYXRpb25PcmlnaW4pO1xuICAgICAgICByZXR1cm4gcmVzb2x2ZWQub3JpZ2luID09PSBsb2NhdGlvbk9yaWdpbiAmJiBoYXNCYXNlUGF0aChyZXNvbHZlZC5wYXRobmFtZSk7XG4gICAgfSBjYXRjaCAoXykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuZnVuY3Rpb24gaW50ZXJwb2xhdGVBcyhyb3V0ZSwgYXNQYXRobmFtZSwgcXVlcnkpIHtcbiAgICBsZXQgaW50ZXJwb2xhdGVkUm91dGUgPSAnJztcbiAgICBjb25zdCBkeW5hbWljUmVnZXggPSAoMCwgX3JvdXRlUmVnZXgpLmdldFJvdXRlUmVnZXgocm91dGUpO1xuICAgIGNvbnN0IGR5bmFtaWNHcm91cHMgPSBkeW5hbWljUmVnZXguZ3JvdXBzO1xuICAgIGNvbnN0IGR5bmFtaWNNYXRjaGVzID0gLy8gVHJ5IHRvIG1hdGNoIHRoZSBkeW5hbWljIHJvdXRlIGFnYWluc3QgdGhlIGFzUGF0aFxuICAgIChhc1BhdGhuYW1lICE9PSByb3V0ZSA/ICgwLCBfcm91dGVNYXRjaGVyKS5nZXRSb3V0ZU1hdGNoZXIoZHluYW1pY1JlZ2V4KShhc1BhdGhuYW1lKSA6ICcnKSB8fCAvLyBGYWxsIGJhY2sgdG8gcmVhZGluZyB0aGUgdmFsdWVzIGZyb20gdGhlIGhyZWZcbiAgICAvLyBUT0RPOiBzaG91bGQgdGhpcyB0YWtlIHByaW9yaXR5OyBhbHNvIG5lZWQgdG8gY2hhbmdlIGluIHRoZSByb3V0ZXIuXG4gICAgcXVlcnk7XG4gICAgaW50ZXJwb2xhdGVkUm91dGUgPSByb3V0ZTtcbiAgICBjb25zdCBwYXJhbXMgPSBPYmplY3Qua2V5cyhkeW5hbWljR3JvdXBzKTtcbiAgICBpZiAoIXBhcmFtcy5ldmVyeSgocGFyYW0pPT57XG4gICAgICAgIGxldCB2YWx1ZSA9IGR5bmFtaWNNYXRjaGVzW3BhcmFtXSB8fCAnJztcbiAgICAgICAgY29uc3QgeyByZXBlYXQgLCBvcHRpb25hbCAgfSA9IGR5bmFtaWNHcm91cHNbcGFyYW1dO1xuICAgICAgICAvLyBzdXBwb3J0IHNpbmdsZS1sZXZlbCBjYXRjaC1hbGxcbiAgICAgICAgLy8gVE9ETzogbW9yZSByb2J1c3QgaGFuZGxpbmcgZm9yIHVzZXItZXJyb3IgKHBhc3NpbmcgYC9gKVxuICAgICAgICBsZXQgcmVwbGFjZWQgPSBgWyR7cmVwZWF0ID8gJy4uLicgOiAnJ30ke3BhcmFtfV1gO1xuICAgICAgICBpZiAob3B0aW9uYWwpIHtcbiAgICAgICAgICAgIHJlcGxhY2VkID0gYCR7IXZhbHVlID8gJy8nIDogJyd9WyR7cmVwbGFjZWR9XWA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlcGVhdCAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHZhbHVlID0gW1xuICAgICAgICAgICAgdmFsdWVcbiAgICAgICAgXTtcbiAgICAgICAgcmV0dXJuIChvcHRpb25hbCB8fCBwYXJhbSBpbiBkeW5hbWljTWF0Y2hlcykgJiYgLy8gSW50ZXJwb2xhdGUgZ3JvdXAgaW50byBkYXRhIFVSTCBpZiBwcmVzZW50XG4gICAgICAgIChpbnRlcnBvbGF0ZWRSb3V0ZSA9IGludGVycG9sYXRlZFJvdXRlLnJlcGxhY2UocmVwbGFjZWQsIHJlcGVhdCA/IHZhbHVlLm1hcCgvLyB0aGVzZSB2YWx1ZXMgc2hvdWxkIGJlIGZ1bGx5IGVuY29kZWQgaW5zdGVhZCBvZiBqdXN0XG4gICAgICAgIC8vIHBhdGggZGVsaW1pdGVyIGVzY2FwZWQgc2luY2UgdGhleSBhcmUgYmVpbmcgaW5zZXJ0ZWRcbiAgICAgICAgLy8gaW50byB0aGUgVVJMIGFuZCB3ZSBleHBlY3QgVVJMIGVuY29kZWQgc2VnbWVudHNcbiAgICAgICAgLy8gd2hlbiBwYXJzaW5nIGR5bmFtaWMgcm91dGUgcGFyYW1zXG4gICAgICAgIChzZWdtZW50KT0+ZW5jb2RlVVJJQ29tcG9uZW50KHNlZ21lbnQpXG4gICAgICAgICkuam9pbignLycpIDogZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKSkgfHwgJy8nKTtcbiAgICB9KSkge1xuICAgICAgICBpbnRlcnBvbGF0ZWRSb3V0ZSA9ICcnIC8vIGRpZCBub3Qgc2F0aXNmeSBhbGwgcmVxdWlyZW1lbnRzXG4gICAgICAgIDtcbiAgICAvLyBuLmIuIFdlIGlnbm9yZSB0aGlzIGVycm9yIGJlY2F1c2Ugd2UgaGFuZGxlIHdhcm5pbmcgZm9yIHRoaXMgY2FzZSBpblxuICAgIC8vIGRldmVsb3BtZW50IGluIHRoZSBgPExpbms+YCBjb21wb25lbnQgZGlyZWN0bHkuXG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHBhcmFtcyxcbiAgICAgICAgcmVzdWx0OiBpbnRlcnBvbGF0ZWRSb3V0ZVxuICAgIH07XG59XG5mdW5jdGlvbiBvbWl0UGFybXNGcm9tUXVlcnkocXVlcnksIHBhcmFtcykge1xuICAgIGNvbnN0IGZpbHRlcmVkUXVlcnkgPSB7XG4gICAgfTtcbiAgICBPYmplY3Qua2V5cyhxdWVyeSkuZm9yRWFjaCgoa2V5KT0+e1xuICAgICAgICBpZiAoIXBhcmFtcy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgICAgICBmaWx0ZXJlZFF1ZXJ5W2tleV0gPSBxdWVyeVtrZXldO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGZpbHRlcmVkUXVlcnk7XG59XG5mdW5jdGlvbiByZXNvbHZlSHJlZihyb3V0ZXIsIGhyZWYsIHJlc29sdmVBcykge1xuICAgIC8vIHdlIHVzZSBhIGR1bW15IGJhc2UgdXJsIGZvciByZWxhdGl2ZSB1cmxzXG4gICAgbGV0IGJhc2U7XG4gICAgbGV0IHVybEFzU3RyaW5nID0gdHlwZW9mIGhyZWYgPT09ICdzdHJpbmcnID8gaHJlZiA6ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKGhyZWYpO1xuICAgIC8vIHJlcGVhdGVkIHNsYXNoZXMgYW5kIGJhY2tzbGFzaGVzIGluIHRoZSBVUkwgYXJlIGNvbnNpZGVyZWRcbiAgICAvLyBpbnZhbGlkIGFuZCB3aWxsIG5ldmVyIG1hdGNoIGEgTmV4dC5qcyBwYWdlL2ZpbGVcbiAgICBjb25zdCB1cmxQcm90b01hdGNoID0gdXJsQXNTdHJpbmcubWF0Y2goL15bYS16QS1aXXsxLH06XFwvXFwvLyk7XG4gICAgY29uc3QgdXJsQXNTdHJpbmdOb1Byb3RvID0gdXJsUHJvdG9NYXRjaCA/IHVybEFzU3RyaW5nLnN1YnN0cih1cmxQcm90b01hdGNoWzBdLmxlbmd0aCkgOiB1cmxBc1N0cmluZztcbiAgICBjb25zdCB1cmxQYXJ0cyA9IHVybEFzU3RyaW5nTm9Qcm90by5zcGxpdCgnPycpO1xuICAgIGlmICgodXJsUGFydHNbMF0gfHwgJycpLm1hdGNoKC8oXFwvXFwvfFxcXFwpLykpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgSW52YWxpZCBocmVmIHBhc3NlZCB0byBuZXh0L3JvdXRlcjogJHt1cmxBc1N0cmluZ30sIHJlcGVhdGVkIGZvcndhcmQtc2xhc2hlcyAoLy8pIG9yIGJhY2tzbGFzaGVzIFxcXFwgYXJlIG5vdCB2YWxpZCBpbiB0aGUgaHJlZmApO1xuICAgICAgICBjb25zdCBub3JtYWxpemVkVXJsID0gKDAsIF91dGlscykubm9ybWFsaXplUmVwZWF0ZWRTbGFzaGVzKHVybEFzU3RyaW5nTm9Qcm90byk7XG4gICAgICAgIHVybEFzU3RyaW5nID0gKHVybFByb3RvTWF0Y2ggPyB1cmxQcm90b01hdGNoWzBdIDogJycpICsgbm9ybWFsaXplZFVybDtcbiAgICB9XG4gICAgLy8gUmV0dXJuIGJlY2F1c2UgaXQgY2Fubm90IGJlIHJvdXRlZCBieSB0aGUgTmV4dC5qcyByb3V0ZXJcbiAgICBpZiAoIWlzTG9jYWxVUkwodXJsQXNTdHJpbmcpKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlQXMgPyBbXG4gICAgICAgICAgICB1cmxBc1N0cmluZ1xuICAgICAgICBdIDogdXJsQXNTdHJpbmc7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIGJhc2UgPSBuZXcgVVJMKHVybEFzU3RyaW5nLnN0YXJ0c1dpdGgoJyMnKSA/IHJvdXRlci5hc1BhdGggOiByb3V0ZXIucGF0aG5hbWUsICdodHRwOi8vbicpO1xuICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgICAgLy8gZmFsbGJhY2sgdG8gLyBmb3IgaW52YWxpZCBhc1BhdGggdmFsdWVzIGUuZy4gLy9cbiAgICAgICAgYmFzZSA9IG5ldyBVUkwoJy8nLCAnaHR0cDovL24nKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZmluYWxVcmwgPSBuZXcgVVJMKHVybEFzU3RyaW5nLCBiYXNlKTtcbiAgICAgICAgZmluYWxVcmwucGF0aG5hbWUgPSAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKGZpbmFsVXJsLnBhdGhuYW1lKTtcbiAgICAgICAgbGV0IGludGVycG9sYXRlZEFzID0gJyc7XG4gICAgICAgIGlmICgoMCwgX2lzRHluYW1pYykuaXNEeW5hbWljUm91dGUoZmluYWxVcmwucGF0aG5hbWUpICYmIGZpbmFsVXJsLnNlYXJjaFBhcmFtcyAmJiByZXNvbHZlQXMpIHtcbiAgICAgICAgICAgIGNvbnN0IHF1ZXJ5ID0gKDAsIF9xdWVyeXN0cmluZykuc2VhcmNoUGFyYW1zVG9VcmxRdWVyeShmaW5hbFVybC5zZWFyY2hQYXJhbXMpO1xuICAgICAgICAgICAgY29uc3QgeyByZXN1bHQgLCBwYXJhbXMgIH0gPSBpbnRlcnBvbGF0ZUFzKGZpbmFsVXJsLnBhdGhuYW1lLCBmaW5hbFVybC5wYXRobmFtZSwgcXVlcnkpO1xuICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgIGludGVycG9sYXRlZEFzID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogcmVzdWx0LFxuICAgICAgICAgICAgICAgICAgICBoYXNoOiBmaW5hbFVybC5oYXNoLFxuICAgICAgICAgICAgICAgICAgICBxdWVyeTogb21pdFBhcm1zRnJvbVF1ZXJ5KHF1ZXJ5LCBwYXJhbXMpXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gaWYgdGhlIG9yaWdpbiBkaWRuJ3QgY2hhbmdlLCBpdCBtZWFucyB3ZSByZWNlaXZlZCBhIHJlbGF0aXZlIGhyZWZcbiAgICAgICAgY29uc3QgcmVzb2x2ZWRIcmVmID0gZmluYWxVcmwub3JpZ2luID09PSBiYXNlLm9yaWdpbiA/IGZpbmFsVXJsLmhyZWYuc2xpY2UoZmluYWxVcmwub3JpZ2luLmxlbmd0aCkgOiBmaW5hbFVybC5ocmVmO1xuICAgICAgICByZXR1cm4gcmVzb2x2ZUFzID8gW1xuICAgICAgICAgICAgcmVzb2x2ZWRIcmVmLFxuICAgICAgICAgICAgaW50ZXJwb2xhdGVkQXMgfHwgcmVzb2x2ZWRIcmVmXG4gICAgICAgIF0gOiByZXNvbHZlZEhyZWY7XG4gICAgfSBjYXRjaCAoXykge1xuICAgICAgICByZXR1cm4gcmVzb2x2ZUFzID8gW1xuICAgICAgICAgICAgdXJsQXNTdHJpbmdcbiAgICAgICAgXSA6IHVybEFzU3RyaW5nO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHN0cmlwT3JpZ2luKHVybCkge1xuICAgIGNvbnN0IG9yaWdpbiA9ICgwLCBfdXRpbHMpLmdldExvY2F0aW9uT3JpZ2luKCk7XG4gICAgcmV0dXJuIHVybC5zdGFydHNXaXRoKG9yaWdpbikgPyB1cmwuc3Vic3RyaW5nKG9yaWdpbi5sZW5ndGgpIDogdXJsO1xufVxuZnVuY3Rpb24gcHJlcGFyZVVybEFzKHJvdXRlciwgdXJsLCBhcykge1xuICAgIC8vIElmIHVybCBhbmQgYXMgcHJvdmlkZWQgYXMgYW4gb2JqZWN0IHJlcHJlc2VudGF0aW9uLFxuICAgIC8vIHdlJ2xsIGZvcm1hdCB0aGVtIGludG8gdGhlIHN0cmluZyB2ZXJzaW9uIGhlcmUuXG4gICAgbGV0IFtyZXNvbHZlZEhyZWYsIHJlc29sdmVkQXNdID0gcmVzb2x2ZUhyZWYocm91dGVyLCB1cmwsIHRydWUpO1xuICAgIGNvbnN0IG9yaWdpbiA9ICgwLCBfdXRpbHMpLmdldExvY2F0aW9uT3JpZ2luKCk7XG4gICAgY29uc3QgaHJlZkhhZE9yaWdpbiA9IHJlc29sdmVkSHJlZi5zdGFydHNXaXRoKG9yaWdpbik7XG4gICAgY29uc3QgYXNIYWRPcmlnaW4gPSByZXNvbHZlZEFzICYmIHJlc29sdmVkQXMuc3RhcnRzV2l0aChvcmlnaW4pO1xuICAgIHJlc29sdmVkSHJlZiA9IHN0cmlwT3JpZ2luKHJlc29sdmVkSHJlZik7XG4gICAgcmVzb2x2ZWRBcyA9IHJlc29sdmVkQXMgPyBzdHJpcE9yaWdpbihyZXNvbHZlZEFzKSA6IHJlc29sdmVkQXM7XG4gICAgY29uc3QgcHJlcGFyZWRVcmwgPSBocmVmSGFkT3JpZ2luID8gcmVzb2x2ZWRIcmVmIDogYWRkQmFzZVBhdGgocmVzb2x2ZWRIcmVmKTtcbiAgICBjb25zdCBwcmVwYXJlZEFzID0gYXMgPyBzdHJpcE9yaWdpbihyZXNvbHZlSHJlZihyb3V0ZXIsIGFzKSkgOiByZXNvbHZlZEFzIHx8IHJlc29sdmVkSHJlZjtcbiAgICByZXR1cm4ge1xuICAgICAgICB1cmw6IHByZXBhcmVkVXJsLFxuICAgICAgICBhczogYXNIYWRPcmlnaW4gPyBwcmVwYXJlZEFzIDogYWRkQmFzZVBhdGgocHJlcGFyZWRBcylcbiAgICB9O1xufVxuZnVuY3Rpb24gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwYXRobmFtZSwgcGFnZXMpIHtcbiAgICBjb25zdCBjbGVhblBhdGhuYW1lID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCgoMCwgX2Rlbm9ybWFsaXplUGFnZVBhdGgpLmRlbm9ybWFsaXplUGFnZVBhdGgocGF0aG5hbWUpKTtcbiAgICBpZiAoY2xlYW5QYXRobmFtZSA9PT0gJy80MDQnIHx8IGNsZWFuUGF0aG5hbWUgPT09ICcvX2Vycm9yJykge1xuICAgICAgICByZXR1cm4gcGF0aG5hbWU7XG4gICAgfVxuICAgIC8vIGhhbmRsZSByZXNvbHZpbmcgaHJlZiBmb3IgZHluYW1pYyByb3V0ZXNcbiAgICBpZiAoIXBhZ2VzLmluY2x1ZGVzKGNsZWFuUGF0aG5hbWUpKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBhcnJheS1jYWxsYmFjay1yZXR1cm5cbiAgICAgICAgcGFnZXMuc29tZSgocGFnZSk9PntcbiAgICAgICAgICAgIGlmICgoMCwgX2lzRHluYW1pYykuaXNEeW5hbWljUm91dGUocGFnZSkgJiYgKDAsIF9yb3V0ZVJlZ2V4KS5nZXRSb3V0ZVJlZ2V4KHBhZ2UpLnJlLnRlc3QoY2xlYW5QYXRobmFtZSkpIHtcbiAgICAgICAgICAgICAgICBwYXRobmFtZSA9IHBhZ2U7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZSk7XG59XG5jb25zdCBtYW51YWxTY3JvbGxSZXN0b3JhdGlvbiA9IHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04gJiYgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgJ3Njcm9sbFJlc3RvcmF0aW9uJyBpbiB3aW5kb3cuaGlzdG9yeSAmJiAhIWZ1bmN0aW9uKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGxldCB2ID0gJ19fbmV4dCc7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1zZXF1ZW5jZXNcbiAgICAgICAgcmV0dXJuIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0odiwgdiksIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0odiksIHRydWU7XG4gICAgfSBjYXRjaCAobikge1xuICAgIH1cbn0oKTtcbmNvbnN0IFNTR19EQVRBX05PVF9GT1VORCA9IFN5bWJvbCgnU1NHX0RBVEFfTk9UX0ZPVU5EJyk7XG5mdW5jdGlvbiBmZXRjaFJldHJ5KHVybCwgYXR0ZW1wdHMpIHtcbiAgICByZXR1cm4gZmV0Y2godXJsLCB7XG4gICAgICAgIC8vIENvb2tpZXMgYXJlIHJlcXVpcmVkIHRvIGJlIHByZXNlbnQgZm9yIE5leHQuanMnIFNTRyBcIlByZXZpZXcgTW9kZVwiLlxuICAgICAgICAvLyBDb29raWVzIG1heSBhbHNvIGJlIHJlcXVpcmVkIGZvciBgZ2V0U2VydmVyU2lkZVByb3BzYC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gPiBgZmV0Y2hgIHdvbuKAmXQgc2VuZCBjb29raWVzLCB1bmxlc3MgeW91IHNldCB0aGUgY3JlZGVudGlhbHMgaW5pdFxuICAgICAgICAvLyA+IG9wdGlvbi5cbiAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0ZldGNoX0FQSS9Vc2luZ19GZXRjaFxuICAgICAgICAvL1xuICAgICAgICAvLyA+IEZvciBtYXhpbXVtIGJyb3dzZXIgY29tcGF0aWJpbGl0eSB3aGVuIGl0IGNvbWVzIHRvIHNlbmRpbmcgJlxuICAgICAgICAvLyA+IHJlY2VpdmluZyBjb29raWVzLCBhbHdheXMgc3VwcGx5IHRoZSBgY3JlZGVudGlhbHM6ICdzYW1lLW9yaWdpbidgXG4gICAgICAgIC8vID4gb3B0aW9uIGluc3RlYWQgb2YgcmVseWluZyBvbiB0aGUgZGVmYXVsdC5cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9mZXRjaCNjYXZlYXRzXG4gICAgICAgIGNyZWRlbnRpYWxzOiAnc2FtZS1vcmlnaW4nXG4gICAgfSkudGhlbigocmVzKT0+e1xuICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgICAgaWYgKGF0dGVtcHRzID4gMSAmJiByZXMuc3RhdHVzID49IDUwMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmZXRjaFJldHJ5KHVybCwgYXR0ZW1wdHMgLSAxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzLmpzb24oKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YS5ub3RGb3VuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBub3RGb3VuZDogU1NHX0RBVEFfTk9UX0ZPVU5EXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3RhdGljIHByb3BzYCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBsb2FkIHN0YXRpYyBwcm9wc2ApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXMuanNvbigpO1xuICAgIH0pO1xufVxuZnVuY3Rpb24gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZiwgaXNTZXJ2ZXJSZW5kZXIpIHtcbiAgICByZXR1cm4gZmV0Y2hSZXRyeShkYXRhSHJlZiwgaXNTZXJ2ZXJSZW5kZXIgPyAzIDogMSkuY2F0Y2goKGVycik9PntcbiAgICAgICAgLy8gV2Ugc2hvdWxkIG9ubHkgdHJpZ2dlciBhIHNlcnZlci1zaWRlIHRyYW5zaXRpb24gaWYgdGhpcyB3YXMgY2F1c2VkXG4gICAgICAgIC8vIG9uIGEgY2xpZW50LXNpZGUgdHJhbnNpdGlvbi4gT3RoZXJ3aXNlLCB3ZSdkIGdldCBpbnRvIGFuIGluZmluaXRlXG4gICAgICAgIC8vIGxvb3AuXG4gICAgICAgIGlmICghaXNTZXJ2ZXJSZW5kZXIpIHtcbiAgICAgICAgICAgICgwLCBfcm91dGVMb2FkZXIpLm1hcmtBc3NldEVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgZXJyO1xuICAgIH0pO1xufVxuY2xhc3MgUm91dGVyIHtcbiAgICBjb25zdHJ1Y3RvcihwYXRobmFtZTEsIHF1ZXJ5MSwgYXMxLCB7IGluaXRpYWxQcm9wcyAsIHBhZ2VMb2FkZXIgLCBBcHAgLCB3cmFwQXBwICwgQ29tcG9uZW50OiBDb21wb25lbnQxICwgZXJyOiBlcnIxICwgc3Vic2NyaXB0aW9uICwgaXNGYWxsYmFjayAsIGxvY2FsZSAsIGxvY2FsZXMgLCBkZWZhdWx0TG9jYWxlICwgZG9tYWluTG9jYWxlcyAsIGlzUHJldmlldyAgfSl7XG4gICAgICAgIC8vIFN0YXRpYyBEYXRhIENhY2hlXG4gICAgICAgIHRoaXMuc2RjID0ge1xuICAgICAgICB9O1xuICAgICAgICAvLyBJbi1mbGlnaHQgU2VydmVyIERhdGEgUmVxdWVzdHMsIGZvciBkZWR1cGluZ1xuICAgICAgICB0aGlzLnNkciA9IHtcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5faWR4ID0gMDtcbiAgICAgICAgdGhpcy5vblBvcFN0YXRlID0gKGUpPT57XG4gICAgICAgICAgICBjb25zdCBzdGF0ZSA9IGUuc3RhdGU7XG4gICAgICAgICAgICBpZiAoIXN0YXRlKSB7XG4gICAgICAgICAgICAgICAgLy8gV2UgZ2V0IHN0YXRlIGFzIHVuZGVmaW5lZCBmb3IgdHdvIHJlYXNvbnMuXG4gICAgICAgICAgICAgICAgLy8gIDEuIFdpdGggb2xkZXIgc2FmYXJpICg8IDgpIGFuZCBvbGRlciBjaHJvbWUgKDwgMzQpXG4gICAgICAgICAgICAgICAgLy8gIDIuIFdoZW4gdGhlIFVSTCBjaGFuZ2VkIHdpdGggI1xuICAgICAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAgICAgLy8gSW4gdGhlIGJvdGggY2FzZXMsIHdlIGRvbid0IG5lZWQgdG8gcHJvY2VlZCBhbmQgY2hhbmdlIHRoZSByb3V0ZS5cbiAgICAgICAgICAgICAgICAvLyAoYXMgaXQncyBhbHJlYWR5IGNoYW5nZWQpXG4gICAgICAgICAgICAgICAgLy8gQnV0IHdlIGNhbiBzaW1wbHkgcmVwbGFjZSB0aGUgc3RhdGUgd2l0aCB0aGUgbmV3IGNoYW5nZXMuXG4gICAgICAgICAgICAgICAgLy8gQWN0dWFsbHksIGZvciAoMSkgd2UgZG9uJ3QgbmVlZCB0byBub3RoaW5nLiBCdXQgaXQncyBoYXJkIHRvIGRldGVjdCB0aGF0IGV2ZW50LlxuICAgICAgICAgICAgICAgIC8vIFNvLCBkb2luZyB0aGUgZm9sbG93aW5nIGZvciAoMSkgZG9lcyBubyBoYXJtLlxuICAgICAgICAgICAgICAgIGNvbnN0IHsgcGF0aG5hbWU6IHBhdGhuYW1lMSAsIHF1ZXJ5OiBxdWVyeTEgIH0gPSB0aGlzO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hhbmdlU3RhdGUoJ3JlcGxhY2VTdGF0ZScsICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aG5hbWU6IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSksXG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBxdWVyeTFcbiAgICAgICAgICAgICAgICB9KSwgKDAsIF91dGlscykuZ2V0VVJMKCkpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghc3RhdGUuX19OKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGZvcmNlZFNjcm9sbDtcbiAgICAgICAgICAgIGNvbnN0IHsgdXJsICwgYXM6IGFzMSAsIG9wdGlvbnMgLCBpZHggIH0gPSBzdGF0ZTtcbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OKSB7XG4gICAgICAgICAgICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pZHggIT09IGlkeCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU25hcHNob3QgY3VycmVudCBzY3JvbGwgcG9zaXRpb246XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ19fbmV4dF9zY3JvbGxfJyArIHRoaXMuX2lkeCwgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB4OiBzZWxmLnBhZ2VYT2Zmc2V0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5OiBzZWxmLnBhZ2VZT2Zmc2V0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAge1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVzdG9yZSBvbGQgc2Nyb2xsIHBvc2l0aW9uOlxuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2ID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgnX19uZXh0X3Njcm9sbF8nICsgaWR4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JjZWRTY3JvbGwgPSBKU09OLnBhcnNlKHYpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcmNlZFNjcm9sbCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeTogMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9pZHggPSBpZHg7XG4gICAgICAgICAgICBjb25zdCB7IHBhdGhuYW1lOiBwYXRobmFtZTEgIH0gPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwodXJsKTtcbiAgICAgICAgICAgIC8vIE1ha2Ugc3VyZSB3ZSBkb24ndCByZS1yZW5kZXIgb24gaW5pdGlhbCBsb2FkLFxuICAgICAgICAgICAgLy8gY2FuIGJlIGNhdXNlZCBieSBuYXZpZ2F0aW5nIGJhY2sgZnJvbSBhbiBleHRlcm5hbCBzaXRlXG4gICAgICAgICAgICBpZiAodGhpcy5pc1NzciAmJiBhczEgPT09IHRoaXMuYXNQYXRoICYmIHBhdGhuYW1lMSA9PT0gdGhpcy5wYXRobmFtZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIElmIHRoZSBkb3duc3RyZWFtIGFwcGxpY2F0aW9uIHJldHVybnMgZmFsc3ksIHJldHVybi5cbiAgICAgICAgICAgIC8vIFRoZXkgd2lsbCB0aGVuIGJlIHJlc3BvbnNpYmxlIGZvciBoYW5kbGluZyB0aGUgZXZlbnQuXG4gICAgICAgICAgICBpZiAodGhpcy5fYnBzICYmICF0aGlzLl9icHMoc3RhdGUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jaGFuZ2UoJ3JlcGxhY2VTdGF0ZScsIHVybCwgYXMxLCBPYmplY3QuYXNzaWduKHtcbiAgICAgICAgICAgIH0sIG9wdGlvbnMsIHtcbiAgICAgICAgICAgICAgICBzaGFsbG93OiBvcHRpb25zLnNoYWxsb3cgJiYgdGhpcy5fc2hhbGxvdyxcbiAgICAgICAgICAgICAgICBsb2NhbGU6IG9wdGlvbnMubG9jYWxlIHx8IHRoaXMuZGVmYXVsdExvY2FsZVxuICAgICAgICAgICAgfSksIGZvcmNlZFNjcm9sbCk7XG4gICAgICAgIH07XG4gICAgICAgIC8vIHJlcHJlc2VudHMgdGhlIGN1cnJlbnQgY29tcG9uZW50IGtleVxuICAgICAgICB0aGlzLnJvdXRlID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZTEpO1xuICAgICAgICAvLyBzZXQgdXAgdGhlIGNvbXBvbmVudCBjYWNoZSAoYnkgcm91dGUga2V5cylcbiAgICAgICAgdGhpcy5jb21wb25lbnRzID0ge1xuICAgICAgICB9O1xuICAgICAgICAvLyBXZSBzaG91bGQgbm90IGtlZXAgdGhlIGNhY2hlLCBpZiB0aGVyZSdzIGFuIGVycm9yXG4gICAgICAgIC8vIE90aGVyd2lzZSwgdGhpcyBjYXVzZSBpc3N1ZXMgd2hlbiB3aGVuIGdvaW5nIGJhY2sgYW5kXG4gICAgICAgIC8vIGNvbWUgYWdhaW4gdG8gdGhlIGVycm9yZWQgcGFnZS5cbiAgICAgICAgaWYgKHBhdGhuYW1lMSAhPT0gJy9fZXJyb3InKSB7XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudHNbdGhpcy5yb3V0ZV0gPSB7XG4gICAgICAgICAgICAgICAgQ29tcG9uZW50OiBDb21wb25lbnQxLFxuICAgICAgICAgICAgICAgIGluaXRpYWw6IHRydWUsXG4gICAgICAgICAgICAgICAgcHJvcHM6IGluaXRpYWxQcm9wcyxcbiAgICAgICAgICAgICAgICBlcnI6IGVycjEsXG4gICAgICAgICAgICAgICAgX19OX1NTRzogaW5pdGlhbFByb3BzICYmIGluaXRpYWxQcm9wcy5fX05fU1NHLFxuICAgICAgICAgICAgICAgIF9fTl9TU1A6IGluaXRpYWxQcm9wcyAmJiBpbml0aWFsUHJvcHMuX19OX1NTUFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10gPSB7XG4gICAgICAgICAgICBDb21wb25lbnQ6IEFwcCxcbiAgICAgICAgICAgIHN0eWxlU2hlZXRzOiBbXVxuICAgICAgICB9O1xuICAgICAgICAvLyBCYWNrd2FyZHMgY29tcGF0IGZvciBSb3V0ZXIucm91dGVyLmV2ZW50c1xuICAgICAgICAvLyBUT0RPOiBTaG91bGQgYmUgcmVtb3ZlIHRoZSBmb2xsb3dpbmcgbWFqb3IgdmVyc2lvbiBhcyBpdCB3YXMgbmV2ZXIgZG9jdW1lbnRlZFxuICAgICAgICB0aGlzLmV2ZW50cyA9IFJvdXRlci5ldmVudHM7XG4gICAgICAgIHRoaXMucGFnZUxvYWRlciA9IHBhZ2VMb2FkZXI7XG4gICAgICAgIHRoaXMucGF0aG5hbWUgPSBwYXRobmFtZTE7XG4gICAgICAgIHRoaXMucXVlcnkgPSBxdWVyeTE7XG4gICAgICAgIC8vIGlmIGF1dG8gcHJlcmVuZGVyZWQgYW5kIGR5bmFtaWMgcm91dGUgd2FpdCB0byB1cGRhdGUgYXNQYXRoXG4gICAgICAgIC8vIHVudGlsIGFmdGVyIG1vdW50IHRvIHByZXZlbnQgaHlkcmF0aW9uIG1pc21hdGNoXG4gICAgICAgIGNvbnN0IGF1dG9FeHBvcnREeW5hbWljID0gKDAsIF9pc0R5bmFtaWMpLmlzRHluYW1pY1JvdXRlKHBhdGhuYW1lMSkgJiYgc2VsZi5fX05FWFRfREFUQV9fLmF1dG9FeHBvcnQ7XG4gICAgICAgIHRoaXMuYXNQYXRoID0gYXV0b0V4cG9ydER5bmFtaWMgPyBwYXRobmFtZTEgOiBhczE7XG4gICAgICAgIHRoaXMuYmFzZVBhdGggPSBiYXNlUGF0aDtcbiAgICAgICAgdGhpcy5zdWIgPSBzdWJzY3JpcHRpb247XG4gICAgICAgIHRoaXMuY2xjID0gbnVsbDtcbiAgICAgICAgdGhpcy5fd3JhcEFwcCA9IHdyYXBBcHA7XG4gICAgICAgIC8vIG1ha2Ugc3VyZSB0byBpZ25vcmUgZXh0cmEgcG9wU3RhdGUgaW4gc2FmYXJpIG9uIG5hdmlnYXRpbmdcbiAgICAgICAgLy8gYmFjayBmcm9tIGV4dGVybmFsIHNpdGVcbiAgICAgICAgdGhpcy5pc1NzciA9IHRydWU7XG4gICAgICAgIHRoaXMuaXNGYWxsYmFjayA9IGlzRmFsbGJhY2s7XG4gICAgICAgIHRoaXMuaXNSZWFkeSA9ICEhKHNlbGYuX19ORVhUX0RBVEFfXy5nc3NwIHx8IHNlbGYuX19ORVhUX0RBVEFfXy5naXAgfHwgc2VsZi5fX05FWFRfREFUQV9fLmFwcEdpcCAmJiAhc2VsZi5fX05FWFRfREFUQV9fLmdzcCB8fCAhYXV0b0V4cG9ydER5bmFtaWMgJiYgIXNlbGYubG9jYXRpb24uc2VhcmNoICYmICFwcm9jZXNzLmVudi5fX05FWFRfSEFTX1JFV1JJVEVTKTtcbiAgICAgICAgdGhpcy5pc1ByZXZpZXcgPSAhIWlzUHJldmlldztcbiAgICAgICAgdGhpcy5pc0xvY2FsZURvbWFpbiA9IGZhbHNlO1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGU7XG4gICAgICAgICAgICB0aGlzLmxvY2FsZXMgPSBsb2NhbGVzO1xuICAgICAgICAgICAgdGhpcy5kZWZhdWx0TG9jYWxlID0gZGVmYXVsdExvY2FsZTtcbiAgICAgICAgICAgIHRoaXMuZG9tYWluTG9jYWxlcyA9IGRvbWFpbkxvY2FsZXM7XG4gICAgICAgICAgICB0aGlzLmlzTG9jYWxlRG9tYWluID0gISFkZXRlY3REb21haW5Mb2NhbGUoZG9tYWluTG9jYWxlcywgc2VsZi5sb2NhdGlvbi5ob3N0bmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAvLyBtYWtlIHN1cmUgXCJhc1wiIGRvZXNuJ3Qgc3RhcnQgd2l0aCBkb3VibGUgc2xhc2hlcyBvciBlbHNlIGl0IGNhblxuICAgICAgICAgICAgLy8gdGhyb3cgYW4gZXJyb3IgYXMgaXQncyBjb25zaWRlcmVkIGludmFsaWRcbiAgICAgICAgICAgIGlmIChhczEuc3Vic3RyKDAsIDIpICE9PSAnLy8nKSB7XG4gICAgICAgICAgICAgICAgLy8gaW4gb3JkZXIgZm9yIGBlLnN0YXRlYCB0byB3b3JrIG9uIHRoZSBgb25wb3BzdGF0ZWAgZXZlbnRcbiAgICAgICAgICAgICAgICAvLyB3ZSBoYXZlIHRvIHJlZ2lzdGVyIHRoZSBpbml0aWFsIHJvdXRlIHVwb24gaW5pdGlhbGl6YXRpb25cbiAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAgICAgICAgICAgICBsb2NhbGVcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIG9wdGlvbnMuX3Nob3VsZFJlc29sdmVIcmVmID0gYXMxICE9PSBwYXRobmFtZTE7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZSgncmVwbGFjZVN0YXRlJywgKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogYWRkQmFzZVBhdGgocGF0aG5hbWUxKSxcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6IHF1ZXJ5MVxuICAgICAgICAgICAgICAgIH0pLCAoMCwgX3V0aWxzKS5nZXRVUkwoKSwgb3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncG9wc3RhdGUnLCB0aGlzLm9uUG9wU3RhdGUpO1xuICAgICAgICAgICAgLy8gZW5hYmxlIGN1c3RvbSBzY3JvbGwgcmVzdG9yYXRpb24gaGFuZGxpbmcgd2hlbiBhdmFpbGFibGVcbiAgICAgICAgICAgIC8vIG90aGVyd2lzZSBmYWxsYmFjayB0byBicm93c2VyJ3MgZGVmYXVsdCBoYW5kbGluZ1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04pIHtcbiAgICAgICAgICAgICAgICBpZiAobWFudWFsU2Nyb2xsUmVzdG9yYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93Lmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSAnbWFudWFsJztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmVsb2FkKCkge1xuICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG4gICAgfVxuICAgIC8qKlxuICAgKiBHbyBiYWNrIGluIGhpc3RvcnlcbiAgICovIGJhY2soKSB7XG4gICAgICAgIHdpbmRvdy5oaXN0b3J5LmJhY2soKTtcbiAgICB9XG4gICAgLyoqXG4gICAqIFBlcmZvcm1zIGEgYHB1c2hTdGF0ZWAgd2l0aCBhcmd1bWVudHNcbiAgICogQHBhcmFtIHVybCBvZiB0aGUgcm91dGVcbiAgICogQHBhcmFtIGFzIG1hc2tzIGB1cmxgIGZvciB0aGUgYnJvd3NlclxuICAgKiBAcGFyYW0gb3B0aW9ucyBvYmplY3QgeW91IGNhbiBkZWZpbmUgYHNoYWxsb3dgIGFuZCBvdGhlciBvcHRpb25zXG4gICAqLyBwdXNoKHVybCwgYXMsIG9wdGlvbnMgPSB7XG4gICAgfSkge1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTikge1xuICAgICAgICAgICAgLy8gVE9ETzogcmVtb3ZlIGluIHRoZSBmdXR1cmUgd2hlbiB3ZSB1cGRhdGUgaGlzdG9yeSBiZWZvcmUgcm91dGUgY2hhbmdlXG4gICAgICAgICAgICAvLyBpcyBjb21wbGV0ZSwgYXMgdGhlIHBvcHN0YXRlIGV2ZW50IHNob3VsZCBoYW5kbGUgdGhpcyBjYXB0dXJlLlxuICAgICAgICAgICAgaWYgKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gU25hcHNob3Qgc2Nyb2xsIHBvc2l0aW9uIHJpZ2h0IGJlZm9yZSBuYXZpZ2F0aW5nIHRvIGEgbmV3IHBhZ2U6XG4gICAgICAgICAgICAgICAgICAgIHNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ19fbmV4dF9zY3JvbGxfJyArIHRoaXMuX2lkeCwgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgeDogc2VsZi5wYWdlWE9mZnNldCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHk6IHNlbGYucGFnZVlPZmZzZXRcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggIHtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgKHsgdXJsICwgYXMgIH0gPSBwcmVwYXJlVXJsQXModGhpcywgdXJsLCBhcykpO1xuICAgICAgICByZXR1cm4gdGhpcy5jaGFuZ2UoJ3B1c2hTdGF0ZScsIHVybCwgYXMsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKipcbiAgICogUGVyZm9ybXMgYSBgcmVwbGFjZVN0YXRlYCB3aXRoIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gdXJsIG9mIHRoZSByb3V0ZVxuICAgKiBAcGFyYW0gYXMgbWFza3MgYHVybGAgZm9yIHRoZSBicm93c2VyXG4gICAqIEBwYXJhbSBvcHRpb25zIG9iamVjdCB5b3UgY2FuIGRlZmluZSBgc2hhbGxvd2AgYW5kIG90aGVyIG9wdGlvbnNcbiAgICovIHJlcGxhY2UodXJsLCBhcywgb3B0aW9ucyA9IHtcbiAgICB9KSB7XG4gICAgICAgICh7IHVybCAsIGFzICB9ID0gcHJlcGFyZVVybEFzKHRoaXMsIHVybCwgYXMpKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hhbmdlKCdyZXBsYWNlU3RhdGUnLCB1cmwsIGFzLCBvcHRpb25zKTtcbiAgICB9XG4gICAgYXN5bmMgY2hhbmdlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucywgZm9yY2VkU2Nyb2xsKSB7XG4gICAgICAgIGlmICghaXNMb2NhbFVSTCh1cmwpKSB7XG4gICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHVybDtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzaG91bGRSZXNvbHZlSHJlZiA9IHVybCA9PT0gYXMgfHwgb3B0aW9ucy5faCB8fCBvcHRpb25zLl9zaG91bGRSZXNvbHZlSHJlZjtcbiAgICAgICAgLy8gZm9yIHN0YXRpYyBwYWdlcyB3aXRoIHF1ZXJ5IHBhcmFtcyBpbiB0aGUgVVJMIHdlIGRlbGF5XG4gICAgICAgIC8vIG1hcmtpbmcgdGhlIHJvdXRlciByZWFkeSB1bnRpbCBhZnRlciB0aGUgcXVlcnkgaXMgdXBkYXRlZFxuICAgICAgICBpZiAob3B0aW9ucy5faCkge1xuICAgICAgICAgICAgdGhpcy5pc1JlYWR5ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcmV2TG9jYWxlID0gdGhpcy5sb2NhbGU7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICB0aGlzLmxvY2FsZSA9IG9wdGlvbnMubG9jYWxlID09PSBmYWxzZSA/IHRoaXMuZGVmYXVsdExvY2FsZSA6IG9wdGlvbnMubG9jYWxlIHx8IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBvcHRpb25zLmxvY2FsZSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBvcHRpb25zLmxvY2FsZSA9IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwoaGFzQmFzZVBhdGgoYXMpID8gZGVsQmFzZVBhdGgoYXMpIDogYXMpO1xuICAgICAgICAgICAgY29uc3QgbG9jYWxlUGF0aFJlc3VsdCA9ICgwLCBfbm9ybWFsaXplTG9jYWxlUGF0aCkubm9ybWFsaXplTG9jYWxlUGF0aChwYXJzZWRBcy5wYXRobmFtZSwgdGhpcy5sb2NhbGVzKTtcbiAgICAgICAgICAgIGlmIChsb2NhbGVQYXRoUmVzdWx0LmRldGVjdGVkTG9jYWxlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2NhbGUgPSBsb2NhbGVQYXRoUmVzdWx0LmRldGVjdGVkTG9jYWxlO1xuICAgICAgICAgICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lID0gYWRkQmFzZVBhdGgocGFyc2VkQXMucGF0aG5hbWUpO1xuICAgICAgICAgICAgICAgIGFzID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkQXMpO1xuICAgICAgICAgICAgICAgIHVybCA9IGFkZEJhc2VQYXRoKCgwLCBfbm9ybWFsaXplTG9jYWxlUGF0aCkubm9ybWFsaXplTG9jYWxlUGF0aChoYXNCYXNlUGF0aCh1cmwpID8gZGVsQmFzZVBhdGgodXJsKSA6IHVybCwgdGhpcy5sb2NhbGVzKS5wYXRobmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZGlkTmF2aWdhdGUgPSBmYWxzZTtcbiAgICAgICAgICAgIC8vIHdlIG5lZWQgdG8gd3JhcCB0aGlzIGluIHRoZSBlbnYgY2hlY2sgYWdhaW4gc2luY2UgcmVnZW5lcmF0b3IgcnVudGltZVxuICAgICAgICAgICAgLy8gbW92ZXMgdGhpcyBvbiBpdHMgb3duIGR1ZSB0byB0aGUgcmV0dXJuXG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgICAgIHZhciByZWY7XG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIGxvY2FsZSBpc24ndCBjb25maWd1cmVkIGhhcmQgbmF2aWdhdGUgdG8gc2hvdyA0MDQgcGFnZVxuICAgICAgICAgICAgICAgIGlmICghKChyZWYgPSB0aGlzLmxvY2FsZXMpID09PSBudWxsIHx8IHJlZiA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVmLmluY2x1ZGVzKHRoaXMubG9jYWxlKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VkQXMucGF0aG5hbWUgPSBhZGRMb2NhbGUocGFyc2VkQXMucGF0aG5hbWUsIHRoaXMubG9jYWxlKTtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWRBcyk7XG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMgd2FzIHByZXZpb3VzbHkgYSByZXR1cm4gYnV0IHdhcyByZW1vdmVkIGluIGZhdm9yXG4gICAgICAgICAgICAgICAgICAgIC8vIG9mIGJldHRlciBkZWFkIGNvZGUgZWxpbWluYXRpb24gd2l0aCByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgICAgICAgICAgIGRpZE5hdmlnYXRlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBkZXRlY3RlZERvbWFpbiA9IGRldGVjdERvbWFpbkxvY2FsZSh0aGlzLmRvbWFpbkxvY2FsZXMsIHVuZGVmaW5lZCwgdGhpcy5sb2NhbGUpO1xuICAgICAgICAgICAgLy8gd2UgbmVlZCB0byB3cmFwIHRoaXMgaW4gdGhlIGVudiBjaGVjayBhZ2FpbiBzaW5jZSByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgICAvLyBtb3ZlcyB0aGlzIG9uIGl0cyBvd24gZHVlIHRvIHRoZSByZXR1cm5cbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICAgICAgLy8gaWYgd2UgYXJlIG5hdmlnYXRpbmcgdG8gYSBkb21haW4gbG9jYWxlIGVuc3VyZSB3ZSByZWRpcmVjdCB0byB0aGVcbiAgICAgICAgICAgICAgICAvLyBjb3JyZWN0IGRvbWFpblxuICAgICAgICAgICAgICAgIGlmICghZGlkTmF2aWdhdGUgJiYgZGV0ZWN0ZWREb21haW4gJiYgdGhpcy5pc0xvY2FsZURvbWFpbiAmJiBzZWxmLmxvY2F0aW9uLmhvc3RuYW1lICE9PSBkZXRlY3RlZERvbWFpbi5kb21haW4pIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXNOb0Jhc2VQYXRoID0gZGVsQmFzZVBhdGgoYXMpO1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwID8gJycgOiAncyd9Oi8vJHtkZXRlY3RlZERvbWFpbi5kb21haW59JHthZGRCYXNlUGF0aChgJHt0aGlzLmxvY2FsZSA9PT0gZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZSA/ICcnIDogYC8ke3RoaXMubG9jYWxlfWB9JHthc05vQmFzZVBhdGggPT09ICcvJyA/ICcnIDogYXNOb0Jhc2VQYXRofWAgfHwgJy8nKX1gO1xuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzIHdhcyBwcmV2aW91c2x5IGEgcmV0dXJuIGJ1dCB3YXMgcmVtb3ZlZCBpbiBmYXZvclxuICAgICAgICAgICAgICAgICAgICAvLyBvZiBiZXR0ZXIgZGVhZCBjb2RlIGVsaW1pbmF0aW9uIHdpdGggcmVnZW5lcmF0b3IgcnVudGltZVxuICAgICAgICAgICAgICAgICAgICBkaWROYXZpZ2F0ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGRpZE5hdmlnYXRlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKCgpPT57XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFvcHRpb25zLl9oKSB7XG4gICAgICAgICAgICB0aGlzLmlzU3NyID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgLy8gbWFya2luZyByb3V0ZSBjaGFuZ2VzIGFzIGEgbmF2aWdhdGlvbiBzdGFydCBlbnRyeVxuICAgICAgICBpZiAoX3V0aWxzLlNUKSB7XG4gICAgICAgICAgICBwZXJmb3JtYW5jZS5tYXJrKCdyb3V0ZUNoYW5nZScpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgc2hhbGxvdyA9ZmFsc2UgIH0gPSBvcHRpb25zO1xuICAgICAgICBjb25zdCByb3V0ZVByb3BzID0ge1xuICAgICAgICAgICAgc2hhbGxvd1xuICAgICAgICB9O1xuICAgICAgICBpZiAodGhpcy5faW5GbGlnaHRSb3V0ZSkge1xuICAgICAgICAgICAgdGhpcy5hYm9ydENvbXBvbmVudExvYWQodGhpcy5faW5GbGlnaHRSb3V0ZSwgcm91dGVQcm9wcyk7XG4gICAgICAgIH1cbiAgICAgICAgYXMgPSBhZGRCYXNlUGF0aChhZGRMb2NhbGUoaGFzQmFzZVBhdGgoYXMpID8gZGVsQmFzZVBhdGgoYXMpIDogYXMsIG9wdGlvbnMubG9jYWxlLCB0aGlzLmRlZmF1bHRMb2NhbGUpKTtcbiAgICAgICAgY29uc3QgY2xlYW5lZEFzID0gZGVsTG9jYWxlKGhhc0Jhc2VQYXRoKGFzKSA/IGRlbEJhc2VQYXRoKGFzKSA6IGFzLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgIHRoaXMuX2luRmxpZ2h0Um91dGUgPSBhcztcbiAgICAgICAgbGV0IGxvY2FsZUNoYW5nZSA9IHByZXZMb2NhbGUgIT09IHRoaXMubG9jYWxlO1xuICAgICAgICAvLyBJZiB0aGUgdXJsIGNoYW5nZSBpcyBvbmx5IHJlbGF0ZWQgdG8gYSBoYXNoIGNoYW5nZVxuICAgICAgICAvLyBXZSBzaG91bGQgbm90IHByb2NlZWQuIFdlIHNob3VsZCBvbmx5IGNoYW5nZSB0aGUgc3RhdGUuXG4gICAgICAgIC8vIFdBUk5JTkc6IGBfaGAgaXMgYW4gaW50ZXJuYWwgb3B0aW9uIGZvciBoYW5kaW5nIE5leHQuanMgY2xpZW50LXNpZGVcbiAgICAgICAgLy8gaHlkcmF0aW9uLiBZb3VyIGFwcCBzaG91bGQgX25ldmVyXyB1c2UgdGhpcyBwcm9wZXJ0eS4gSXQgbWF5IGNoYW5nZSBhdFxuICAgICAgICAvLyBhbnkgdGltZSB3aXRob3V0IG5vdGljZS5cbiAgICAgICAgaWYgKCFvcHRpb25zLl9oICYmIHRoaXMub25seUFIYXNoQ2hhbmdlKGNsZWFuZWRBcykgJiYgIWxvY2FsZUNoYW5nZSkge1xuICAgICAgICAgICAgdGhpcy5hc1BhdGggPSBjbGVhbmVkQXM7XG4gICAgICAgICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ2hhc2hDaGFuZ2VTdGFydCcsIGFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIC8vIFRPRE86IGRvIHdlIG5lZWQgdGhlIHJlc29sdmVkIGhyZWYgd2hlbiBvbmx5IGEgaGFzaCBjaGFuZ2U/XG4gICAgICAgICAgICB0aGlzLmNoYW5nZVN0YXRlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucyk7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbFRvSGFzaChjbGVhbmVkQXMpO1xuICAgICAgICAgICAgdGhpcy5ub3RpZnkodGhpcy5jb21wb25lbnRzW3RoaXMucm91dGVdLCBudWxsKTtcbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgnaGFzaENoYW5nZUNvbXBsZXRlJywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHBhcnNlZCA9ICgwLCBfcGFyc2VSZWxhdGl2ZVVybCkucGFyc2VSZWxhdGl2ZVVybCh1cmwpO1xuICAgICAgICBsZXQgeyBwYXRobmFtZTogcGF0aG5hbWUxICwgcXVlcnk6IHF1ZXJ5MSAgfSA9IHBhcnNlZDtcbiAgICAgICAgLy8gVGhlIGJ1aWxkIG1hbmlmZXN0IG5lZWRzIHRvIGJlIGxvYWRlZCBiZWZvcmUgYXV0by1zdGF0aWMgZHluYW1pYyBwYWdlc1xuICAgICAgICAvLyBnZXQgdGhlaXIgcXVlcnkgcGFyYW1ldGVycyB0byBhbGxvdyBlbnN1cmluZyB0aGV5IGNhbiBiZSBwYXJzZWQgcHJvcGVybHlcbiAgICAgICAgLy8gd2hlbiByZXdyaXR0ZW4gdG9cbiAgICAgICAgbGV0IHBhZ2VzLCByZXdyaXRlcztcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHBhZ2VzID0gYXdhaXQgdGhpcy5wYWdlTG9hZGVyLmdldFBhZ2VMaXN0KCk7XG4gICAgICAgICAgICAoeyBfX3Jld3JpdGVzOiByZXdyaXRlcyAgfSA9IGF3YWl0ICgwLCBfcm91dGVMb2FkZXIpLmdldENsaWVudEJ1aWxkTWFuaWZlc3QoKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycjEpIHtcbiAgICAgICAgICAgIC8vIElmIHdlIGZhaWwgdG8gcmVzb2x2ZSB0aGUgcGFnZSBsaXN0IG9yIGNsaWVudC1idWlsZCBtYW5pZmVzdCwgd2UgbXVzdFxuICAgICAgICAgICAgLy8gZG8gYSBzZXJ2ZXItc2lkZSB0cmFuc2l0aW9uOlxuICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBhcztcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiBhc2tlZCB0byBjaGFuZ2UgdGhlIGN1cnJlbnQgVVJMIHdlIHNob3VsZCByZWxvYWQgdGhlIGN1cnJlbnQgcGFnZVxuICAgICAgICAvLyAobm90IGxvY2F0aW9uLnJlbG9hZCgpIGJ1dCByZWxvYWQgZ2V0SW5pdGlhbFByb3BzIGFuZCBvdGhlciBOZXh0LmpzIHN0dWZmcylcbiAgICAgICAgLy8gV2UgYWxzbyBuZWVkIHRvIHNldCB0aGUgbWV0aG9kID0gcmVwbGFjZVN0YXRlIGFsd2F5c1xuICAgICAgICAvLyBhcyB0aGlzIHNob3VsZCBub3QgZ28gaW50byB0aGUgaGlzdG9yeSAoVGhhdCdzIGhvdyBicm93c2VycyB3b3JrKVxuICAgICAgICAvLyBXZSBzaG91bGQgY29tcGFyZSB0aGUgbmV3IGFzUGF0aCB0byB0aGUgY3VycmVudCBhc1BhdGgsIG5vdCB0aGUgdXJsXG4gICAgICAgIGlmICghdGhpcy51cmxJc05ldyhjbGVhbmVkQXMpICYmICFsb2NhbGVDaGFuZ2UpIHtcbiAgICAgICAgICAgIG1ldGhvZCA9ICdyZXBsYWNlU3RhdGUnO1xuICAgICAgICB9XG4gICAgICAgIC8vIHdlIG5lZWQgdG8gcmVzb2x2ZSB0aGUgYXMgdmFsdWUgdXNpbmcgcmV3cml0ZXMgZm9yIGR5bmFtaWMgU1NHXG4gICAgICAgIC8vIHBhZ2VzIHRvIGFsbG93IGJ1aWxkaW5nIHRoZSBkYXRhIFVSTCBjb3JyZWN0bHlcbiAgICAgICAgbGV0IHJlc29sdmVkQXMgPSBhcztcbiAgICAgICAgLy8gdXJsIGFuZCBhcyBzaG91bGQgYWx3YXlzIGJlIHByZWZpeGVkIHdpdGggYmFzZVBhdGggYnkgdGhpc1xuICAgICAgICAvLyBwb2ludCBieSBlaXRoZXIgbmV4dC9saW5rIG9yIHJvdXRlci5wdXNoL3JlcGxhY2Ugc28gc3RyaXAgdGhlXG4gICAgICAgIC8vIGJhc2VQYXRoIGZyb20gdGhlIHBhdGhuYW1lIHRvIG1hdGNoIHRoZSBwYWdlcyBkaXIgMS10by0xXG4gICAgICAgIHBhdGhuYW1lMSA9IHBhdGhuYW1lMSA/ICgwLCBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCkucmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2goZGVsQmFzZVBhdGgocGF0aG5hbWUxKSkgOiBwYXRobmFtZTE7XG4gICAgICAgIGlmIChzaG91bGRSZXNvbHZlSHJlZiAmJiBwYXRobmFtZTEgIT09ICcvX2Vycm9yJykge1xuICAgICAgICAgICAgb3B0aW9ucy5fc2hvdWxkUmVzb2x2ZUhyZWYgPSB0cnVlO1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMgJiYgYXMuc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmV3cml0ZXNSZXN1bHQgPSAoMCwgX3Jlc29sdmVSZXdyaXRlcykuZGVmYXVsdChhZGRCYXNlUGF0aChhZGRMb2NhbGUoY2xlYW5lZEFzLCB0aGlzLmxvY2FsZSkpLCBwYWdlcywgcmV3cml0ZXMsIHF1ZXJ5MSwgKHApPT5yZXNvbHZlRHluYW1pY1JvdXRlKHAsIHBhZ2VzKVxuICAgICAgICAgICAgICAgICwgdGhpcy5sb2NhbGVzKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlZEFzID0gcmV3cml0ZXNSZXN1bHQuYXNQYXRoO1xuICAgICAgICAgICAgICAgIGlmIChyZXdyaXRlc1Jlc3VsdC5tYXRjaGVkUGFnZSAmJiByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gaWYgdGhpcyBkaXJlY3RseSBtYXRjaGVzIGEgcGFnZSB3ZSBuZWVkIHRvIHVwZGF0ZSB0aGUgaHJlZiB0b1xuICAgICAgICAgICAgICAgICAgICAvLyBhbGxvdyB0aGUgY29ycmVjdCBwYWdlIGNodW5rIHRvIGJlIGxvYWRlZFxuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTEgPSByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWY7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSk7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSByZXNvbHZlRHluYW1pY1JvdXRlKHBhdGhuYW1lMSwgcGFnZXMpO1xuICAgICAgICAgICAgICAgIGlmIChwYXJzZWQucGF0aG5hbWUgIT09IHBhdGhuYW1lMSkge1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTEgPSBwYXJzZWQucGF0aG5hbWU7XG4gICAgICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IGFkZEJhc2VQYXRoKHBhdGhuYW1lMSk7XG4gICAgICAgICAgICAgICAgICAgIHVybCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJvdXRlID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZTEpO1xuICAgICAgICBpZiAoIWlzTG9jYWxVUkwoYXMpKSB7XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBocmVmOiBcIiR7dXJsfVwiIGFuZCBhczogXCIke2FzfVwiLCByZWNlaXZlZCByZWxhdGl2ZSBocmVmIGFuZCBleHRlcm5hbCBhc2AgKyBgXFxuU2VlIG1vcmUgaW5mbzogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvaW52YWxpZC1yZWxhdGl2ZS11cmwtZXh0ZXJuYWwtYXNgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYXM7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmVzb2x2ZWRBcyA9IGRlbExvY2FsZShkZWxCYXNlUGF0aChyZXNvbHZlZEFzKSwgdGhpcy5sb2NhbGUpO1xuICAgICAgICBpZiAoKDAsIF9pc0R5bmFtaWMpLmlzRHluYW1pY1JvdXRlKHJvdXRlKSkge1xuICAgICAgICAgICAgY29uc3QgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwocmVzb2x2ZWRBcyk7XG4gICAgICAgICAgICBjb25zdCBhc1BhdGhuYW1lID0gcGFyc2VkQXMucGF0aG5hbWU7XG4gICAgICAgICAgICBjb25zdCByb3V0ZVJlZ2V4ID0gKDAsIF9yb3V0ZVJlZ2V4KS5nZXRSb3V0ZVJlZ2V4KHJvdXRlKTtcbiAgICAgICAgICAgIGNvbnN0IHJvdXRlTWF0Y2ggPSAoMCwgX3JvdXRlTWF0Y2hlcikuZ2V0Um91dGVNYXRjaGVyKHJvdXRlUmVnZXgpKGFzUGF0aG5hbWUpO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkSW50ZXJwb2xhdGUgPSByb3V0ZSA9PT0gYXNQYXRobmFtZTtcbiAgICAgICAgICAgIGNvbnN0IGludGVycG9sYXRlZEFzID0gc2hvdWxkSW50ZXJwb2xhdGUgPyBpbnRlcnBvbGF0ZUFzKHJvdXRlLCBhc1BhdGhuYW1lLCBxdWVyeTEpIDoge1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICghcm91dGVNYXRjaCB8fCBzaG91bGRJbnRlcnBvbGF0ZSAmJiAhaW50ZXJwb2xhdGVkQXMucmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbWlzc2luZ1BhcmFtcyA9IE9iamVjdC5rZXlzKHJvdXRlUmVnZXguZ3JvdXBzKS5maWx0ZXIoKHBhcmFtKT0+IXF1ZXJ5MVtwYXJhbV1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGlmIChtaXNzaW5nUGFyYW1zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgJHtzaG91bGRJbnRlcnBvbGF0ZSA/IGBJbnRlcnBvbGF0aW5nIGhyZWZgIDogYE1pc21hdGNoaW5nIFxcYGFzXFxgIGFuZCBcXGBocmVmXFxgYH0gZmFpbGVkIHRvIG1hbnVhbGx5IHByb3ZpZGUgYCArIGB0aGUgcGFyYW1zOiAke21pc3NpbmdQYXJhbXMuam9pbignLCAnKX0gaW4gdGhlIFxcYGhyZWZcXGAncyBcXGBxdWVyeVxcYGApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigoc2hvdWxkSW50ZXJwb2xhdGUgPyBgVGhlIHByb3ZpZGVkIFxcYGhyZWZcXGAgKCR7dXJsfSkgdmFsdWUgaXMgbWlzc2luZyBxdWVyeSB2YWx1ZXMgKCR7bWlzc2luZ1BhcmFtcy5qb2luKCcsICcpfSkgdG8gYmUgaW50ZXJwb2xhdGVkIHByb3Blcmx5LiBgIDogYFRoZSBwcm92aWRlZCBcXGBhc1xcYCB2YWx1ZSAoJHthc1BhdGhuYW1lfSkgaXMgaW5jb21wYXRpYmxlIHdpdGggdGhlIFxcYGhyZWZcXGAgdmFsdWUgKCR7cm91dGV9KS4gYCkgKyBgUmVhZCBtb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy8ke3Nob3VsZEludGVycG9sYXRlID8gJ2hyZWYtaW50ZXJwb2xhdGlvbi1mYWlsZWQnIDogJ2luY29tcGF0aWJsZS1ocmVmLWFzJ31gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHNob3VsZEludGVycG9sYXRlKSB7XG4gICAgICAgICAgICAgICAgYXMgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihPYmplY3QuYXNzaWduKHtcbiAgICAgICAgICAgICAgICB9LCBwYXJzZWRBcywge1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogaW50ZXJwb2xhdGVkQXMucmVzdWx0LFxuICAgICAgICAgICAgICAgICAgICBxdWVyeTogb21pdFBhcm1zRnJvbVF1ZXJ5KHF1ZXJ5MSwgaW50ZXJwb2xhdGVkQXMucGFyYW1zKVxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gTWVyZ2UgcGFyYW1zIGludG8gYHF1ZXJ5YCwgb3ZlcndyaXRpbmcgYW55IHNwZWNpZmllZCBpbiBzZWFyY2hcbiAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHF1ZXJ5MSwgcm91dGVNYXRjaCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZVN0YXJ0JywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdmFyIHJlZiwgcmVmMTtcbiAgICAgICAgICAgIGxldCByb3V0ZUluZm8gPSBhd2FpdCB0aGlzLmdldFJvdXRlSW5mbyhyb3V0ZSwgcGF0aG5hbWUxLCBxdWVyeTEsIGFzLCByZXNvbHZlZEFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIGxldCB7IGVycm9yICwgcHJvcHMgLCBfX05fU1NHICwgX19OX1NTUCAgfSA9IHJvdXRlSW5mbztcbiAgICAgICAgICAgIC8vIGhhbmRsZSByZWRpcmVjdCBvbiBjbGllbnQtdHJhbnNpdGlvblxuICAgICAgICAgICAgaWYgKChfX05fU1NHIHx8IF9fTl9TU1ApICYmIHByb3BzKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzLnBhZ2VQcm9wcyAmJiBwcm9wcy5wYWdlUHJvcHMuX19OX1JFRElSRUNUKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRlc3RpbmF0aW9uID0gcHJvcHMucGFnZVByb3BzLl9fTl9SRURJUkVDVDtcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgaWYgZGVzdGluYXRpb24gaXMgaW50ZXJuYWwgKHJlc29sdmVzIHRvIGEgcGFnZSkgYW5kIGF0dGVtcHRcbiAgICAgICAgICAgICAgICAgICAgLy8gY2xpZW50LW5hdmlnYXRpb24gaWYgaXQgaXMgZmFsbGluZyBiYWNrIHRvIGhhcmQgbmF2aWdhdGlvbiBpZlxuICAgICAgICAgICAgICAgICAgICAvLyBpdCdzIG5vdFxuICAgICAgICAgICAgICAgICAgICBpZiAoZGVzdGluYXRpb24uc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJzZWRIcmVmID0gKDAsIF9wYXJzZVJlbGF0aXZlVXJsKS5wYXJzZVJlbGF0aXZlVXJsKGRlc3RpbmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlZEhyZWYucGF0aG5hbWUgPSByZXNvbHZlRHluYW1pY1JvdXRlKHBhcnNlZEhyZWYucGF0aG5hbWUsIHBhZ2VzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgdXJsOiBuZXdVcmwgLCBhczogbmV3QXMgIH0gPSBwcmVwYXJlVXJsQXModGhpcywgZGVzdGluYXRpb24sIGRlc3RpbmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNoYW5nZShtZXRob2QsIG5ld1VybCwgbmV3QXMsIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gZGVzdGluYXRpb247XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgoKT0+e1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5pc1ByZXZpZXcgPSAhIXByb3BzLl9fTl9QUkVWSUVXO1xuICAgICAgICAgICAgICAgIC8vIGhhbmRsZSBTU0cgZGF0YSA0MDRcbiAgICAgICAgICAgICAgICBpZiAocHJvcHMubm90Rm91bmQgPT09IFNTR19EQVRBX05PVF9GT1VORCkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgbm90Rm91bmRSb3V0ZTtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hDb21wb25lbnQoJy80MDQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kUm91dGUgPSAnLzQwNCc7XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKF8pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kUm91dGUgPSAnL19lcnJvcic7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcm91dGVJbmZvID0gYXdhaXQgdGhpcy5nZXRSb3V0ZUluZm8obm90Rm91bmRSb3V0ZSwgbm90Rm91bmRSb3V0ZSwgcXVlcnkxLCBhcywgcmVzb2x2ZWRBcywge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2hhbGxvdzogZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdiZWZvcmVIaXN0b3J5Q2hhbmdlJywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZShtZXRob2QsIHVybCwgYXMsIG9wdGlvbnMpO1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhcHBDb21wID0gdGhpcy5jb21wb25lbnRzWycvX2FwcCddLkNvbXBvbmVudDtcbiAgICAgICAgICAgICAgICB3aW5kb3cubmV4dC5pc1ByZXJlbmRlcmVkID0gYXBwQ29tcC5nZXRJbml0aWFsUHJvcHMgPT09IGFwcENvbXAub3JpZ0dldEluaXRpYWxQcm9wcyAmJiAhcm91dGVJbmZvLkNvbXBvbmVudC5nZXRJbml0aWFsUHJvcHM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5faCAmJiBwYXRobmFtZTEgPT09ICcvX2Vycm9yJyAmJiAoKHJlZiA9IHNlbGYuX19ORVhUX0RBVEFfXy5wcm9wcykgPT09IG51bGwgfHwgcmVmID09PSB2b2lkIDAgPyB2b2lkIDAgOiAocmVmMSA9IHJlZi5wYWdlUHJvcHMpID09PSBudWxsIHx8IHJlZjEgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlZjEuc3RhdHVzQ29kZSkgPT09IDUwMCAmJiAocHJvcHMgPT09IG51bGwgfHwgcHJvcHMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHByb3BzLnBhZ2VQcm9wcykpIHtcbiAgICAgICAgICAgICAgICAvLyBlbnN1cmUgc3RhdHVzQ29kZSBpcyBzdGlsbCBjb3JyZWN0IGZvciBzdGF0aWMgNTAwIHBhZ2VcbiAgICAgICAgICAgICAgICAvLyB3aGVuIHVwZGF0aW5nIHF1ZXJ5IGluZm9ybWF0aW9uXG4gICAgICAgICAgICAgICAgcHJvcHMucGFnZVByb3BzLnN0YXR1c0NvZGUgPSA1MDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBzaGFsbG93IHJvdXRpbmcgaXMgb25seSBhbGxvd2VkIGZvciBzYW1lIHBhZ2UgVVJMIGNoYW5nZXMuXG4gICAgICAgICAgICBjb25zdCBpc1ZhbGlkU2hhbGxvd1JvdXRlID0gb3B0aW9ucy5zaGFsbG93ICYmIHRoaXMucm91dGUgPT09IHJvdXRlO1xuICAgICAgICAgICAgdmFyIF9zY3JvbGw7XG4gICAgICAgICAgICBjb25zdCBzaG91bGRTY3JvbGwgPSAoX3Njcm9sbCA9IG9wdGlvbnMuc2Nyb2xsKSAhPT0gbnVsbCAmJiBfc2Nyb2xsICE9PSB2b2lkIDAgPyBfc2Nyb2xsIDogIWlzVmFsaWRTaGFsbG93Um91dGU7XG4gICAgICAgICAgICBjb25zdCByZXNldFNjcm9sbCA9IHNob3VsZFNjcm9sbCA/IHtcbiAgICAgICAgICAgICAgICB4OiAwLFxuICAgICAgICAgICAgICAgIHk6IDBcbiAgICAgICAgICAgIH0gOiBudWxsO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5zZXQocm91dGUsIHBhdGhuYW1lMSwgcXVlcnkxLCBjbGVhbmVkQXMsIHJvdXRlSW5mbywgZm9yY2VkU2Nyb2xsICE9PSBudWxsICYmIGZvcmNlZFNjcm9sbCAhPT0gdm9pZCAwID8gZm9yY2VkU2Nyb2xsIDogcmVzZXRTY3JvbGwpLmNhdGNoKChlKT0+e1xuICAgICAgICAgICAgICAgIGlmIChlLmNhbmNlbGxlZCkgZXJyb3IgPSBlcnJvciB8fCBlO1xuICAgICAgICAgICAgICAgIGVsc2UgdGhyb3cgZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgZXJyb3IsIGNsZWFuZWRBcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLmxvY2FsZSkge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQubGFuZyA9IHRoaXMubG9jYWxlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VDb21wbGV0ZScsIGFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGNhdGNoIChlcnIxKSB7XG4gICAgICAgICAgICBpZiAoZXJyMS5jYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBlcnIxO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNoYW5nZVN0YXRlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucyA9IHtcbiAgICB9KSB7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHdpbmRvdy5oaXN0b3J5ID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5IGlzIG5vdCBhdmFpbGFibGUuYCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cuaGlzdG9yeVttZXRob2RdID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5LiR7bWV0aG9kfSBpcyBub3QgYXZhaWxhYmxlYCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgIT09ICdwdXNoU3RhdGUnIHx8ICgwLCBfdXRpbHMpLmdldFVSTCgpICE9PSBhcykge1xuICAgICAgICAgICAgdGhpcy5fc2hhbGxvdyA9IG9wdGlvbnMuc2hhbGxvdztcbiAgICAgICAgICAgIHdpbmRvdy5oaXN0b3J5W21ldGhvZF0oe1xuICAgICAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgICAgICBhcyxcbiAgICAgICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgICAgICAgIF9fTjogdHJ1ZSxcbiAgICAgICAgICAgICAgICBpZHg6IHRoaXMuX2lkeCA9IG1ldGhvZCAhPT0gJ3B1c2hTdGF0ZScgPyB0aGlzLl9pZHggOiB0aGlzLl9pZHggKyAxXG4gICAgICAgICAgICB9LCAvLyBNb3N0IGJyb3dzZXJzIGN1cnJlbnRseSBpZ25vcmVzIHRoaXMgcGFyYW1ldGVyLCBhbHRob3VnaCB0aGV5IG1heSB1c2UgaXQgaW4gdGhlIGZ1dHVyZS5cbiAgICAgICAgICAgIC8vIFBhc3NpbmcgdGhlIGVtcHR5IHN0cmluZyBoZXJlIHNob3VsZCBiZSBzYWZlIGFnYWluc3QgZnV0dXJlIGNoYW5nZXMgdG8gdGhlIG1ldGhvZC5cbiAgICAgICAgICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IaXN0b3J5L3JlcGxhY2VTdGF0ZVxuICAgICAgICAgICAgJycsIGFzKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBoYW5kbGVSb3V0ZUluZm9FcnJvcihlcnIsIHBhdGhuYW1lLCBxdWVyeSwgYXMsIHJvdXRlUHJvcHMsIGxvYWRFcnJvckZhaWwpIHtcbiAgICAgICAgaWYgKGVyci5jYW5jZWxsZWQpIHtcbiAgICAgICAgICAgIC8vIGJ1YmJsZSB1cCBjYW5jZWxsYXRpb24gZXJyb3JzXG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCgwLCBfcm91dGVMb2FkZXIpLmlzQXNzZXRFcnJvcihlcnIpIHx8IGxvYWRFcnJvckZhaWwpIHtcbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VFcnJvcicsIGVyciwgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgLy8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgcGFnZSBpdCBjb3VsZCBiZSBvbmUgb2YgZm9sbG93aW5nIHJlYXNvbnNcbiAgICAgICAgICAgIC8vICAxLiBQYWdlIGRvZXNuJ3QgZXhpc3RzXG4gICAgICAgICAgICAvLyAgMi4gUGFnZSBkb2VzIGV4aXN0IGluIGEgZGlmZmVyZW50IHpvbmVcbiAgICAgICAgICAgIC8vICAzLiBJbnRlcm5hbCBlcnJvciB3aGlsZSBsb2FkaW5nIHRoZSBwYWdlXG4gICAgICAgICAgICAvLyBTbywgZG9pbmcgYSBoYXJkIHJlbG9hZCBpcyB0aGUgcHJvcGVyIHdheSB0byBkZWFsIHdpdGggdGhpcy5cbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYXM7XG4gICAgICAgICAgICAvLyBDaGFuZ2luZyB0aGUgVVJMIGRvZXNuJ3QgYmxvY2sgZXhlY3V0aW5nIHRoZSBjdXJyZW50IGNvZGUgcGF0aC5cbiAgICAgICAgICAgIC8vIFNvIGxldCdzIHRocm93IGEgY2FuY2VsbGF0aW9uIGVycm9yIHN0b3AgdGhlIHJvdXRpbmcgbG9naWMuXG4gICAgICAgICAgICB0aHJvdyBidWlsZENhbmNlbGxhdGlvbkVycm9yKCk7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGxldCBDb21wb25lbnQxO1xuICAgICAgICAgICAgbGV0IHN0eWxlU2hlZXRzO1xuICAgICAgICAgICAgbGV0IHByb3BzO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBDb21wb25lbnQxID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2Ygc3R5bGVTaGVldHMgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgKHsgcGFnZTogQ29tcG9uZW50MSAsIHN0eWxlU2hlZXRzICB9ID0gYXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudCgnL19lcnJvcicpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHJvdXRlSW5mbyA9IHtcbiAgICAgICAgICAgICAgICBwcm9wcyxcbiAgICAgICAgICAgICAgICBDb21wb25lbnQ6IENvbXBvbmVudDEsXG4gICAgICAgICAgICAgICAgc3R5bGVTaGVldHMsXG4gICAgICAgICAgICAgICAgZXJyLFxuICAgICAgICAgICAgICAgIGVycm9yOiBlcnJcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoIXJvdXRlSW5mby5wcm9wcykge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IGF3YWl0IHRoaXMuZ2V0SW5pdGlhbFByb3BzKENvbXBvbmVudDEsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycixcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAoZ2lwRXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGluIGVycm9yIHBhZ2UgYGdldEluaXRpYWxQcm9wc2A6ICcsIGdpcEVycik7XG4gICAgICAgICAgICAgICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcm91dGVJbmZvO1xuICAgICAgICB9IGNhdGNoIChyb3V0ZUluZm9FcnIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmhhbmRsZVJvdXRlSW5mb0Vycm9yKHJvdXRlSW5mb0VyciwgcGF0aG5hbWUsIHF1ZXJ5LCBhcywgcm91dGVQcm9wcywgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYXN5bmMgZ2V0Um91dGVJbmZvKHJvdXRlLCBwYXRobmFtZSwgcXVlcnksIGFzLCByZXNvbHZlZEFzLCByb3V0ZVByb3BzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBleGlzdGluZ1JvdXRlSW5mbyA9IHRoaXMuY29tcG9uZW50c1tyb3V0ZV07XG4gICAgICAgICAgICBpZiAocm91dGVQcm9wcy5zaGFsbG93ICYmIGV4aXN0aW5nUm91dGVJbmZvICYmIHRoaXMucm91dGUgPT09IHJvdXRlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGV4aXN0aW5nUm91dGVJbmZvO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgY2FjaGVkUm91dGVJbmZvID0gZXhpc3RpbmdSb3V0ZUluZm8gJiYgJ2luaXRpYWwnIGluIGV4aXN0aW5nUm91dGVJbmZvID8gdW5kZWZpbmVkIDogZXhpc3RpbmdSb3V0ZUluZm87XG4gICAgICAgICAgICBjb25zdCByb3V0ZUluZm8gPSBjYWNoZWRSb3V0ZUluZm8gPyBjYWNoZWRSb3V0ZUluZm8gOiBhd2FpdCB0aGlzLmZldGNoQ29tcG9uZW50KHJvdXRlKS50aGVuKChyZXMpPT4oe1xuICAgICAgICAgICAgICAgICAgICBDb21wb25lbnQ6IHJlcy5wYWdlLFxuICAgICAgICAgICAgICAgICAgICBzdHlsZVNoZWV0czogcmVzLnN0eWxlU2hlZXRzLFxuICAgICAgICAgICAgICAgICAgICBfX05fU1NHOiByZXMubW9kLl9fTl9TU0csXG4gICAgICAgICAgICAgICAgICAgIF9fTl9TU1A6IHJlcy5tb2QuX19OX1NTUFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY29uc3QgeyBDb21wb25lbnQ6IENvbXBvbmVudDEgLCBfX05fU1NHICwgX19OX1NTUCAgfSA9IHJvdXRlSW5mbztcbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBpc1ZhbGlkRWxlbWVudFR5cGUgIH0gPSByZXF1aXJlKCdyZWFjdC1pcycpO1xuICAgICAgICAgICAgICAgIGlmICghaXNWYWxpZEVsZW1lbnRUeXBlKENvbXBvbmVudDEpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVGhlIGRlZmF1bHQgZXhwb3J0IGlzIG5vdCBhIFJlYWN0IENvbXBvbmVudCBpbiBwYWdlOiBcIiR7cGF0aG5hbWV9XCJgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZGF0YUhyZWY7XG4gICAgICAgICAgICBpZiAoX19OX1NTRyB8fCBfX05fU1NQKSB7XG4gICAgICAgICAgICAgICAgZGF0YUhyZWYgPSB0aGlzLnBhZ2VMb2FkZXIuZ2V0RGF0YUhyZWYoKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZSxcbiAgICAgICAgICAgICAgICAgICAgcXVlcnlcbiAgICAgICAgICAgICAgICB9KSwgcmVzb2x2ZWRBcywgX19OX1NTRywgdGhpcy5sb2NhbGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcHJvcHMgPSBhd2FpdCB0aGlzLl9nZXREYXRhKCgpPT5fX05fU1NHID8gdGhpcy5fZ2V0U3RhdGljRGF0YShkYXRhSHJlZikgOiBfX05fU1NQID8gdGhpcy5fZ2V0U2VydmVyRGF0YShkYXRhSHJlZikgOiB0aGlzLmdldEluaXRpYWxQcm9wcyhDb21wb25lbnQxLCAvLyB3ZSBwcm92aWRlIEFwcFRyZWUgbGF0ZXIgc28gdGhpcyBuZWVkcyB0byBiZSBgYW55YFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgICAgICAgICBhc1BhdGg6IGFzLFxuICAgICAgICAgICAgICAgICAgICBsb2NhbGU6IHRoaXMubG9jYWxlLFxuICAgICAgICAgICAgICAgICAgICBsb2NhbGVzOiB0aGlzLmxvY2FsZXMsXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHRMb2NhbGU6IHRoaXMuZGVmYXVsdExvY2FsZVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcm91dGVJbmZvLnByb3BzID0gcHJvcHM7XG4gICAgICAgICAgICB0aGlzLmNvbXBvbmVudHNbcm91dGVdID0gcm91dGVJbmZvO1xuICAgICAgICAgICAgcmV0dXJuIHJvdXRlSW5mbztcbiAgICAgICAgfSBjYXRjaCAoZXJyMikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlUm91dGVJbmZvRXJyb3IoZXJyMiwgcGF0aG5hbWUsIHF1ZXJ5LCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgc2V0KHJvdXRlLCBwYXRobmFtZSwgcXVlcnksIGFzLCBkYXRhLCByZXNldFNjcm9sbCkge1xuICAgICAgICB0aGlzLmlzRmFsbGJhY2sgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5yb3V0ZSA9IHJvdXRlO1xuICAgICAgICB0aGlzLnBhdGhuYW1lID0gcGF0aG5hbWU7XG4gICAgICAgIHRoaXMucXVlcnkgPSBxdWVyeTtcbiAgICAgICAgdGhpcy5hc1BhdGggPSBhcztcbiAgICAgICAgcmV0dXJuIHRoaXMubm90aWZ5KGRhdGEsIHJlc2V0U2Nyb2xsKTtcbiAgICB9XG4gICAgLyoqXG4gICAqIENhbGxiYWNrIHRvIGV4ZWN1dGUgYmVmb3JlIHJlcGxhY2luZyByb3V0ZXIgc3RhdGVcbiAgICogQHBhcmFtIGNiIGNhbGxiYWNrIHRvIGJlIGV4ZWN1dGVkXG4gICAqLyBiZWZvcmVQb3BTdGF0ZShjYikge1xuICAgICAgICB0aGlzLl9icHMgPSBjYjtcbiAgICB9XG4gICAgb25seUFIYXNoQ2hhbmdlKGFzKSB7XG4gICAgICAgIGlmICghdGhpcy5hc1BhdGgpIHJldHVybiBmYWxzZTtcbiAgICAgICAgY29uc3QgW29sZFVybE5vSGFzaCwgb2xkSGFzaF0gPSB0aGlzLmFzUGF0aC5zcGxpdCgnIycpO1xuICAgICAgICBjb25zdCBbbmV3VXJsTm9IYXNoLCBuZXdIYXNoXSA9IGFzLnNwbGl0KCcjJyk7XG4gICAgICAgIC8vIE1ha2VzIHN1cmUgd2Ugc2Nyb2xsIHRvIHRoZSBwcm92aWRlZCBoYXNoIGlmIHRoZSB1cmwvaGFzaCBhcmUgdGhlIHNhbWVcbiAgICAgICAgaWYgKG5ld0hhc2ggJiYgb2xkVXJsTm9IYXNoID09PSBuZXdVcmxOb0hhc2ggJiYgb2xkSGFzaCA9PT0gbmV3SGFzaCkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhlIHVybHMgYXJlIGNoYW5nZSwgdGhlcmUncyBtb3JlIHRoYW4gYSBoYXNoIGNoYW5nZVxuICAgICAgICBpZiAob2xkVXJsTm9IYXNoICE9PSBuZXdVcmxOb0hhc2gpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiB0aGUgaGFzaCBoYXMgY2hhbmdlZCwgdGhlbiBpdCdzIGEgaGFzaCBvbmx5IGNoYW5nZS5cbiAgICAgICAgLy8gVGhpcyBjaGVjayBpcyBuZWNlc3NhcnkgdG8gaGFuZGxlIGJvdGggdGhlIGVudGVyIGFuZFxuICAgICAgICAvLyBsZWF2ZSBoYXNoID09PSAnJyBjYXNlcy4gVGhlIGlkZW50aXR5IGNhc2UgZmFsbHMgdGhyb3VnaFxuICAgICAgICAvLyBhbmQgaXMgdHJlYXRlZCBhcyBhIG5leHQgcmVsb2FkLlxuICAgICAgICByZXR1cm4gb2xkSGFzaCAhPT0gbmV3SGFzaDtcbiAgICB9XG4gICAgc2Nyb2xsVG9IYXNoKGFzKSB7XG4gICAgICAgIGNvbnN0IFssIGhhc2hdID0gYXMuc3BsaXQoJyMnKTtcbiAgICAgICAgLy8gU2Nyb2xsIHRvIHRvcCBpZiB0aGUgaGFzaCBpcyBqdXN0IGAjYCB3aXRoIG5vIHZhbHVlIG9yIGAjdG9wYFxuICAgICAgICAvLyBUbyBtaXJyb3IgYnJvd3NlcnNcbiAgICAgICAgaWYgKGhhc2ggPT09ICcnIHx8IGhhc2ggPT09ICd0b3AnKSB7XG4gICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gRmlyc3Qgd2UgY2hlY2sgaWYgdGhlIGVsZW1lbnQgYnkgaWQgaXMgZm91bmRcbiAgICAgICAgY29uc3QgaWRFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGhhc2gpO1xuICAgICAgICBpZiAoaWRFbCkge1xuICAgICAgICAgICAgaWRFbC5zY3JvbGxJbnRvVmlldygpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIElmIHRoZXJlJ3Mgbm8gZWxlbWVudCB3aXRoIHRoZSBpZCwgd2UgY2hlY2sgdGhlIGBuYW1lYCBwcm9wZXJ0eVxuICAgICAgICAvLyBUbyBtaXJyb3IgYnJvd3NlcnNcbiAgICAgICAgY29uc3QgbmFtZUVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeU5hbWUoaGFzaClbMF07XG4gICAgICAgIGlmIChuYW1lRWwpIHtcbiAgICAgICAgICAgIG5hbWVFbC5zY3JvbGxJbnRvVmlldygpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHVybElzTmV3KGFzUGF0aCkge1xuICAgICAgICByZXR1cm4gdGhpcy5hc1BhdGggIT09IGFzUGF0aDtcbiAgICB9XG4gICAgLyoqXG4gICAqIFByZWZldGNoIHBhZ2UgY29kZSwgeW91IG1heSB3YWl0IGZvciB0aGUgZGF0YSBkdXJpbmcgcGFnZSByZW5kZXJpbmcuXG4gICAqIFRoaXMgZmVhdHVyZSBvbmx5IHdvcmtzIGluIHByb2R1Y3Rpb24hXG4gICAqIEBwYXJhbSB1cmwgdGhlIGhyZWYgb2YgcHJlZmV0Y2hlZCBwYWdlXG4gICAqIEBwYXJhbSBhc1BhdGggdGhlIGFzIHBhdGggb2YgdGhlIHByZWZldGNoZWQgcGFnZVxuICAgKi8gYXN5bmMgcHJlZmV0Y2godXJsLCBhc1BhdGggPSB1cmwsIG9wdGlvbnMgPSB7XG4gICAgfSkge1xuICAgICAgICBsZXQgcGFyc2VkID0gKDAsIF9wYXJzZVJlbGF0aXZlVXJsKS5wYXJzZVJlbGF0aXZlVXJsKHVybCk7XG4gICAgICAgIGxldCB7IHBhdGhuYW1lOiBwYXRobmFtZTIgIH0gPSBwYXJzZWQ7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5sb2NhbGUgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgcGF0aG5hbWUyID0gKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhdGhuYW1lMiwgdGhpcy5sb2NhbGVzKS5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSBwYXRobmFtZTI7XG4gICAgICAgICAgICAgICAgdXJsID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKTtcbiAgICAgICAgICAgICAgICBsZXQgcGFyc2VkQXMgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwoYXNQYXRoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBsb2NhbGVQYXRoUmVzdWx0ID0gKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhcnNlZEFzLnBhdGhuYW1lLCB0aGlzLmxvY2FsZXMpO1xuICAgICAgICAgICAgICAgIHBhcnNlZEFzLnBhdGhuYW1lID0gbG9jYWxlUGF0aFJlc3VsdC5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBvcHRpb25zLmxvY2FsZSA9IGxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGUgfHwgdGhpcy5kZWZhdWx0TG9jYWxlO1xuICAgICAgICAgICAgICAgIGFzUGF0aCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZEFzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYWdlcyA9IGF3YWl0IHRoaXMucGFnZUxvYWRlci5nZXRQYWdlTGlzdCgpO1xuICAgICAgICBsZXQgcmVzb2x2ZWRBcyA9IGFzUGF0aDtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMgJiYgYXNQYXRoLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgICAgICAgICAgbGV0IHJld3JpdGVzO1xuICAgICAgICAgICAgKHsgX19yZXdyaXRlczogcmV3cml0ZXMgIH0gPSBhd2FpdCAoMCwgX3JvdXRlTG9hZGVyKS5nZXRDbGllbnRCdWlsZE1hbmlmZXN0KCkpO1xuICAgICAgICAgICAgY29uc3QgcmV3cml0ZXNSZXN1bHQgPSAoMCwgX3Jlc29sdmVSZXdyaXRlcykuZGVmYXVsdChhZGRCYXNlUGF0aChhZGRMb2NhbGUoYXNQYXRoLCB0aGlzLmxvY2FsZSkpLCBwYWdlcywgcmV3cml0ZXMsIHBhcnNlZC5xdWVyeSwgKHApPT5yZXNvbHZlRHluYW1pY1JvdXRlKHAsIHBhZ2VzKVxuICAgICAgICAgICAgLCB0aGlzLmxvY2FsZXMpO1xuICAgICAgICAgICAgcmVzb2x2ZWRBcyA9IGRlbExvY2FsZShkZWxCYXNlUGF0aChyZXdyaXRlc1Jlc3VsdC5hc1BhdGgpLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgICAgICBpZiAocmV3cml0ZXNSZXN1bHQubWF0Y2hlZFBhZ2UgJiYgcmV3cml0ZXNSZXN1bHQucmVzb2x2ZWRIcmVmKSB7XG4gICAgICAgICAgICAgICAgLy8gaWYgdGhpcyBkaXJlY3RseSBtYXRjaGVzIGEgcGFnZSB3ZSBuZWVkIHRvIHVwZGF0ZSB0aGUgaHJlZiB0b1xuICAgICAgICAgICAgICAgIC8vIGFsbG93IHRoZSBjb3JyZWN0IHBhZ2UgY2h1bmsgdG8gYmUgbG9hZGVkXG4gICAgICAgICAgICAgICAgcGF0aG5hbWUyID0gcmV3cml0ZXNSZXN1bHQucmVzb2x2ZWRIcmVmO1xuICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHBhdGhuYW1lMjtcbiAgICAgICAgICAgICAgICB1cmwgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcGFyc2VkLnBhdGhuYW1lID0gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwYXJzZWQucGF0aG5hbWUsIHBhZ2VzKTtcbiAgICAgICAgICAgIGlmIChwYXJzZWQucGF0aG5hbWUgIT09IHBhdGhuYW1lMikge1xuICAgICAgICAgICAgICAgIHBhdGhuYW1lMiA9IHBhcnNlZC5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSBwYXRobmFtZTI7XG4gICAgICAgICAgICAgICAgdXJsID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCByb3V0ZSA9ICgwLCBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCkucmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aG5hbWUyKTtcbiAgICAgICAgLy8gUHJlZmV0Y2ggaXMgbm90IHN1cHBvcnRlZCBpbiBkZXZlbG9wbWVudCBtb2RlIGJlY2F1c2UgaXQgd291bGQgdHJpZ2dlciBvbi1kZW1hbmQtZW50cmllc1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgIHRoaXMucGFnZUxvYWRlci5faXNTc2cocm91dGUpLnRoZW4oKGlzU3NnKT0+e1xuICAgICAgICAgICAgICAgIHJldHVybiBpc1NzZyA/IHRoaXMuX2dldFN0YXRpY0RhdGEodGhpcy5wYWdlTG9hZGVyLmdldERhdGFIcmVmKHVybCwgcmVzb2x2ZWRBcywgdHJ1ZSwgdHlwZW9mIG9wdGlvbnMubG9jYWxlICE9PSAndW5kZWZpbmVkJyA/IG9wdGlvbnMubG9jYWxlIDogdGhpcy5sb2NhbGUpKSA6IGZhbHNlO1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB0aGlzLnBhZ2VMb2FkZXJbb3B0aW9ucy5wcmlvcml0eSA/ICdsb2FkUGFnZScgOiAncHJlZmV0Y2gnXShyb3V0ZSksIFxuICAgICAgICBdKTtcbiAgICB9XG4gICAgYXN5bmMgZmV0Y2hDb21wb25lbnQocm91dGUpIHtcbiAgICAgICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgICAgICBjb25zdCBjYW5jZWwgPSB0aGlzLmNsYyA9ICgpPT57XG4gICAgICAgICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBjb21wb25lbnRSZXN1bHQgPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIubG9hZFBhZ2Uocm91dGUpO1xuICAgICAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihgQWJvcnQgZmV0Y2hpbmcgY29tcG9uZW50IGZvciByb3V0ZTogXCIke3JvdXRlfVwiYCk7XG4gICAgICAgICAgICBlcnJvci5jYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNhbmNlbCA9PT0gdGhpcy5jbGMpIHtcbiAgICAgICAgICAgIHRoaXMuY2xjID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29tcG9uZW50UmVzdWx0O1xuICAgIH1cbiAgICBfZ2V0RGF0YShmbikge1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IGNhbmNlbCA9ICgpPT57XG4gICAgICAgICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLmNsYyA9IGNhbmNlbDtcbiAgICAgICAgcmV0dXJuIGZuKCkudGhlbigoZGF0YSk9PntcbiAgICAgICAgICAgIGlmIChjYW5jZWwgPT09IHRoaXMuY2xjKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jbGMgPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycjIgPSBuZXcgRXJyb3IoJ0xvYWRpbmcgaW5pdGlhbCBwcm9wcyBjYW5jZWxsZWQnKTtcbiAgICAgICAgICAgICAgICBlcnIyLmNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyMjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgX2dldFN0YXRpY0RhdGEoZGF0YUhyZWYpIHtcbiAgICAgICAgY29uc3QgeyBocmVmOiBjYWNoZUtleSAgfSA9IG5ldyBVUkwoZGF0YUhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicgJiYgIXRoaXMuaXNQcmV2aWV3ICYmIHRoaXMuc2RjW2NhY2hlS2V5XSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh0aGlzLnNkY1tjYWNoZUtleV0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmZXRjaE5leHREYXRhKGRhdGFIcmVmLCB0aGlzLmlzU3NyKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgdGhpcy5zZGNbY2FjaGVLZXldID0gZGF0YTtcbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgX2dldFNlcnZlckRhdGEoZGF0YUhyZWYpIHtcbiAgICAgICAgY29uc3QgeyBocmVmOiByZXNvdXJjZUtleSAgfSA9IG5ldyBVUkwoZGF0YUhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgaWYgKHRoaXMuc2RyW3Jlc291cmNlS2V5XSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2RyW3Jlc291cmNlS2V5XTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5zZHJbcmVzb3VyY2VLZXldID0gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZiwgdGhpcy5pc1NzcikudGhlbigoZGF0YSk9PntcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnNkcltyZXNvdXJjZUtleV07XG4gICAgICAgICAgICByZXR1cm4gZGF0YTtcbiAgICAgICAgfSkuY2F0Y2goKGVycjIpPT57XG4gICAgICAgICAgICBkZWxldGUgdGhpcy5zZHJbcmVzb3VyY2VLZXldO1xuICAgICAgICAgICAgdGhyb3cgZXJyMjtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGdldEluaXRpYWxQcm9wcyhDb21wb25lbnQsIGN0eCkge1xuICAgICAgICBjb25zdCB7IENvbXBvbmVudDogQXBwMSAgfSA9IHRoaXMuY29tcG9uZW50c1snL19hcHAnXTtcbiAgICAgICAgY29uc3QgQXBwVHJlZSA9IHRoaXMuX3dyYXBBcHAoQXBwMSk7XG4gICAgICAgIGN0eC5BcHBUcmVlID0gQXBwVHJlZTtcbiAgICAgICAgcmV0dXJuICgwLCBfdXRpbHMpLmxvYWRHZXRJbml0aWFsUHJvcHMoQXBwMSwge1xuICAgICAgICAgICAgQXBwVHJlZSxcbiAgICAgICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgICAgIHJvdXRlcjogdGhpcyxcbiAgICAgICAgICAgIGN0eFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgYWJvcnRDb21wb25lbnRMb2FkKGFzLCByb3V0ZVByb3BzKSB7XG4gICAgICAgIGlmICh0aGlzLmNsYykge1xuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgYnVpbGRDYW5jZWxsYXRpb25FcnJvcigpLCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICB0aGlzLmNsYygpO1xuICAgICAgICAgICAgdGhpcy5jbGMgPSBudWxsO1xuICAgICAgICB9XG4gICAgfVxuICAgIG5vdGlmeShkYXRhLCByZXNldFNjcm9sbCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zdWIoZGF0YSwgdGhpcy5jb21wb25lbnRzWycvX2FwcCddLkNvbXBvbmVudCwgcmVzZXRTY3JvbGwpO1xuICAgIH1cbn1cblJvdXRlci5ldmVudHMgPSAoMCwgX21pdHQpLmRlZmF1bHQoKTtcbmV4cG9ydHMuZGVmYXVsdCA9IFJvdXRlcjtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyLmpzLm1hcCIsImltcG9ydCB7IEZvb3RlciwgSGVhZCwgTmF2QmFyIH0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cydcclxuaW1wb3J0IHN0eWxlZCwgeyBjc3MsIGtleWZyYW1lcyB9IGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcidcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7TWVkaWFIZWFkLCBDYXRlZ29yeUJhcn0gZnJvbSAnLi4vLi4vLi4vY29tcG9uZW50cy9NZWRpYUNvbXBvbmVudCc7XHJcbmNvbnN0IEJveCA9IHN0eWxlZC5kaXZgXHJcbiAgICBwYWRkaW5nLXRvcDogMTB2aDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHdpZHRoOiAxMDB2dztcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgYmFja2dyb3VuZDogYW50aXF1ZXdoaXRlO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuYFxyXG5jb25zdCBNZWRpYV9Dc3MgPSBjc3NgXHJcbiAgICBodG1sLFxyXG4gICAgYm9keSB7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IGFudGlxdWV3aGl0ZTtcclxuICAgIH1cclxuXHJcbiAgICAuY29uZGl0aW9uIHtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XHJcbiAgICB9XHJcblxyXG4gICAgLmNvbmRpdGlvbjpob3ZlcntcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcblxyXG4gICAgKiB7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgfVxyXG4gICAgXHJcbmBcclxuY29uc3QgSW1nQ3NzID0gY3NzYFxyXG5cclxuLmltZ0dhbGxlcnl7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIG1hcmdpbjogMTBweDtcclxufVxyXG5cclxuLkdhbENvbnRhaW5lcntcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHBhZGRpbmctdG9wOiAxMHZoO1xyXG59XHJcbi5jYXRlZ29yeUNvbnRhaW5lcntcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcbmBcclxuY29uc3QgRG9udEhhdmUgPSBzdHlsZWQuaDFgXHJcbiAgICBmb250LXNpemU6IDRyZW07XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuXHJcbmBcclxuY29uc3QgTWVkaWFDYXRlZ29yeSA9ICgpID0+IHtcclxuICAgIGxldCBkYXRhID0gcmVxdWlyZShcIi4uLy4uLy4uL3B1YmxpYy9tZWRpYV9jb250ZW50L2NvbnRlbnRzLmpzb25cIilcclxuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gICAgY29uc3QgeyBjYXRlZ29yeSB9ID0gcm91dGVyLnF1ZXJ5O1xyXG4gICAgY29uc3Qgc2l6ZSA9IFtbXCIyMHZ3XCIsXCIyMHZ3XCIgXSwgW1wiMjB2d1wiLCBcIjMwdndcIl0sIFtcIjMwdndcIiwgXCIzMHZ3XCJdXTtcclxuICAgIGlmKHJvdXRlci5hc1BhdGggPT0gXCIvbWVkaWEvd2FsbHBhcGVyXCIpe1xyXG4gICAgICAgIGRhdGEgPSBkYXRhLndhbGxwYXBlcjtcclxuICAgIH1cclxuICAgIGVsc2UgaWYocm91dGVyLmFzUGF0aCA9PSBcIi9tZWRpYS92aWRlb1wiKXtcclxuICAgICAgICBkYXRhID0gZGF0YS52aWRlbztcclxuICAgIH1cclxuICAgIGVsc2UgaWYocm91dGVyLmFzUGF0aCA9PSBcIi9tZWRpYS9zY3JlZW5zaG90XCIpe1xyXG4gICAgICAgIGRhdGEgPSBkYXRhLnNjcmVlbnNob3Q7XHJcbiAgICB9XHJcbiAgICBlbHNlIGlmKHJvdXRlci5hc1BhdGggPT0gXCIvbWVkaWEvYXJ0d29ya1wiKXtcclxuICAgICAgICBkYXRhID0gZGF0YS5hcnR3b3JrO1xyXG4gICAgfVxyXG4gICAgZWxzZSBpZihyb3V0ZXIuYXNQYXRoID09IFwiL21lZGlhL2xvZ29cIil7XHJcbiAgICAgICAgZGF0YSA9IGRhdGEubG9nbztcclxuICAgIH1cclxuICAgIGVsc2UgaWYocm91dGVyLmFzUGF0aCA9PSBcIi9tZWRpYS9jb250ZW50X2NyZWF0b3JcIil7XHJcbiAgICAgICAgZGF0YSA9IGRhdGEuY29udGVudF9jcmVhdG9yO1xyXG4gICAgfVxyXG4gICAgZWxzZXtcclxuICAgICAgICBkYXRhID0gZGF0YS53YWxscGFwZXIuY29uY2F0KGRhdGEudmlkZW8sIGRhdGEuc2NyZWVuc2hvdCwgZGF0YS5hcnR3b3JrLCBkYXRhLmxvZ28sIGRhdGEuY29udGVudF9jcmVhdG9yKTtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8SGVhZCB0aXRsZT1cIlZBTE9SQU5UOiDguYDguIHguKHguKLguLTguIfguJvguLfguJnguIjguLLguIEgUmlvdCBHYW1lcyDguYPguJnguKPguLnguJvguYHguJrguJogNXY1IOC4l+C4teC5iOC4guC4seC4muC5gOC4hOC4peC4t+C5iOC4reC4meC5guC4lOC4ouC4leC4seC4p+C4peC4sOC4hOC4o+C4meC4seC4geC4ouC4tOC4h+C4m+C4t+C4meC4nOC4ueC5ieC4oeC4suC4geC4hOC4p+C4suC4oeC4quC4suC4oeC4suC4o+C4llwiIC8+XHJcbiAgICAgICAgICAgIDxOYXZCYXIgLz5cclxuICAgICAgICAgICAgPHN0eWxlPnsgTWVkaWFfQ3NzIH08L3N0eWxlPlxyXG4gICAgICAgICAgICA8c3R5bGU+eyBJbWdDc3MgfTwvc3R5bGU+XHJcbiAgICAgICAgICAgIDxNZWRpYUhlYWQvPlxyXG4gICAgICAgICAgICA8Qm94PlxyXG5cclxuICAgICAgICAgICAgICAgIDxDYXRlZ29yeUJhci8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIkdhbENvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS5tYXAoKCBpbWFnZSwgaW5kZXggKT0+e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGltZ1NpemUgPSBzaXplW01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSozKV1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoPGRpdiBrZXk9eyBpbmRleCB9IGNsYXNzTmFtZT1cImltZ0dhbGxlcnlcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBgdXJsKCR7aW1hZ2UucGF0aH0pYCwgd2lkdGg6IGAke2ltZ1NpemVbMF19YCwgaGVpZ2h0OiBgJHtpbWdTaXplWzFdfWB9fSA+PC9kaXY+KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSAgICBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPERvbnRIYXZlIHN0eWxlPXt7IGRpc3BsYXk6IGAke2RhdGEubGVuZ3RoID09IDA/XCJibG9ja1wiOiBcIm5vbmVcIn1gfX0+4LiB4Lil4Lix4Lia4Lih4Liy4LiV4Lij4Lin4LiI4Liq4Lit4Lia4LmD4Lir4Lih4LmI4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiH4LmD4LiZ4Lig4Liy4Lii4Lir4Lil4Lix4LiHITwvRG9udEhhdmU+XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICA8Rm9vdGVyIC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1lZGlhQ2F0ZWdvcnk7XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcbmltcG9ydCB7IE5hdkl0ZW1MYXlvdXQgfSBmcm9tICcuL05hdkl0ZW1MYXlvdXQnXHJcblxyXG5jb25zdCBTdHlsZWRDYXJldERvd24gPSBzdHlsZWQuc3ZnYFxyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgd2lkdGg6IDE2cHg7XHJcbiAgICBoZWlnaHQ6IDE2cHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDZweDtcclxuICAgIGZpbGw6ICM3RTdFN0U7XHJcbiAgICAke05hdkl0ZW1MYXlvdXR9OmhvdmVyICYge1xyXG4gICAgICAgIGZpbGw6IHdoaXRlO1xyXG4gICAgfVxyXG5gXHJcblxyXG5jb25zdCBDYXJldERvd24gPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRDYXJldERvd24gdmlld0JveD1cIjAgMCAxNiAxNlwiPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwiTTcuMjQ3IDExLjE0IDIuNDUxIDUuNjU4QzEuODg1IDUuMDEzIDIuMzQ1IDQgMy4yMDQgNGg5LjU5MmExIDEgMCAwIDEgLjc1MyAxLjY1OWwtNC43OTYgNS40OGExIDEgMCAwIDEtMS41MDYgMHpcIi8+XHJcbiAgICAgICAgPC9TdHlsZWRDYXJldERvd24+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENhcmV0RG93bjsiLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBTdHlsZWRMaSB9IGZyb20gJy4vU3R5bGVkTGknXHJcblxyXG5jb25zdCBTdHlsZWRBcnJvd1VwID0gc3R5bGVkLnN2Z2BcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHdpZHRoOiAxNnB4O1xyXG4gICAgaGVpZ2h0OiAxNnB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDJweDtcclxuICAgIHBhZGRpbmctdG9wOiA2cHg7XHJcbiAgICBmaWxsOiAjN0U3RTdFO1xyXG4gICAgJHtTdHlsZWRMaX06aG92ZXIgJiB7XHJcbiAgICAgICAgZmlsbDogd2hpdGU7XHJcbiAgICB9XHJcbmBcclxuXHJcbmNvbnN0IERyb3Bkb3duQXJyb3dVcCA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFN0eWxlZEFycm93VXAgdmlld0JveD1cIjAgMCAxNiAxNlwiPlxyXG4gICAgICAgICAgICA8cGF0aCBmaWxsUnVsZT1cImV2ZW5vZGRcIiBkPVwiTTE0IDIuNWEuNS41IDAgMCAwLS41LS41aC02YS41LjUgMCAwIDAgMCAxaDQuNzkzTDIuMTQ2IDEzLjE0NmEuNS41IDAgMCAwIC43MDguNzA4TDEzIDMuNzA3VjguNWEuNS41IDAgMCAwIDEgMHYtNnpcIi8+XHJcbiAgICAgICAgPC9TdHlsZWRBcnJvd1VwPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEcm9wZG93bkFycm93VXA7IiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuaW1wb3J0IHsgTmF2SXRlbUxheW91dCB9IGZyb20gJy4vTmF2SXRlbUxheW91dCdcclxuXHJcbmNvbnN0IFN0eWxlZEFycm93VXAgPSBzdHlsZWQuc3ZnYFxyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgd2lkdGg6IDE2cHg7XHJcbiAgICBoZWlnaHQ6IDE2cHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMnB4O1xyXG4gICAgcGFkZGluZy10b3A6IDZweDtcclxuICAgIGZpbGw6ICM3RTdFN0U7XHJcbiAgICAke05hdkl0ZW1MYXlvdXR9OmhvdmVyICYge1xyXG4gICAgICAgIGZpbGw6IHdoaXRlO1xyXG4gICAgfVxyXG5gXHJcblxyXG5jb25zdCBOYXZBcnJvd1VwID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkQXJyb3dVcCB2aWV3Qm94PVwiMCAwIDE2IDE2XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGZpbGxSdWxlPVwiZXZlbm9kZFwiIGQ9XCJNMTQgMi41YS41LjUgMCAwIDAtLjUtLjVoLTZhLjUuNSAwIDAgMCAwIDFoNC43OTNMMi4xNDYgMTMuMTQ2YS41LjUgMCAwIDAgLjcwOC43MDhMMTMgMy43MDdWOC41YS41LjUgMCAwIDAgMSAwdi02elwiLz5cclxuICAgICAgICA8L1N0eWxlZEFycm93VXA+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5hdkFycm93VXA7IiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmV4cG9ydCBjb25zdCBOYXZJdGVtTGF5b3V0ID0gc3R5bGVkLmRpdmBcclxuICAgIGZvbnQtZmFtaWx5OiAnQmFpIEphbWp1cmVlJywgc2Fucy1zZXJpZjtcclxuICAgIHBhZGRpbmctbGVmdDogMWVtO1xyXG4gICAgcGFkZGluZy1yaWdodDogMWVtO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgbGluZS1oZWlnaHQ6IDgwcHg7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDRweDtcclxuICAgIG1hcmdpbi1yaWdodDogNHB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMnB4IHJnYigyNTUsIDcwLCA4NSkgc29saWQ7XHJcbiAgICB9XHJcbmAiLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBSaW90R2FtZXNCYXIgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL05hdi9SaW90R2FtZXNCYXInXHJcblxyXG5jb25zdCBTdHlsZWRMb2dvID0gc3R5bGVkLnN2Z2BcclxuICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgaGVpZ2h0OiAyNHB4O1xyXG5gXHJcblxyXG5jb25zdCBSaW90TG9nb1dyYXBwZXIgPSBzdHlsZWQuYnV0dG9uYFxyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgbWFyZ2luOiAwIDEycHg7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuYFxyXG5cclxuY29uc3QgU3R5bGVkQ2FyZXREb3duID0gc3R5bGVkLnN2Z2BcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHdpZHRoOiAxNnB4O1xyXG4gICAgaGVpZ2h0OiAxNnB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDhweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDRweDtcclxuICAgIHBhZGRpbmctdG9wOiA2cHg7XHJcbiAgICBmaWxsOiAjN0U3RTdFO1xyXG4gICAgJHtSaW90TG9nb1dyYXBwZXJ9OmhvdmVyICYge1xyXG4gICAgICAgIGZpbGw6IHdoaXRlO1xyXG4gICAgfVxyXG5gXHJcblxyXG5jb25zdCBDYXJldERvd24gPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRDYXJldERvd24gdmlld0JveD1cIjAgMCAxNiAxNlwiPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwiTTcuMjQ3IDExLjE0IDIuNDUxIDUuNjU4QzEuODg1IDUuMDEzIDIuMzQ1IDQgMy4yMDQgNGg5LjU5MmExIDEgMCAwIDEgLjc1MyAxLjY1OWwtNC43OTYgNS40OGExIDEgMCAwIDEtMS41MDYgMHpcIi8+XHJcbiAgICAgICAgPC9TdHlsZWRDYXJldERvd24+XHJcbiAgICApXHJcbn1cclxuXHJcbmNvbnN0IFJpb3RMb2dvID0gKHsgaXNHYW1lQmFyT3Blbiwgb25DbGljaywgc3RhdGVDb250cm9sIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPFJpb3RMb2dvV3JhcHBlciBvbkNsaWNrPXtvbkNsaWNrfT5cclxuICAgICAgICAgICAgICAgIDxTdHlsZWRMb2dvIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwiI2ZmZlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTIuNTM0IDIxLjc3bC0xLjA5LTIuODEgMTAuNTIuNTQtLjQ1MSA0LjV6TTE1LjA2IDBMLjMwNyA2Ljk2OSAyLjU5IDE3LjQ3MUg1LjZsLS41Mi03LjUxMi40NjEtLjE0NCAxLjgxIDcuNjU2aDMuMTI2bC0uMTE2LTkuMTUuNDYyLS4xNDQgMS41ODIgOS4yOTRoMy4zMWwuNzgtMTEuMDUzLjQ2Mi0uMTQ0LjgyIDExLjE5N2g0LjM3NmwxLjU0LTE1LjM3WlwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L1N0eWxlZExvZ28+XHJcbiAgICAgICAgICAgICAgICA8Q2FyZXREb3duIC8+XHJcbiAgICAgICAgICAgIDwvUmlvdExvZ29XcmFwcGVyPlxyXG4gICAgICAgICAgICA8UmlvdEdhbWVzQmFyIGlzT3Blbj17aXNHYW1lQmFyT3Blbn0gc3RhdGVDb250cm9sPXtzdGF0ZUNvbnRyb2x9IC8+XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJpb3RMb2dvOyIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcclxuXHJcbmV4cG9ydCBjb25zdCBTdHlsZWRMaSA9IHN0eWxlZC5saWBcclxuICAgIGxpbmUtaGVpZ2h0OiA1MHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyNHB4O1xyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzMzMztcclxuICAgIH1cclxuYCIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcclxuXHJcbmV4cG9ydCBjb25zdCBTdHlsZWRMaW5rID0gc3R5bGVkLmFgXHJcbiAgICBmb250LWZhbWlseTogJ0JhaSBKYW1qdXJlZScsIHNhbnMtc2VyaWY7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEycHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMnB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgbGluZS1oZWlnaHQ6IDgwcHg7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgbWFyZ2luOiAwIC44NWVtO1xyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMnB4IHJnYigyNTUsIDcwLCA4NSkgc29saWQ7XHJcbiAgICB9XHJcbmAiLCJpbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcblxyXG5jb25zdCBTdHlsZWRMb2dvID0gc3R5bGVkLnN2Z2BcclxuICAgIHdpZHRoOiAzNXB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogMjIuNXB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDRweDtcclxuICAgIG1hcmdpbi1yaWdodDogNHB4O1xyXG5gXHJcblxyXG5jb25zdCBWYWxvcmFudExvZ28gPSAoeyBocmVmIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPExpbmsgaHJlZj17aHJlZn0gcGFzc0hyZWY+XHJcbiAgICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICAgICAgPFN0eWxlZExvZ28gdmlld0JveD1cIjAgMCAxMDAgMTAwXCIgZmlsbD1cIiNmZmZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTk5LjI1IDQ4LjY2VjEwLjI4YzAtLjU5LS43NS0uODYtMS4xMi0uMzlsLTQxLjkyIDUyLjRhLjYyNy42MjcgMCAwMC40OSAxLjAyaDMwLjI5Yy44MiAwIDEuNTktLjM3IDIuMS0xLjAxbDkuNTctMTEuOTZjLjM4LS40OC41OS0xLjA3LjU5LTEuNjh6TTEuMTcgNTAuMzRMMzIuNjYgODkuN2MuNTEuNjQgMS4yOCAxLjAxIDIuMSAxLjAxaDMwLjI5Yy41MyAwIC44Mi0uNjEuNDktMS4wMkwxLjcgOS44OWMtLjM3LS40Ni0xLjEyLS4yLTEuMTIuMzl2MzguMzhjMCAuNjEuMjEgMS4yLjU5IDEuNjh6XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvU3R5bGVkTG9nbz5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVmFsb3JhbnRMb2dvOyIsImV4cG9ydCB7TmF2SXRlbUxheW91dH0gZnJvbSAnLi9OYXZJdGVtTGF5b3V0J1xyXG5leHBvcnQge2RlZmF1bHQgYXMgTmF2QXJyb3dVcH0gZnJvbSAnLi9OYXZBcnJvd1VwJ1xyXG5leHBvcnQge2RlZmF1bHQgYXMgRHJvcGRvd25BcnJvd1VwfSBmcm9tICcuL0Ryb3Bkb3duQXJyb3dVcCdcclxuZXhwb3J0IHtkZWZhdWx0IGFzIENhcmV0RG93bn0gZnJvbSAnLi9DYXJldERvd24nXHJcbmV4cG9ydCB7U3R5bGVkTGlua30gZnJvbSAnLi9TdHlsZWRMaW5rJ1xyXG5leHBvcnQge1N0eWxlZExpfSBmcm9tICcuL1N0eWxlZExpJ1xyXG5leHBvcnQge2RlZmF1bHQgYXMgVmFsb3JhbnRMb2dvfSBmcm9tICcuL1ZhbG9yYW50TG9nbydcclxuZXhwb3J0IHtkZWZhdWx0IGFzIFJpb3RMb2dvfSBmcm9tICcuL1Jpb3RMb2dvJ1xyXG4iLCIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJzdHJva2VcIjogXCJOZXdzX3N0cm9rZV9fMUdlQm9cIixcblx0XCJzbGlkZXJOYXZcIjogXCJOZXdzX3NsaWRlck5hdl9fMkJIZjZcIixcblx0XCJ0ZXh0QmFja2dyb3VuZDFcIjogXCJOZXdzX3RleHRCYWNrZ3JvdW5kMV9fanB1dnpcIixcblx0XCJ0ZXh0QmFja2dyb3VuZDJcIjogXCJOZXdzX3RleHRCYWNrZ3JvdW5kMl9falY1cUFcIlxufTtcbiIsIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcInN0cm9rZVwiOiBcIm1lZGlhX3N0cm9rZV9fbkNvMjdcIlxufTtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L2NsaWVudC9saW5rJylcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zZXJ2ZXIvZGVub3JtYWxpemUtcGFnZS1wYXRoLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zaGFyZWQvbGliL2kxOG4vbm9ybWFsaXplLWxvY2FsZS1wYXRoLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zaGFyZWQvbGliL21pdHQuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyLWNvbnRleHQuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2dldC1hc3NldC1wYXRoLWZyb20tcm91dGUuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL2lzLWR5bmFtaWMuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3BhcnNlLXJlbGF0aXZlLXVybC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcXVlcnlzdHJpbmcuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3JvdXRlLW1hdGNoZXIuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvcm91dGVyL3V0aWxzL3JvdXRlLXJlZ2V4LmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zaGFyZWQvbGliL3V0aWxzLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L3JvdXRlclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1pc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3R5bGVkLWNvbXBvbmVudHNcIik7IiwiLyogKGlnbm9yZWQpICovIl0sIm5hbWVzIjpbInN0eWxlZCIsIlN0eWxlZEJ1dHRvbldyYXBwZXIiLCJidXR0b24iLCJDb250ZW50IiwiZGl2IiwicHJvcHMiLCJpc1doaXRlIiwiaXNCb3JkZXJlZCIsIldoaXRlQm94IiwiQnV0dG9uQm9yZGVyIiwiVG9wQm9yZGVyIiwiQm90dG9tQm9yZGVyIiwiQnV0dG9uIiwiY2hpbGRyZW4iLCJTdHlsZWRMb2dvIiwic3ZnIiwiRmlzdExvZ28iLCJGb290ZXJMYXlvdXQiLCJSaW90R2FtZXNMb2dvIiwiQnV0dG9uV3JhcHBlciIsIkZhY2Vib29rSWNvbiIsIkluc3RhZ3JhbUljb24iLCJZb3V0dWJlSWNvbiIsIlAiLCJwIiwiUmVzZXJ2ZWQiLCJMb2dvV3JhcHBlciIsIlVuZGVybGluZSIsIkxpbmtXcmFwcGVyIiwiU29jaWFsV3JhcHBlciIsIkZvb3RlciIsImZvb3RlciIsImRlZmF1bHQiLCJXcmFwcGVyIiwiYSIsImhyZWYiLCJOZXh0SGVhZCIsIkhlYWQiLCJ0aXRsZSIsIkxpbmsiLCJGaWx0ZXJEcm9wYm94IiwidXNlUm91dGVyIiwiQmFyIiwidWwiLCJDYXRlZ29yeSIsImxpIiwiQ2F0ZWdvcnlCYXIiLCJyb3V0ZXIiLCJjYXRlZ29yeSIsInF1ZXJ5IiwiY29sb3IiLCJib3JkZXJCb3R0b20iLCJ1c2VTdGF0ZSIsIlJlYWN0IiwiVGV4dCIsIkJveCIsInR5cGUiLCJvblNlbGVjdENoYW5nZSIsImUiLCJsb2NhbGUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInB1c2giLCJwYXRobmFtZSIsImFzUGF0aCIsInNjcm9sbCIsImNvbnZlcnQiLCJpdGVtTGlzdCIsIm9wZW5Ecm9wYm94IiwiY29uc29sZSIsImxvZyIsIm1hcCIsIml0ZW0iLCJpbmRleCIsIlR4dCIsIlRleHRCZ0NvbnRhaW5lciIsInN0eWxlcyIsIk1lZGlhSGVhZGVyIiwiTWVkaWFUb3BpY0NvbnRpYW5lciIsIk1lZGlhVG9waWMiLCJoMSIsIk1lZGlhVG9waWNDb250ZW50IiwiTWVkaWFIZWFkZXJJbWciLCJzcGFuIiwiQm90TGVmdEltZyIsIkxpbmUiLCJNZWRpYUhlYWQiLCJoZWlnaHQiLCJvdmVyZmxvdyIsImJhY2tncm91bmQiLCJ6SW5kZXgiLCJ0b3AiLCJ0ZXh0QmFja2dyb3VuZCIsInN0cm9rZSIsImZvbnRTaXplIiwiTGFuZ1NlbGVjdG9yIiwiTGFuZ0J1dHRvbiIsImlzT3BlbiIsIm9uQ2xpY2siLCJTdHlsZWRMYXlvdXQiLCJTdHlsZWRDaGVja2VkSWNvbiIsIkNoZWNrZWRJY29uIiwiU3R5bGVkVHJpYW5nbGVVcCIsIlRyaWFuZ2xlVXAiLCJMYW5ndWFnZVN1cHBvcnQiLCJTdHlsZUxhbmdJdGVtIiwic2VsZWN0ZWQiLCJMYW5nSXRlbSIsImkiLCJOYXZMYXlvdXQiLCJOYXZJdGVtIiwiRHJvcGRvd24iLCJFeHRlcm5hbExpIiwiTGkiLCJFeHRlcm5hbCIsIlZhbG9yYW50TG9nbyIsIlJpb3RMb2dvIiwiU2VwYXJhdG9yIiwiUGxheUJ1dHRvbiIsIlJpZ2h0TmF2IiwiTmF2QmFyIiwib3BlblJpb3RHYW1lQmFyIiwic2V0T3BlblJpb3RHYW1lQmFyIiwib3BlbkxhbmdTZWxlY3RvciIsInNldE9wZW5MYW5nU2VsZWN0b3IiLCJvcGVuUGxheVBvcHVwIiwic2V0T3BlblBsYXlQb3B1cCIsImhhbmRsZVJpb3RHYW1lQmFyQ2xpY2siLCJwcmV2ZW50RGVmYXVsdCIsImhhbmRsZUxhbmdDbGljayIsImhhbmRsZVBsYXlQb3B1cENsaWNrIiwiUmlvdEdhbWVCYXJTdGF0ZUNvbnRyb2wiLCJzdGF0ZSIsIlBsYXlQb3B1cFN0YXRlQ29udHJvbCIsIkRyb3Bkb3duQXJyb3dVcCIsIlN0eWxlZExpIiwiTmF2SXRlbUxheW91dCIsIkNhcmV0RG93biIsIlVsIiwiTmF2QXJyb3dVcCIsIkV4dGVybmFsTGluayIsIlN0eWxlZExpbmsiLCJOYXYiLCJuYXYiLCJOYXZTZXBhcmF0b3IiLCJQbGF5UG9wdXAiLCJzdGF0ZUNvbnRyb2wiLCJQb3B1cFdyYXBwZXIiLCJEaW1tZWRCYWNrZ3JvdW5kIiwiUG9wdXAiLCJQb3B1cFRpdGxlV3JhcHBlciIsIlBvcHVwQnV0dG9uV3JhcHBlciIsIkJ1dHRvbkxhYmVsIiwiRXhpdEJ1dHRvbldyYXBwZXIiLCJFeGl0QnV0dG9uIiwiU3ZnRXhpdCIsIkV4aXRCdXR0b25TdHlsZSIsIkdhbWVzQmFyIiwiR2FtZXNCYXJXcmFwcGVyIiwiVGl0bGVSaW90R2FtZXMiLCJSaW90R2FtZXNCYXIiLCJjc3MiLCJUZXh0QkciLCJ0ZXh0QmFja2dyb3VuZDEiLCJ0ZXh0QmFja2dyb3VuZDIiLCJTdHlsZWRUaXRsZSIsInRleHRDb2xvciIsIlRpdGxlIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJleHBvcnRzIiwiX3JlYWN0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfcm91dGVyIiwiX3JvdXRlcjEiLCJfdXNlSW50ZXJzZWN0aW9uIiwib2JqIiwiX19lc01vZHVsZSIsInByZWZldGNoZWQiLCJwcmVmZXRjaCIsImFzIiwib3B0aW9ucyIsImlzTG9jYWxVUkwiLCJjYXRjaCIsImVyciIsImN1ckxvY2FsZSIsImlzTW9kaWZpZWRFdmVudCIsImV2ZW50IiwiY3VycmVudFRhcmdldCIsIm1ldGFLZXkiLCJjdHJsS2V5Iiwic2hpZnRLZXkiLCJhbHRLZXkiLCJuYXRpdmVFdmVudCIsIndoaWNoIiwibGlua0NsaWNrZWQiLCJyZXBsYWNlIiwic2hhbGxvdyIsIm5vZGVOYW1lIiwiaW5kZXhPZiIsImNyZWF0ZVByb3BFcnJvciIsImFyZ3MiLCJFcnJvciIsImtleSIsImV4cGVjdGVkIiwiYWN0dWFsIiwicmVxdWlyZWRQcm9wc0d1YXJkIiwicmVxdWlyZWRQcm9wcyIsImtleXMiLCJmb3JFYWNoIiwiXyIsIm9wdGlvbmFsUHJvcHNHdWFyZCIsInBhc3NIcmVmIiwib3B0aW9uYWxQcm9wcyIsInZhbFR5cGUiLCJoYXNXYXJuZWQiLCJ1c2VSZWYiLCJjdXJyZW50Iiwid2FybiIsInVzZU1lbW8iLCJyZXNvbHZlZEhyZWYiLCJyZXNvbHZlZEFzIiwicmVzb2x2ZUhyZWYiLCJjcmVhdGVFbGVtZW50IiwiY2hpbGQiLCJDaGlsZHJlbiIsIm9ubHkiLCJjaGlsZFJlZiIsInJlZiIsInNldEludGVyc2VjdGlvblJlZiIsImlzVmlzaWJsZSIsInVzZUludGVyc2VjdGlvbiIsInJvb3RNYXJnaW4iLCJzZXRSZWYiLCJ1c2VDYWxsYmFjayIsImVsIiwidXNlRWZmZWN0Iiwic2hvdWxkUHJlZmV0Y2giLCJpc1ByZWZldGNoZWQiLCJjaGlsZFByb3BzIiwiZGVmYXVsdFByZXZlbnRlZCIsIm9uTW91c2VFbnRlciIsInByaW9yaXR5IiwibG9jYWxlRG9tYWluIiwiaXNMb2NhbGVEb21haW4iLCJnZXREb21haW5Mb2NhbGUiLCJsb2NhbGVzIiwiZG9tYWluTG9jYWxlcyIsImFkZEJhc2VQYXRoIiwiYWRkTG9jYWxlIiwiZGVmYXVsdExvY2FsZSIsImNsb25lRWxlbWVudCIsIl9kZWZhdWx0IiwicmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2giLCJub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaCIsInBhdGgiLCJlbmRzV2l0aCIsInNsaWNlIiwicHJvY2VzcyIsImVudiIsIl9fTkVYVF9UUkFJTElOR19TTEFTSCIsInRlc3QiLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwiY2FuY2VsSWRsZUNhbGxiYWNrIiwic2VsZiIsImJpbmQiLCJ3aW5kb3ciLCJjYiIsInN0YXJ0IiwiRGF0ZSIsIm5vdyIsInNldFRpbWVvdXQiLCJkaWRUaW1lb3V0IiwidGltZVJlbWFpbmluZyIsIk1hdGgiLCJtYXgiLCJpZCIsImNsZWFyVGltZW91dCIsIm1hcmtBc3NldEVycm9yIiwiaXNBc3NldEVycm9yIiwiZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCIsImNyZWF0ZVJvdXRlTG9hZGVyIiwiX2dldEFzc2V0UGF0aEZyb21Sb3V0ZSIsIl9yZXF1ZXN0SWRsZUNhbGxiYWNrIiwiTVNfTUFYX0lETEVfREVMQVkiLCJ3aXRoRnV0dXJlIiwiZ2VuZXJhdG9yIiwiZW50cnkiLCJnZXQiLCJmdXR1cmUiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlc29sdmVyIiwicHJvbSIsInNldCIsInRoZW4iLCJoYXNQcmVmZXRjaCIsImxpbmsiLCJkb2N1bWVudCIsIk1TSW5wdXRNZXRob2RDb250ZXh0IiwiZG9jdW1lbnRNb2RlIiwicmVsTGlzdCIsInN1cHBvcnRzIiwiY2FuUHJlZmV0Y2giLCJwcmVmZXRjaFZpYURvbSIsInJlcyIsInJlaiIsInF1ZXJ5U2VsZWN0b3IiLCJyZWwiLCJjcm9zc09yaWdpbiIsIl9fTkVYVF9DUk9TU19PUklHSU4iLCJvbmxvYWQiLCJvbmVycm9yIiwiaGVhZCIsImFwcGVuZENoaWxkIiwiQVNTRVRfTE9BRF9FUlJPUiIsIlN5bWJvbCIsImFwcGVuZFNjcmlwdCIsInNyYyIsInNjcmlwdCIsInJlamVjdCIsImJvZHkiLCJkZXZCdWlsZFByb21pc2UiLCJyZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0IiwibXMiLCJjYW5jZWxsZWQiLCJyIiwiX19CVUlMRF9NQU5JRkVTVCIsIm9uQnVpbGRNYW5pZmVzdCIsIl9fQlVJTERfTUFOSUZFU1RfQ0IiLCJnZXRGaWxlc0ZvclJvdXRlIiwiYXNzZXRQcmVmaXgiLCJyb3V0ZSIsInNjcmlwdHMiLCJlbmNvZGVVUkkiLCJtYW5pZmVzdCIsImFsbEZpbGVzIiwiZmlsdGVyIiwidiIsImVudHJ5cG9pbnRzIiwiTWFwIiwibG9hZGVkU2NyaXB0cyIsInN0eWxlU2hlZXRzIiwicm91dGVzIiwibWF5YmVFeGVjdXRlU2NyaXB0IiwiZmV0Y2hTdHlsZVNoZWV0IiwiZmV0Y2giLCJvayIsInRleHQiLCJjb250ZW50Iiwid2hlbkVudHJ5cG9pbnQiLCJvbkVudHJ5cG9pbnQiLCJleGVjdXRlIiwiZm4iLCJjb21wb25lbnQiLCJlcnJvciIsImlucHV0Iiwib2xkIiwibG9hZFJvdXRlIiwicm91dGVGaWxlc1Byb21pc2UiLCJhbGwiLCJoYXMiLCJlbnRyeXBvaW50IiwiZmluYWxseSIsImFzc2lnbiIsImNuIiwibmF2aWdhdG9yIiwiY29ubmVjdGlvbiIsInNhdmVEYXRhIiwiZWZmZWN0aXZlVHlwZSIsIm91dHB1dCIsImVudW1lcmFibGUiLCJfd2l0aFJvdXRlciIsImNyZWF0ZVJvdXRlciIsIm1ha2VQdWJsaWNSb3V0ZXJJbnN0YW5jZSIsIl9yb3V0ZXJDb250ZXh0Iiwic2luZ2xldG9uUm91dGVyIiwicmVhZHlDYWxsYmFja3MiLCJyZWFkeSIsInVybFByb3BlcnR5RmllbGRzIiwicm91dGVyRXZlbnRzIiwiY29yZU1ldGhvZEZpZWxkcyIsImV2ZW50cyIsImZpZWxkIiwiZ2V0Um91dGVyIiwib24iLCJldmVudEZpZWxkIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzdWJzdHJpbmciLCJfc2luZ2xldG9uUm91dGVyIiwibWVzc2FnZSIsInN0YWNrIiwidXNlQ29udGV4dCIsIlJvdXRlckNvbnRleHQiLCJpbnN0YW5jZSIsInByb3BlcnR5IiwiQXJyYXkiLCJpc0FycmF5IiwiaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIiLCJJbnRlcnNlY3Rpb25PYnNlcnZlciIsImRpc2FibGVkIiwiaXNEaXNhYmxlZCIsInVub2JzZXJ2ZSIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwidW5kZWZpbmVkIiwidGFnTmFtZSIsIm9ic2VydmUiLCJpZGxlQ2FsbGJhY2siLCJlbGVtZW50IiwiY2FsbGJhY2siLCJvYnNlcnZlciIsImVsZW1lbnRzIiwiY3JlYXRlT2JzZXJ2ZXIiLCJkZWxldGUiLCJzaXplIiwiZGlzY29ubmVjdCIsIm9ic2VydmVycyIsImVudHJpZXMiLCJpc0ludGVyc2VjdGluZyIsImludGVyc2VjdGlvblJhdGlvIiwid2l0aFJvdXRlciIsIkNvbXBvc2VkQ29tcG9uZW50IiwiV2l0aFJvdXRlcldyYXBwZXIiLCJnZXRJbml0aWFsUHJvcHMiLCJvcmlnR2V0SW5pdGlhbFByb3BzIiwibmFtZSIsImRpc3BsYXlOYW1lIiwiZGVsTG9jYWxlIiwiaGFzQmFzZVBhdGgiLCJkZWxCYXNlUGF0aCIsImludGVycG9sYXRlQXMiLCJfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCIsIl9yb3V0ZUxvYWRlciIsIl9kZW5vcm1hbGl6ZVBhZ2VQYXRoIiwiX25vcm1hbGl6ZUxvY2FsZVBhdGgiLCJfbWl0dCIsIl91dGlscyIsIl9pc0R5bmFtaWMiLCJfcGFyc2VSZWxhdGl2ZVVybCIsIl9xdWVyeXN0cmluZyIsIl9yZXNvbHZlUmV3cml0ZXMiLCJfcm91dGVNYXRjaGVyIiwiX3JvdXRlUmVnZXgiLCJkZXRlY3REb21haW5Mb2NhbGUiLCJfX05FWFRfSTE4Tl9TVVBQT1JUIiwiYmFzZVBhdGgiLCJfX05FWFRfUk9VVEVSX0JBU0VQQVRIIiwiYnVpbGRDYW5jZWxsYXRpb25FcnJvciIsImFkZFBhdGhQcmVmaXgiLCJwcmVmaXgiLCJzdGFydHNXaXRoIiwicGF0aE5vUXVlcnlIYXNoIiwibm9ybWFsaXplTG9jYWxlUGF0aCIsImRldGVjdGVkTG9jYWxlIiwiZGV0ZWN0ZWREb21haW4iLCJodHRwIiwiZG9tYWluIiwicGF0aExvd2VyIiwidG9Mb3dlckNhc2UiLCJsb2NhbGVMb3dlciIsImxlbmd0aCIsInN1YnN0ciIsInF1ZXJ5SW5kZXgiLCJoYXNoSW5kZXgiLCJ1cmwiLCJsb2NhdGlvbk9yaWdpbiIsImdldExvY2F0aW9uT3JpZ2luIiwicmVzb2x2ZWQiLCJVUkwiLCJvcmlnaW4iLCJhc1BhdGhuYW1lIiwiaW50ZXJwb2xhdGVkUm91dGUiLCJkeW5hbWljUmVnZXgiLCJnZXRSb3V0ZVJlZ2V4IiwiZHluYW1pY0dyb3VwcyIsImdyb3VwcyIsImR5bmFtaWNNYXRjaGVzIiwiZ2V0Um91dGVNYXRjaGVyIiwicGFyYW1zIiwiZXZlcnkiLCJwYXJhbSIsInJlcGVhdCIsIm9wdGlvbmFsIiwicmVwbGFjZWQiLCJzZWdtZW50IiwiZW5jb2RlVVJJQ29tcG9uZW50Iiwiam9pbiIsInJlc3VsdCIsIm9taXRQYXJtc0Zyb21RdWVyeSIsImZpbHRlcmVkUXVlcnkiLCJpbmNsdWRlcyIsInJlc29sdmVBcyIsImJhc2UiLCJ1cmxBc1N0cmluZyIsImZvcm1hdFdpdGhWYWxpZGF0aW9uIiwidXJsUHJvdG9NYXRjaCIsIm1hdGNoIiwidXJsQXNTdHJpbmdOb1Byb3RvIiwidXJsUGFydHMiLCJzcGxpdCIsIm5vcm1hbGl6ZWRVcmwiLCJub3JtYWxpemVSZXBlYXRlZFNsYXNoZXMiLCJmaW5hbFVybCIsImludGVycG9sYXRlZEFzIiwiaXNEeW5hbWljUm91dGUiLCJzZWFyY2hQYXJhbXMiLCJzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5IiwiaGFzaCIsInN0cmlwT3JpZ2luIiwicHJlcGFyZVVybEFzIiwiaHJlZkhhZE9yaWdpbiIsImFzSGFkT3JpZ2luIiwicHJlcGFyZWRVcmwiLCJwcmVwYXJlZEFzIiwicmVzb2x2ZUR5bmFtaWNSb3V0ZSIsInBhZ2VzIiwiY2xlYW5QYXRobmFtZSIsImRlbm9ybWFsaXplUGFnZVBhdGgiLCJzb21lIiwicGFnZSIsInJlIiwibWFudWFsU2Nyb2xsUmVzdG9yYXRpb24iLCJfX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OIiwiaGlzdG9yeSIsInNlc3Npb25TdG9yYWdlIiwic2V0SXRlbSIsInJlbW92ZUl0ZW0iLCJuIiwiU1NHX0RBVEFfTk9UX0ZPVU5EIiwiZmV0Y2hSZXRyeSIsImF0dGVtcHRzIiwiY3JlZGVudGlhbHMiLCJzdGF0dXMiLCJqc29uIiwiZGF0YSIsIm5vdEZvdW5kIiwiZmV0Y2hOZXh0RGF0YSIsImRhdGFIcmVmIiwiaXNTZXJ2ZXJSZW5kZXIiLCJSb3V0ZXIiLCJjb25zdHJ1Y3RvciIsInBhdGhuYW1lMSIsInF1ZXJ5MSIsImFzMSIsImluaXRpYWxQcm9wcyIsInBhZ2VMb2FkZXIiLCJBcHAiLCJ3cmFwQXBwIiwiQ29tcG9uZW50IiwiQ29tcG9uZW50MSIsImVycjEiLCJzdWJzY3JpcHRpb24iLCJpc0ZhbGxiYWNrIiwiaXNQcmV2aWV3Iiwic2RjIiwic2RyIiwiX2lkeCIsIm9uUG9wU3RhdGUiLCJjaGFuZ2VTdGF0ZSIsImdldFVSTCIsIl9fTiIsImZvcmNlZFNjcm9sbCIsImlkeCIsIkpTT04iLCJzdHJpbmdpZnkiLCJ4IiwicGFnZVhPZmZzZXQiLCJ5IiwicGFnZVlPZmZzZXQiLCJnZXRJdGVtIiwicGFyc2UiLCJwYXJzZVJlbGF0aXZlVXJsIiwiaXNTc3IiLCJfYnBzIiwiY2hhbmdlIiwiX3NoYWxsb3ciLCJjb21wb25lbnRzIiwiaW5pdGlhbCIsIl9fTl9TU0ciLCJfX05fU1NQIiwiYXV0b0V4cG9ydER5bmFtaWMiLCJfX05FWFRfREFUQV9fIiwiYXV0b0V4cG9ydCIsInN1YiIsImNsYyIsIl93cmFwQXBwIiwiaXNSZWFkeSIsImdzc3AiLCJnaXAiLCJhcHBHaXAiLCJnc3AiLCJsb2NhdGlvbiIsInNlYXJjaCIsIl9fTkVYVF9IQVNfUkVXUklURVMiLCJob3N0bmFtZSIsIl9zaG91bGRSZXNvbHZlSHJlZiIsImFkZEV2ZW50TGlzdGVuZXIiLCJzY3JvbGxSZXN0b3JhdGlvbiIsInJlbG9hZCIsImJhY2siLCJtZXRob2QiLCJzaG91bGRSZXNvbHZlSHJlZiIsIl9oIiwicHJldkxvY2FsZSIsInBhcnNlZEFzIiwibG9jYWxlUGF0aFJlc3VsdCIsImRpZE5hdmlnYXRlIiwiYXNOb0Jhc2VQYXRoIiwiU1QiLCJwZXJmb3JtYW5jZSIsIm1hcmsiLCJyb3V0ZVByb3BzIiwiX2luRmxpZ2h0Um91dGUiLCJhYm9ydENvbXBvbmVudExvYWQiLCJjbGVhbmVkQXMiLCJsb2NhbGVDaGFuZ2UiLCJvbmx5QUhhc2hDaGFuZ2UiLCJlbWl0Iiwic2Nyb2xsVG9IYXNoIiwibm90aWZ5IiwicGFyc2VkIiwicmV3cml0ZXMiLCJnZXRQYWdlTGlzdCIsIl9fcmV3cml0ZXMiLCJ1cmxJc05ldyIsInJld3JpdGVzUmVzdWx0IiwibWF0Y2hlZFBhZ2UiLCJyb3V0ZVJlZ2V4Iiwicm91dGVNYXRjaCIsInNob3VsZEludGVycG9sYXRlIiwibWlzc2luZ1BhcmFtcyIsInJlZjEiLCJyb3V0ZUluZm8iLCJnZXRSb3V0ZUluZm8iLCJwYWdlUHJvcHMiLCJfX05fUkVESVJFQ1QiLCJkZXN0aW5hdGlvbiIsInBhcnNlZEhyZWYiLCJuZXdVcmwiLCJuZXdBcyIsIl9fTl9QUkVWSUVXIiwibm90Rm91bmRSb3V0ZSIsImZldGNoQ29tcG9uZW50IiwiYXBwQ29tcCIsIm5leHQiLCJpc1ByZXJlbmRlcmVkIiwic3RhdHVzQ29kZSIsImlzVmFsaWRTaGFsbG93Um91dGUiLCJfc2Nyb2xsIiwic2hvdWxkU2Nyb2xsIiwicmVzZXRTY3JvbGwiLCJkb2N1bWVudEVsZW1lbnQiLCJsYW5nIiwiaGFuZGxlUm91dGVJbmZvRXJyb3IiLCJsb2FkRXJyb3JGYWlsIiwiZ2lwRXJyIiwicm91dGVJbmZvRXJyIiwiZXhpc3RpbmdSb3V0ZUluZm8iLCJjYWNoZWRSb3V0ZUluZm8iLCJtb2QiLCJpc1ZhbGlkRWxlbWVudFR5cGUiLCJnZXREYXRhSHJlZiIsIl9nZXREYXRhIiwiX2dldFN0YXRpY0RhdGEiLCJfZ2V0U2VydmVyRGF0YSIsImVycjIiLCJiZWZvcmVQb3BTdGF0ZSIsIm9sZFVybE5vSGFzaCIsIm9sZEhhc2giLCJuZXdVcmxOb0hhc2giLCJuZXdIYXNoIiwic2Nyb2xsVG8iLCJpZEVsIiwiZ2V0RWxlbWVudEJ5SWQiLCJzY3JvbGxJbnRvVmlldyIsIm5hbWVFbCIsImdldEVsZW1lbnRzQnlOYW1lIiwicGF0aG5hbWUyIiwiX2lzU3NnIiwiaXNTc2ciLCJjYW5jZWwiLCJjb21wb25lbnRSZXN1bHQiLCJsb2FkUGFnZSIsImNhY2hlS2V5IiwicmVzb3VyY2VLZXkiLCJjdHgiLCJBcHAxIiwiQXBwVHJlZSIsImxvYWRHZXRJbml0aWFsUHJvcHMiLCJrZXlmcmFtZXMiLCJNZWRpYV9Dc3MiLCJJbWdDc3MiLCJEb250SGF2ZSIsIk1lZGlhQ2F0ZWdvcnkiLCJ3YWxscGFwZXIiLCJ2aWRlbyIsInNjcmVlbnNob3QiLCJhcnR3b3JrIiwibG9nbyIsImNvbnRlbnRfY3JlYXRvciIsImNvbmNhdCIsImltYWdlIiwiaW1nU2l6ZSIsImZsb29yIiwicmFuZG9tIiwid2lkdGgiLCJkaXNwbGF5IiwiU3R5bGVkQ2FyZXREb3duIiwiU3R5bGVkQXJyb3dVcCIsIlJpb3RMb2dvV3JhcHBlciIsImlzR2FtZUJhck9wZW4iXSwic291cmNlUm9vdCI6IiJ9