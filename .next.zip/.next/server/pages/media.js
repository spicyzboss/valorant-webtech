(() => {
var exports = {};
exports.id = "pages/media";
exports.ids = ["pages/media"];
exports.modules = {

/***/ "./components/Button/Button.jsx":
/*!**************************************!*\
  !*** ./components/Button/Button.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Button\\Button.jsx";


const StyledButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    border: none;
    width: 270px;
    height: 68px;
    background: none;
    padding: 6px;
    cursor: pointer;
    margin: 0;
    position: relative;
`;
const Content = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    background-color: ${props => props.isWhite ? "#ece8e1" : "#ff4655"};
    height: 100%;
    width: 100%;
    font-family: 'Bai Jamjuree', sans-serif;
    font-weight: 500;
    color: ${props => props.isWhite ? "#0f1923" : "white"};
    transition: background ease-in .2s, border .2s;
    &:hover {
        background: #0f1923;
        outline: ${props => props.isBordered ? `solid ${props.isWhite ? "#ece8e144" : "#ff465544"} 1px` : "none"};
        color: white;
    }
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
`;
const WhiteBox = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    position: absolute;
    background-color: #0f1923;
    width: 5px;
    height: 5px;
    right: 0;
    bottom: 0;
    transition: background ease-in .3s;
    ${Content}:hover & {
        background-color: white;
    }
`;
const ButtonBorder = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    border-left: solid #bdbcb7 1px;
    border-right: solid #bdbcb7 1px;
    left: 0;
    width: 100%;
    height: 29px;
    position: absolute;
`;
const TopBorder = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(ButtonBorder)`
    border-top: solid #bdbcb7 1px;
    top: 0;
`;
const BottomBorder = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(ButtonBorder)`
    border-bottom: solid #bdbcb7 1px;
    bottom: 0;
`;

const Button = ({
  children,
  isWhite,
  isBordered
}) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledButtonWrapper, {
  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TopBorder, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 67,
    columnNumber: 9
  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(BottomBorder, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 68,
    columnNumber: 9
  }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Content, {
    isWhite: isWhite,
    isBordered: isBordered,
    children: [children, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(WhiteBox, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 69,
    columnNumber: 9
  }, undefined)]
}, void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 66,
  columnNumber: 5
}, undefined);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);

/***/ }),

/***/ "./components/Button/index.js":
/*!************************************!*\
  !*** ./components/Button/index.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Button": () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ "./components/Button/Button.jsx");


/***/ }),

/***/ "./components/Footer/FistLogo.jsx":
/*!****************************************!*\
  !*** ./components/Footer/FistLogo.jsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\FistLogo.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 30px;
    height: 30px;
    margin-right: 6px;
`;

const FistLogo = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 24 24",
    fill: "#E6E6E6",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "M12.534 21.77l-1.09-2.81 10.52.54-.451 4.5zM15.06 0L.307 6.969 2.59 17.471H5.6l-.52-7.512.461-.144 1.81 7.656h3.126l-.116-9.15.462-.144 1.582 9.294h3.31l.78-11.053.462-.144.82 11.197h4.376l1.54-15.37Z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FistLogo);

/***/ }),

/***/ "./components/Footer/Footer.jsx":
/*!**************************************!*\
  !*** ./components/Footer/Footer.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _FooterLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FooterLayout */ "./components/Footer/FooterLayout.jsx");
/* harmony import */ var _RiotGamesLogo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./RiotGamesLogo */ "./components/Footer/RiotGamesLogo.jsx");
/* harmony import */ var _FistLogo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FistLogo */ "./components/Footer/FistLogo.jsx");
/* harmony import */ var _LinkHover__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./LinkHover */ "./components/Footer/LinkHover.jsx");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Icon */ "./components/Footer/Icon/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\Footer.jsx";







const P = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
    user-select: none;
    font-size: 12px;
`;
const Reserved = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(P)`
    max-width: 500px;
    text-align: center;
    cursor: default;
`;
const LogoWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    display: flex;
    cursor: pointer;
`;
const Underline = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(P)`
    text-decoration: underline;
    cursor: pointer;
`;
const LinkWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    display: flex;
    column-gap: 12px;
`;
const SocialWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    display: flex;
    column-gap: 24px;
`;

const Footer = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_FooterLayout__WEBPACK_IMPORTED_MODULE_1__.FooterLayout, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_LinkHover__WEBPACK_IMPORTED_MODULE_4__.default, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(P, {
        children: "\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E40\u0E01\u0E21"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(LogoWrapper, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_FistLogo__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_RiotGamesLogo__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(SocialWrapper, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_Icon__WEBPACK_IMPORTED_MODULE_5__.FacebookIcon, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_Icon__WEBPACK_IMPORTED_MODULE_5__.YoutubeIcon, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_Icon__WEBPACK_IMPORTED_MODULE_5__.InstagramIcon, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Reserved, {
      children: "\xA9 \u0E2A\u0E07\u0E27\u0E19\u0E25\u0E34\u0E02\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E15\u0E32\u0E21\u0E01\u0E0F\u0E2B\u0E21\u0E32\u0E22 \u0E1E.\u0E28. 2563 \u0E1A\u0E23\u0E34\u0E29\u0E31\u0E17 Riot, VALORANT \u0E41\u0E25\u0E30\u0E42\u0E25\u0E42\u0E01\u0E49\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32 \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E1A\u0E23\u0E34\u0E01\u0E32\u0E23\u0E41\u0E25\u0E30/\u0E2B\u0E23\u0E37\u0E2D \u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E01\u0E32\u0E23\u0E04\u0E49\u0E32\u0E08\u0E14\u0E17\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E02\u0E49\u0E2D\u0E07 \u0E16\u0E37\u0E2D\u0E40\u0E1B\u0E47\u0E19\u0E01\u0E23\u0E23\u0E21\u0E2A\u0E34\u0E17\u0E18\u0E34\u0E4C\u0E02\u0E2D\u0E07 Riot Games, Inc."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(LinkWrapper, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Underline, {
        children: "\u0E19\u0E42\u0E22\u0E1A\u0E32\u0E22\u0E04\u0E27\u0E32\u0E21\u0E40\u0E1B\u0E47\u0E19\u0E2A\u0E48\u0E27\u0E19\u0E15\u0E31\u0E27"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Underline, {
        children: "\u0E02\u0E49\u0E2D\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(Underline, {
        children: "\u0E01\u0E32\u0E23\u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E04\u0E38\u0E01\u0E01\u0E35\u0E49"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 41,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

/***/ }),

/***/ "./components/Footer/FooterLayout.jsx":
/*!********************************************!*\
  !*** ./components/Footer/FooterLayout.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FooterLayout": () => (/* binding */ FooterLayout)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const FooterLayout = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().footer)`
    width: 100%;
    height: 570px;
    background-color: #111;
    display: flex;
    flex-direction: column;
    align-items: center;
    color: #7e7e7e;
    fill: #7e7e7e;
    row-gap: 32px;
    padding: 28px;
    font-family: 'Bai Jamjuree', sans-serif;
`;

/***/ }),

/***/ "./components/Footer/Icon/FacebookIcon.jsx":
/*!*************************************************!*\
  !*** ./components/Footer/Icon/FacebookIcon.jsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\Icon\\FacebookIcon.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 24px;
    height: 24px;
    transition: fill .3s;
    cursor: pointer;
    &:hover {
        fill: white;
    }
`;

const FacebookIcon = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FacebookIcon);

/***/ }),

/***/ "./components/Footer/Icon/InstagramIcon.jsx":
/*!**************************************************!*\
  !*** ./components/Footer/Icon/InstagramIcon.jsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\Icon\\InstagramIcon.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 24px;
    height: 24px;
    transition: fill .3s;
    cursor: pointer;
    &:hover {
        fill: white;
    }
`;

const InstagramIcon = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 24 24",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12zm2.829-17.698c-.739-.034-.96-.04-2.829-.04-1.87 0-2.09.006-2.829.04-.682.031-1.053.145-1.3.241-.326.127-.56.278-.805.523a2.171 2.171 0 00-.523.805c-.096.247-.21.618-.24 1.3-.035.739-.042.96-.042 2.829 0 1.87.007 2.09.041 2.829.031.682.145 1.053.241 1.3.127.326.278.56.523.804.246.245.479.397.805.524.247.096.618.21 1.3.24.738.035.96.042 2.829.042 1.87 0 2.09-.008 2.829-.041.682-.031 1.053-.145 1.3-.241.326-.127.56-.278.804-.524.245-.245.397-.478.524-.805.096-.246.21-.617.24-1.3.035-.738.042-.959.042-2.828 0-1.87-.008-2.09-.041-2.829-.031-.682-.145-1.053-.241-1.3a2.164 2.164 0 00-.524-.805 2.172 2.172 0 00-.805-.523c-.246-.096-.617-.21-1.3-.24zm-5.715-1.26C9.86 5.008 10.099 5 12 5c1.901 0 2.14.008 2.886.042.745.034 1.254.153 1.7.325.46.18.85.419 1.24.808.389.389.628.78.807 1.24.173.445.291.954.325 1.699.035.746.043.985.043 2.886 0 1.901-.009 2.14-.043 2.886-.034.745-.152 1.254-.325 1.7a3.43 3.43 0 01-.807 1.24c-.39.389-.78.628-1.24.807-.445.173-.955.291-1.7.325-.746.034-.985.042-2.886.042-1.9 0-2.14-.008-2.886-.042-.745-.034-1.254-.152-1.7-.325a3.43 3.43 0 01-1.239-.808 3.428 3.428 0 01-.807-1.24c-.173-.445-.292-.954-.326-1.699C5.008 14.14 5 13.901 5 12c0-1.901.008-2.14.042-2.886.034-.745.153-1.254.326-1.7.178-.46.418-.85.807-1.239.389-.39.78-.628 1.24-.807.445-.173.954-.292 1.699-.326zM12 8.405a3.594 3.594 0 100 7.19 3.594 3.594 0 000-7.19zm0 5.928a2.333 2.333 0 110-4.666 2.333 2.333 0 010 4.666zm4.577-6.07a.84.84 0 11-1.68 0 .84.84 0 011.68 0z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InstagramIcon);

/***/ }),

/***/ "./components/Footer/Icon/YoutubeIcon.jsx":
/*!************************************************!*\
  !*** ./components/Footer/Icon/YoutubeIcon.jsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\Icon\\YoutubeIcon.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 24px;
    height: 24px;
    transition: fill .3s;
    cursor: pointer;
    &:hover {
        fill: white;
    }
`;

const YoutubeIcon = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 24 24",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12zm5.47-16.231c.602.148 1.077.583 1.237 1.136C19 9.908 19 12 19 12s0 2.092-.293 3.095c-.16.553-.635.988-1.238 1.136C16.38 16.5 12 16.5 12 16.5s-4.378 0-5.47-.268c-.602-.149-1.077-.584-1.237-1.137C5 14.092 5 12 5 12s0-2.092.293-3.095c.16-.553.635-.988 1.237-1.136C7.622 7.5 12 7.5 12 7.5s4.378 0 5.47.269zM14.226 12l-3.659-1.9v3.8l3.66-1.9z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (YoutubeIcon);

/***/ }),

/***/ "./components/Footer/Icon/index.js":
/*!*****************************************!*\
  !*** ./components/Footer/Icon/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FacebookIcon": () => (/* reexport safe */ _FacebookIcon__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "InstagramIcon": () => (/* reexport safe */ _InstagramIcon__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "YoutubeIcon": () => (/* reexport safe */ _YoutubeIcon__WEBPACK_IMPORTED_MODULE_2__.default)
/* harmony export */ });
/* harmony import */ var _FacebookIcon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FacebookIcon */ "./components/Footer/Icon/FacebookIcon.jsx");
/* harmony import */ var _InstagramIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./InstagramIcon */ "./components/Footer/Icon/InstagramIcon.jsx");
/* harmony import */ var _YoutubeIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./YoutubeIcon */ "./components/Footer/Icon/YoutubeIcon.jsx");




/***/ }),

/***/ "./components/Footer/LinkHover.jsx":
/*!*****************************************!*\
  !*** ./components/Footer/LinkHover.jsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\LinkHover.jsx";


const Wrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().a)`
    transition: color .3s;
    cursor: pointer;
    &:hover {
        color: white;
    }
    font-weight: 700;
`;

const ButtonWrapper = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Wrapper, {
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonWrapper);

/***/ }),

/***/ "./components/Footer/RiotGamesLogo.jsx":
/*!*********************************************!*\
  !*** ./components/Footer/RiotGamesLogo.jsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Footer\\RiotGamesLogo.jsx";


const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 60px;
    height: 30px;
`;

const RiotGamesLogo = ({
  href
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLogo, {
    viewBox: "0 0 600 305.41",
    fill: "#E6E6E6",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m404.82 290.61-.39225-11.291 39.032-.46128.35814-12.305-39.851-.49538-.39793-11.431 52.503-1.2291.43285-13.5h-70.833l-2.1115 65.51h74.251l-.52138-13.525zm-353.18-24.086-.83372 12.256 19.699.65862-.24932 12.442-41.232-1.209 1.7963-35.938 56.692-1.3121-.81934-13.525h-73.228l-6.5665 65.51h83.436l-2.1631-39.519zm516.81 5.0681-54.116-9.1478.2347-7.0907 51.77-1.931-1.3064-13.525h-66.547l-3.4036 33.955 55.016 9.566.24932 6.2399-57.242 2.2232-1.4038 13.525h80.115z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m347.63 305.41-6.5664-65.51h-18.851l-27.082 31.228-27.085-31.228h-18.851l-6.5664 65.51h22.146l2.1201-42.499 28.237 28.973 28.231-28.973 2.1258 42.499z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m254.55 0h-44.324l-4.0338 202.59h53.552z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m391.89 158.52-48.907 1.5786-1.6215-119.15 51.151 1.5499zm42.862-158.43h-138.19l-5.3804 202.5h153.38z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m600 44.336-4.9363-44.335h-136.15l1.1517 39.493 43.547 1.507 4.4635 161.59h53.66l-16.052-160.14z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m73.64 41.444 42.711-1.4296 4.8675 40.364-49.297 23.286zm49.899 161.15h58.167l-37.909-90.925 30.251-16.528-20.668-95.139h-148.48l-4.8875 43.905 33.216-1.1088-16.018 159.8h51.984l1.4067-50.939 37.456-20.462z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      d: "m151.82 275.89 4.5037-21.433 21.625-.97698 4.518 21.507zm37.044 29.526h22.424l-17.743-65.513h-52.615l-17.74 65.513h22.424l3.4723-16.528 36.402.47021z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RiotGamesLogo);

/***/ }),

/***/ "./components/Footer/index.js":
/*!************************************!*\
  !*** ./components/Footer/index.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Footer": () => (/* reexport safe */ _Footer__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Footer */ "./components/Footer/Footer.jsx");


/***/ }),

/***/ "./components/Head.jsx":
/*!*****************************!*\
  !*** ./components/Head.jsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Head.jsx";



const Head = ({
  title
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_0___default()), {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      charSet: "UTF-8"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      httpEquiv: "X-UA-Compatible",
      content: "IE=edge"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("meta", {
      name: "viewport",
      content: "width=device-width, initial-scale=1.0"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("link", {
      rel: "shortcut icon",
      href: "favicon.svg",
      type: "image/x-svg"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("title", {
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Head);

/***/ }),

/***/ "./components/MediaComponent/CategoryBar.jsx":
/*!***************************************************!*\
  !*** ./components/MediaComponent/CategoryBar.jsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! . */ "./components/MediaComponent/index.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\CategoryBar.jsx";






const Bar = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().ul)`
    height: 10vh;
    position: relative;
    display: block;
    }
`;
const Category = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().li)`
float: left;
margin-left: 50px;
list-style-type: none; 
height: 5vh;
`;

const CategoryBar = () => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  const {
    category
  } = router.query;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Bar, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "all" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "all" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/all",
          scroll: false,
          children: "\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 151
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "wallpaper" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "wallpaper" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/wallpaper",
          scroll: false,
          children: "\u0E27\u0E2D\u0E25\u0E40\u0E1B\u0E40\u0E1B\u0E2D\u0E23\u0E4C"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 163
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "video" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "video" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/video",
          scroll: false,
          children: "\u0E27\u0E34\u0E14\u0E35\u0E42\u0E2D"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 155
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "screenshot" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "screenshot" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/screenshot",
          scroll: false,
          children: "\u0E2A\u0E01\u0E23\u0E35\u0E19\u0E0A\u0E47\u0E2D\u0E15"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 165
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "artwork" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "artwork" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/artwork",
          scroll: false,
          children: "\u0E2D\u0E32\u0E23\u0E4C\u0E17\u0E40\u0E27\u0E34\u0E23\u0E4C\u0E01"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 159
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "logo" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "logo" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/logo",
          scroll: false,
          children: "\u0E42\u0E25\u0E42\u0E01\u0E49"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 153
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Category, {
        style: {
          color: `${category == "content_creator" ? "black" : "#8b978f"}`,
          borderBottom: `${category == "content_creator" ? "1px solid black" : "none"}`
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
          href: "/media/content_creator",
          scroll: false,
          children: "\u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C\u0E04\u0E23\u0E35\u0E40\u0E2D\u0E40\u0E15\u0E2D\u0E23\u0E4C"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 175
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_2__.FilterDropbox, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 9
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryBar);

/***/ }),

/***/ "./components/MediaComponent/FilterDropbox.jsx":
/*!*****************************************************!*\
  !*** ./components/MediaComponent/FilterDropbox.jsx ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\FilterDropbox.jsx";







const Text = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "FilterDropbox__Text",
  componentId: "sc-3iobc0-0"
})(["text-align:center;position:relative;color:black;background:antiquewhite;width:10vw;height:10vh;"]);
const Box = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "FilterDropbox__Box",
  componentId: "sc-3iobc0-1"
})(["width:10vw;height:10vh;position:absolute;right:10vw;background:none;top:0;cursor:pointer;border:1px solid #8b978f;"]);

const FilterDropbox = () => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  let {
    category,
    type
  } = router.query;

  if (typeof type === 'undefined') {
    type = `all`;
  }

  const onSelectChange = e => {
    let locale = e.target.value;

    if (typeof category === 'undefined') {
      category = `all`;
      locale = `media/${category}/${locale}`;
      router.push(locale);
    } else if (typeof type === 'undefined') {
      locale = `${category}/${locale}`;
      router.push(locale);
    } else {
      locale = {
        pathname: '/media/[category]/[type]',
        query: {
          category: `${category}`,
          "type": `${locale}`
        },
        asPath: `/media/${category}/${locale}`
      };
      router.push(locale.asPath, locale.asPath, {
        scroll: false
      });
    }
  };

  let convert = {
    "all": "ทั้งหมด",
    "agents": "เอเจนท์",
    "maps": "แผนที่",
    "arsenals": "คลังแสง"
  };
  let itemList = [{
    "type": "ทั้งหมด",
    "value": `all`
  }, {
    "type": "เอเจนท์",
    "value": `agents`
  }, {
    "type": "แผนที่",
    "value": `maps`
  }, {
    "type": "คลังแสง",
    "value": `arsenals`
  }];

  const openDropbox = e => {
    console.log(e.target);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Box, {
      onClick: openDropbox,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Text, {
        value: `/${type}`,
        children: convert[type]
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 17
      }, undefined), itemList.map((item, index) => {
        if (item.type != convert[type]) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(Text, {
            value: item.value,
            children: item.type
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 36
          }, undefined);
        }
      })]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilterDropbox);

/***/ }),

/***/ "./components/MediaComponent/MediaHead.jsx":
/*!*************************************************!*\
  !*** ./components/MediaComponent/MediaHead.jsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _TextBg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../TextBg */ "./components/TextBg.jsx");
/* harmony import */ var _styles_media_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../styles/media.module.css */ "./styles/media.module.css");
/* harmony import */ var _styles_media_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_media_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\MediaComponent\\MediaHead.jsx";





const Box = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
position: relative;
width: 100vw;
display: block;
box-sizing: border-box;
`;
const MediaHeader = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
width: 60vw;
height: 90vh;
background: #ff4655;
position: relative;

&:after{
    content: "";
    width: 90%;
    position: absolute;
    height: 7.5vh;
    background: antiquewhite;
    bottom: 0;
    transform: translateX(-10%) skewX(50deg);
}
`;
const MediaTopicContianer = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
position: absolute;
height: 60%;
width: 90%;
right: 0;
bottom: 20%;
border-top: 1px solid white;
z-index: 1;
&:before{
    content: "";
    position: absolute;
    width: 20px;
    height: 20%;
    border-left: 1px solid white;
    bottom: -20%;
}

`;
const MediaTopic = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().h1)`
font-size: 10vh;
color: white;
position: relative;
margin-top: 30px;
margin-bottom: 30px;
overflow: hidden;
`;
const MediaTopicContent = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
width: 55%;
color: white;
font-size: 2.5vh;
margin-bottom: 3vh;
overflow: hidden;
`;
const MediaHeaderImg = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().span)`
background: url("../../../../media_content/pic/Media_Header.jpg");
background-size: cover;
width: 52.75vw;
height: 74.5vh;
position: absolute;
right: 7.5%;
bottom: -1px;
z-index: 1;
transform-origin: bottom;
&:before{
    content: "";
    width: 50px;
    height: 50px;
    background: #ff4655;
    position: absolute;
}
&:after{
    content: "";
    position: absolute;
    background: antiquewhite;
    width: 6vw;
    height: 10vh;
    bottom: 0;
    transform: skewX(40deg) translateX(-4vw);
}
`;
const BotLeftImg = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
position: absolute;
width: 100px;
height: 100px;
border: 1px solid white;
opacity: .5;
bottom: 0;
right: 0;
&:before{
    content: "";
    position: absolute;
    width: 50%;
    height: 50%;
    right: -7.5px;
    top: 25%;
    transform: skewX(-45deg);
    border-left: 3px solid white;
}
&:after{
    content: "";
    position: absolute;
    width: 5px;
    height: 5px;
    bottom: 0;
    background: white;
}
`;
const Line = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    position: absolute;
    width: 33.6313vw;
    height: 10px;
    bottom: 0;
    border-bottom: 1px solid white;
    &:after{
        content: "";
        position: absolute;
        width: 20%;
        border-top: 1px solid #ff4655;
        bottom: -1px;
        left: 10%;
    }

`;

const MediaHead = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Box, {
      style: {
        height: "92.5vh",
        overflow: "hidden"
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_TextBg__WEBPACK_IMPORTED_MODULE_1__.TextBgContainer, {
        style: {
          background: "none",
          zIndex: 1,
          top: "35vh"
        },
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_TextBg__WEBPACK_IMPORTED_MODULE_1__.Txt, {
          className: ((_styles_media_module_css__WEBPACK_IMPORTED_MODULE_3___default().textBackground), (_styles_media_module_css__WEBPACK_IMPORTED_MODULE_3___default().stroke)),
          style: {
            fontSize: "15vw"
          },
          children: "VALORANT"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 136,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 135,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaHeader, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaTopicContianer, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaTopic, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: "MoveUp",
              children: "\u0E2A\u0E37\u0E48\u0E2D"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 140,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 140,
            columnNumber: 21
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaTopicContent, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: "MoveUp",
              children: "\u0E07\u0E32\u0E19\u0E02\u0E2D\u0E07\u0E40\u0E23\u0E32\u0E04\u0E37\u0E2D\u0E01\u0E32\u0E23\u0E40\u0E25\u0E48\u0E19\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13 \u0E44\u0E21\u0E48\u0E27\u0E48\u0E32\u0E04\u0E38\u0E13\u0E08\u0E30\u0E40\u0E1B\u0E47\u0E19\u0E2A\u0E37\u0E48\u0E2D \u0E04\u0E2D\u0E19\u0E40\u0E17\u0E19\u0E15\u0E4C\u0E04\u0E23\u0E35\u0E40\u0E2D\u0E40\u0E15\u0E2D\u0E23\u0E4C \u0E2B\u0E23\u0E37\u0E2D\u0E17\u0E31\u0E49\u0E07\u0E2A\u0E2D\u0E07 \u0E04\u0E38\u0E13\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E43\u0E0A\u0E49\u0E17\u0E38\u0E01\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E17\u0E35\u0E48\u0E04\u0E38\u0E13\u0E40\u0E2B\u0E47\u0E19\u0E17\u0E35\u0E48\u0E19\u0E35\u0E48\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 141,
              columnNumber: 40
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 141,
            columnNumber: 21
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaTopicContent, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: "MoveUp",
              children: ["\u0E42\u0E1B\u0E23\u0E14\u0E2D\u0E22\u0E48\u0E32\u0E25\u0E37\u0E21\u0E41\u0E17\u0E47\u0E01 @PlayVALORANT \u0E1A\u0E19\u0E42\u0E0B\u0E40\u0E0A\u0E35\u0E22\u0E25\u0E21\u0E35\u0E40\u0E14\u0E35\u0E22\u0E2B\u0E32\u0E01\u0E04\u0E38\u0E13\u0E44\u0E14\u0E49\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E1C\u0E25\u0E07\u0E32\u0E19\u0E14\u0E49\u0E27\u0E22\u0E44\u0E1F\u0E25\u0E4C\u0E19\u0E35\u0E49 \u0E40\u0E23\u0E32\u0E2D\u0E14\u0E43\u0E08\u0E23\u0E2D\u0E41\u0E17\u0E1A\u0E44\u0E21\u0E48\u0E44\u0E2B\u0E27\u0E17\u0E35\u0E48\u0E08\u0E30\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A\u0E0A\u0E21\u0E2A\u0E34\u0E48\u0E07\u0E17\u0E35\u0E48\u0E04\u0E38\u0E13\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E02\u0E36\u0E49\u0E19\u0E21\u0E32 \u0E41\u0E15\u0E48\u0E2D\u0E22\u0E48\u0E32\u0E25\u0E37\u0E21\u0E40\u0E01\u0E35\u0E48\u0E22\u0E27\u0E01\u0E31\u0E1A", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("a", {
                className: "condition",
                href: "#",
                children: "\u0E40\u0E07\u0E37\u0E48\u0E2D\u0E19\u0E44\u0E02\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19 \u0E02\u0E2D\u0E07\u0E40\u0E23\u0E32\u0E25\u0E48\u0E30"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 142,
                columnNumber: 212
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 40
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 142,
            columnNumber: 21
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Line, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 143,
            columnNumber: 21
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 139,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 138,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(MediaHeaderImg, {
        className: "MoveUp",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(BotLeftImg, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 146,
          columnNumber: 48
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 146,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 134,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MediaHead);

/***/ }),

/***/ "./components/MediaComponent/index.js":
/*!********************************************!*\
  !*** ./components/MediaComponent/index.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterDropbox": () => (/* reexport safe */ _FilterDropbox__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "MediaHead": () => (/* reexport safe */ _MediaHead__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "CategoryBar": () => (/* reexport safe */ _CategoryBar__WEBPACK_IMPORTED_MODULE_2__.default)
/* harmony export */ });
/* harmony import */ var _FilterDropbox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FilterDropbox */ "./components/MediaComponent/FilterDropbox.jsx");
/* harmony import */ var _MediaHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MediaHead */ "./components/MediaComponent/MediaHead.jsx");
/* harmony import */ var _CategoryBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CategoryBar */ "./components/MediaComponent/CategoryBar.jsx");




/***/ }),

/***/ "./components/Nav/LangButton.jsx":
/*!***************************************!*\
  !*** ./components/Nav/LangButton.jsx ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _LangSelector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./LangSelector */ "./components/Nav/LangSelector.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\LangButton.jsx";




const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 32px;
    height: 32px;
    margin-left: 12px;
    margin-right: 12px;
    padding: 8px;
    background-color: #33333377;
    border-radius: 50%;
    cursor: pointer;
    right: 164px;
`;
const ButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    background: none;
    padding: 0;
    margin: 0;
    border: none;
    cursor: pointer;
`;

const LangButton = ({
  isOpen,
  onClick
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonWrapper, {
      onClick: onClick,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledLogo, {
        viewBox: "0 0 16 16",
        fill: "#fff",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
          d: "M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm7.5-6.923c-.67.204-1.335.82-1.887 1.855A7.97 7.97 0 0 0 5.145 4H7.5V1.077zM4.09 4a9.267 9.267 0 0 1 .64-1.539 6.7 6.7 0 0 1 .597-.933A7.025 7.025 0 0 0 2.255 4H4.09zm-.582 3.5c.03-.877.138-1.718.312-2.5H1.674a6.958 6.958 0 0 0-.656 2.5h2.49zM4.847 5a12.5 12.5 0 0 0-.338 2.5H7.5V5H4.847zM8.5 5v2.5h2.99a12.495 12.495 0 0 0-.337-2.5H8.5zM4.51 8.5a12.5 12.5 0 0 0 .337 2.5H7.5V8.5H4.51zm3.99 0V11h2.653c.187-.765.306-1.608.338-2.5H8.5zM5.145 12c.138.386.295.744.468 1.068.552 1.035 1.218 1.65 1.887 1.855V12H5.145zm.182 2.472a6.696 6.696 0 0 1-.597-.933A9.268 9.268 0 0 1 4.09 12H2.255a7.024 7.024 0 0 0 3.072 2.472zM3.82 11a13.652 13.652 0 0 1-.312-2.5h-2.49c.062.89.291 1.733.656 2.5H3.82zm6.853 3.472A7.024 7.024 0 0 0 13.745 12H11.91a9.27 9.27 0 0 1-.64 1.539 6.688 6.688 0 0 1-.597.933zM8.5 12v2.923c.67-.204 1.335-.82 1.887-1.855.173-.324.33-.682.468-1.068H8.5zm3.68-1h2.146c.365-.767.594-1.61.656-2.5h-2.49a13.65 13.65 0 0 1-.312 2.5zm2.802-3.5a6.959 6.959 0 0 0-.656-2.5H12.18c.174.782.282 1.623.312 2.5h2.49zM11.27 2.461c.247.464.462.98.64 1.539h1.835a7.024 7.024 0 0 0-3.072-2.472c.218.284.418.598.597.933zM10.855 4a7.966 7.966 0 0 0-.468-1.068C9.835 1.897 9.17 1.282 8.5 1.077V4h2.355z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_LangSelector__WEBPACK_IMPORTED_MODULE_1__.LangSelector, {
      isOpen: isOpen
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LangButton);

/***/ }),

/***/ "./components/Nav/LangSelector.jsx":
/*!*****************************************!*\
  !*** ./components/Nav/LangSelector.jsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LangSelector": () => (/* binding */ LangSelector)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\LangSelector.jsx";



const StyledLayout = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    width: 240px;
    height: 360px;
    background-color: white;
    position: fixed;
    right: 70px;
    top: 94px;
    z-index: 5000;
    border-radius: 4px;
    display: ${props => props.isOpen ? "block" : "none"};
`;
const StyledCheckedIcon = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 20px;
    height: 20px;
    fill: #c4202b;
    position: absolute;
    right: 16px;
`;

const CheckedIcon = () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledCheckedIcon, {
  viewBox: "0 0 16 16",
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
    d: "M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 25,
    columnNumber: 9
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 24,
  columnNumber: 5
}, undefined);

const StyledTriangleUp = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 32px;
    height: 32px;
    position: absolute;
    top: -14px;
    left: 104px;
`;

const TriangleUp = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledTriangleUp, {
    viewBox: "0 0 16 16",
    fill: "#fff",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fillRule: "evenodd",
      d: "M7.022 1.566a1.13 1.13 0 0 1 1.96 0l6.857 11.667c.457.778-.092 1.767-.98 1.767H1.144c-.889 0-1.437-.99-.98-1.767L7.022 1.566z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 9
  }, undefined);
};

const LanguageSupport = ["ENGLISH (NA)", "ENGLISH (EUW)", "DEUTSCH", "ESPAÑOL (EUW)", "FRANÇAIS", "ITALIANO", "POLSKI", "РУССКИЙ", "TÜRKÇE", "ESPAÑOL (LATAM)", "INDONESIAN", "日本語", "한국어", "PORTUGUÊS", "ภาษาไทย", "Tiếng Việt", "繁體中文", "العربية"];
const StyleLangItem = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    font-family: 'Kanit', sans-serif;
    font-size: 13px;
    font-weight: 400;
    padding: 10px 24px;
    margin: 0;
    width: 100%;
    color: ${props => props.selected ? "#c4202b" : "#999"};
    transition: color .4s;
    cursor: ${props => props.selected ? "default" : "pointer"};
    &:hover {
        color: #111;
    }
    position: relative;
    display: flex;
    align-items: flex-end;
`;

const LangItem = ({
  children,
  selected
}) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyleLangItem, {
  selected: children === selected,
  children: [children, children === selected ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(CheckedIcon, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 87,
    columnNumber: 35
  }, undefined) : null]
}, void 0, true, {
  fileName: _jsxFileName,
  lineNumber: 85,
  columnNumber: 5
}, undefined);

const Content = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    overflow: auto;
    height: 100%;
    width: 100%;
    margin: 0;
    padding: 10px 0;
`;
const LangSelector = ({
  isOpen
}) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledLayout, {
    isOpen: isOpen,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Content, {
      children: LanguageSupport.map((e, i) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(LangItem, {
        selected: "\u0E20\u0E32\u0E29\u0E32\u0E44\u0E17\u0E22",
        children: e
      }, i, false, {
        fileName: _jsxFileName,
        lineNumber: 104,
        columnNumber: 21
      }, undefined))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 102,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TriangleUp, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 109,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 101,
    columnNumber: 9
  }, undefined)
}, void 0, false);

/***/ }),

/***/ "./components/Nav/NavBar.jsx":
/*!***********************************!*\
  !*** ./components/Nav/NavBar.jsx ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _NavLayout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavLayout */ "./components/Nav/NavLayout.jsx");
/* harmony import */ var _NavItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavItem */ "./components/Nav/NavItem/index.js");
/* harmony import */ var _NavDropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NavDropdown */ "./components/Nav/NavDropdown/index.js");
/* harmony import */ var _NavExternalLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavExternalLink */ "./components/Nav/NavExternalLink/index.js");
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var _NavSeparator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./NavSeparator */ "./components/Nav/NavSeparator.jsx");
/* harmony import */ var _LangButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./LangButton */ "./components/Nav/LangButton.jsx");
/* harmony import */ var _PlayButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./PlayButton */ "./components/Nav/PlayButton.jsx");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _RightNav__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./RightNav */ "./components/Nav/RightNav.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavBar.jsx";












const NavBar = () => {
  const {
    0: openRiotGameBar,
    1: setOpenRiotGameBar
  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
  const {
    0: openLangSelector,
    1: setOpenLangSelector
  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
  const {
    0: openPlayPopup,
    1: setOpenPlayPopup
  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);

  const handleRiotGameBarClick = e => {
    e.preventDefault();
    setOpenRiotGameBar(!openRiotGameBar);
    setOpenLangSelector(false);
  };

  const handleLangClick = e => {
    e.preventDefault();
    setOpenLangSelector(!openLangSelector);
    setOpenRiotGameBar(false);
  };

  const handlePlayPopupClick = e => {
    e.preventDefault();
    setOpenPlayPopup(!openPlayPopup);
    setOpenRiotGameBar(false);
    setOpenLangSelector(false);
  };

  const RiotGameBarStateControl = state => {
    setOpenRiotGameBar(state);
  };

  const PlayPopupStateControl = state => {
    setOpenPlayPopup(state);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavLayout__WEBPACK_IMPORTED_MODULE_0__.default, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_4__.RiotLogo, {
      isGameBarOpen: openRiotGameBar,
      onClick: handleRiotGameBarClick,
      stateControl: RiotGameBarStateControl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavSeparator__WEBPACK_IMPORTED_MODULE_5__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_4__.ValorantLogo, {
      href: "/"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
      title: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E40\u0E01\u0E21",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/agents",
        title: "\u0E40\u0E2D\u0E40\u0E08\u0E19\u0E17\u0E4C"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/maps",
        title: "\u0E41\u0E1C\u0E19\u0E17\u0E35\u0E48"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/arsenal",
        title: "\u0E04\u0E25\u0E31\u0E07\u0E41\u0E2A\u0E07"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavItem__WEBPACK_IMPORTED_MODULE_1__.NavItem, {
      href: "/media",
      title: "\u0E2A\u0E37\u0E48\u0E2D"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 48,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavItem__WEBPACK_IMPORTED_MODULE_1__.NavItem, {
      href: "/news",
      title: "\u0E02\u0E48\u0E32\u0E27\u0E2A\u0E32\u0E23"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavItem__WEBPACK_IMPORTED_MODULE_1__.NavItem, {
      href: "/leaderboards",
      title: "\u0E01\u0E23\u0E30\u0E14\u0E32\u0E19\u0E1C\u0E39\u0E49\u0E19\u0E33"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
      title: "\u0E0B\u0E31\u0E1E\u0E1E\u0E2D\u0E23\u0E4C\u0E15",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/specs",
        title: "\u0E2A\u0E40\u0E1B\u0E04"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.ExternalLi, {
        title: "\u0E0B\u0E31\u0E1E\u0E1E\u0E2D\u0E23\u0E4C\u0E15"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Li, {
        href: "/community-code",
        title: "\u0E01\u0E0F\u0E23\u0E30\u0E40\u0E1A\u0E35\u0E22\u0E1A"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 51,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
      title: "\u0E42\u0E0B\u0E40\u0E0A\u0E35\u0E22\u0E25",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.ExternalLi, {
        title: "FACEBOOK"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.ExternalLi, {
        title: "YOUTUBE"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavDropdown__WEBPACK_IMPORTED_MODULE_2__.ExternalLi, {
        title: "INSTAGRAM"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_NavExternalLink__WEBPACK_IMPORTED_MODULE_3__.External, {
      title: "\u0E2D\u0E35\u0E2A\u0E1B\u0E2D\u0E23\u0E4C\u0E15"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 61,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_RightNav__WEBPACK_IMPORTED_MODULE_9__.RightNav, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_LangButton__WEBPACK_IMPORTED_MODULE_6__.default, {
        isOpen: openLangSelector,
        onClick: handleLangClick
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxDEV)(_PlayButton__WEBPACK_IMPORTED_MODULE_7__.default, {
        isOpen: openPlayPopup,
        onClick: handlePlayPopupClick,
        stateControl: PlayPopupStateControl,
        children: "\u0E40\u0E25\u0E48\u0E19\u0E40\u0E25\u0E22"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 39,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavBar);

/***/ }),

/***/ "./components/Nav/NavDropdown/ExternalLi.jsx":
/*!***************************************************!*\
  !*** ./components/Nav/NavDropdown/ExternalLi.jsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavDropdown\\ExternalLi.jsx";



const ExternalLi = ({
  title
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_0__.StyledLi, {
    children: [title, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_0__.DropdownArrowUp, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExternalLi);

/***/ }),

/***/ "./components/Nav/NavDropdown/Li.jsx":
/*!*******************************************!*\
  !*** ./components/Nav/NavDropdown/Li.jsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavDropdown\\Li.jsx";




const Li = ({
  href,
  title
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
    href: href,
    passHref: true,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.StyledLi, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("a", {
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 8,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Li);

/***/ }),

/***/ "./components/Nav/NavDropdown/NavDropdown.jsx":
/*!****************************************************!*\
  !*** ./components/Nav/NavDropdown/NavDropdown.jsx ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var _Ul__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Ul */ "./components/Nav/NavDropdown/Ul.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavDropdown\\NavDropdown.jsx";




const Dropdown = ({
  title,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_0__.NavItemLayout, {
    children: [title, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_0__.CaretDown, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_Ul__WEBPACK_IMPORTED_MODULE_1__.Ul, {
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dropdown);

/***/ }),

/***/ "./components/Nav/NavDropdown/Ul.jsx":
/*!*******************************************!*\
  !*** ./components/Nav/NavDropdown/Ul.jsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ul": () => (/* binding */ Ul)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");


const Ul = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().ul)`
    list-style-type: none;
    min-width: 200px;
    background-color: #111;
    position: absolute;
    top: 80px;
    left: 0;
    margin: 0;
    padding: 0;
    display: none;
    ${_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.NavItemLayout}:hover & {
        display: block;
    }
`;

/***/ }),

/***/ "./components/Nav/NavDropdown/index.js":
/*!*********************************************!*\
  !*** ./components/Nav/NavDropdown/index.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Li": () => (/* reexport safe */ _Li__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "Dropdown": () => (/* reexport safe */ _NavDropdown__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "ExternalLi": () => (/* reexport safe */ _ExternalLi__WEBPACK_IMPORTED_MODULE_2__.default)
/* harmony export */ });
/* harmony import */ var _Li__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Li */ "./components/Nav/NavDropdown/Li.jsx");
/* harmony import */ var _NavDropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavDropdown */ "./components/Nav/NavDropdown/NavDropdown.jsx");
/* harmony import */ var _ExternalLi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ExternalLi */ "./components/Nav/NavDropdown/ExternalLi.jsx");




/***/ }),

/***/ "./components/Nav/NavExternalLink/NavExternalLink.jsx":
/*!************************************************************!*\
  !*** ./components/Nav/NavExternalLink/NavExternalLink.jsx ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavExternalLink\\NavExternalLink.jsx";




const ExternalLink = ({
  title,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.NavItemLayout, {
    children: [title, children, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.NavArrowUp, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExternalLink);

/***/ }),

/***/ "./components/Nav/NavExternalLink/index.js":
/*!*************************************************!*\
  !*** ./components/Nav/NavExternalLink/index.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "External": () => (/* reexport safe */ _NavExternalLink__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _NavExternalLink__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavExternalLink */ "./components/Nav/NavExternalLink/NavExternalLink.jsx");


/***/ }),

/***/ "./components/Nav/NavItem/NavItem.jsx":
/*!********************************************!*\
  !*** ./components/Nav/NavItem/NavItem.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_nav_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../styles/nav_components */ "./styles/nav_components/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavItem\\NavItem.jsx";




const NavItem = ({
  href,
  title,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
    href: href,
    passHref: true,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_nav_components__WEBPACK_IMPORTED_MODULE_1__.StyledLink, {
      children: [title, children]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavItem);

/***/ }),

/***/ "./components/Nav/NavItem/index.js":
/*!*****************************************!*\
  !*** ./components/Nav/NavItem/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavItem": () => (/* reexport safe */ _NavItem__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _NavItem__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavItem */ "./components/Nav/NavItem/NavItem.jsx");


/***/ }),

/***/ "./components/Nav/NavLayout.jsx":
/*!**************************************!*\
  !*** ./components/Nav/NavLayout.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\NavLayout.jsx";


const Nav = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().nav)`
    width: 100%;
    height: 80px;
    background-color: #111;
    display: flex;
    z-index: 4000;
    position: fixed;
    top: 0;
    padding-left: 26px;
    padding-right: 26px;
`;

const NavLayout = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("header", {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Nav, {
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavLayout);

/***/ }),

/***/ "./components/Nav/NavSeparator.jsx":
/*!*****************************************!*\
  !*** ./components/Nav/NavSeparator.jsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const NavSeparator = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    height: 30px;
    width: 2px;
    background-color: #7e7e7e;
    margin-top: 25px;
    margin-left: 12px;
    margin-right: 12px;
    opacity: .4;
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavSeparator);

/***/ }),

/***/ "./components/Nav/PlayButton.jsx":
/*!***************************************!*\
  !*** ./components/Nav/PlayButton.jsx ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _PlayPopup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PlayPopup */ "./components/Nav/PlayPopup.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\PlayButton.jsx";




const Button = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    background-color: rgb(255, 70, 85);
    margin-left: 4px;
    margin-right: 4px;
    height: 40px;
    width: 130px;
    border: none;
    border-radius: 2px;
    color: white;
    font-family: 'Bai Jamjuree', sans-serif;
    font-weight: 500;
    cursor: pointer;
    right: 26px;
`;

const PlayButton = ({
  children,
  onClick,
  isOpen,
  stateControl
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Button, {
      onClick: onClick,
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_PlayPopup__WEBPACK_IMPORTED_MODULE_1__.PlayPopup, {
      isOpen: isOpen,
      stateControl: stateControl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlayButton);

/***/ }),

/***/ "./components/Nav/PlayPopup.jsx":
/*!**************************************!*\
  !*** ./components/Nav/PlayPopup.jsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlayPopup": () => (/* binding */ PlayPopup)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Button */ "./components/Button/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\PlayPopup.jsx";




const PopupWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    width: 100vw;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    display: ${props => props.isOpen ? "flex" : "none"};
    justify-content: center;
    align-items: center;
`;
const DimmedBackground = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    width: 100%;
    height: 100%;
    background-color: #111;
    opacity: .7;
    position: absolute;
    z-index: 4000;
    top: 0;
`;
const Popup = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    width: 100px;
    height: 100px;
    border-top: 1px solid #968d8c;
    border-bottom: 1px solid #968d8c;
    background-color: #0f1923;
    z-index: 6000;
    height: 40vh;
    width: calc(2/3*100%);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    position: relative;
`;
const PopupTitleWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    height: 70%;
    width: 100%;
    font-family: 'Kanit', sans-serif;
    font-size: 32px;
    font-weight: 600;
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    column-gap: 24px;
`;
const PopupButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: center;
    column-gap: 40px;
`;
const ButtonLabel = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
    color: white;
    font-size: 14px;
    font-weight: 300;
`;
const ButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    display: flex;
    flex-direction: column;
    align-items: center;
`;
const ExitButtonWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    width: 60px;
    height: 60px;
    border: solid white 1px;
    position: absolute;
    top: 15px;
    right: 15px;
    background: transparent;
    cursor: pointer;
`;

const ExitButton = ({
  onClick
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ExitButtonWrapper, {
    onClick: onClick,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ExitButtonStyle, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 88,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 87,
    columnNumber: 9
  }, undefined);
};

const SvgExit = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 48px;
    height: 48px;
    transition: scale .2s;
    ${ExitButtonWrapper}:hover & {
        scale: 1.15;
    }
`;

const ExitButtonStyle = () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(SvgExit, {
  viewBox: "0 0 72 72",
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
    fill: "none",
    stroke: "#ece8e1",
    d: "M61.5 9.5l-7 7m-38 38l-7 7M30.3 42l2.8-3m8.6 3L30.3 30m11.4 0l-2.6 2.8"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 104,
    columnNumber: 9
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 103,
  columnNumber: 5
}, undefined);

const PlayPopup = ({
  isOpen,
  stateControl
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(PopupWrapper, {
      isOpen: isOpen,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Popup, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(PopupTitleWrapper, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
            children: "\\"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 25
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
            children: "\u0E40\u0E15\u0E23\u0E35\u0E22\u0E21\u0E15\u0E31\u0E27\u0E43\u0E2B\u0E49\u0E1E\u0E23\u0E49\u0E2D\u0E21"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 115,
            columnNumber: 25
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
            children: "\\"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 116,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 113,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(PopupButtonWrapper, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonWrapper, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonLabel, {
              children: "\u0E09\u0E31\u0E19\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Riot"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 120,
              columnNumber: 29
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, {
              isWhite: true,
              isBordered: true,
              children: "\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E17\u0E31\u0E19\u0E17\u0E35"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 121,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 119,
            columnNumber: 25
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonWrapper, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ButtonLabel, {
              children: "\u0E09\u0E31\u0E19\u0E21\u0E35\u0E1A\u0E31\u0E0D\u0E0A\u0E35 Riot \u0E41\u0E25\u0E49\u0E27"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 124,
              columnNumber: 29
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_Button__WEBPACK_IMPORTED_MODULE_1__.Button, {
              isBordered: true,
              children: "\u0E25\u0E07\u0E0A\u0E37\u0E48\u0E2D\u0E40\u0E02\u0E49\u0E32\u0E43\u0E0A\u0E49"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 125,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 123,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 118,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(ExitButton, {
          onClick: () => stateControl(false)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 128,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 112,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(DimmedBackground, {
        onClick: () => stateControl(false)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 130,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 111,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

/***/ }),

/***/ "./components/Nav/RightNav.jsx":
/*!*************************************!*\
  !*** ./components/Nav/RightNav.jsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RightNav": () => (/* binding */ RightNav)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const RightNav = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    padding: 0;
    margin: 0 24px 0 0;
    position: fixed;
    right: 0;
    display: flex;
    align-items: center;
    height: 80px;
`;

/***/ }),

/***/ "./components/Nav/RiotGamesBar.jsx":
/*!*****************************************!*\
  !*** ./components/Nav/RiotGamesBar.jsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RiotGamesBar": () => (/* binding */ RiotGamesBar)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\Nav\\RiotGamesBar.jsx";


const GamesBar = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    position: fixed;
    left: 0;
    height: 370px;
    width: 100%;
    background-color: white;
    z-index: 10000;
    opacity: 1;
    padding: 24px 40px;
`;
const DimmedBackground = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    z-index: 9000;
    background-color: #111;
    opacity: .7;
    position: fixed;
    left: 0;
    top: 0;
    margin-top: 80px;
    width: 100vw;
    height: 100vh;
`;
const GamesBarWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    position: fixed;
    left: 0;
    top: 0;
    margin-top: 80px;
    width: 100vw;
    height: 100vh;
    display: ${props => props.isOpen ? "block" : "none"};
`;
const StyledTriangleUp = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 32px;
    height: 32px;
    position: absolute;
    top: -14px;
    left: 38px;
`;
const TitleRiotGames = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
    font-family: 'Kanit', sans-serif;
    font-size: 24px;
    margin: 0;
    font-weight: 700;
`;

const TriangleUp = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledTriangleUp, {
    viewBox: "0 0 16 16",
    fill: "#fff",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("path", {
      fillRule: "evenodd",
      d: "M7.022 1.566a1.13 1.13 0 0 1 1.96 0l6.857 11.667c.457.778-.092 1.767-.98 1.767H1.144c-.889 0-1.437-.99-.98-1.767L7.022 1.566z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 9
  }, undefined);
};

const RiotGamesBar = ({
  isOpen,
  stateControl
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(GamesBarWrapper, {
    isOpen: isOpen,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TriangleUp, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(GamesBar, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TitleRiotGames, {
        children: "RIOT GAMES"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(DimmedBackground, {
      onClick: () => stateControl(false)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 61,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./components/Nav/index.js":
/*!*********************************!*\
  !*** ./components/Nav/index.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavBar": () => (/* reexport safe */ _NavBar__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var _NavBar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavBar */ "./components/Nav/NavBar.jsx");


/***/ }),

/***/ "./components/TextBg.jsx":
/*!*******************************!*\
  !*** ./components/TextBg.jsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Txt": () => (/* binding */ Txt),
/* harmony export */   "TextBgContainer": () => (/* binding */ TextBgContainer)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_News_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/News.module.css */ "./styles/News.module.css");
/* harmony import */ var _styles_News_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_News_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\TextBg.jsx";




const TextBgContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "TextBg__TextBgContainer",
  componentId: "sc-1lib2cb-0"
})(["position:absolute;width:100vw;height:150vh;background:#0f1923;"]);
const Txt = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
  displayName: "TextBg__Txt",
  componentId: "sc-1lib2cb-1"
})(["font-family:DINNextLTW04-Medium;font-size:22.65vw;font-weight:400;Z-index:1;@media (max-width:800px){font-size:27.65vw;}"]);

const TextBG = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(TextBgContainer, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h2", {
        className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_2___default().stroke),
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Txt, {
          className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_2___default().textBackground1),
          children: "WE ARE"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 17
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Txt, {
          className: (_styles_News_module_css__WEBPACK_IMPORTED_MODULE_2___default().textBackground2),
          children: "VALORANT"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 17
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 13
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 9
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextBG);


/***/ }),

/***/ "./components/TextTitle.jsx":
/*!**********************************!*\
  !*** ./components/TextTitle.jsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\components\\TextTitle.jsx";


const StyledTitle = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().p)`
  font-size: 4.25rem;
  font-weight: bold;
  font-family: 'Kanit', sans-serif;
  color: ${props => props.color};
  margin: 0;
  width: 60%;
  line-height: 1.3;
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({
  textColor,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(StyledTitle, {
    color: textColor,
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
});

/***/ }),

/***/ "./components/index.js":
/*!*****************************!*\
  !*** ./components/index.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Head": () => (/* reexport safe */ _Head__WEBPACK_IMPORTED_MODULE_0__.default),
/* harmony export */   "Title": () => (/* reexport safe */ _TextTitle__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "NavBar": () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_2__.NavBar),
/* harmony export */   "Footer": () => (/* reexport safe */ _Footer__WEBPACK_IMPORTED_MODULE_3__.Footer),
/* harmony export */   "Button": () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_4__.Button)
/* harmony export */ });
/* harmony import */ var _Head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Head */ "./components/Head.jsx");
/* harmony import */ var _TextTitle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TextTitle */ "./components/TextTitle.jsx");
/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Nav */ "./components/Nav/index.js");
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Footer */ "./components/Footer/index.js");
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Button */ "./components/Button/index.js");






/***/ }),

/***/ "./node_modules/next/dist/client/link.js":
/*!***********************************************!*\
  !*** ./node_modules/next/dist/client/link.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ../shared/lib/router/router */ "./node_modules/next/dist/shared/lib/router/router.js");

var _router1 = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router).isLocalURL(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (true) {
      // rethrow to show invalid URL errors
      throw err;
    }
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router).isLocalURL(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null && as.indexOf('#') >= 0) {
    scroll = false;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (true) {
    function createPropError(args) {
      return new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + ( false ? 0 : ''));
    } // TypeScript trick for type-guarding:


    const requiredPropsGuard = {
      href: true
    };
    const requiredProps = Object.keys(requiredPropsGuard);
    requiredProps.forEach(key => {
      if (key === 'href') {
        if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: props[key] === null ? 'null' : typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // TypeScript trick for type-guarding:

    const optionalPropsGuard = {
      as: true,
      replace: true,
      scroll: true,
      shallow: true,
      passHref: true,
      prefetch: true,
      locale: true
    };
    const optionalProps = Object.keys(optionalPropsGuard);
    optionalProps.forEach(key => {
      const valType = typeof props[key];

      if (key === 'as') {
        if (props[key] && valType !== 'string' && valType !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: valType
          });
        }
      } else if (key === 'locale') {
        if (props[key] && valType !== 'string') {
          throw createPropError({
            key,
            expected: '`string`',
            actual: valType
          });
        }
      } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'prefetch') {
        if (props[key] != null && valType !== 'boolean') {
          throw createPropError({
            key,
            expected: '`boolean`',
            actual: valType
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // This hook is in a conditional but that is ok because `process.env.NODE_ENV` never changes
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const hasWarned = _react.default.useRef(false);

    if (props.prefetch && !hasWarned.current) {
      hasWarned.current = true;
      console.warn('Next.js auto-prefetches automatically based on viewport. The prefetch attribute is no longer needed. More: https://nextjs.org/docs/messages/prefetch-true-deprecated');
    }
  }

  const p = props.prefetch !== false;
  const router = (0, _router1).useRouter();

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router).resolveHref(router, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router).resolveHref(router, props.as) : resolvedAs || resolvedHref
    };
  }, [router, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  let child;

  if (true) {
    try {
      child = _react.default.Children.only(children);
    } catch (err) {
      throw new Error(`Multiple children were passed to <Link> with \`href\` of \`${props.href}\` but only one child is supported https://nextjs.org/docs/messages/link-multiple-children` + ( false ? 0 : ''));
    }
  } else {}

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection).useIntersection({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  _react.default.useEffect(() => {
    const shouldPrefetch = isVisible && p && (0, _router).isLocalURL(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);

  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router).isLocalURL(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router).getDomainLocale(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router).addBasePath((0, _router).addLocale(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/client/normalize-trailing-slash.js":
/*!*******************************************************************!*\
  !*** ./node_modules/next/dist/client/normalize-trailing-slash.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}

const normalizePathTrailingSlash =  false ? 0 : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.requestIdleCallback = exports.cancelIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/route-loader.js":
/*!*******************************************************!*\
  !*** ./node_modules/next/dist/client/route-loader.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.createRouteLoader = createRouteLoader;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/router/utils/get-asset-path-from-route */ "../shared/lib/router/utils/get-asset-path-from-route"));

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
} // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (e) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR');

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // We wait for pages to be built in dev before we start the route transition
// timeout to prevent an un-necessary hard navigation in development.


let devBuildPromise; // Resolve a promise that times out after given amount of milliseconds.

function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject); // We wrap these checks separately for better dead-code elimination in
    // production bundles.

    if (true) {
      (devBuildPromise || Promise.resolve()).then(() => {
        (0, _requestIdleCallback).requestIdleCallback(() => setTimeout(() => {
          if (!cancelled) {
            reject(err);
          }
        }, ms));
      });
    }

    if (false) {}
  });
}

function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (true) {
    return Promise.resolve({
      scripts: [assetPrefix + '/_next/static/chunks/pages' + encodeURI((0, _getAssetPathFromRoute).default(route, '.js'))],
      // Styles are handled by `style-loader` in development:
      css: []
    });
  }

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route, prefetch) {
      return withFuture(route, routes, () => {
        const routeFilesPromise = getFilesForRoute(assetPrefix, route).then(({
          scripts,
          css
        }) => {
          return Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
        }).then(res => {
          return this.whenEntrypoint(route).then(entrypoint => ({
            entrypoint,
            styles: res[1]
          }));
        });

        if (true) {
          devBuildPromise = new Promise(resolve => {
            if (routeFilesPromise) {
              return routeFilesPromise.finally(() => {
                resolve();
              });
            }
          });
        }

        return resolvePromiseWithTimeout(routeFilesPromise, MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`))).then(({
          entrypoint,
          styles
        }) => {
          const res = Object.assign({
            styles: styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        }).catch(err => {
          if (prefetch) {
            // we don't want to cache errors during prefetch
            throw err;
          }

          return {
            error: err
          };
        });
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback).requestIdleCallback(() => this.loadRoute(route, true).catch(() => {}));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

/***/ }),

/***/ "./node_modules/next/dist/client/router.js":
/*!*************************************************!*\
  !*** ./node_modules/next/dist/client/router.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "Router", ({
  enumerable: true,
  get: function () {
    return _router.default;
  }
}));
Object.defineProperty(exports, "withRouter", ({
  enumerable: true,
  get: function () {
    return _withRouter.default;
  }
}));
exports.useRouter = useRouter;
exports.createRouter = createRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/router/router */ "./node_modules/next/dist/shared/lib/router/router.js"));

var _routerContext = __webpack_require__(/*! ../shared/lib/router-context */ "../shared/lib/router-context");

var _withRouter = _interopRequireDefault(__webpack_require__(/*! ./with-router */ "./node_modules/next/dist/client/with-router.js"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const singletonRouter = {
  router: null,
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain', 'domainLocales'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" on the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
}

var _default = singletonRouter;
exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
}

function createRouter(...args) {
  singletonRouter.router = new _router.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}

function makePublicRouterInstance(router) {
  const _router1 = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router1[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router1[property]) ? [] : {}, _router1[property]) // makes sure query is not stateful
      ;
      continue;
    }

    instance[property] = _router1[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router1[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react).useRef();
  const [visible, setVisible] = (0, _react).useState(false);
  const setRef = (0, _react).useCallback(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react).useEffect(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback).requestIdleCallback(() => setVisible(true));
        return () => (0, _requestIdleCallback).cancelIdleCallback(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/with-router.js":
/*!******************************************************!*\
  !*** ./node_modules/next/dist/client/with-router.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router).useRouter()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (true) {
    const name = ComposedComponent.displayName || ComposedComponent.name || 'Unknown';
    WithRouterWrapper.displayName = `withRouter(${name})`;
  }

  return WithRouterWrapper;
}

/***/ }),

/***/ "./node_modules/next/dist/shared/lib/router/router.js":
/*!************************************************************!*\
  !*** ./node_modules/next/dist/shared/lib/router/router.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../client/normalize-trailing-slash */ "./node_modules/next/dist/client/normalize-trailing-slash.js");

var _routeLoader = __webpack_require__(/*! ../../../client/route-loader */ "./node_modules/next/dist/client/route-loader.js");

var _denormalizePagePath = __webpack_require__(/*! ../../../server/denormalize-page-path */ "../../../server/denormalize-page-path");

var _normalizeLocalePath = __webpack_require__(/*! ../i18n/normalize-locale-path */ "../i18n/normalize-locale-path");

var _mitt = _interopRequireDefault(__webpack_require__(/*! ../mitt */ "../mitt"));

var _utils = __webpack_require__(/*! ../utils */ "../shared/lib/utils");

var _isDynamic = __webpack_require__(/*! ./utils/is-dynamic */ "./utils/is-dynamic");

var _parseRelativeUrl = __webpack_require__(/*! ./utils/parse-relative-url */ "./utils/parse-relative-url");

var _querystring = __webpack_require__(/*! ./utils/querystring */ "./utils/querystring");

var _resolveRewrites = _interopRequireDefault(__webpack_require__(/*! ./utils/resolve-rewrites */ "?5c99"));

var _routeMatcher = __webpack_require__(/*! ./utils/route-matcher */ "./utils/route-matcher");

var _routeRegex = __webpack_require__(/*! ./utils/route-regex */ "./utils/route-regex");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash).normalizePathTrailingSlash(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {} else {
    return false;
  }
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}

function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#') || url.startsWith('?')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils).getLocationOrigin();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex).getRouteRegex(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher).getRouteMatcher(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && (interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = '' // did not satisfy all requirements
    ; // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}

function resolveHref(router, href, resolveAs) {
  // we use a dummy base url for relative urls
  let base;
  let urlAsString = typeof href === 'string' ? href : (0, _utils).formatWithValidation(href); // repeated slashes and backslashes in the URL are considered
  // invalid and will never match a Next.js page/file

  const urlProtoMatch = urlAsString.match(/^[a-zA-Z]{1,}:\/\//);
  const urlAsStringNoProto = urlProtoMatch ? urlAsString.substr(urlProtoMatch[0].length) : urlAsString;
  const urlParts = urlAsStringNoProto.split('?');

  if ((urlParts[0] || '').match(/(\/\/|\\)/)) {
    console.error(`Invalid href passed to next/router: ${urlAsString}, repeated forward-slashes (//) or backslashes \\ are not valid in the href`);
    const normalizedUrl = (0, _utils).normalizeRepeatedSlashes(urlAsStringNoProto);
    urlAsString = (urlProtoMatch ? urlProtoMatch[0] : '') + normalizedUrl;
  } // Return because it cannot be routed by the Next.js router


  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    base = new URL(urlAsString.startsWith('#') ? router.asPath : router.pathname, 'http://n');
  } catch (_) {
    // fallback to / for invalid asPath values e.g. //
    base = new URL('/', 'http://n');
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash).normalizePathTrailingSlash(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic).isDynamicRoute(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring).searchParamsToUrlQuery(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils).formatWithValidation({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils).getLocationOrigin();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router, url, true);
  const origin = (0, _utils).getLocationOrigin();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash).removePathTrailingSlash((0, _denormalizePagePath).denormalizePagePath(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic).isDynamicRoute(page) && (0, _routeRegex).getRouteRegex(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname);
}

const manualScrollRestoration =  false && 0;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader).markAssetError(err);
    }

    throw err;
  });
}

class Router {
  constructor(pathname1, query1, as1, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component: Component1,
    err: err1,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    // Static Data Cache
    this.sdc = {}; // In-flight Server Data Requests, for deduping

    this.sdr = {};
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname: pathname1,
          query: query1
        } = this;
        this.changeState('replaceState', (0, _utils).formatWithValidation({
          pathname: addBasePath(pathname1),
          query: query1
        }), (0, _utils).getURL());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as: as1,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname: pathname1
      } = (0, _parseRelativeUrl).parseRelativeUrl(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as1 === this.asPath && pathname1 === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as1, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname1); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (pathname1 !== '/_error') {
      this.components[this.route] = {
        Component: Component1,
        initial: true,
        props: initialProps,
        err: err1,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: []
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = pathname1;
    this.query = query1; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic).isDynamicRoute(pathname1) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? pathname1 : as1;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || self.__NEXT_DATA__.appGip && !self.__NEXT_DATA__.gsp || !autoExportDynamic && !self.location.search && !false);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    }

    const shouldResolveHref = url === as || options._h || options._shouldResolveHref; // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated

    if (options._h) {
      this.isReady = true;
    }

    const prevLocale = this.locale;

    if (false) { var ref; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as;
    let localeChange = prevLocale !== this.locale; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs) && !localeChange) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl).parseRelativeUrl(url);
    let {
      pathname: pathname1,
      query: query1
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader).getClientBuildManifest());
    } catch (err1) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname1 = pathname1 ? (0, _normalizeTrailingSlash).removePathTrailingSlash(delBasePath(pathname1)) : pathname1;

    if (shouldResolveHref && pathname1 !== '/_error') {
      options._shouldResolveHref = true;

      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname1, pages);

        if (parsed.pathname !== pathname1) {
          pathname1 = parsed.pathname;
          parsed.pathname = addBasePath(pathname1);
          url = (0, _utils).formatWithValidation(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname1);

    if (!isLocalURL(as)) {
      if (true) {
        throw new Error(`Invalid href: "${url}" and as: "${as}", received relative href and external as` + `\nSee more info: https://nextjs.org/docs/messages/invalid-relative-url-external-as`);
      }

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic).isDynamicRoute(route)) {
      const parsedAs = (0, _parseRelativeUrl).parseRelativeUrl(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex).getRouteRegex(route);
      const routeMatch = (0, _routeMatcher).getRouteMatcher(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query1) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query1[param]);

        if (missingParams.length > 0) {
          if (true) {
            console.warn(`${shouldInterpolate ? `Interpolating href` : `Mismatching \`as\` and \`href\``} failed to manually provide ` + `the params: ${missingParams.join(', ')} in the \`href\`'s \`query\``);
          }

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils).formatWithValidation(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query1, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query1, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var ref, ref1;
      let routeInfo = await this.getRouteInfo(route, pathname1, query1, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl).parseRelativeUrl(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);
            const {
              url: newUrl,
              as: newAs
            } = prepareUrlAs(this, destination, destination);
            return this.change(method, newUrl, newAs, options);
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query1, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (true) {
        const appComp = this.components['/_app'].Component;
        window.next.isPrerendered = appComp.getInitialProps === appComp.origGetInitialProps && !routeInfo.Component.getInitialProps;
      }

      if (options._h && pathname1 === '/_error' && ((ref = self.__NEXT_DATA__.props) === null || ref === void 0 ? void 0 : (ref1 = ref.pageProps) === null || ref1 === void 0 ? void 0 : ref1.statusCode) === 500 && (props === null || props === void 0 ? void 0 : props.pageProps)) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      } // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;

      var _scroll;

      const shouldScroll = (_scroll = options.scroll) !== null && _scroll !== void 0 ? _scroll : !isValidShallowRoute;
      const resetScroll = shouldScroll ? {
        x: 0,
        y: 0
      } : null;
      await this.set(route, pathname1, query1, cleanedAs, routeInfo, forcedScroll !== null && forcedScroll !== void 0 ? forcedScroll : resetScroll).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err1) {
      if (err1.cancelled) {
        return false;
      }

      throw err1;
    }
  }

  changeState(method, url, as, options = {}) {
    if (true) {
      if (typeof window.history === 'undefined') {
        console.error(`Warning: window.history is not available.`);
        return;
      }

      if (typeof window.history[method] === 'undefined') {
        console.error(`Warning: window.history.${method} is not available`);
        return;
      }
    }

    if (method !== 'pushState' || (0, _utils).getURL() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader).isAssetError(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component1;
      let styleSheets;
      let props;

      if (typeof Component1 === 'undefined' || typeof styleSheets === 'undefined') {
        ({
          page: Component1,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component: Component1,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component1, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component: Component1,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (true) {
        const {
          isValidElementType
        } = __webpack_require__(/*! react-is */ "react-is");

        if (!isValidElementType(Component1)) {
          throw new Error(`The default export is not a React Component in page: "${pathname}"`);
        }
      }

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils).formatWithValidation({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component1, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as,
        locale: this.locale,
        locales: this.locales,
        defaultLocale: this.defaultLocale
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err2) {
      return this.handleRouteInfoError(err2, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl).parseRelativeUrl(url);
    let {
      pathname: pathname2
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname2) {
        pathname2 = parsed.pathname;
        parsed.pathname = pathname2;
        url = (0, _utils).formatWithValidation(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash).removePathTrailingSlash(pathname2); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (true) {
      return;
    }

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err2 = new Error('Loading initial props cancelled');
        err2.cancelled = true;
        throw err2;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if (false) {}

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err2 => {
      delete this.sdr[resourceKey];
      throw err2;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App1
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App1);

    ctx.AppTree = AppTree;
    return (0, _utils).loadGetInitialProps(App1, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

Router.events = (0, _mitt).default();
exports.default = Router;

/***/ }),

/***/ "./pages/media/index.jsx":
/*!*******************************!*\
  !*** ./pages/media/index.jsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../components */ "./components/index.js");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_TextBg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/TextBg */ "./components/TextBg.jsx");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_MediaComponent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/MediaComponent */ "./components/MediaComponent/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\pages\\media\\index.jsx";









const Box = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().div)`
    position: relative;
    width: 100vw;
    display: block;
    box-sizing: border-box;
`;
const Media_Css = styled_components__WEBPACK_IMPORTED_MODULE_1__.css`
    html,
    body {
        padding: 0;
        margin: 0;
        overflow-x: hidden;
        background-color: antiquewhite;
    }

    .condition {
        color: black;
        display: block;
        text-decoration: underline;
    }

    .condition:hover{
        color: white;
    }

    * {
    box-sizing: border-box;
    }
    
`;
const ImgCss = styled_components__WEBPACK_IMPORTED_MODULE_1__.css`

.imgGallery{
    float: left;
    margin: 10px;
}

.GalContainer{
    width: 90%;
    margin: auto;
    display: block;
    padding-top: 10vh;
}
.categoryContainer{
    display: block;
}
`;
const DontHave = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().h1)`
    font-size: 4rem;
    display: block;

`;

const Media = () => {
  let data = __webpack_require__(/*! ../../public/media_content/contents.json */ "./public/media_content/contents.json");

  data = data.wallpaper.concat(data.video, data.screenshot, data.artwork, data.logo, data.content_creator);
  const size = [["20vw", "20vw"], ["20vw", "30vw"], ["30vw", "30vw"]];
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components__WEBPACK_IMPORTED_MODULE_0__.Head, {
      title: "VALORANT: \u0E40\u0E01\u0E21\u0E22\u0E34\u0E07\u0E1B\u0E37\u0E19\u0E08\u0E32\u0E01 Riot Games \u0E43\u0E19\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A 5v5 \u0E17\u0E35\u0E48\u0E02\u0E31\u0E1A\u0E40\u0E04\u0E25\u0E37\u0E48\u0E2D\u0E19\u0E42\u0E14\u0E22\u0E15\u0E31\u0E27\u0E25\u0E30\u0E04\u0E23\u0E19\u0E31\u0E01\u0E22\u0E34\u0E07\u0E1B\u0E37\u0E19\u0E1C\u0E39\u0E49\u0E21\u0E32\u0E01\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 72,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components__WEBPACK_IMPORTED_MODULE_0__.NavBar, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("style", {
      children: Media_Css
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 74,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("style", {
      children: ImgCss
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components_MediaComponent__WEBPACK_IMPORTED_MODULE_6__.MediaHead, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 76,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Box, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components_MediaComponent__WEBPACK_IMPORTED_MODULE_6__.CategoryBar, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "GalContainer",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(DontHave, {
          style: {
            display: `none`
          },
          children: "\u0E01\u0E25\u0E31\u0E1A\u0E21\u0E32\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E43\u0E2B\u0E21\u0E48\u0E2D\u0E35\u0E01\u0E04\u0E23\u0E31\u0E49\u0E07\u0E43\u0E19\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07!"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 21
        }, undefined), data.map((image, index) => {
          let imgSize = size[Math.floor(Math.random() * 3)];
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "imgGallery",
            style: {
              background: `url(${image.path})`,
              backgroundSize: "cover",
              width: `${imgSize[0]}`,
              height: `${imgSize[1]}`
            }
          }, index, false, {
            fileName: _jsxFileName,
            lineNumber: 84,
            columnNumber: 37
          }, undefined);
        })]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_components__WEBPACK_IMPORTED_MODULE_0__.Footer, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 89,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Media);

/***/ }),

/***/ "./styles/nav_components/CaretDown.jsx":
/*!*********************************************!*\
  !*** ./styles/nav_components/CaretDown.jsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavItemLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavItemLayout */ "./styles/nav_components/NavItemLayout.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\CaretDown.jsx";



const StyledCaretDown = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-left: 4px;
    padding-top: 6px;
    fill: #7E7E7E;
    ${_NavItemLayout__WEBPACK_IMPORTED_MODULE_1__.NavItemLayout}:hover & {
        fill: white;
    }
`;

const CaretDown = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledCaretDown, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
      d: "M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CaretDown);

/***/ }),

/***/ "./styles/nav_components/DropdownArrowUp.jsx":
/*!***************************************************!*\
  !*** ./styles/nav_components/DropdownArrowUp.jsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _StyledLi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StyledLi */ "./styles/nav_components/StyledLi.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\DropdownArrowUp.jsx";



const StyledArrowUp = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-left: 2px;
    padding-top: 6px;
    fill: #7E7E7E;
    ${_StyledLi__WEBPACK_IMPORTED_MODULE_1__.StyledLi}:hover & {
        fill: white;
    }
`;

const DropdownArrowUp = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledArrowUp, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
      fillRule: "evenodd",
      d: "M14 2.5a.5.5 0 0 0-.5-.5h-6a.5.5 0 0 0 0 1h4.793L2.146 13.146a.5.5 0 0 0 .708.708L13 3.707V8.5a.5.5 0 0 0 1 0v-6z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DropdownArrowUp);

/***/ }),

/***/ "./styles/nav_components/NavArrowUp.jsx":
/*!**********************************************!*\
  !*** ./styles/nav_components/NavArrowUp.jsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavItemLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavItemLayout */ "./styles/nav_components/NavItemLayout.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\NavArrowUp.jsx";



const StyledArrowUp = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-left: 2px;
    padding-top: 6px;
    fill: #7E7E7E;
    ${_NavItemLayout__WEBPACK_IMPORTED_MODULE_1__.NavItemLayout}:hover & {
        fill: white;
    }
`;

const NavArrowUp = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledArrowUp, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
      fillRule: "evenodd",
      d: "M14 2.5a.5.5 0 0 0-.5-.5h-6a.5.5 0 0 0 0 1h4.793L2.146 13.146a.5.5 0 0 0 .708.708L13 3.707V8.5a.5.5 0 0 0 1 0v-6z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavArrowUp);

/***/ }),

/***/ "./styles/nav_components/NavItemLayout.jsx":
/*!*************************************************!*\
  !*** ./styles/nav_components/NavItemLayout.jsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavItemLayout": () => (/* binding */ NavItemLayout)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const NavItemLayout = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().div)`
    font-family: 'Bai Jamjuree', sans-serif;
    padding-left: 1em;
    padding-right: 1em;
    color: white;
    line-height: 80px;
    font-size: 14px;
    font-weight: 500;
    margin-left: 4px;
    margin-right: 4px;
    cursor: pointer;
    position: relative;
    &:hover {
        border-bottom: 2px rgb(255, 70, 85) solid;
    }
`;

/***/ }),

/***/ "./styles/nav_components/RiotLogo.jsx":
/*!********************************************!*\
  !*** ./styles/nav_components/RiotLogo.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Nav_RiotGamesBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/Nav/RiotGamesBar */ "./components/Nav/RiotGamesBar.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\RiotLogo.jsx";




const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    width: 24px;
    height: 24px;
`;
const RiotLogoWrapper = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().button)`
    cursor: pointer;
    margin: 0 12px;
    padding: 0;
    background: none;
    border: none;
`;
const StyledCaretDown = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().svg)`
    display: inline-block;
    width: 16px;
    height: 16px;
    margin-left: 8px;
    margin-bottom: 4px;
    padding-top: 6px;
    fill: #7E7E7E;
    ${RiotLogoWrapper}:hover & {
        fill: white;
    }
`;

const CaretDown = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledCaretDown, {
    viewBox: "0 0 16 16",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
      d: "M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 9
  }, undefined);
};

const RiotLogo = ({
  isGameBarOpen,
  onClick,
  stateControl
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(RiotLogoWrapper, {
      onClick: onClick,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledLogo, {
        viewBox: "0 0 24 24",
        fill: "#fff",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
          d: "M12.534 21.77l-1.09-2.81 10.52.54-.451 4.5zM15.06 0L.307 6.969 2.59 17.471H5.6l-.52-7.512.461-.144 1.81 7.656h3.126l-.116-9.15.462-.144 1.582 9.294h3.31l.78-11.053.462-.144.82 11.197h4.376l1.54-15.37Z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(CaretDown, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_components_Nav_RiotGamesBar__WEBPACK_IMPORTED_MODULE_1__.RiotGamesBar, {
      isOpen: isGameBarOpen,
      stateControl: stateControl
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RiotLogo);

/***/ }),

/***/ "./styles/nav_components/StyledLi.jsx":
/*!********************************************!*\
  !*** ./styles/nav_components/StyledLi.jsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StyledLi": () => (/* binding */ StyledLi)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const StyledLi = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().li)`
    line-height: 50px;
    padding-left: 24px;
    &:hover {
        background-color: #333;
    }
`;

/***/ }),

/***/ "./styles/nav_components/StyledLink.jsx":
/*!**********************************************!*\
  !*** ./styles/nav_components/StyledLink.jsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StyledLink": () => (/* binding */ StyledLink)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const StyledLink = (styled_components__WEBPACK_IMPORTED_MODULE_0___default().a)`
    font-family: 'Bai Jamjuree', sans-serif;
    padding-left: 12px;
    padding-right: 12px;
    color: white;
    line-height: 80px;
    font-size: 14px;
    font-weight: 500;
    margin: 0 .85em;
    &:hover {
        border-bottom: 2px rgb(255, 70, 85) solid;
    }
`;

/***/ }),

/***/ "./styles/nav_components/ValorantLogo.jsx":
/*!************************************************!*\
  !*** ./styles/nav_components/ValorantLogo.jsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\User\\Desktop\\valorant\\valorant_web\\mynextapp\\styles\\nav_components\\ValorantLogo.jsx";



const StyledLogo = (styled_components__WEBPACK_IMPORTED_MODULE_1___default().svg)`
    width: 35px;
    height: 35px;
    margin-top: 22.5px;
    margin-left: 4px;
    margin-right: 4px;
`;

const ValorantLogo = ({
  href
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_0___default()), {
    href: href,
    passHref: true,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("a", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(StyledLogo, {
        viewBox: "0 0 100 100",
        fill: "#fff",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("path", {
          d: "M99.25 48.66V10.28c0-.59-.75-.86-1.12-.39l-41.92 52.4a.627.627 0 00.49 1.02h30.29c.82 0 1.59-.37 2.1-1.01l9.57-11.96c.38-.48.59-1.07.59-1.68zM1.17 50.34L32.66 89.7c.51.64 1.28 1.01 2.1 1.01h30.29c.53 0 .82-.61.49-1.02L1.7 9.89c-.37-.46-1.12-.2-1.12.39v38.38c0 .61.21 1.2.59 1.68z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ValorantLogo);

/***/ }),

/***/ "./styles/nav_components/index.js":
/*!****************************************!*\
  !*** ./styles/nav_components/index.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavItemLayout": () => (/* reexport safe */ _NavItemLayout__WEBPACK_IMPORTED_MODULE_0__.NavItemLayout),
/* harmony export */   "NavArrowUp": () => (/* reexport safe */ _NavArrowUp__WEBPACK_IMPORTED_MODULE_1__.default),
/* harmony export */   "DropdownArrowUp": () => (/* reexport safe */ _DropdownArrowUp__WEBPACK_IMPORTED_MODULE_2__.default),
/* harmony export */   "CaretDown": () => (/* reexport safe */ _CaretDown__WEBPACK_IMPORTED_MODULE_3__.default),
/* harmony export */   "StyledLink": () => (/* reexport safe */ _StyledLink__WEBPACK_IMPORTED_MODULE_4__.StyledLink),
/* harmony export */   "StyledLi": () => (/* reexport safe */ _StyledLi__WEBPACK_IMPORTED_MODULE_5__.StyledLi),
/* harmony export */   "ValorantLogo": () => (/* reexport safe */ _ValorantLogo__WEBPACK_IMPORTED_MODULE_6__.default),
/* harmony export */   "RiotLogo": () => (/* reexport safe */ _RiotLogo__WEBPACK_IMPORTED_MODULE_7__.default)
/* harmony export */ });
/* harmony import */ var _NavItemLayout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavItemLayout */ "./styles/nav_components/NavItemLayout.jsx");
/* harmony import */ var _NavArrowUp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavArrowUp */ "./styles/nav_components/NavArrowUp.jsx");
/* harmony import */ var _DropdownArrowUp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DropdownArrowUp */ "./styles/nav_components/DropdownArrowUp.jsx");
/* harmony import */ var _CaretDown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CaretDown */ "./styles/nav_components/CaretDown.jsx");
/* harmony import */ var _StyledLink__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./StyledLink */ "./styles/nav_components/StyledLink.jsx");
/* harmony import */ var _StyledLi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./StyledLi */ "./styles/nav_components/StyledLi.jsx");
/* harmony import */ var _ValorantLogo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ValorantLogo */ "./styles/nav_components/ValorantLogo.jsx");
/* harmony import */ var _RiotLogo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./RiotLogo */ "./styles/nav_components/RiotLogo.jsx");









/***/ }),

/***/ "./styles/News.module.css":
/*!********************************!*\
  !*** ./styles/News.module.css ***!
  \********************************/
/***/ ((module) => {

// Exports
module.exports = {
	"stroke": "News_stroke__1GeBo",
	"sliderNav": "News_sliderNav__2BHf6",
	"textBackground1": "News_textBackground1__jpuvz",
	"textBackground2": "News_textBackground2__jV5qA"
};


/***/ }),

/***/ "./styles/media.module.css":
/*!*********************************!*\
  !*** ./styles/media.module.css ***!
  \*********************************/
/***/ ((module) => {

// Exports
module.exports = {
	"stroke": "media_stroke__nCo27"
};


/***/ }),

/***/ "./node_modules/next/link.js":
/*!***********************************!*\
  !*** ./node_modules/next/link.js ***!
  \***********************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(/*! ./dist/client/link */ "./node_modules/next/dist/client/link.js")


/***/ }),

/***/ "../../../server/denormalize-page-path":
/*!************************************************************!*\
  !*** external "next/dist/server/denormalize-page-path.js" ***!
  \************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ "../i18n/normalize-locale-path":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/i18n/normalize-locale-path.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ "../mitt":
/*!***********************************************!*\
  !*** external "next/dist/shared/lib/mitt.js" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ "../shared/lib/router-context":
/*!*********************************************************!*\
  !*** external "next/dist/shared/lib/router-context.js" ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ "../shared/lib/router/utils/get-asset-path-from-route":
/*!*********************************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/get-asset-path-from-route.js" ***!
  \*********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ "./utils/is-dynamic":
/*!******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/is-dynamic.js" ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ "./utils/parse-relative-url":
/*!**************************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/parse-relative-url.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ "./utils/querystring":
/*!*******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/querystring.js" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ "./utils/route-matcher":
/*!*********************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/route-matcher.js" ***!
  \*********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ "./utils/route-regex":
/*!*******************************************************************!*\
  !*** external "next/dist/shared/lib/router/utils/route-regex.js" ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ "../shared/lib/utils":
/*!************************************************!*\
  !*** external "next/dist/shared/lib/utils.js" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-is");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ }),

/***/ "?5c99":
/*!******************************************!*\
  !*** ./utils/resolve-rewrites (ignored) ***!
  \******************************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "./public/media_content/contents.json":
/*!********************************************!*\
  !*** ./public/media_content/contents.json ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"wallpaper":[{"path":"../../media_content/pic/wallpaper/W_01.jpeg","type":"arsenals"},{"path":"../../media_content/pic/wallpaper/W_02.jpeg","type":"maps"},{"path":"../../media_content/pic/wallpaper/W_03.jpeg","type":"agents"},{"path":"../../media_content/pic/wallpaper/W_04.jpeg","type":"arsenals"}],"video":[],"screenshot":[],"artwork":[{"path":"../../media_content/pic/artwork/A_01.jpeg","type":"agents"},{"path":"../../media_content/pic/artwork/A_02.jpeg","type":"arsenals"},{"path":"../../media_content/pic/artwork/A_03.jpeg","type":"agents"},{"path":"../../media_content/pic/artwork/A_04.jpeg","type":"agents"}],"logo":[{"path":"../../media_content/pic/logo/L_01.jpeg","type":"NO RELATE"}],"content_creator":[{"path":"../../media_content/pic/content_creator/C_01.jpeg","type":"NO RELATE"}]}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/media/index.jsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvbWVkaWEuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOztBQUVBLE1BQU1DLG1CQUFtQixHQUFHRCxpRUFBYztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FUQTtBQVdBLE1BQU1HLE9BQU8sR0FBR0gsOERBQVc7QUFDM0Isd0JBQXdCSyxLQUFLLElBQUlBLEtBQUssQ0FBQ0MsT0FBTixHQUFnQixTQUFoQixHQUE0QixTQUFVO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYUQsS0FBSyxJQUFJQSxLQUFLLENBQUNDLE9BQU4sR0FBZ0IsU0FBaEIsR0FBNEIsT0FBUTtBQUMxRDtBQUNBO0FBQ0E7QUFDQSxtQkFBbUJELEtBQUssSUFBSUEsS0FBSyxDQUFDRSxVQUFOLEdBQW9CLFNBQVFGLEtBQUssQ0FBQ0MsT0FBTixHQUFnQixXQUFoQixHQUE4QixXQUFZLE1BQXRFLEdBQThFLE1BQU87QUFDakg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FqQkE7QUFtQkEsTUFBTUUsUUFBUSxHQUFHUiw4REFBVztBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1HLE9BQVE7QUFDZDtBQUNBO0FBQ0EsQ0FYQTtBQWFBLE1BQU1NLFlBQVksR0FBR1QsOERBQVc7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FQQTtBQVNBLE1BQU1VLFNBQVMsR0FBR1Ysd0RBQU0sQ0FBQ1MsWUFBRCxDQUFlO0FBQ3ZDO0FBQ0E7QUFDQSxDQUhBO0FBS0EsTUFBTUUsWUFBWSxHQUFHWCx3REFBTSxDQUFDUyxZQUFELENBQWU7QUFDMUM7QUFDQTtBQUNBLENBSEE7O0FBS0EsTUFBTUcsTUFBTSxHQUFHLENBQUM7QUFBRUMsRUFBQUEsUUFBRjtBQUFZUCxFQUFBQSxPQUFaO0FBQXFCQyxFQUFBQTtBQUFyQixDQUFELGtCQUNYLDhEQUFDLG1CQUFEO0FBQUEsMEJBQ0ksOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREosZUFFSSw4REFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGSixlQUdJLDhEQUFDLE9BQUQ7QUFBUyxXQUFPLEVBQUVELE9BQWxCO0FBQTJCLGNBQVUsRUFBRUMsVUFBdkM7QUFBQSxlQUNLTSxRQURMLGVBRUksOERBQUMsUUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURKOztBQVdBLGlFQUFlRCxNQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzRUE7O0FBRUEsTUFBTUUsVUFBVSxHQUFHZCw4REFBVztBQUM5QjtBQUNBO0FBQ0E7QUFDQSxDQUpBOztBQU1BLE1BQU1nQixRQUFRLEdBQUcsTUFBTTtBQUNuQixzQkFDSSw4REFBQyxVQUFEO0FBQVksV0FBTyxFQUFDLFdBQXBCO0FBQWdDLFFBQUksRUFBQyxTQUFyQztBQUFBLDJCQUNJO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsaUVBQWVBLFFBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1PLENBQUMsR0FBR3ZCLDREQUFTO0FBQ25CO0FBQ0E7QUFDQSxDQUhBO0FBS0EsTUFBTXlCLFFBQVEsR0FBR3pCLHdEQUFNLENBQUN1QixDQUFELENBQUk7QUFDM0I7QUFDQTtBQUNBO0FBQ0EsQ0FKQTtBQU1BLE1BQU1HLFdBQVcsR0FBRzFCLDhEQUFXO0FBQy9CO0FBQ0E7QUFDQSxDQUhBO0FBS0EsTUFBTTJCLFNBQVMsR0FBRzNCLHdEQUFNLENBQUN1QixDQUFELENBQUk7QUFDNUI7QUFDQTtBQUNBLENBSEE7QUFLQSxNQUFNSyxXQUFXLEdBQUc1Qiw4REFBVztBQUMvQjtBQUNBO0FBQ0EsQ0FIQTtBQUtBLE1BQU02QixhQUFhLEdBQUc3Qiw4REFBVztBQUNqQztBQUNBO0FBQ0EsQ0FIQTs7QUFLQSxNQUFNOEIsTUFBTSxHQUFHLE1BQU07QUFDakIsc0JBQ0ksOERBQUMsdURBQUQ7QUFBQSw0QkFDSSw4REFBQywrQ0FBRDtBQUFBLDZCQUNJLDhEQUFDLENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBSUksOERBQUMsV0FBRDtBQUFBLDhCQUNJLDhEQUFDLDhDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFFSSw4REFBQyxtREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKSixlQVFJLDhEQUFDLGFBQUQ7QUFBQSw4QkFDSSw4REFBQywrQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUksOERBQUMsOENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQUdJLDhEQUFDLGdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVJKLGVBYUksOERBQUMsUUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFiSixlQWNJLDhEQUFDLFdBQUQ7QUFBQSw4QkFDSSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUksOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQUdJLDhEQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBc0JILENBdkJEOztBQXlCQSxpRUFBZUEsTUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvREE7QUFFTyxNQUFNYixZQUFZLEdBQUdqQixpRUFBYztBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FaTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGUDs7QUFFQSxNQUFNYyxVQUFVLEdBQUdkLDhEQUFXO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FSQTs7QUFVQSxNQUFNb0IsWUFBWSxHQUFHLE1BQU07QUFDdkIsc0JBQ0ksOERBQUMsVUFBRDtBQUFZLFdBQU8sRUFBQyxXQUFwQjtBQUFBLDJCQUNJO0FBQU0sT0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsaUVBQWVBLFlBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEJBOztBQUVBLE1BQU1OLFVBQVUsR0FBR2QsOERBQVc7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVJBOztBQVVBLE1BQU1xQixhQUFhLEdBQUcsTUFBTTtBQUN4QixzQkFDSSw4REFBQyxVQUFEO0FBQVksV0FBTyxFQUFDLFdBQXBCO0FBQUEsMkJBQ0k7QUFBTSxjQUFRLEVBQUMsU0FBZjtBQUF5QixjQUFRLEVBQUMsU0FBbEM7QUFBNEMsT0FBQyxFQUFDO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFLSCxDQU5EOztBQVFBLGlFQUFlQSxhQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BCQTs7QUFFQSxNQUFNUCxVQUFVLEdBQUdkLDhEQUFXO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FSQTs7QUFVQSxNQUFNc0IsV0FBVyxHQUFHLE1BQU07QUFDdEIsc0JBQ0ksOERBQUMsVUFBRDtBQUFZLFdBQU8sRUFBQyxXQUFwQjtBQUFBLDJCQUNJO0FBQU0sY0FBUSxFQUFDLFNBQWY7QUFBeUIsY0FBUSxFQUFDLFNBQWxDO0FBQTRDLE9BQUMsRUFBQztBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxpRUFBZUEsV0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQkE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDREE7O0FBRUEsTUFBTVcsT0FBTyxHQUFHakMsNERBQVM7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FQQTs7QUFTQSxNQUFNbUIsYUFBYSxHQUFHLENBQUM7QUFBRU4sRUFBQUE7QUFBRixDQUFELEtBQWtCO0FBQ3BDLHNCQUNJLDhEQUFDLE9BQUQ7QUFBQSxjQUNLQTtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsaUVBQWVNLGFBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJBOztBQUVBLE1BQU1MLFVBQVUsR0FBR2QsOERBQVc7QUFDOUI7QUFDQTtBQUNBLENBSEE7O0FBS0EsTUFBTWtCLGFBQWEsR0FBRyxDQUFDO0FBQUVpQixFQUFBQTtBQUFGLENBQUQsS0FBYztBQUNoQyxzQkFDSSw4REFBQyxVQUFEO0FBQVksV0FBTyxFQUFDLGdCQUFwQjtBQUFxQyxRQUFJLEVBQUMsU0FBMUM7QUFBQSw0QkFDSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFFSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkosZUFHSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEosZUFJSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkosZUFLSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEosZUFNSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTkosZUFPSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFXSCxDQVpEOztBQWNBLGlFQUFlakIsYUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckJBOzs7QUFFQSxNQUFNbUIsSUFBSSxHQUFHLENBQUM7QUFBRUMsRUFBQUE7QUFBRixDQUFELEtBQWU7QUFDeEIsc0JBQ0ksOERBQUMsa0RBQUQ7QUFBQSw0QkFDSTtBQUFNLGFBQU8sRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFFSTtBQUFNLGVBQVMsRUFBQyxpQkFBaEI7QUFBa0MsYUFBTyxFQUFDO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkosZUFHSTtBQUFNLFVBQUksRUFBQyxVQUFYO0FBQXNCLGFBQU8sRUFBQztBQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUhKLGVBSUk7QUFBTSxTQUFHLEVBQUMsZUFBVjtBQUEwQixVQUFJLEVBQUMsYUFBL0I7QUFBNkMsVUFBSSxFQUFDO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkosZUFLSTtBQUFBLGdCQUFRQTtBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFTSCxDQVZEOztBQVlBLGlFQUFlRCxJQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZEE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU1LLEdBQUcsR0FBRzFDLDZEQUFVO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FMQTtBQU1BLE1BQU00QyxRQUFRLEdBQUc1Qyw2REFBVTtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBTEE7O0FBTUEsTUFBTThDLFdBQVcsR0FBRyxNQUFNO0FBQ3RCLFFBQU1DLE1BQU0sR0FBR04sc0RBQVMsRUFBeEI7QUFDQSxRQUFNO0FBQUVPLElBQUFBO0FBQUYsTUFBZUQsTUFBTSxDQUFDRSxLQUE1QjtBQUVBLHNCQUNBO0FBQUEsMkJBQ0ksOERBQUMsR0FBRDtBQUFBLDhCQUNJLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUU7QUFBRUMsVUFBQUEsS0FBSyxFQUFHLEdBQUdGLFFBQVEsSUFBSSxLQUFaLEdBQWtCLE9BQWxCLEdBQTJCLFNBQVUsRUFBbEQ7QUFBcURHLFVBQUFBLFlBQVksRUFBRyxHQUFHSCxRQUFRLElBQUksS0FBWixHQUFrQixpQkFBbEIsR0FBcUMsTUFBTztBQUFuSCxTQUFqQjtBQUFBLCtCQUEwSSw4REFBQyxrREFBRDtBQUFNLGNBQUksRUFBQyxZQUFYO0FBQXdCLGdCQUFNLEVBQUUsS0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUVJLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUU7QUFBRUUsVUFBQUEsS0FBSyxFQUFHLEdBQUdGLFFBQVEsSUFBSSxXQUFaLEdBQXdCLE9BQXhCLEdBQWlDLFNBQVUsRUFBeEQ7QUFBMkRHLFVBQUFBLFlBQVksRUFBRyxHQUFHSCxRQUFRLElBQUksV0FBWixHQUF3QixpQkFBeEIsR0FBMkMsTUFBTztBQUEvSCxTQUFqQjtBQUFBLCtCQUFzSiw4REFBQyxrREFBRDtBQUFNLGNBQUksRUFBQyxrQkFBWDtBQUE4QixnQkFBTSxFQUFFLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkosZUFHSSw4REFBQyxRQUFEO0FBQVUsYUFBSyxFQUFFO0FBQUVFLFVBQUFBLEtBQUssRUFBRyxHQUFHRixRQUFRLElBQUksT0FBWixHQUFvQixPQUFwQixHQUE2QixTQUFVLEVBQXBEO0FBQXVERyxVQUFBQSxZQUFZLEVBQUcsR0FBR0gsUUFBUSxJQUFJLE9BQVosR0FBb0IsaUJBQXBCLEdBQXVDLE1BQU87QUFBdkgsU0FBakI7QUFBQSwrQkFBOEksOERBQUMsa0RBQUQ7QUFBTSxjQUFJLEVBQUMsY0FBWDtBQUEwQixnQkFBTSxFQUFFLEtBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTlJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEosZUFJSSw4REFBQyxRQUFEO0FBQVUsYUFBSyxFQUFFO0FBQUVFLFVBQUFBLEtBQUssRUFBRyxHQUFHRixRQUFRLElBQUksWUFBWixHQUF5QixPQUF6QixHQUFrQyxTQUFVLEVBQXpEO0FBQTRERyxVQUFBQSxZQUFZLEVBQUcsR0FBR0gsUUFBUSxJQUFJLFlBQVosR0FBeUIsaUJBQXpCLEdBQTRDLE1BQU87QUFBakksU0FBakI7QUFBQSwrQkFBd0osOERBQUMsa0RBQUQ7QUFBTSxjQUFJLEVBQUMsbUJBQVg7QUFBK0IsZ0JBQU0sRUFBRSxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpKLGVBS0ksOERBQUMsUUFBRDtBQUFVLGFBQUssRUFBRTtBQUFFRSxVQUFBQSxLQUFLLEVBQUcsR0FBR0YsUUFBUSxJQUFJLFNBQVosR0FBc0IsT0FBdEIsR0FBK0IsU0FBVSxFQUF0RDtBQUF5REcsVUFBQUEsWUFBWSxFQUFHLEdBQUdILFFBQVEsSUFBSSxTQUFaLEdBQXNCLGlCQUF0QixHQUF5QyxNQUFPO0FBQTNILFNBQWpCO0FBQUEsK0JBQWtKLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLGdCQUFYO0FBQTRCLGdCQUFNLEVBQUUsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMSixlQU1JLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUU7QUFBRUUsVUFBQUEsS0FBSyxFQUFHLEdBQUdGLFFBQVEsSUFBSSxNQUFaLEdBQW1CLE9BQW5CLEdBQTRCLFNBQVUsRUFBbkQ7QUFBc0RHLFVBQUFBLFlBQVksRUFBRyxHQUFHSCxRQUFRLElBQUksTUFBWixHQUFtQixpQkFBbkIsR0FBc0MsTUFBTztBQUFySCxTQUFqQjtBQUFBLCtCQUE0SSw4REFBQyxrREFBRDtBQUFNLGNBQUksRUFBQyxhQUFYO0FBQXlCLGdCQUFNLEVBQUUsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFOSixlQU9JLDhEQUFDLFFBQUQ7QUFBVSxhQUFLLEVBQUU7QUFBRUUsVUFBQUEsS0FBSyxFQUFHLEdBQUdGLFFBQVEsSUFBSSxpQkFBWixHQUE4QixPQUE5QixHQUF1QyxTQUFVLEVBQTlEO0FBQWlFRyxVQUFBQSxZQUFZLEVBQUcsR0FBR0gsUUFBUSxJQUFJLGlCQUFaLEdBQThCLGlCQUE5QixHQUFpRCxNQUFPO0FBQTNJLFNBQWpCO0FBQUEsK0JBQWtLLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLHdCQUFYO0FBQW9DLGdCQUFNLEVBQUUsS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBbEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQSixlQVFJLDhEQUFDLDRDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosbUJBREE7QUFjSCxDQWxCRDs7QUFvQkEsaUVBQWVGLFdBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBLE1BQU1RLElBQUksR0FBR3RELHVFQUFIO0FBQUE7QUFBQTtBQUFBLHVHQUFWO0FBVUEsTUFBTXVELEdBQUcsR0FBR3ZELHVFQUFIO0FBQUE7QUFBQTtBQUFBLDBIQUFUOztBQVlBLE1BQU13QyxhQUFhLEdBQUcsTUFBTTtBQUN4QixRQUFNTyxNQUFNLEdBQUdOLHNEQUFTLEVBQXhCO0FBQ0EsTUFBSTtBQUFFTyxJQUFBQSxRQUFGO0FBQVlRLElBQUFBO0FBQVosTUFBcUJULE1BQU0sQ0FBQ0UsS0FBaEM7O0FBQ0EsTUFBRyxPQUFPTyxJQUFQLEtBQWdCLFdBQW5CLEVBQStCO0FBQzNCQSxJQUFBQSxJQUFJLEdBQUksS0FBUjtBQUNIOztBQUNELFFBQU1DLGNBQWMsR0FBSUMsQ0FBRCxJQUFPO0FBQzFCLFFBQUlDLE1BQU0sR0FBR0QsQ0FBQyxDQUFDRSxNQUFGLENBQVNDLEtBQXRCOztBQUNBLFFBQUcsT0FBT2IsUUFBUCxLQUFvQixXQUF2QixFQUFtQztBQUMvQkEsTUFBQUEsUUFBUSxHQUFJLEtBQVo7QUFDQVcsTUFBQUEsTUFBTSxHQUFJLFNBQVNYLFFBQVUsSUFBSVcsTUFBUSxFQUF6QztBQUNBWixNQUFBQSxNQUFNLENBQUNlLElBQVAsQ0FBWUgsTUFBWjtBQUNILEtBSkQsTUFNSyxJQUFHLE9BQU9ILElBQVAsS0FBZ0IsV0FBbkIsRUFBK0I7QUFDaENHLE1BQUFBLE1BQU0sR0FBSSxHQUFHWCxRQUFVLElBQUlXLE1BQVEsRUFBbkM7QUFDQVosTUFBQUEsTUFBTSxDQUFDZSxJQUFQLENBQVlILE1BQVo7QUFDSCxLQUhJLE1BSUQ7QUFDQUEsTUFBQUEsTUFBTSxHQUFHO0FBQ0xJLFFBQUFBLFFBQVEsRUFBRSwwQkFETDtBQUVMZCxRQUFBQSxLQUFLLEVBQUU7QUFBQ0QsVUFBQUEsUUFBUSxFQUFHLEdBQUdBLFFBQVUsRUFBekI7QUFBNEIsa0JBQVMsR0FBR1csTUFBUTtBQUFoRCxTQUZGO0FBR0xLLFFBQUFBLE1BQU0sRUFBRyxVQUFVaEIsUUFBVSxJQUFJVyxNQUFRO0FBSHBDLE9BQVQ7QUFLQVosTUFBQUEsTUFBTSxDQUFDZSxJQUFQLENBQVlILE1BQU0sQ0FBQ0ssTUFBbkIsRUFBMkJMLE1BQU0sQ0FBQ0ssTUFBbEMsRUFBeUM7QUFDckNDLFFBQUFBLE1BQU0sRUFBRTtBQUQ2QixPQUF6QztBQUdIO0FBQ0osR0F0QkQ7O0FBdUJBLE1BQUlDLE9BQU8sR0FBRztBQUNWLFdBQU8sU0FERztBQUVWLGNBQVUsU0FGQTtBQUdWLFlBQVEsUUFIRTtBQUlWLGdCQUFZO0FBSkYsR0FBZDtBQU1BLE1BQUlDLFFBQVEsR0FBRyxDQUFDO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FBRCxFQUNkO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FEYyxFQUVkO0FBQUMsWUFBUyxRQUFWO0FBQW9CLGFBQVc7QUFBL0IsR0FGYyxFQUdkO0FBQUMsWUFBUyxTQUFWO0FBQXFCLGFBQVc7QUFBaEMsR0FIYyxDQUFmOztBQUlBLFFBQU1DLFdBQVcsR0FBSVYsQ0FBRCxJQUFPO0FBQ3ZCVyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVosQ0FBQyxDQUFDRSxNQUFkO0FBQ0gsR0FGRDs7QUFHQSxzQkFDSTtBQUFBLDJCQUNJLDhEQUFDLEdBQUQ7QUFBSyxhQUFPLEVBQUdRLFdBQWY7QUFBQSw4QkFDSSw4REFBQyxJQUFEO0FBQU0sYUFBSyxFQUFHLElBQUdaLElBQUssRUFBdEI7QUFBQSxrQkFBMkJVLE9BQU8sQ0FBQ1YsSUFBRDtBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLEVBR1FXLFFBQVEsQ0FBQ0ksR0FBVCxDQUFhLENBQUNDLElBQUQsRUFBT0MsS0FBUCxLQUFlO0FBQ3hCLFlBQUdELElBQUksQ0FBQ2hCLElBQUwsSUFBYVUsT0FBTyxDQUFDVixJQUFELENBQXZCLEVBQThCO0FBQzFCLDhCQUFPLDhEQUFDLElBQUQ7QUFBb0IsaUJBQUssRUFBRWdCLElBQUksQ0FBQ1gsS0FBaEM7QUFBQSxzQkFBd0NXLElBQUksQ0FBQ2hCO0FBQTdDLGFBQVlpQixLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVA7QUFDSDtBQUNKLE9BSkQsQ0FIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQWdCSCxDQTFERDs7QUEyREEsaUVBQWVqQyxhQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZGQTtBQUNBO0FBQ0E7OztBQUVBLE1BQU1lLEdBQUcsR0FBR3ZELDhEQUFXO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FMQTtBQU1BLE1BQU02RSxXQUFXLEdBQUc3RSw4REFBVztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FmQTtBQWdCQSxNQUFNOEUsbUJBQW1CLEdBQUc5RSw4REFBVztBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBakJBO0FBa0JBLE1BQU0rRSxVQUFVLEdBQUcvRSw2REFBVTtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVBBO0FBUUEsTUFBTWlGLGlCQUFpQixHQUFHakYsOERBQVc7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBTkE7QUFPQSxNQUFNa0YsY0FBYyxHQUFHbEYsK0RBQVk7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQTFCQTtBQTJCQSxNQUFNb0YsVUFBVSxHQUFHcEYsOERBQVc7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQTFCQTtBQTJCQSxNQUFNcUYsSUFBSSxHQUFHckYsOERBQVc7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBZkE7O0FBaUJBLE1BQU1zRixTQUFTLEdBQUcsTUFBTTtBQUNwQixzQkFDSTtBQUFBLDJCQUNJLDhEQUFDLEdBQUQ7QUFBSyxXQUFLLEVBQUU7QUFBRUMsUUFBQUEsTUFBTSxFQUFFLFFBQVY7QUFBb0JDLFFBQUFBLFFBQVEsRUFBRTtBQUE5QixPQUFaO0FBQUEsOEJBQ0EsOERBQUMsb0RBQUQ7QUFBaUIsYUFBSyxFQUFFO0FBQUVDLFVBQUFBLFVBQVUsRUFBRSxNQUFkO0FBQXNCQyxVQUFBQSxNQUFNLEVBQUUsQ0FBOUI7QUFBaUNDLFVBQUFBLEdBQUcsRUFBRTtBQUF0QyxTQUF4QjtBQUFBLCtCQUNJLDhEQUFDLHdDQUFEO0FBQUssbUJBQVMsR0FBR2YsZ0ZBQUEsRUFBdUJBLHdFQUExQixDQUFkO0FBQXdELGVBQUssRUFBRTtBQUFFa0IsWUFBQUEsUUFBUSxFQUFFO0FBQVosV0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURBLGVBSUEsOERBQUMsV0FBRDtBQUFBLCtCQUNJLDhEQUFDLG1CQUFEO0FBQUEsa0NBQ0ksOERBQUMsVUFBRDtBQUFBLG1DQUFZO0FBQUssdUJBQVMsRUFBQyxRQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQUVJLDhEQUFDLGlCQUFEO0FBQUEsbUNBQW1CO0FBQUssdUJBQVMsRUFBQyxRQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkosZUFHSSw4REFBQyxpQkFBRDtBQUFBLG1DQUFtQjtBQUFLLHVCQUFTLEVBQUMsUUFBZjtBQUFBLDYwQkFBNEs7QUFBRyx5QkFBUyxFQUFDLFdBQWI7QUFBeUIsb0JBQUksRUFBQyxHQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNUs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEosZUFJSSw4REFBQyxJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKQSxlQVlBLDhEQUFDLGNBQUQ7QUFBZ0IsaUJBQVMsRUFBQyxRQUExQjtBQUFBLCtCQUFtQyw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQW9CSCxDQXJCRDs7QUFzQkEsaUVBQWVSLFNBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEpBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBOzs7QUFFQSxNQUFNeEUsVUFBVSxHQUFHZCw4REFBVztBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVZBO0FBWUEsTUFBTW1CLGFBQWEsR0FBR25CLGlFQUFjO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5BOztBQVFBLE1BQU1nRyxVQUFVLEdBQUcsQ0FBQztBQUFFQyxFQUFBQSxNQUFGO0FBQVVDLEVBQUFBO0FBQVYsQ0FBRCxLQUF5QjtBQUN4QyxzQkFDSTtBQUFBLDRCQUNJLDhEQUFDLGFBQUQ7QUFBZSxhQUFPLEVBQUVBLE9BQXhCO0FBQUEsNkJBQ0ksOERBQUMsVUFBRDtBQUFZLGVBQU8sRUFBQyxXQUFwQjtBQUFnQyxZQUFJLEVBQUMsTUFBckM7QUFBQSwrQkFDSTtBQUFNLFdBQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQU1JLDhEQUFDLHVEQUFEO0FBQWMsWUFBTSxFQUFFRDtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5KO0FBQUEsa0JBREo7QUFVSCxDQVhEOztBQWFBLGlFQUFlRCxVQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BDQTs7O0FBRUEsTUFBTUcsWUFBWSxHQUFHbkcsOERBQVc7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWVLLEtBQUssSUFBSUEsS0FBSyxDQUFDNEYsTUFBTixHQUFlLE9BQWYsR0FBeUIsTUFBTztBQUN4RCxDQVZBO0FBWUEsTUFBTUcsaUJBQWlCLEdBQUdwRyw4REFBVztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTs7QUFRQSxNQUFNcUcsV0FBVyxHQUFHLG1CQUNoQiw4REFBQyxpQkFBRDtBQUFtQixTQUFPLEVBQUMsV0FBM0I7QUFBQSx5QkFDSTtBQUFNLEtBQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREo7O0FBTUEsTUFBTUMsZ0JBQWdCLEdBQUd0Ryw4REFBVztBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTs7QUFRQSxNQUFNdUcsVUFBVSxHQUFHLE1BQU07QUFDckIsc0JBQ0ksOERBQUMsZ0JBQUQ7QUFBa0IsV0FBTyxFQUFDLFdBQTFCO0FBQXNDLFFBQUksRUFBQyxNQUEzQztBQUFBLDJCQUNJO0FBQU0sY0FBUSxFQUFDLFNBQWY7QUFBeUIsT0FBQyxFQUFDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFLSCxDQU5EOztBQVFBLE1BQU1DLGVBQWUsR0FBRyxDQUNwQixjQURvQixFQUVwQixlQUZvQixFQUdwQixTQUhvQixFQUlwQixlQUpvQixFQUtwQixVQUxvQixFQU1wQixVQU5vQixFQU9wQixRQVBvQixFQVFwQixTQVJvQixFQVNwQixRQVRvQixFQVVwQixpQkFWb0IsRUFXcEIsWUFYb0IsRUFZcEIsS0Fab0IsRUFhcEIsS0Fib0IsRUFjcEIsV0Fkb0IsRUFlcEIsU0Fmb0IsRUFnQnBCLFlBaEJvQixFQWlCcEIsTUFqQm9CLEVBa0JwQixTQWxCb0IsQ0FBeEI7QUFxQkEsTUFBTUMsYUFBYSxHQUFHekcsOERBQVc7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYUssS0FBSyxJQUFJQSxLQUFLLENBQUNxRyxRQUFOLEdBQWlCLFNBQWpCLEdBQTZCLE1BQU87QUFDMUQ7QUFDQSxjQUFjckcsS0FBSyxJQUFJQSxLQUFLLENBQUNxRyxRQUFOLEdBQWlCLFNBQWpCLEdBQTZCLFNBQVU7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FoQkE7O0FBa0JBLE1BQU1DLFFBQVEsR0FBRyxDQUFDO0FBQUU5RixFQUFBQSxRQUFGO0FBQVk2RixFQUFBQTtBQUFaLENBQUQsa0JBQ2IsOERBQUMsYUFBRDtBQUFlLFVBQVEsRUFBRTdGLFFBQVEsS0FBSzZGLFFBQXRDO0FBQUEsYUFDSzdGLFFBREwsRUFFS0EsUUFBUSxLQUFLNkYsUUFBYixnQkFBeUIsOERBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXpCLEdBQTJDLElBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURKOztBQU9BLE1BQU12RyxPQUFPLEdBQUdILDhEQUFXO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5BO0FBUU8sTUFBTStGLFlBQVksR0FBRyxDQUFDO0FBQUVFLEVBQUFBO0FBQUYsQ0FBRCxrQkFDeEI7QUFBQSx5QkFDSSw4REFBQyxZQUFEO0FBQWMsVUFBTSxFQUFFQSxNQUF0QjtBQUFBLDRCQUNJLDhEQUFDLE9BQUQ7QUFBQSxnQkFDS08sZUFBZSxDQUFDakMsR0FBaEIsQ0FBb0IsQ0FBQ2IsQ0FBRCxFQUFJa0QsQ0FBSixrQkFDakIsOERBQUMsUUFBRDtBQUFVLGdCQUFRLEVBQUMsNENBQW5CO0FBQUEsa0JBQ0tsRDtBQURMLFNBQWtDa0QsQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFRSSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosaUJBREc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEdQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQSxNQUFNWSxNQUFNLEdBQUcsTUFBTTtBQUNqQixRQUFNO0FBQUEsT0FBQ0MsZUFBRDtBQUFBLE9BQWtCQztBQUFsQixNQUF3Q3RFLCtDQUFRLENBQUMsS0FBRCxDQUF0RDtBQUNBLFFBQU07QUFBQSxPQUFDdUUsZ0JBQUQ7QUFBQSxPQUFtQkM7QUFBbkIsTUFBMEN4RSwrQ0FBUSxDQUFDLEtBQUQsQ0FBeEQ7QUFDQSxRQUFNO0FBQUEsT0FBQ3lFLGFBQUQ7QUFBQSxPQUFnQkM7QUFBaEIsTUFBb0MxRSwrQ0FBUSxDQUFDLEtBQUQsQ0FBbEQ7O0FBQ0EsUUFBTTJFLHNCQUFzQixHQUFHckUsQ0FBQyxJQUFJO0FBQ2hDQSxJQUFBQSxDQUFDLENBQUNzRSxjQUFGO0FBQ0FOLElBQUFBLGtCQUFrQixDQUFDLENBQUNELGVBQUYsQ0FBbEI7QUFDQUcsSUFBQUEsbUJBQW1CLENBQUMsS0FBRCxDQUFuQjtBQUNILEdBSkQ7O0FBS0EsUUFBTUssZUFBZSxHQUFHdkUsQ0FBQyxJQUFJO0FBQ3pCQSxJQUFBQSxDQUFDLENBQUNzRSxjQUFGO0FBQ0FKLElBQUFBLG1CQUFtQixDQUFDLENBQUNELGdCQUFGLENBQW5CO0FBQ0FELElBQUFBLGtCQUFrQixDQUFDLEtBQUQsQ0FBbEI7QUFDSCxHQUpEOztBQUtBLFFBQU1RLG9CQUFvQixHQUFHeEUsQ0FBQyxJQUFJO0FBQzlCQSxJQUFBQSxDQUFDLENBQUNzRSxjQUFGO0FBQ0FGLElBQUFBLGdCQUFnQixDQUFDLENBQUNELGFBQUYsQ0FBaEI7QUFDQUgsSUFBQUEsa0JBQWtCLENBQUMsS0FBRCxDQUFsQjtBQUNBRSxJQUFBQSxtQkFBbUIsQ0FBQyxLQUFELENBQW5CO0FBQ0gsR0FMRDs7QUFNQSxRQUFNTyx1QkFBdUIsR0FBR0MsS0FBSyxJQUFJO0FBQ3JDVixJQUFBQSxrQkFBa0IsQ0FBQ1UsS0FBRCxDQUFsQjtBQUNILEdBRkQ7O0FBR0EsUUFBTUMscUJBQXFCLEdBQUdELEtBQUssSUFBSTtBQUNuQ04sSUFBQUEsZ0JBQWdCLENBQUNNLEtBQUQsQ0FBaEI7QUFDSCxHQUZEOztBQUdBLHNCQUNJLCtEQUFDLCtDQUFEO0FBQUEsNEJBQ0ksK0RBQUMsNERBQUQ7QUFBVSxtQkFBYSxFQUFFWCxlQUF6QjtBQUEwQyxhQUFPLEVBQUVNLHNCQUFuRDtBQUEyRSxrQkFBWSxFQUFFSTtBQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBRUksK0RBQUMsa0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGSixlQUdJLCtEQUFDLGdFQUFEO0FBQWMsVUFBSSxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEosZUFJSSwrREFBQyxrREFBRDtBQUFVLFdBQUssRUFBQyx3REFBaEI7QUFBQSw4QkFDSSwrREFBQyw0Q0FBRDtBQUFJLFlBQUksRUFBQyxTQUFUO0FBQW1CLGFBQUssRUFBQztBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUksK0RBQUMsNENBQUQ7QUFBSSxZQUFJLEVBQUMsT0FBVDtBQUFpQixhQUFLLEVBQUM7QUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQUdJLCtEQUFDLDRDQUFEO0FBQUksWUFBSSxFQUFDLFVBQVQ7QUFBb0IsYUFBSyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpKLGVBU0ksK0RBQUMsNkNBQUQ7QUFBUyxVQUFJLEVBQUMsUUFBZDtBQUF1QixXQUFLLEVBQUM7QUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFUSixlQVVJLCtEQUFDLDZDQUFEO0FBQVMsVUFBSSxFQUFDLE9BQWQ7QUFBc0IsV0FBSyxFQUFDO0FBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVkosZUFXSSwrREFBQyw2Q0FBRDtBQUFTLFVBQUksRUFBQyxlQUFkO0FBQThCLFdBQUssRUFBQztBQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVhKLGVBWUksK0RBQUMsa0RBQUQ7QUFBVSxXQUFLLEVBQUMsa0RBQWhCO0FBQUEsOEJBQ0ksK0RBQUMsNENBQUQ7QUFBSSxZQUFJLEVBQUMsUUFBVDtBQUFrQixhQUFLLEVBQUM7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUVJLCtEQUFDLG9EQUFEO0FBQVksYUFBSyxFQUFDO0FBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkosZUFHSSwrREFBQyw0Q0FBRDtBQUFJLFlBQUksRUFBQyxpQkFBVDtBQUEyQixhQUFLLEVBQUM7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWkosZUFpQkksK0RBQUMsa0RBQUQ7QUFBVSxXQUFLLEVBQUMsNENBQWhCO0FBQUEsOEJBQ0ksK0RBQUMsb0RBQUQ7QUFBWSxhQUFLLEVBQUM7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUVJLCtEQUFDLG9EQUFEO0FBQVksYUFBSyxFQUFDO0FBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkosZUFHSSwrREFBQyxvREFBRDtBQUFZLGFBQUssRUFBQztBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqQkosZUFzQkksK0RBQUMsc0RBQUQ7QUFBVSxXQUFLLEVBQUM7QUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF0QkosZUF1QkksK0RBQUMsK0NBQUQ7QUFBQSw4QkFDSSwrREFBQyxnREFBRDtBQUFZLGNBQU0sRUFBRVIsZ0JBQXBCO0FBQXNDLGVBQU8sRUFBRU07QUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUVJLCtEQUFDLGdEQUFEO0FBQVksY0FBTSxFQUFFSixhQUFwQjtBQUFtQyxlQUFPLEVBQUVLLG9CQUE1QztBQUFrRSxvQkFBWSxFQUFFRyxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQThCSCxDQXhERDs7QUEwREEsaUVBQWViLE1BQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyRUE7OztBQUVBLE1BQU1SLFVBQVUsR0FBRyxDQUFDO0FBQUUxRSxFQUFBQTtBQUFGLENBQUQsS0FBZTtBQUM5QixzQkFDSSw4REFBQyw0REFBRDtBQUFBLGVBQ0tBLEtBREwsZUFFSSw4REFBQyxtRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBTUgsQ0FQRDs7QUFTQSxpRUFBZTBFLFVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1hBO0FBQ0E7OztBQUVBLE1BQU1DLEVBQUUsR0FBRyxDQUFDO0FBQUU5RSxFQUFBQSxJQUFGO0FBQVFHLEVBQUFBO0FBQVIsQ0FBRCxLQUFxQjtBQUM1QixzQkFDSSw4REFBQyxrREFBRDtBQUFNLFFBQUksRUFBRUgsSUFBWjtBQUFrQixZQUFRLE1BQTFCO0FBQUEsMkJBQ0ksOERBQUMsNERBQUQ7QUFBQSw2QkFDSTtBQUFBLGtCQUFJRztBQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBT0gsQ0FSRDs7QUFVQSxpRUFBZTJFLEVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDYkE7QUFDQTs7O0FBRUEsTUFBTUYsUUFBUSxHQUFHLENBQUM7QUFBRXpFLEVBQUFBLEtBQUY7QUFBU3pCLEVBQUFBO0FBQVQsQ0FBRCxLQUF5QjtBQUN0QyxzQkFDSSw4REFBQyxpRUFBRDtBQUFBLGVBQ0t5QixLQURMLGVBRUksOERBQUMsNkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGSixlQUdJLDhEQUFDLG1DQUFEO0FBQUEsZ0JBQ0t6QjtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFTSCxDQVZEOztBQVlBLGlFQUFla0csUUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZkE7QUFDQTtBQUVPLE1BQU0yQixFQUFFLEdBQUcxSSw2REFBVTtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNd0ksaUVBQWM7QUFDcEI7QUFDQTtBQUNBLENBYk87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSFA7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RBO0FBQ0E7OztBQUVBLE1BQU1JLFlBQVksR0FBRyxDQUFDO0FBQUV0RyxFQUFBQSxLQUFGO0FBQVN6QixFQUFBQTtBQUFULENBQUQsS0FBeUI7QUFDMUMsc0JBQ0ksOERBQUMsaUVBQUQ7QUFBQSxlQUNLeUIsS0FETCxFQUVLekIsUUFGTCxlQUdJLDhEQUFDLDhEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFPSCxDQVJEOztBQVVBLGlFQUFlK0gsWUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2JBO0FBQ0E7OztBQUVBLE1BQU05QixPQUFPLEdBQUcsQ0FBQztBQUFFM0UsRUFBQUEsSUFBRjtBQUFRRyxFQUFBQSxLQUFSO0FBQWV6QixFQUFBQTtBQUFmLENBQUQsS0FBK0I7QUFDM0Msc0JBQ0ksOERBQUMsa0RBQUQ7QUFBTSxRQUFJLEVBQUVzQixJQUFaO0FBQWtCLFlBQVEsTUFBMUI7QUFBQSwyQkFDSSw4REFBQyw4REFBRDtBQUFBLGlCQUFhRyxLQUFiLEVBQW9CekIsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxpRUFBZWlHLE9BQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1hBOztBQUVBLE1BQU1nQyxHQUFHLEdBQUc5SSw4REFBVztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVZBOztBQVlBLE1BQU02RyxTQUFTLEdBQUcsQ0FBQztBQUFFaEcsRUFBQUE7QUFBRixDQUFELEtBQWtCO0FBQ2hDLHNCQUNJO0FBQUEsMkJBQ0ksOERBQUMsR0FBRDtBQUFBLGdCQUNLQTtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFPSCxDQVJEOztBQVVBLGlFQUFlZ0csU0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4QkE7QUFFQSxNQUFNbUMsWUFBWSxHQUFHaEosOERBQVc7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVJBO0FBVUEsaUVBQWVnSixZQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaQTtBQUNBOzs7QUFFQSxNQUFNcEksTUFBTSxHQUFHWixpRUFBYztBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQWJBOztBQWVBLE1BQU1zSCxVQUFVLEdBQUcsQ0FBQztBQUFFekcsRUFBQUEsUUFBRjtBQUFZcUYsRUFBQUEsT0FBWjtBQUFxQkQsRUFBQUEsTUFBckI7QUFBNkJpRCxFQUFBQTtBQUE3QixDQUFELEtBQWlEO0FBQ2hFLHNCQUNJO0FBQUEsNEJBQ0ksOERBQUMsTUFBRDtBQUFRLGFBQU8sRUFBRWhELE9BQWpCO0FBQUEsZ0JBQ0tyRjtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFJSSw4REFBQyxpREFBRDtBQUFXLFlBQU0sRUFBRW9GLE1BQW5CO0FBQTJCLGtCQUFZLEVBQUVpRDtBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpKO0FBQUEsa0JBREo7QUFRSCxDQVREOztBQVdBLGlFQUFlNUIsVUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0JBO0FBQ0E7OztBQUVBLE1BQU02QixZQUFZLEdBQUduSiw4REFBVztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZUssS0FBSyxJQUFJQSxLQUFLLENBQUM0RixNQUFOLEdBQWUsTUFBZixHQUF3QixNQUFPO0FBQ3ZEO0FBQ0E7QUFDQSxDQVRBO0FBV0EsTUFBTW1ELGdCQUFnQixHQUFHcEosOERBQVc7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVJBO0FBVUEsTUFBTXFKLEtBQUssR0FBR3JKLDhEQUFXO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FkQTtBQWdCQSxNQUFNc0osaUJBQWlCLEdBQUd0Siw4REFBVztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBWEE7QUFhQSxNQUFNdUosa0JBQWtCLEdBQUd2Siw4REFBVztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTtBQVFBLE1BQU13SixXQUFXLEdBQUd4Siw0REFBUztBQUM3QjtBQUNBO0FBQ0E7QUFDQSxDQUpBO0FBTUEsTUFBTW1CLGFBQWEsR0FBR25CLDhEQUFXO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBLENBSkE7QUFNQSxNQUFNeUosaUJBQWlCLEdBQUd6SixpRUFBYztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FUQTs7QUFXQSxNQUFNMEosVUFBVSxHQUFHLENBQUM7QUFBRXhELEVBQUFBO0FBQUYsQ0FBRCxLQUFpQjtBQUNoQyxzQkFDSSw4REFBQyxpQkFBRDtBQUFtQixXQUFPLEVBQUVBLE9BQTVCO0FBQUEsMkJBQ0ksOERBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxNQUFNeUQsT0FBTyxHQUFHM0osOERBQVc7QUFDM0I7QUFDQTtBQUNBO0FBQ0EsTUFBTXlKLGlCQUFrQjtBQUN4QjtBQUNBO0FBQ0EsQ0FQQTs7QUFTQSxNQUFNRyxlQUFlLEdBQUcsbUJBQ3BCLDhEQUFDLE9BQUQ7QUFBUyxTQUFPLEVBQUMsV0FBakI7QUFBQSx5QkFDSTtBQUFNLFFBQUksRUFBQyxNQUFYO0FBQWtCLFVBQU0sRUFBQyxTQUF6QjtBQUFtQyxLQUFDLEVBQUM7QUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESjs7QUFNTyxNQUFNWCxTQUFTLEdBQUcsQ0FBQztBQUFFaEQsRUFBQUEsTUFBRjtBQUFVaUQsRUFBQUE7QUFBVixDQUFELEtBQThCO0FBQ25ELHNCQUNJO0FBQUEsMkJBQ0ksOERBQUMsWUFBRDtBQUFjLFlBQU0sRUFBRWpELE1BQXRCO0FBQUEsOEJBQ0ksOERBQUMsS0FBRDtBQUFBLGdDQUNJLDhEQUFDLGlCQUFEO0FBQUEsa0NBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUFFSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGSixlQUdJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQU1JLDhEQUFDLGtCQUFEO0FBQUEsa0NBQ0ksOERBQUMsYUFBRDtBQUFBLG9DQUNJLDhEQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFFSSw4REFBQywyQ0FBRDtBQUFRLHFCQUFPLE1BQWY7QUFBZ0Isd0JBQVUsTUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBS0ksOERBQUMsYUFBRDtBQUFBLG9DQUNJLDhEQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFFSSw4REFBQywyQ0FBRDtBQUFRLHdCQUFVLE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkosZUFnQkksOERBQUMsVUFBRDtBQUFZLGlCQUFPLEVBQUUsTUFBTWlELFlBQVksQ0FBQyxLQUFEO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQW1CSSw4REFBQyxnQkFBRDtBQUFrQixlQUFPLEVBQUUsTUFBTUEsWUFBWSxDQUFDLEtBQUQ7QUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosbUJBREo7QUF5QkgsQ0ExQk07Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0dQO0FBRU8sTUFBTTNCLFFBQVEsR0FBR3ZILDhEQUFXO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FSTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGUDs7QUFFQSxNQUFNNkosUUFBUSxHQUFHN0osOERBQVc7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBVEE7QUFXQSxNQUFNb0osZ0JBQWdCLEdBQUdwSiw4REFBVztBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVZBO0FBWUEsTUFBTThKLGVBQWUsR0FBRzlKLDhEQUFXO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWVLLEtBQUssSUFBSUEsS0FBSyxDQUFDNEYsTUFBTixHQUFlLE9BQWYsR0FBeUIsTUFBTztBQUN4RCxDQVJBO0FBVUEsTUFBTUssZ0JBQWdCLEdBQUd0Ryw4REFBVztBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTtBQVFBLE1BQU0rSixjQUFjLEdBQUcvSiw0REFBUztBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBLENBTEE7O0FBT0EsTUFBTXVHLFVBQVUsR0FBRyxNQUFNO0FBQ3JCLHNCQUNJLDhEQUFDLGdCQUFEO0FBQWtCLFdBQU8sRUFBQyxXQUExQjtBQUFzQyxRQUFJLEVBQUMsTUFBM0M7QUFBQSwyQkFDSTtBQUFNLGNBQVEsRUFBQyxTQUFmO0FBQXlCLE9BQUMsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRTyxNQUFNeUQsWUFBWSxHQUFHLENBQUM7QUFBRS9ELEVBQUFBLE1BQUY7QUFBVWlELEVBQUFBO0FBQVYsQ0FBRCxLQUE2QjtBQUNyRCxzQkFDSSw4REFBQyxlQUFEO0FBQWlCLFVBQU0sRUFBRWpELE1BQXpCO0FBQUEsNEJBQ0ksOERBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBRUksOERBQUMsUUFBRDtBQUFBLDZCQUNJLDhEQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZKLGVBS0ksOERBQUMsZ0JBQUQ7QUFBa0IsYUFBTyxFQUFFLE1BQU1pRCxZQUFZLENBQUMsS0FBRDtBQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBU0gsQ0FWTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFEUDtBQUNBOzs7QUFHQSxNQUFNdkUsZUFBZSxHQUFHM0UsdUVBQUg7QUFBQTtBQUFBO0FBQUEsc0VBQXJCO0FBTUEsTUFBTTBFLEdBQUcsR0FBRzFFLHdFQUFIO0FBQUE7QUFBQTtBQUFBLGdJQUFUOztBQVNBLE1BQU1rSyxNQUFNLEdBQUcsTUFBTTtBQUNqQixzQkFDSTtBQUFBLDJCQUNBLDhEQUFDLGVBQUQ7QUFBQSw2QkFDSTtBQUFJLGlCQUFTLEVBQUd0Rix1RUFBaEI7QUFBQSxnQ0FDSSw4REFBQyxHQUFEO0FBQUssbUJBQVMsRUFBR0EsZ0ZBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBRUksOERBQUMsR0FBRDtBQUFLLG1CQUFTLEVBQUdBLGdGQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREEsbUJBREo7QUFhSCxDQWREOztBQWVBLGlFQUFlc0YsTUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbENBOztBQUVBLE1BQU1HLFdBQVcsR0FBR3JLLDREQUFTO0FBQzdCO0FBQ0E7QUFDQTtBQUNBLFdBQVdLLEtBQUssSUFBSUEsS0FBSyxDQUFDNkMsS0FBTTtBQUNoQztBQUNBO0FBQ0E7QUFDQSxDQVJBO0FBVUEsaUVBQWUsQ0FBQztBQUFFb0gsRUFBQUEsU0FBRjtBQUFhekosRUFBQUE7QUFBYixDQUFELEtBQTZCO0FBQ3hDLHNCQUNJLDhEQUFDLFdBQUQ7QUFBYSxTQUFLLEVBQUV5SixTQUFwQjtBQUFBLGNBQ0t6SjtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1pBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNIYTs7QUFDYjJKLDhDQUE2QztBQUN6QzNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBNkcsZUFBQSxHQUFrQixLQUFLLENBQXZCOztBQUNBLElBQUlDLE1BQU0sR0FBR0Msc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBUixDQUFuQzs7QUFDQSxJQUFJQyxPQUFPLEdBQUdELG1CQUFPLENBQUMseUZBQUQsQ0FBckI7O0FBQ0EsSUFBSUUsUUFBUSxHQUFHRixtQkFBTyxDQUFDLDJEQUFELENBQXRCOztBQUNBLElBQUlHLGdCQUFnQixHQUFHSCxtQkFBTyxDQUFDLCtFQUFELENBQTlCOztBQUNBLFNBQVNELHNCQUFULENBQWdDSyxHQUFoQyxFQUFxQztBQUNqQyxTQUFPQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsVUFBWCxHQUF3QkQsR0FBeEIsR0FBOEI7QUFDakNqSixJQUFBQSxPQUFPLEVBQUVpSjtBQUR3QixHQUFyQztBQUdIOztBQUNELE1BQU1FLFVBQVUsR0FBRyxFQUFuQjs7QUFFQSxTQUFTQyxRQUFULENBQWtCckksTUFBbEIsRUFBMEJaLElBQTFCLEVBQWdDa0osRUFBaEMsRUFBb0NDLE9BQXBDLEVBQTZDO0FBQ3pDLE1BQUksSUFBSixFQUE4QztBQUM5QyxNQUFJLENBQUMsQ0FBQyxHQUFHUixPQUFKLEVBQWFTLFVBQWIsQ0FBd0JwSixJQUF4QixDQUFMLEVBQW9DLE9BRkssQ0FHekM7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FZLEVBQUFBLE1BQU0sQ0FBQ3FJLFFBQVAsQ0FBZ0JqSixJQUFoQixFQUFzQmtKLEVBQXRCLEVBQTBCQyxPQUExQixFQUFtQ0UsS0FBbkMsQ0FBMENDLEdBQUQsSUFBTztBQUM1QyxjQUEyQztBQUN2QztBQUNBLFlBQU1BLEdBQU47QUFDSDtBQUNKLEdBTEQ7QUFNQSxRQUFNQyxTQUFTLEdBQUdKLE9BQU8sSUFBSSxPQUFPQSxPQUFPLENBQUMzSCxNQUFmLEtBQTBCLFdBQXJDLEdBQW1EMkgsT0FBTyxDQUFDM0gsTUFBM0QsR0FBb0VaLE1BQU0sSUFBSUEsTUFBTSxDQUFDWSxNQUF2RyxDQWJ5QyxDQWN6Qzs7QUFDQXdILEVBQUFBLFVBQVUsQ0FBQ2hKLElBQUksR0FBRyxHQUFQLEdBQWFrSixFQUFiLElBQW1CSyxTQUFTLEdBQUcsTUFBTUEsU0FBVCxHQUFxQixFQUFqRCxDQUFELENBQVYsR0FBbUUsSUFBbkU7QUFDSDs7QUFDRCxTQUFTQyxlQUFULENBQXlCQyxLQUF6QixFQUFnQztBQUM1QixRQUFNO0FBQUVoSSxJQUFBQTtBQUFGLE1BQWNnSSxLQUFLLENBQUNDLGFBQTFCO0FBQ0EsU0FBT2pJLE1BQU0sSUFBSUEsTUFBTSxLQUFLLE9BQXJCLElBQWdDZ0ksS0FBSyxDQUFDRSxPQUF0QyxJQUFpREYsS0FBSyxDQUFDRyxPQUF2RCxJQUFrRUgsS0FBSyxDQUFDSSxRQUF4RSxJQUFvRkosS0FBSyxDQUFDSyxNQUExRixJQUFvR0wsS0FBSyxDQUFDTSxXQUFOLElBQXFCTixLQUFLLENBQUNNLFdBQU4sQ0FBa0JDLEtBQWxCLEtBQTRCLENBQTVKO0FBQ0g7O0FBQ0QsU0FBU0MsV0FBVCxDQUFxQjFJLENBQXJCLEVBQXdCWCxNQUF4QixFQUFnQ1osSUFBaEMsRUFBc0NrSixFQUF0QyxFQUEwQ2dCLE9BQTFDLEVBQW1EQyxPQUFuRCxFQUE0RHJJLE1BQTVELEVBQW9FTixNQUFwRSxFQUE0RTtBQUN4RSxRQUFNO0FBQUU0SSxJQUFBQTtBQUFGLE1BQWdCN0ksQ0FBQyxDQUFDbUksYUFBeEI7O0FBQ0EsTUFBSVUsUUFBUSxLQUFLLEdBQWIsS0FBcUJaLGVBQWUsQ0FBQ2pJLENBQUQsQ0FBZixJQUFzQixDQUFDLENBQUMsR0FBR29ILE9BQUosRUFBYVMsVUFBYixDQUF3QnBKLElBQXhCLENBQTVDLENBQUosRUFBZ0Y7QUFDNUU7QUFDQTtBQUNIOztBQUNEdUIsRUFBQUEsQ0FBQyxDQUFDc0UsY0FBRixHQU53RSxDQU94RTs7QUFDQSxNQUFJL0QsTUFBTSxJQUFJLElBQVYsSUFBa0JvSCxFQUFFLENBQUNtQixPQUFILENBQVcsR0FBWCxLQUFtQixDQUF6QyxFQUE0QztBQUN4Q3ZJLElBQUFBLE1BQU0sR0FBRyxLQUFUO0FBQ0gsR0FWdUUsQ0FXeEU7OztBQUNBbEIsRUFBQUEsTUFBTSxDQUFDc0osT0FBTyxHQUFHLFNBQUgsR0FBZSxNQUF2QixDQUFOLENBQXFDbEssSUFBckMsRUFBMkNrSixFQUEzQyxFQUErQztBQUMzQ2lCLElBQUFBLE9BRDJDO0FBRTNDM0ksSUFBQUEsTUFGMkM7QUFHM0NNLElBQUFBO0FBSDJDLEdBQS9DO0FBS0g7O0FBQ0QsU0FBUzFCLElBQVQsQ0FBY2xDLEtBQWQsRUFBcUI7QUFDakIsWUFBMkM7QUFDdkMsYUFBU29NLGVBQVQsQ0FBeUJDLElBQXpCLEVBQStCO0FBQzNCLGFBQU8sSUFBSUMsS0FBSixDQUFXLGdDQUErQkQsSUFBSSxDQUFDRSxHQUFJLGdCQUFlRixJQUFJLENBQUNHLFFBQVMsNkJBQTRCSCxJQUFJLENBQUNJLE1BQU8sYUFBOUcsSUFBOEgsU0FBZ0MsQ0FBaEMsR0FBcUcsRUFBbk8sQ0FBVixDQUFQO0FBQ0gsS0FIc0MsQ0FJdkM7OztBQUNBLFVBQU1DLGtCQUFrQixHQUFHO0FBQ3ZCNUssTUFBQUEsSUFBSSxFQUFFO0FBRGlCLEtBQTNCO0FBR0EsVUFBTTZLLGFBQWEsR0FBR3hDLE1BQU0sQ0FBQ3lDLElBQVAsQ0FBWUYsa0JBQVosQ0FBdEI7QUFDQUMsSUFBQUEsYUFBYSxDQUFDRSxPQUFkLENBQXVCTixHQUFELElBQU87QUFDekIsVUFBSUEsR0FBRyxLQUFLLE1BQVosRUFBb0I7QUFDaEIsWUFBSXZNLEtBQUssQ0FBQ3VNLEdBQUQsQ0FBTCxJQUFjLElBQWQsSUFBc0IsT0FBT3ZNLEtBQUssQ0FBQ3VNLEdBQUQsQ0FBWixLQUFzQixRQUF0QixJQUFrQyxPQUFPdk0sS0FBSyxDQUFDdU0sR0FBRCxDQUFaLEtBQXNCLFFBQWxGLEVBQTRGO0FBQ3hGLGdCQUFNSCxlQUFlLENBQUM7QUFDbEJHLFlBQUFBLEdBRGtCO0FBRWxCQyxZQUFBQSxRQUFRLEVBQUUsc0JBRlE7QUFHbEJDLFlBQUFBLE1BQU0sRUFBRXpNLEtBQUssQ0FBQ3VNLEdBQUQsQ0FBTCxLQUFlLElBQWYsR0FBc0IsTUFBdEIsR0FBK0IsT0FBT3ZNLEtBQUssQ0FBQ3VNLEdBQUQ7QUFIakMsV0FBRCxDQUFyQjtBQUtIO0FBQ0osT0FSRCxNQVFPO0FBQ0g7QUFDQTtBQUNBLGNBQU1PLENBQUMsR0FBR1AsR0FBVjtBQUNIO0FBQ0osS0FkRCxFQVR1QyxDQXdCdkM7O0FBQ0EsVUFBTVEsa0JBQWtCLEdBQUc7QUFDdkIvQixNQUFBQSxFQUFFLEVBQUUsSUFEbUI7QUFFdkJnQixNQUFBQSxPQUFPLEVBQUUsSUFGYztBQUd2QnBJLE1BQUFBLE1BQU0sRUFBRSxJQUhlO0FBSXZCcUksTUFBQUEsT0FBTyxFQUFFLElBSmM7QUFLdkJlLE1BQUFBLFFBQVEsRUFBRSxJQUxhO0FBTXZCakMsTUFBQUEsUUFBUSxFQUFFLElBTmE7QUFPdkJ6SCxNQUFBQSxNQUFNLEVBQUU7QUFQZSxLQUEzQjtBQVNBLFVBQU0ySixhQUFhLEdBQUc5QyxNQUFNLENBQUN5QyxJQUFQLENBQVlHLGtCQUFaLENBQXRCO0FBQ0FFLElBQUFBLGFBQWEsQ0FBQ0osT0FBZCxDQUF1Qk4sR0FBRCxJQUFPO0FBQ3pCLFlBQU1XLE9BQU8sR0FBRyxPQUFPbE4sS0FBSyxDQUFDdU0sR0FBRCxDQUE1Qjs7QUFDQSxVQUFJQSxHQUFHLEtBQUssSUFBWixFQUFrQjtBQUNkLFlBQUl2TSxLQUFLLENBQUN1TSxHQUFELENBQUwsSUFBY1csT0FBTyxLQUFLLFFBQTFCLElBQXNDQSxPQUFPLEtBQUssUUFBdEQsRUFBZ0U7QUFDNUQsZ0JBQU1kLGVBQWUsQ0FBQztBQUNsQkcsWUFBQUEsR0FEa0I7QUFFbEJDLFlBQUFBLFFBQVEsRUFBRSxzQkFGUTtBQUdsQkMsWUFBQUEsTUFBTSxFQUFFUztBQUhVLFdBQUQsQ0FBckI7QUFLSDtBQUNKLE9BUkQsTUFRTyxJQUFJWCxHQUFHLEtBQUssUUFBWixFQUFzQjtBQUN6QixZQUFJdk0sS0FBSyxDQUFDdU0sR0FBRCxDQUFMLElBQWNXLE9BQU8sS0FBSyxRQUE5QixFQUF3QztBQUNwQyxnQkFBTWQsZUFBZSxDQUFDO0FBQ2xCRyxZQUFBQSxHQURrQjtBQUVsQkMsWUFBQUEsUUFBUSxFQUFFLFVBRlE7QUFHbEJDLFlBQUFBLE1BQU0sRUFBRVM7QUFIVSxXQUFELENBQXJCO0FBS0g7QUFDSixPQVJNLE1BUUEsSUFBSVgsR0FBRyxLQUFLLFNBQVIsSUFBcUJBLEdBQUcsS0FBSyxRQUE3QixJQUF5Q0EsR0FBRyxLQUFLLFNBQWpELElBQThEQSxHQUFHLEtBQUssVUFBdEUsSUFBb0ZBLEdBQUcsS0FBSyxVQUFoRyxFQUE0RztBQUMvRyxZQUFJdk0sS0FBSyxDQUFDdU0sR0FBRCxDQUFMLElBQWMsSUFBZCxJQUFzQlcsT0FBTyxLQUFLLFNBQXRDLEVBQWlEO0FBQzdDLGdCQUFNZCxlQUFlLENBQUM7QUFDbEJHLFlBQUFBLEdBRGtCO0FBRWxCQyxZQUFBQSxRQUFRLEVBQUUsV0FGUTtBQUdsQkMsWUFBQUEsTUFBTSxFQUFFUztBQUhVLFdBQUQsQ0FBckI7QUFLSDtBQUNKLE9BUk0sTUFRQTtBQUNIO0FBQ0E7QUFDQSxjQUFNSixDQUFDLEdBQUdQLEdBQVY7QUFDSDtBQUNKLEtBL0JELEVBbkN1QyxDQW1FdkM7QUFDQTs7QUFDQSxVQUFNWSxTQUFTLEdBQUc3QyxNQUFNLENBQUMzSSxPQUFQLENBQWV5TCxNQUFmLENBQXNCLEtBQXRCLENBQWxCOztBQUNBLFFBQUlwTixLQUFLLENBQUMrSyxRQUFOLElBQWtCLENBQUNvQyxTQUFTLENBQUNFLE9BQWpDLEVBQTBDO0FBQ3RDRixNQUFBQSxTQUFTLENBQUNFLE9BQVYsR0FBb0IsSUFBcEI7QUFDQXJKLE1BQUFBLE9BQU8sQ0FBQ3NKLElBQVIsQ0FBYSxzS0FBYjtBQUNIO0FBQ0o7O0FBQ0QsUUFBTW5NLENBQUMsR0FBR25CLEtBQUssQ0FBQytLLFFBQU4sS0FBbUIsS0FBN0I7QUFDQSxRQUFNckksTUFBTSxHQUFHLENBQUMsR0FBR2dJLFFBQUosRUFBY3RJLFNBQWQsRUFBZjs7QUFDQSxRQUFNO0FBQUVOLElBQUFBLElBQUY7QUFBU2tKLElBQUFBO0FBQVQsTUFBaUJWLE1BQU0sQ0FBQzNJLE9BQVAsQ0FBZTRMLE9BQWYsQ0FBdUIsTUFBSTtBQUM5QyxVQUFNLENBQUNDLFlBQUQsRUFBZUMsVUFBZixJQUE2QixDQUFDLEdBQUdoRCxPQUFKLEVBQWFpRCxXQUFiLENBQXlCaEwsTUFBekIsRUFBaUMxQyxLQUFLLENBQUM4QixJQUF2QyxFQUE2QyxJQUE3QyxDQUFuQztBQUNBLFdBQU87QUFDSEEsTUFBQUEsSUFBSSxFQUFFMEwsWUFESDtBQUVIeEMsTUFBQUEsRUFBRSxFQUFFaEwsS0FBSyxDQUFDZ0wsRUFBTixHQUFXLENBQUMsR0FBR1AsT0FBSixFQUFhaUQsV0FBYixDQUF5QmhMLE1BQXpCLEVBQWlDMUMsS0FBSyxDQUFDZ0wsRUFBdkMsQ0FBWCxHQUF3RHlDLFVBQVUsSUFBSUQ7QUFGdkUsS0FBUDtBQUlILEdBTnNCLEVBTXBCLENBQ0M5SyxNQURELEVBRUMxQyxLQUFLLENBQUM4QixJQUZQLEVBR0M5QixLQUFLLENBQUNnTCxFQUhQLENBTm9CLENBQXZCOztBQVdBLE1BQUk7QUFBRXhLLElBQUFBLFFBQUY7QUFBYXdMLElBQUFBLE9BQWI7QUFBdUJDLElBQUFBLE9BQXZCO0FBQWlDckksSUFBQUEsTUFBakM7QUFBMENOLElBQUFBO0FBQTFDLE1BQXNEdEQsS0FBMUQsQ0F6RmlCLENBMEZqQjs7QUFDQSxNQUFJLE9BQU9RLFFBQVAsS0FBb0IsUUFBeEIsRUFBa0M7QUFDOUJBLElBQUFBLFFBQVEsR0FBRyxhQUFjOEosTUFBTSxDQUFDM0ksT0FBUCxDQUFlZ00sYUFBZixDQUE2QixHQUE3QixFQUFrQyxJQUFsQyxFQUF3Q25OLFFBQXhDLENBQXpCO0FBQ0gsR0E3RmdCLENBOEZqQjs7O0FBQ0EsTUFBSW9OLEtBQUo7O0FBQ0EsWUFBNEM7QUFDeEMsUUFBSTtBQUNBQSxNQUFBQSxLQUFLLEdBQUd0RCxNQUFNLENBQUMzSSxPQUFQLENBQWVrTSxRQUFmLENBQXdCQyxJQUF4QixDQUE2QnROLFFBQTdCLENBQVI7QUFDSCxLQUZELENBRUUsT0FBTzRLLEdBQVAsRUFBWTtBQUNWLFlBQU0sSUFBSWtCLEtBQUosQ0FBVyw4REFBNkR0TSxLQUFLLENBQUM4QixJQUFLLDRGQUF6RSxJQUF3SyxTQUFnQyxDQUFoQyxHQUFzRyxFQUE5USxDQUFWLENBQU47QUFDSDtBQUNKLEdBTkQsTUFNTyxFQUVOOztBQUNELFFBQU1pTSxRQUFRLEdBQUdILEtBQUssSUFBSSxPQUFPQSxLQUFQLEtBQWlCLFFBQTFCLElBQXNDQSxLQUFLLENBQUNJLEdBQTdEO0FBQ0EsUUFBTSxDQUFDQyxrQkFBRCxFQUFxQkMsU0FBckIsSUFBa0MsQ0FBQyxHQUFHdkQsZ0JBQUosRUFBc0J3RCxlQUF0QixDQUFzQztBQUMxRUMsSUFBQUEsVUFBVSxFQUFFO0FBRDhELEdBQXRDLENBQXhDOztBQUdBLFFBQU1DLE1BQU0sR0FBRy9ELE1BQU0sQ0FBQzNJLE9BQVAsQ0FBZTJNLFdBQWYsQ0FBNEJDLEVBQUQsSUFBTTtBQUM1Q04sSUFBQUEsa0JBQWtCLENBQUNNLEVBQUQsQ0FBbEI7O0FBQ0EsUUFBSVIsUUFBSixFQUFjO0FBQ1YsVUFBSSxPQUFPQSxRQUFQLEtBQW9CLFVBQXhCLEVBQW9DQSxRQUFRLENBQUNRLEVBQUQsQ0FBUixDQUFwQyxLQUNLLElBQUksT0FBT1IsUUFBUCxLQUFvQixRQUF4QixFQUFrQztBQUNuQ0EsUUFBQUEsUUFBUSxDQUFDVixPQUFULEdBQW1Ca0IsRUFBbkI7QUFDSDtBQUNKO0FBQ0osR0FSYyxFQVFaLENBQ0NSLFFBREQsRUFFQ0Usa0JBRkQsQ0FSWSxDQUFmOztBQVlBM0QsRUFBQUEsTUFBTSxDQUFDM0ksT0FBUCxDQUFlNk0sU0FBZixDQUF5QixNQUFJO0FBQ3pCLFVBQU1DLGNBQWMsR0FBR1AsU0FBUyxJQUFJL00sQ0FBYixJQUFrQixDQUFDLEdBQUdzSixPQUFKLEVBQWFTLFVBQWIsQ0FBd0JwSixJQUF4QixDQUF6QztBQUNBLFVBQU11SixTQUFTLEdBQUcsT0FBTy9ILE1BQVAsS0FBa0IsV0FBbEIsR0FBZ0NBLE1BQWhDLEdBQXlDWixNQUFNLElBQUlBLE1BQU0sQ0FBQ1ksTUFBNUU7QUFDQSxVQUFNb0wsWUFBWSxHQUFHNUQsVUFBVSxDQUFDaEosSUFBSSxHQUFHLEdBQVAsR0FBYWtKLEVBQWIsSUFBbUJLLFNBQVMsR0FBRyxNQUFNQSxTQUFULEdBQXFCLEVBQWpELENBQUQsQ0FBL0I7O0FBQ0EsUUFBSW9ELGNBQWMsSUFBSSxDQUFDQyxZQUF2QixFQUFxQztBQUNqQzNELE1BQUFBLFFBQVEsQ0FBQ3JJLE1BQUQsRUFBU1osSUFBVCxFQUFla0osRUFBZixFQUFtQjtBQUN2QjFILFFBQUFBLE1BQU0sRUFBRStIO0FBRGUsT0FBbkIsQ0FBUjtBQUdIO0FBQ0osR0FURCxFQVNHLENBQ0NMLEVBREQsRUFFQ2xKLElBRkQsRUFHQ29NLFNBSEQsRUFJQzVLLE1BSkQsRUFLQ25DLENBTEQsRUFNQ3VCLE1BTkQsQ0FUSDs7QUFpQkEsUUFBTWlNLFVBQVUsR0FBRztBQUNmWCxJQUFBQSxHQUFHLEVBQUVLLE1BRFU7QUFFZnhJLElBQUFBLE9BQU8sRUFBR3hDLENBQUQsSUFBSztBQUNWLFVBQUl1SyxLQUFLLENBQUM1TixLQUFOLElBQWUsT0FBTzROLEtBQUssQ0FBQzVOLEtBQU4sQ0FBWTZGLE9BQW5CLEtBQStCLFVBQWxELEVBQThEO0FBQzFEK0gsUUFBQUEsS0FBSyxDQUFDNU4sS0FBTixDQUFZNkYsT0FBWixDQUFvQnhDLENBQXBCO0FBQ0g7O0FBQ0QsVUFBSSxDQUFDQSxDQUFDLENBQUN1TCxnQkFBUCxFQUF5QjtBQUNyQjdDLFFBQUFBLFdBQVcsQ0FBQzFJLENBQUQsRUFBSVgsTUFBSixFQUFZWixJQUFaLEVBQWtCa0osRUFBbEIsRUFBc0JnQixPQUF0QixFQUErQkMsT0FBL0IsRUFBd0NySSxNQUF4QyxFQUFnRE4sTUFBaEQsQ0FBWDtBQUNIO0FBQ0o7QUFUYyxHQUFuQjs7QUFXQXFMLEVBQUFBLFVBQVUsQ0FBQ0UsWUFBWCxHQUEyQnhMLENBQUQsSUFBSztBQUMzQixRQUFJLENBQUMsQ0FBQyxHQUFHb0gsT0FBSixFQUFhUyxVQUFiLENBQXdCcEosSUFBeEIsQ0FBTCxFQUFvQzs7QUFDcEMsUUFBSThMLEtBQUssQ0FBQzVOLEtBQU4sSUFBZSxPQUFPNE4sS0FBSyxDQUFDNU4sS0FBTixDQUFZNk8sWUFBbkIsS0FBb0MsVUFBdkQsRUFBbUU7QUFDL0RqQixNQUFBQSxLQUFLLENBQUM1TixLQUFOLENBQVk2TyxZQUFaLENBQXlCeEwsQ0FBekI7QUFDSDs7QUFDRDBILElBQUFBLFFBQVEsQ0FBQ3JJLE1BQUQsRUFBU1osSUFBVCxFQUFla0osRUFBZixFQUFtQjtBQUN2QjhELE1BQUFBLFFBQVEsRUFBRTtBQURhLEtBQW5CLENBQVI7QUFHSCxHQVJELENBckppQixDQThKakI7QUFDQTs7O0FBQ0EsTUFBSTlPLEtBQUssQ0FBQ2dOLFFBQU4sSUFBa0JZLEtBQUssQ0FBQ3pLLElBQU4sS0FBZSxHQUFmLElBQXNCLEVBQUUsVUFBVXlLLEtBQUssQ0FBQzVOLEtBQWxCLENBQTVDLEVBQXNFO0FBQ2xFLFVBQU1xTCxTQUFTLEdBQUcsT0FBTy9ILE1BQVAsS0FBa0IsV0FBbEIsR0FBZ0NBLE1BQWhDLEdBQXlDWixNQUFNLElBQUlBLE1BQU0sQ0FBQ1ksTUFBNUUsQ0FEa0UsQ0FFbEU7QUFDQTs7QUFDQSxVQUFNeUwsWUFBWSxHQUFHck0sTUFBTSxJQUFJQSxNQUFNLENBQUNzTSxjQUFqQixJQUFtQyxDQUFDLEdBQUd2RSxPQUFKLEVBQWF3RSxlQUFiLENBQTZCakUsRUFBN0IsRUFBaUNLLFNBQWpDLEVBQTRDM0ksTUFBTSxJQUFJQSxNQUFNLENBQUN3TSxPQUE3RCxFQUFzRXhNLE1BQU0sSUFBSUEsTUFBTSxDQUFDeU0sYUFBdkYsQ0FBeEQ7QUFDQVIsSUFBQUEsVUFBVSxDQUFDN00sSUFBWCxHQUFrQmlOLFlBQVksSUFBSSxDQUFDLEdBQUd0RSxPQUFKLEVBQWEyRSxXQUFiLENBQXlCLENBQUMsR0FBRzNFLE9BQUosRUFBYTRFLFNBQWIsQ0FBdUJyRSxFQUF2QixFQUEyQkssU0FBM0IsRUFBc0MzSSxNQUFNLElBQUlBLE1BQU0sQ0FBQzRNLGFBQXZELENBQXpCLENBQWxDO0FBQ0g7O0FBQ0QsU0FBTyxhQUFjaEYsTUFBTSxDQUFDM0ksT0FBUCxDQUFlNE4sWUFBZixDQUE0QjNCLEtBQTVCLEVBQW1DZSxVQUFuQyxDQUFyQjtBQUNIOztBQUNELElBQUlhLFFBQVEsR0FBR3ROLElBQWY7QUFDQW1JLGVBQUEsR0FBa0JtRixRQUFsQjs7Ozs7Ozs7Ozs7QUNqT2E7O0FBQ2JyRiw4Q0FBNkM7QUFDekMzRyxFQUFBQSxLQUFLLEVBQUU7QUFEa0MsQ0FBN0M7QUFHQTZHLCtCQUFBLEdBQWtDb0YsdUJBQWxDO0FBQ0FwRixrQ0FBQSxHQUFxQyxLQUFLLENBQTFDOztBQUNBLFNBQVNvRix1QkFBVCxDQUFpQ0UsSUFBakMsRUFBdUM7QUFDbkMsU0FBT0EsSUFBSSxDQUFDQyxRQUFMLENBQWMsR0FBZCxLQUFzQkQsSUFBSSxLQUFLLEdBQS9CLEdBQXFDQSxJQUFJLENBQUNFLEtBQUwsQ0FBVyxDQUFYLEVBQWMsQ0FBQyxDQUFmLENBQXJDLEdBQXlERixJQUFoRTtBQUNIOztBQUNELE1BQU1ELDBCQUEwQixHQUFHSSxNQUFBLEdBQXFDSCxDQUFyQyxHQVEvQkYsdUJBUko7QUFTQXBGLGtDQUFBLEdBQXFDcUYsMEJBQXJDOzs7Ozs7Ozs7OztBQ2xCYTs7QUFDYnZGLDhDQUE2QztBQUN6QzNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBNkcsMkJBQUEsR0FBOEJBLDBCQUFBLEdBQTZCLEtBQUssQ0FBaEU7O0FBQ0EsTUFBTTZGLG1CQUFtQixHQUFHLE9BQU9FLElBQVAsS0FBZ0IsV0FBaEIsSUFBK0JBLElBQUksQ0FBQ0YsbUJBQXBDLElBQTJERSxJQUFJLENBQUNGLG1CQUFMLENBQXlCRyxJQUF6QixDQUE4QkMsTUFBOUIsQ0FBM0QsSUFBb0csVUFBU0MsRUFBVCxFQUFhO0FBQ3pJLE1BQUlDLEtBQUssR0FBR0MsSUFBSSxDQUFDQyxHQUFMLEVBQVo7QUFDQSxTQUFPQyxVQUFVLENBQUMsWUFBVztBQUN6QkosSUFBQUEsRUFBRSxDQUFDO0FBQ0NLLE1BQUFBLFVBQVUsRUFBRSxLQURiO0FBRUNDLE1BQUFBLGFBQWEsRUFBRSxZQUFXO0FBQ3RCLGVBQU9DLElBQUksQ0FBQ0MsR0FBTCxDQUFTLENBQVQsRUFBWSxNQUFNTixJQUFJLENBQUNDLEdBQUwsS0FBYUYsS0FBbkIsQ0FBWixDQUFQO0FBQ0g7QUFKRixLQUFELENBQUY7QUFNSCxHQVBnQixFQU9kLENBUGMsQ0FBakI7QUFRSCxDQVZEOztBQVdBbkcsMkJBQUEsR0FBOEI2RixtQkFBOUI7O0FBQ0EsTUFBTUMsa0JBQWtCLEdBQUcsT0FBT0MsSUFBUCxLQUFnQixXQUFoQixJQUErQkEsSUFBSSxDQUFDRCxrQkFBcEMsSUFBMERDLElBQUksQ0FBQ0Qsa0JBQUwsQ0FBd0JFLElBQXhCLENBQTZCQyxNQUE3QixDQUExRCxJQUFrRyxVQUFTVSxFQUFULEVBQWE7QUFDdEksU0FBT0MsWUFBWSxDQUFDRCxFQUFELENBQW5CO0FBQ0gsQ0FGRDs7QUFHQTNHLDBCQUFBLEdBQTZCOEYsa0JBQTdCOzs7Ozs7Ozs7OztBQ3BCYTs7QUFDYmhHLDhDQUE2QztBQUN6QzNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBNkcsc0JBQUEsR0FBeUI2RyxjQUF6QjtBQUNBN0csb0JBQUEsR0FBdUI4RyxZQUF2QjtBQUNBOUcsOEJBQUEsR0FBaUMrRyxzQkFBakM7QUFDQS9HLHlCQUFBLEdBQTRCZ0gsaUJBQTVCOztBQUNBLElBQUlDLHNCQUFzQixHQUFHL0csc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsa0hBQUQsQ0FBUixDQUFuRDs7QUFDQSxJQUFJK0csb0JBQW9CLEdBQUcvRyxtQkFBTyxDQUFDLHlGQUFELENBQWxDOztBQUNBLFNBQVNELHNCQUFULENBQWdDSyxHQUFoQyxFQUFxQztBQUNqQyxTQUFPQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsVUFBWCxHQUF3QkQsR0FBeEIsR0FBOEI7QUFDakNqSixJQUFBQSxPQUFPLEVBQUVpSjtBQUR3QixHQUFyQztBQUdILEVBQ0Q7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU00RyxpQkFBaUIsR0FBRyxJQUExQjs7QUFDQSxTQUFTQyxVQUFULENBQW9CbEYsR0FBcEIsRUFBeUJySSxHQUF6QixFQUE4QndOLFNBQTlCLEVBQXlDO0FBQ3JDLE1BQUlDLEtBQUssR0FBR3pOLEdBQUcsQ0FBQzBOLEdBQUosQ0FBUXJGLEdBQVIsQ0FBWjs7QUFDQSxNQUFJb0YsS0FBSixFQUFXO0FBQ1AsUUFBSSxZQUFZQSxLQUFoQixFQUF1QjtBQUNuQixhQUFPQSxLQUFLLENBQUNFLE1BQWI7QUFDSDs7QUFDRCxXQUFPQyxPQUFPLENBQUNDLE9BQVIsQ0FBZ0JKLEtBQWhCLENBQVA7QUFDSDs7QUFDRCxNQUFJSyxRQUFKO0FBQ0EsUUFBTUMsSUFBSSxHQUFHLElBQUlILE9BQUosQ0FBYUMsT0FBRCxJQUFXO0FBQ2hDQyxJQUFBQSxRQUFRLEdBQUdELE9BQVg7QUFDSCxHQUZZLENBQWI7QUFHQTdOLEVBQUFBLEdBQUcsQ0FBQ2dPLEdBQUosQ0FBUTNGLEdBQVIsRUFBYW9GLEtBQUssR0FBRztBQUNqQkksSUFBQUEsT0FBTyxFQUFFQyxRQURRO0FBRWpCSCxJQUFBQSxNQUFNLEVBQUVJO0FBRlMsR0FBckI7QUFJQSxTQUFPUCxTQUFTLEdBQUdBLFNBQVMsR0FBR1MsSUFBWixDQUFrQjNPLEtBQUQsS0FBVXdPLFFBQVEsQ0FBQ3hPLEtBQUQsQ0FBUixFQUFpQkEsS0FBM0IsQ0FBakIsQ0FBSCxHQUNaeU8sSUFESjtBQUVIOztBQUNELFNBQVNHLFdBQVQsQ0FBcUJDLElBQXJCLEVBQTJCO0FBQ3ZCLE1BQUk7QUFDQUEsSUFBQUEsSUFBSSxHQUFHQyxRQUFRLENBQUMzRSxhQUFULENBQXVCLE1BQXZCLENBQVA7QUFDQSxXQUFPO0FBQ1A7QUFDQyxPQUFDLENBQUMyQyxNQUFNLENBQUNpQyxvQkFBVCxJQUFpQyxDQUFDLENBQUNELFFBQVEsQ0FBQ0UsWUFBN0MsSUFBOERILElBQUksQ0FBQ0ksT0FBTCxDQUFhQyxRQUFiLENBQXNCLFVBQXRCO0FBRjlEO0FBR0gsR0FMRCxDQUtFLE9BQU9yUCxDQUFQLEVBQVU7QUFDUixXQUFPLEtBQVA7QUFDSDtBQUNKOztBQUNELE1BQU1zUCxXQUFXLEdBQUdQLFdBQVcsRUFBL0I7O0FBQ0EsU0FBU1EsY0FBVCxDQUF3QjlRLElBQXhCLEVBQThCa0osRUFBOUIsRUFBa0NxSCxJQUFsQyxFQUF3QztBQUNwQyxTQUFPLElBQUlQLE9BQUosQ0FBWSxDQUFDZSxHQUFELEVBQU1DLEdBQU4sS0FBWTtBQUMzQixRQUFJUixRQUFRLENBQUNTLGFBQVQsQ0FBd0IsK0JBQThCalIsSUFBSyxJQUEzRCxDQUFKLEVBQXFFO0FBQ2pFLGFBQU8rUSxHQUFHLEVBQVY7QUFDSDs7QUFDRFIsSUFBQUEsSUFBSSxHQUFHQyxRQUFRLENBQUMzRSxhQUFULENBQXVCLE1BQXZCLENBQVAsQ0FKMkIsQ0FLM0I7O0FBQ0EsUUFBSTNDLEVBQUosRUFBUXFILElBQUksQ0FBQ3JILEVBQUwsR0FBVUEsRUFBVjtBQUNScUgsSUFBQUEsSUFBSSxDQUFDVyxHQUFMLEdBQVksVUFBWjtBQUNBWCxJQUFBQSxJQUFJLENBQUNZLFdBQUwsR0FBbUJuRCxTQUFuQjtBQUNBdUMsSUFBQUEsSUFBSSxDQUFDYyxNQUFMLEdBQWNOLEdBQWQ7QUFDQVIsSUFBQUEsSUFBSSxDQUFDZSxPQUFMLEdBQWVOLEdBQWYsQ0FWMkIsQ0FXM0I7O0FBQ0FULElBQUFBLElBQUksQ0FBQ3ZRLElBQUwsR0FBWUEsSUFBWjtBQUNBd1EsSUFBQUEsUUFBUSxDQUFDZSxJQUFULENBQWNDLFdBQWQsQ0FBMEJqQixJQUExQjtBQUNILEdBZE0sQ0FBUDtBQWVIOztBQUNELE1BQU1rQixnQkFBZ0IsR0FBR0MsTUFBTSxDQUFDLGtCQUFELENBQS9COztBQUNBLFNBQVN0QyxjQUFULENBQXdCOUYsR0FBeEIsRUFBNkI7QUFDekIsU0FBT2pCLE1BQU0sQ0FBQ0MsY0FBUCxDQUFzQmdCLEdBQXRCLEVBQTJCbUksZ0JBQTNCLEVBQTZDLEVBQTdDLENBQVA7QUFFSDs7QUFDRCxTQUFTcEMsWUFBVCxDQUFzQi9GLEdBQXRCLEVBQTJCO0FBQ3ZCLFNBQU9BLEdBQUcsSUFBSW1JLGdCQUFnQixJQUFJbkksR0FBbEM7QUFDSDs7QUFDRCxTQUFTcUksWUFBVCxDQUFzQkMsR0FBdEIsRUFBMkJDLE1BQTNCLEVBQW1DO0FBQy9CLFNBQU8sSUFBSTdCLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVU2QixNQUFWLEtBQW1CO0FBQ2xDRCxJQUFBQSxNQUFNLEdBQUdyQixRQUFRLENBQUMzRSxhQUFULENBQXVCLFFBQXZCLENBQVQsQ0FEa0MsQ0FFbEM7QUFDQTtBQUNBOztBQUNBZ0csSUFBQUEsTUFBTSxDQUFDUixNQUFQLEdBQWdCcEIsT0FBaEI7O0FBQ0E0QixJQUFBQSxNQUFNLENBQUNQLE9BQVAsR0FBaUIsTUFBSVEsTUFBTSxDQUFDMUMsY0FBYyxDQUFDLElBQUk1RSxLQUFKLENBQVcsMEJBQXlCb0gsR0FBSSxFQUF4QyxDQUFELENBQWYsQ0FBM0IsQ0FOa0MsQ0FRbEM7QUFDQTs7O0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ1YsV0FBUCxHQUFxQm5ELFNBQXJCLENBVmtDLENBV2xDO0FBQ0E7O0FBQ0E2RCxJQUFBQSxNQUFNLENBQUNELEdBQVAsR0FBYUEsR0FBYjtBQUNBcEIsSUFBQUEsUUFBUSxDQUFDdUIsSUFBVCxDQUFjUCxXQUFkLENBQTBCSyxNQUExQjtBQUNILEdBZk0sQ0FBUDtBQWdCSCxFQUNEO0FBQ0E7OztBQUNBLElBQUlHLGVBQUosRUFDQTs7QUFDQSxTQUFTQyx5QkFBVCxDQUFtQzVTLENBQW5DLEVBQXNDNlMsRUFBdEMsRUFBMEM1SSxHQUExQyxFQUErQztBQUMzQyxTQUFPLElBQUkwRyxPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFVNkIsTUFBVixLQUFtQjtBQUNsQyxRQUFJSyxTQUFTLEdBQUcsS0FBaEI7QUFDQTlTLElBQUFBLENBQUMsQ0FBQ2dSLElBQUYsQ0FBUStCLENBQUQsSUFBSztBQUNSO0FBQ0FELE1BQUFBLFNBQVMsR0FBRyxJQUFaO0FBQ0FsQyxNQUFBQSxPQUFPLENBQUNtQyxDQUFELENBQVA7QUFDSCxLQUpELEVBSUcvSSxLQUpILENBSVN5SSxNQUpULEVBRmtDLENBT2xDO0FBQ0E7O0FBQ0EsY0FBNEM7QUFDeEMsT0FBQ0UsZUFBZSxJQUFJaEMsT0FBTyxDQUFDQyxPQUFSLEVBQXBCLEVBQXVDSSxJQUF2QyxDQUE0QyxNQUFJO0FBQzVDLFNBQUMsR0FBR1osb0JBQUosRUFBMEJyQixtQkFBMUIsQ0FBOEMsTUFBSVMsVUFBVSxDQUFDLE1BQUk7QUFDekQsY0FBSSxDQUFDc0QsU0FBTCxFQUFnQjtBQUNaTCxZQUFBQSxNQUFNLENBQUN4SSxHQUFELENBQU47QUFDSDtBQUNKLFNBSnVELEVBSXJENEksRUFKcUQsQ0FBNUQ7QUFNSCxPQVBEO0FBUUg7O0FBQ0QsZUFBNEMsRUFPM0M7QUFDSixHQTNCTSxDQUFQO0FBNEJIOztBQUNELFNBQVM1QyxzQkFBVCxHQUFrQztBQUM5QixNQUFJaEIsSUFBSSxDQUFDK0QsZ0JBQVQsRUFBMkI7QUFDdkIsV0FBT3JDLE9BQU8sQ0FBQ0MsT0FBUixDQUFnQjNCLElBQUksQ0FBQytELGdCQUFyQixDQUFQO0FBQ0g7O0FBQ0QsUUFBTUMsZUFBZSxHQUFHLElBQUl0QyxPQUFKLENBQWFDLE9BQUQsSUFBVztBQUMzQztBQUNBLFVBQU14QixFQUFFLEdBQUdILElBQUksQ0FBQ2lFLG1CQUFoQjs7QUFDQWpFLElBQUFBLElBQUksQ0FBQ2lFLG1CQUFMLEdBQTJCLE1BQUk7QUFDM0J0QyxNQUFBQSxPQUFPLENBQUMzQixJQUFJLENBQUMrRCxnQkFBTixDQUFQO0FBQ0E1RCxNQUFBQSxFQUFFLElBQUlBLEVBQUUsRUFBUjtBQUNILEtBSEQ7QUFJSCxHQVB1QixDQUF4QjtBQVFBLFNBQU93RCx5QkFBeUIsQ0FBQ0ssZUFBRCxFQUFrQjVDLGlCQUFsQixFQUFxQ04sY0FBYyxDQUFDLElBQUk1RSxLQUFKLENBQVUsc0NBQVYsQ0FBRCxDQUFuRCxDQUFoQztBQUNIOztBQUNELFNBQVNnSSxnQkFBVCxDQUEwQkMsV0FBMUIsRUFBdUNDLEtBQXZDLEVBQThDO0FBQzFDLFlBQTRDO0FBQ3hDLFdBQU8xQyxPQUFPLENBQUNDLE9BQVIsQ0FBZ0I7QUFDbkIwQyxNQUFBQSxPQUFPLEVBQUUsQ0FDTEYsV0FBVyxHQUFHLDRCQUFkLEdBQTZDRyxTQUFTLENBQUMsQ0FBQyxHQUFHcEQsc0JBQUosRUFBNEIzUCxPQUE1QixDQUFvQzZTLEtBQXBDLEVBQTJDLEtBQTNDLENBQUQsQ0FEakQsQ0FEVTtBQUluQjtBQUNBNUssTUFBQUEsR0FBRyxFQUFFO0FBTGMsS0FBaEIsQ0FBUDtBQU9IOztBQUNELFNBQU93SCxzQkFBc0IsR0FBR2UsSUFBekIsQ0FBK0J3QyxRQUFELElBQVk7QUFDN0MsUUFBSSxFQUFFSCxLQUFLLElBQUlHLFFBQVgsQ0FBSixFQUEwQjtBQUN0QixZQUFNekQsY0FBYyxDQUFDLElBQUk1RSxLQUFKLENBQVcsMkJBQTBCa0ksS0FBTSxFQUEzQyxDQUFELENBQXBCO0FBQ0g7O0FBQ0QsVUFBTUksUUFBUSxHQUFHRCxRQUFRLENBQUNILEtBQUQsQ0FBUixDQUFnQnRRLEdBQWhCLENBQXFCeU4sS0FBRCxJQUFTNEMsV0FBVyxHQUFHLFNBQWQsR0FBMEJHLFNBQVMsQ0FBQy9DLEtBQUQsQ0FBaEUsQ0FBakI7QUFFQSxXQUFPO0FBQ0g4QyxNQUFBQSxPQUFPLEVBQUVHLFFBQVEsQ0FBQ0MsTUFBVCxDQUFpQkMsQ0FBRCxJQUFLQSxDQUFDLENBQUNsRixRQUFGLENBQVcsS0FBWCxDQUFyQixDQUROO0FBR0hoRyxNQUFBQSxHQUFHLEVBQUVnTCxRQUFRLENBQUNDLE1BQVQsQ0FBaUJDLENBQUQsSUFBS0EsQ0FBQyxDQUFDbEYsUUFBRixDQUFXLE1BQVgsQ0FBckI7QUFIRixLQUFQO0FBTUgsR0FaTSxDQUFQO0FBYUg7O0FBQ0QsU0FBU3lCLGlCQUFULENBQTJCa0QsV0FBM0IsRUFBd0M7QUFDcEMsUUFBTVEsV0FBVyxHQUFHLElBQUlDLEdBQUosRUFBcEI7QUFDQSxRQUFNQyxhQUFhLEdBQUcsSUFBSUQsR0FBSixFQUF0QjtBQUNBLFFBQU1FLFdBQVcsR0FBRyxJQUFJRixHQUFKLEVBQXBCO0FBQ0EsUUFBTUcsTUFBTSxHQUFHLElBQUlILEdBQUosRUFBZjs7QUFDQSxXQUFTSSxrQkFBVCxDQUE0QjFCLEdBQTVCLEVBQWlDO0FBQzdCLFFBQUl6QixJQUFJLEdBQUdnRCxhQUFhLENBQUNyRCxHQUFkLENBQWtCOEIsR0FBbEIsQ0FBWDs7QUFDQSxRQUFJekIsSUFBSixFQUFVO0FBQ04sYUFBT0EsSUFBUDtBQUNILEtBSjRCLENBSzdCOzs7QUFDQSxRQUFJSyxRQUFRLENBQUNTLGFBQVQsQ0FBd0IsZ0JBQWVXLEdBQUksSUFBM0MsQ0FBSixFQUFxRDtBQUNqRCxhQUFPNUIsT0FBTyxDQUFDQyxPQUFSLEVBQVA7QUFDSDs7QUFDRGtELElBQUFBLGFBQWEsQ0FBQy9DLEdBQWQsQ0FBa0J3QixHQUFsQixFQUF1QnpCLElBQUksR0FBR3dCLFlBQVksQ0FBQ0MsR0FBRCxDQUExQztBQUNBLFdBQU96QixJQUFQO0FBQ0g7O0FBQ0QsV0FBU29ELGVBQVQsQ0FBeUJ2VCxJQUF6QixFQUErQjtBQUMzQixRQUFJbVEsSUFBSSxHQUFHaUQsV0FBVyxDQUFDdEQsR0FBWixDQUFnQjlQLElBQWhCLENBQVg7O0FBQ0EsUUFBSW1RLElBQUosRUFBVTtBQUNOLGFBQU9BLElBQVA7QUFDSDs7QUFDRGlELElBQUFBLFdBQVcsQ0FBQ2hELEdBQVosQ0FBZ0JwUSxJQUFoQixFQUFzQm1RLElBQUksR0FBR3FELEtBQUssQ0FBQ3hULElBQUQsQ0FBTCxDQUFZcVEsSUFBWixDQUFrQlUsR0FBRCxJQUFPO0FBQ2pELFVBQUksQ0FBQ0EsR0FBRyxDQUFDMEMsRUFBVCxFQUFhO0FBQ1QsY0FBTSxJQUFJakosS0FBSixDQUFXLDhCQUE2QnhLLElBQUssRUFBN0MsQ0FBTjtBQUNIOztBQUNELGFBQU8rUSxHQUFHLENBQUMyQyxJQUFKLEdBQVdyRCxJQUFYLENBQWlCcUQsSUFBRCxLQUFTO0FBQ3hCMVQsUUFBQUEsSUFBSSxFQUFFQSxJQURrQjtBQUV4QjJULFFBQUFBLE9BQU8sRUFBRUQ7QUFGZSxPQUFULENBQWhCLENBQVA7QUFLSCxLQVQ0QixFQVMxQnJLLEtBVDBCLENBU25CQyxHQUFELElBQU87QUFDWixZQUFNOEYsY0FBYyxDQUFDOUYsR0FBRCxDQUFwQjtBQUNILEtBWDRCLENBQTdCO0FBWUEsV0FBTzZHLElBQVA7QUFDSDs7QUFDRCxTQUFPO0FBQ0h5RCxJQUFBQSxjQUFjLENBQUVsQixLQUFGLEVBQVM7QUFDbkIsYUFBTy9DLFVBQVUsQ0FBQytDLEtBQUQsRUFBUU8sV0FBUixDQUFqQjtBQUNILEtBSEU7O0FBSUhZLElBQUFBLFlBQVksQ0FBRW5CLEtBQUYsRUFBU29CLE9BQVQsRUFBa0I7QUFDMUI5RCxNQUFBQSxPQUFPLENBQUNDLE9BQVIsQ0FBZ0I2RCxPQUFoQixFQUF5QnpELElBQXpCLENBQStCMEQsRUFBRCxJQUFNQSxFQUFFLEVBQXRDLEVBQ0UxRCxJQURGLENBQ1E5SCxPQUFELEtBQVk7QUFDWHlMLFFBQUFBLFNBQVMsRUFBRXpMLE9BQU8sSUFBSUEsT0FBTyxDQUFDMUksT0FBbkIsSUFBOEIwSSxPQUQ5QjtBQUVYQSxRQUFBQSxPQUFPLEVBQUVBO0FBRkUsT0FBWixDQURQLEVBS0dlLEdBQUQsS0FBUTtBQUNGMkssUUFBQUEsS0FBSyxFQUFFM0s7QUFETCxPQUFSLENBTEYsRUFRRStHLElBUkYsQ0FRUTZELEtBQUQsSUFBUztBQUNaLGNBQU1DLEdBQUcsR0FBR2xCLFdBQVcsQ0FBQ25ELEdBQVosQ0FBZ0I0QyxLQUFoQixDQUFaO0FBQ0FPLFFBQUFBLFdBQVcsQ0FBQzdDLEdBQVosQ0FBZ0JzQyxLQUFoQixFQUF1QndCLEtBQXZCO0FBQ0EsWUFBSUMsR0FBRyxJQUFJLGFBQWFBLEdBQXhCLEVBQTZCQSxHQUFHLENBQUNsRSxPQUFKLENBQVlpRSxLQUFaO0FBQ2hDLE9BWkQ7QUFhSCxLQWxCRTs7QUFtQkhFLElBQUFBLFNBQVMsQ0FBRTFCLEtBQUYsRUFBU3pKLFFBQVQsRUFBbUI7QUFDeEIsYUFBTzBHLFVBQVUsQ0FBQytDLEtBQUQsRUFBUVcsTUFBUixFQUFnQixNQUFJO0FBQ2pDLGNBQU1nQixpQkFBaUIsR0FBRzdCLGdCQUFnQixDQUFDQyxXQUFELEVBQWNDLEtBQWQsQ0FBaEIsQ0FBcUNyQyxJQUFyQyxDQUEwQyxDQUFDO0FBQUVzQyxVQUFBQSxPQUFGO0FBQVk3SyxVQUFBQTtBQUFaLFNBQUQsS0FBc0I7QUFDdEYsaUJBQU9rSSxPQUFPLENBQUNzRSxHQUFSLENBQVksQ0FDZnJCLFdBQVcsQ0FBQ3NCLEdBQVosQ0FBZ0I3QixLQUFoQixJQUF5QixFQUF6QixHQUE4QjFDLE9BQU8sQ0FBQ3NFLEdBQVIsQ0FBWTNCLE9BQU8sQ0FBQ3ZRLEdBQVIsQ0FBWWtSLGtCQUFaLENBQVosQ0FEZixFQUVmdEQsT0FBTyxDQUFDc0UsR0FBUixDQUFZeE0sR0FBRyxDQUFDMUYsR0FBSixDQUFRbVIsZUFBUixDQUFaLENBRmUsQ0FBWixDQUFQO0FBSUgsU0FMeUIsRUFLdkJsRCxJQUx1QixDQUtqQlUsR0FBRCxJQUFPO0FBQ1gsaUJBQU8sS0FBSzZDLGNBQUwsQ0FBb0JsQixLQUFwQixFQUEyQnJDLElBQTNCLENBQWlDbUUsVUFBRCxLQUFlO0FBQzlDQSxZQUFBQSxVQUQ4QztBQUU5Qy9SLFlBQUFBLE1BQU0sRUFBRXNPLEdBQUcsQ0FBQyxDQUFEO0FBRm1DLFdBQWYsQ0FBaEMsQ0FBUDtBQUtILFNBWHlCLENBQTFCOztBQVlBLGtCQUE0QztBQUN4Q2lCLFVBQUFBLGVBQWUsR0FBRyxJQUFJaEMsT0FBSixDQUFhQyxPQUFELElBQVc7QUFDckMsZ0JBQUlvRSxpQkFBSixFQUF1QjtBQUNuQixxQkFBT0EsaUJBQWlCLENBQUNJLE9BQWxCLENBQTBCLE1BQUk7QUFDakN4RSxnQkFBQUEsT0FBTztBQUNWLGVBRk0sQ0FBUDtBQUdIO0FBQ0osV0FOaUIsQ0FBbEI7QUFPSDs7QUFDRCxlQUFPZ0MseUJBQXlCLENBQUNvQyxpQkFBRCxFQUFvQjNFLGlCQUFwQixFQUF1Q04sY0FBYyxDQUFDLElBQUk1RSxLQUFKLENBQVcsbUNBQWtDa0ksS0FBTSxFQUFuRCxDQUFELENBQXJELENBQXpCLENBQXVJckMsSUFBdkksQ0FBNEksQ0FBQztBQUFFbUUsVUFBQUEsVUFBRjtBQUFlL1IsVUFBQUE7QUFBZixTQUFELEtBQTRCO0FBQzNLLGdCQUFNc08sR0FBRyxHQUFHMUksTUFBTSxDQUFDcU0sTUFBUCxDQUFjO0FBQ3RCalMsWUFBQUEsTUFBTSxFQUFFQTtBQURjLFdBQWQsRUFFVCtSLFVBRlMsQ0FBWjtBQUdBLGlCQUFPLFdBQVdBLFVBQVgsR0FBd0JBLFVBQXhCLEdBQXFDekQsR0FBNUM7QUFDSCxTQUxNLEVBS0oxSCxLQUxJLENBS0dDLEdBQUQsSUFBTztBQUNaLGNBQUlMLFFBQUosRUFBYztBQUNWO0FBQ0Esa0JBQU1LLEdBQU47QUFDSDs7QUFDRCxpQkFBTztBQUNIMkssWUFBQUEsS0FBSyxFQUFFM0s7QUFESixXQUFQO0FBR0gsU0FiTSxDQUFQO0FBY0gsT0FwQ2dCLENBQWpCO0FBcUNILEtBekRFOztBQTBESEwsSUFBQUEsUUFBUSxDQUFFeUosS0FBRixFQUFTO0FBQ2I7QUFDQTtBQUNBLFVBQUlpQyxFQUFKOztBQUNBLFVBQUlBLEVBQUUsR0FBR0MsU0FBUyxDQUFDQyxVQUFuQixFQUErQjtBQUMzQjtBQUNBLFlBQUlGLEVBQUUsQ0FBQ0csUUFBSCxJQUFlLEtBQUszRyxJQUFMLENBQVV3RyxFQUFFLENBQUNJLGFBQWIsQ0FBbkIsRUFBZ0QsT0FBTy9FLE9BQU8sQ0FBQ0MsT0FBUixFQUFQO0FBQ25EOztBQUNELGFBQU91QyxnQkFBZ0IsQ0FBQ0MsV0FBRCxFQUFjQyxLQUFkLENBQWhCLENBQXFDckMsSUFBckMsQ0FBMkMyRSxNQUFELElBQVVoRixPQUFPLENBQUNzRSxHQUFSLENBQVl6RCxXQUFXLEdBQUdtRSxNQUFNLENBQUNyQyxPQUFQLENBQWV2USxHQUFmLENBQW9CeVAsTUFBRCxJQUFVZixjQUFjLENBQUNlLE1BQUQsRUFBUyxRQUFULENBQTNDLENBQUgsR0FDMUUsRUFEbUQsQ0FBcEQsRUFFTHhCLElBRkssQ0FFQSxNQUFJO0FBQ1AsU0FBQyxHQUFHWixvQkFBSixFQUEwQnJCLG1CQUExQixDQUE4QyxNQUFJLEtBQUtnRyxTQUFMLENBQWUxQixLQUFmLEVBQXNCLElBQXRCLEVBQTRCckosS0FBNUIsQ0FBa0MsTUFBSSxDQUNuRixDQUQ2QyxDQUFsRDtBQUdILE9BTk0sRUFNSkEsS0FOSSxFQU1FO0FBQ1QsWUFBSSxDQUNILENBUk0sQ0FBUDtBQVNIOztBQTNFRSxHQUFQO0FBNkVIOzs7Ozs7Ozs7OztBQ3RSWTs7QUFDYmhCLDhDQUE2QztBQUN6QzNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBMkcsMENBQXlDO0FBQ3JDNE0sRUFBQUEsVUFBVSxFQUFFLElBRHlCO0FBRXJDbkYsRUFBQUEsR0FBRyxFQUFFLFlBQVc7QUFDWixXQUFPbkgsT0FBTyxDQUFDOUksT0FBZjtBQUNIO0FBSm9DLENBQXpDO0FBTUF3SSw4Q0FBNkM7QUFDekM0TSxFQUFBQSxVQUFVLEVBQUUsSUFENkI7QUFFekNuRixFQUFBQSxHQUFHLEVBQUUsWUFBVztBQUNaLFdBQU9vRixXQUFXLENBQUNyVixPQUFuQjtBQUNIO0FBSndDLENBQTdDO0FBTUEwSSxpQkFBQSxHQUFvQmpJLFNBQXBCO0FBQ0FpSSxvQkFBQSxHQUF1QjRNLFlBQXZCO0FBQ0E1TSxnQ0FBQSxHQUFtQzZNLHdCQUFuQztBQUNBN00sZUFBQSxHQUFrQixLQUFLLENBQXZCOztBQUNBLElBQUlDLE1BQU0sR0FBR0Msc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBUixDQUFuQzs7QUFDQSxJQUFJQyxPQUFPLEdBQUdGLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLHlGQUFELENBQVIsQ0FBcEM7O0FBQ0EsSUFBSTJNLGNBQWMsR0FBRzNNLG1CQUFPLENBQUMsa0VBQUQsQ0FBNUI7O0FBQ0EsSUFBSXdNLFdBQVcsR0FBR3pNLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLHFFQUFELENBQVIsQ0FBeEM7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NLLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ2pKLElBQUFBLE9BQU8sRUFBRWlKO0FBRHdCLEdBQXJDO0FBR0g7O0FBQ0QsTUFBTXdNLGVBQWUsR0FBRztBQUNwQjFVLEVBQUFBLE1BQU0sRUFBRSxJQURZO0FBRXBCMlUsRUFBQUEsY0FBYyxFQUFFLEVBRkk7O0FBR3BCQyxFQUFBQSxLQUFLLENBQUUvRyxFQUFGLEVBQU07QUFDUCxRQUFJLEtBQUs3TixNQUFULEVBQWlCLE9BQU82TixFQUFFLEVBQVQ7O0FBQ2pCLGVBQW1DLEVBRWxDO0FBQ0o7O0FBUm1CLENBQXhCLEVBVUE7O0FBQ0EsTUFBTWdILGlCQUFpQixHQUFHLENBQ3RCLFVBRHNCLEVBRXRCLE9BRnNCLEVBR3RCLE9BSHNCLEVBSXRCLFFBSnNCLEVBS3RCLFlBTHNCLEVBTXRCLFlBTnNCLEVBT3RCLFVBUHNCLEVBUXRCLFFBUnNCLEVBU3RCLFNBVHNCLEVBVXRCLGVBVnNCLEVBV3RCLFNBWHNCLEVBWXRCLFdBWnNCLEVBYXRCLGdCQWJzQixFQWN0QixlQWRzQixDQUExQjtBQWdCQSxNQUFNQyxZQUFZLEdBQUcsQ0FDakIsa0JBRGlCLEVBRWpCLHFCQUZpQixFQUdqQixxQkFIaUIsRUFJakIsa0JBSmlCLEVBS2pCLGlCQUxpQixFQU1qQixvQkFOaUIsQ0FBckI7QUFRQSxNQUFNQyxnQkFBZ0IsR0FBRyxDQUNyQixNQURxQixFQUVyQixTQUZxQixFQUdyQixRQUhxQixFQUlyQixNQUpxQixFQUtyQixVQUxxQixFQU1yQixnQkFOcUIsQ0FBekIsRUFRQTs7QUFDQXROLE1BQU0sQ0FBQ0MsY0FBUCxDQUFzQmdOLGVBQXRCLEVBQXVDLFFBQXZDLEVBQWlEO0FBQzdDeEYsRUFBQUEsR0FBRyxHQUFJO0FBQ0gsV0FBT25ILE9BQU8sQ0FBQzlJLE9BQVIsQ0FBZ0IrVixNQUF2QjtBQUNIOztBQUg0QyxDQUFqRDtBQUtBSCxpQkFBaUIsQ0FBQzFLLE9BQWxCLENBQTJCOEssS0FBRCxJQUFTO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0F4TixFQUFBQSxNQUFNLENBQUNDLGNBQVAsQ0FBc0JnTixlQUF0QixFQUF1Q08sS0FBdkMsRUFBOEM7QUFDMUMvRixJQUFBQSxHQUFHLEdBQUk7QUFDSCxZQUFNbFAsTUFBTSxHQUFHa1YsU0FBUyxFQUF4QjtBQUNBLGFBQU9sVixNQUFNLENBQUNpVixLQUFELENBQWI7QUFDSDs7QUFKeUMsR0FBOUM7QUFNSCxDQVhEO0FBWUFGLGdCQUFnQixDQUFDNUssT0FBakIsQ0FBMEI4SyxLQUFELElBQVM7QUFDOUJQLEVBQUFBLGVBQWUsQ0FBQ08sS0FBRCxDQUFmLEdBQXlCLENBQUMsR0FBR3RMLElBQUosS0FBVztBQUNoQyxVQUFNM0osTUFBTSxHQUFHa1YsU0FBUyxFQUF4QjtBQUNBLFdBQU9sVixNQUFNLENBQUNpVixLQUFELENBQU4sQ0FBYyxHQUFHdEwsSUFBakIsQ0FBUDtBQUNILEdBSEQ7QUFJSCxDQUxEO0FBTUFtTCxZQUFZLENBQUMzSyxPQUFiLENBQXNCdEIsS0FBRCxJQUFTO0FBQzFCNkwsRUFBQUEsZUFBZSxDQUFDRSxLQUFoQixDQUFzQixNQUFJO0FBQ3RCN00sSUFBQUEsT0FBTyxDQUFDOUksT0FBUixDQUFnQitWLE1BQWhCLENBQXVCRyxFQUF2QixDQUEwQnRNLEtBQTFCLEVBQWlDLENBQUMsR0FBR2MsSUFBSixLQUFXO0FBQ3hDLFlBQU15TCxVQUFVLEdBQUksS0FBSXZNLEtBQUssQ0FBQ3dNLE1BQU4sQ0FBYSxDQUFiLEVBQWdCQyxXQUFoQixFQUE4QixHQUFFek0sS0FBSyxDQUFDME0sU0FBTixDQUFnQixDQUFoQixDQUFtQixFQUEzRTtBQUNBLFlBQU1DLGdCQUFnQixHQUFHZCxlQUF6Qjs7QUFDQSxVQUFJYyxnQkFBZ0IsQ0FBQ0osVUFBRCxDQUFwQixFQUFrQztBQUM5QixZQUFJO0FBQ0FJLFVBQUFBLGdCQUFnQixDQUFDSixVQUFELENBQWhCLENBQTZCLEdBQUd6TCxJQUFoQztBQUNILFNBRkQsQ0FFRSxPQUFPakIsR0FBUCxFQUFZO0FBQ1ZwSCxVQUFBQSxPQUFPLENBQUMrUixLQUFSLENBQWUsd0NBQXVDK0IsVUFBVyxFQUFqRTtBQUNBOVQsVUFBQUEsT0FBTyxDQUFDK1IsS0FBUixDQUFlLEdBQUUzSyxHQUFHLENBQUMrTSxPQUFRLEtBQUkvTSxHQUFHLENBQUNnTixLQUFNLEVBQTNDO0FBQ0g7QUFDSjtBQUNKLEtBWEQ7QUFZSCxHQWJEO0FBY0gsQ0FmRDs7QUFnQkEsU0FBU1IsU0FBVCxHQUFxQjtBQUNqQixNQUFJLENBQUNSLGVBQWUsQ0FBQzFVLE1BQXJCLEVBQTZCO0FBQ3pCLFVBQU15VixPQUFPLEdBQUcsZ0NBQWdDLHFFQUFoRDtBQUNBLFVBQU0sSUFBSTdMLEtBQUosQ0FBVTZMLE9BQVYsQ0FBTjtBQUNIOztBQUNELFNBQU9mLGVBQWUsQ0FBQzFVLE1BQXZCO0FBQ0g7O0FBQ0QsSUFBSThNLFFBQVEsR0FBRzRILGVBQWY7QUFDQS9NLGVBQUEsR0FBa0JtRixRQUFsQjs7QUFDQSxTQUFTcE4sU0FBVCxHQUFxQjtBQUNqQixTQUFPa0ksTUFBTSxDQUFDM0ksT0FBUCxDQUFlMFcsVUFBZixDQUEwQmxCLGNBQWMsQ0FBQ21CLGFBQXpDLENBQVA7QUFDSDs7QUFDRCxTQUFTckIsWUFBVCxDQUFzQixHQUFHNUssSUFBekIsRUFBK0I7QUFDM0IrSyxFQUFBQSxlQUFlLENBQUMxVSxNQUFoQixHQUF5QixJQUFJK0gsT0FBTyxDQUFDOUksT0FBWixDQUFvQixHQUFHMEssSUFBdkIsQ0FBekI7QUFDQStLLEVBQUFBLGVBQWUsQ0FBQ0MsY0FBaEIsQ0FBK0J4SyxPQUEvQixDQUF3QzBELEVBQUQsSUFBTUEsRUFBRSxFQUEvQztBQUVBNkcsRUFBQUEsZUFBZSxDQUFDQyxjQUFoQixHQUFpQyxFQUFqQztBQUNBLFNBQU9ELGVBQWUsQ0FBQzFVLE1BQXZCO0FBQ0g7O0FBQ0QsU0FBU3dVLHdCQUFULENBQWtDeFUsTUFBbEMsRUFBMEM7QUFDdEMsUUFBTWdJLFFBQVEsR0FBR2hJLE1BQWpCO0FBQ0EsUUFBTTZWLFFBQVEsR0FBRyxFQUFqQjs7QUFFQSxPQUFLLE1BQU1DLFFBQVgsSUFBdUJqQixpQkFBdkIsRUFBeUM7QUFDckMsUUFBSSxPQUFPN00sUUFBUSxDQUFDOE4sUUFBRCxDQUFmLEtBQThCLFFBQWxDLEVBQTRDO0FBQ3hDRCxNQUFBQSxRQUFRLENBQUNDLFFBQUQsQ0FBUixHQUFxQnJPLE1BQU0sQ0FBQ3FNLE1BQVAsQ0FBY2lDLEtBQUssQ0FBQ0MsT0FBTixDQUFjaE8sUUFBUSxDQUFDOE4sUUFBRCxDQUF0QixJQUFvQyxFQUFwQyxHQUF5QyxFQUF2RCxFQUNsQjlOLFFBQVEsQ0FBQzhOLFFBQUQsQ0FEVSxDQUFyQixDQUN1QjtBQUR2QjtBQUdBO0FBQ0g7O0FBQ0RELElBQUFBLFFBQVEsQ0FBQ0MsUUFBRCxDQUFSLEdBQXFCOU4sUUFBUSxDQUFDOE4sUUFBRCxDQUE3QjtBQUNILEdBWnFDLENBYXRDOzs7QUFDQUQsRUFBQUEsUUFBUSxDQUFDYixNQUFULEdBQWtCak4sT0FBTyxDQUFDOUksT0FBUixDQUFnQitWLE1BQWxDO0FBQ0FELEVBQUFBLGdCQUFnQixDQUFDNUssT0FBakIsQ0FBMEI4SyxLQUFELElBQVM7QUFDOUJZLElBQUFBLFFBQVEsQ0FBQ1osS0FBRCxDQUFSLEdBQWtCLENBQUMsR0FBR3RMLElBQUosS0FBVztBQUN6QixhQUFPM0IsUUFBUSxDQUFDaU4sS0FBRCxDQUFSLENBQWdCLEdBQUd0TCxJQUFuQixDQUFQO0FBQ0gsS0FGRDtBQUdILEdBSkQ7QUFLQSxTQUFPa00sUUFBUDtBQUNIOzs7Ozs7Ozs7OztBQ3hKWTs7QUFDYnBPLDhDQUE2QztBQUN6QzNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBNkcsdUJBQUEsR0FBMEI4RCxlQUExQjs7QUFDQSxJQUFJN0QsTUFBTSxHQUFHRSxtQkFBTyxDQUFDLG9CQUFELENBQXBCOztBQUNBLElBQUkrRyxvQkFBb0IsR0FBRy9HLG1CQUFPLENBQUMseUZBQUQsQ0FBbEM7O0FBQ0EsTUFBTW1PLHVCQUF1QixHQUFHLE9BQU9DLG9CQUFQLEtBQWdDLFdBQWhFOztBQUNBLFNBQVN6SyxlQUFULENBQXlCO0FBQUVDLEVBQUFBLFVBQUY7QUFBZXlLLEVBQUFBO0FBQWYsQ0FBekIsRUFBcUQ7QUFDakQsUUFBTUMsVUFBVSxHQUFHRCxRQUFRLElBQUksQ0FBQ0YsdUJBQWhDO0FBQ0EsUUFBTUksU0FBUyxHQUFHLENBQUMsR0FBR3pPLE1BQUosRUFBWThDLE1BQVosRUFBbEI7QUFDQSxRQUFNLENBQUM0TCxPQUFELEVBQVVDLFVBQVYsSUFBd0IsQ0FBQyxHQUFHM08sTUFBSixFQUFZdkgsUUFBWixDQUFxQixLQUFyQixDQUE5QjtBQUNBLFFBQU1zTCxNQUFNLEdBQUcsQ0FBQyxHQUFHL0QsTUFBSixFQUFZZ0UsV0FBWixDQUF5QkMsRUFBRCxJQUFNO0FBQ3pDLFFBQUl3SyxTQUFTLENBQUMxTCxPQUFkLEVBQXVCO0FBQ25CMEwsTUFBQUEsU0FBUyxDQUFDMUwsT0FBVjtBQUNBMEwsTUFBQUEsU0FBUyxDQUFDMUwsT0FBVixHQUFvQjZMLFNBQXBCO0FBQ0g7O0FBQ0QsUUFBSUosVUFBVSxJQUFJRSxPQUFsQixFQUEyQjs7QUFDM0IsUUFBSXpLLEVBQUUsSUFBSUEsRUFBRSxDQUFDNEssT0FBYixFQUFzQjtBQUNsQkosTUFBQUEsU0FBUyxDQUFDMUwsT0FBVixHQUFvQitMLE9BQU8sQ0FBQzdLLEVBQUQsRUFBTUwsU0FBRCxJQUFhQSxTQUFTLElBQUkrSyxVQUFVLENBQUMvSyxTQUFELENBQXpDLEVBQ3pCO0FBQ0VFLFFBQUFBO0FBREYsT0FEeUIsQ0FBM0I7QUFJSDtBQUNKLEdBWmMsRUFZWixDQUNDMEssVUFERCxFQUVDMUssVUFGRCxFQUdDNEssT0FIRCxDQVpZLENBQWY7QUFpQkEsR0FBQyxHQUFHMU8sTUFBSixFQUFZa0UsU0FBWixDQUFzQixNQUFJO0FBQ3RCLFFBQUksQ0FBQ21LLHVCQUFMLEVBQThCO0FBQzFCLFVBQUksQ0FBQ0ssT0FBTCxFQUFjO0FBQ1YsY0FBTUssWUFBWSxHQUFHLENBQUMsR0FBRzlILG9CQUFKLEVBQTBCckIsbUJBQTFCLENBQThDLE1BQUkrSSxVQUFVLENBQUMsSUFBRCxDQUE1RCxDQUFyQjtBQUVBLGVBQU8sTUFBSSxDQUFDLEdBQUcxSCxvQkFBSixFQUEwQnBCLGtCQUExQixDQUE2Q2tKLFlBQTdDLENBQVg7QUFFSDtBQUNKO0FBQ0osR0FURCxFQVNHLENBQ0NMLE9BREQsQ0FUSDtBQVlBLFNBQU8sQ0FDSDNLLE1BREcsRUFFSDJLLE9BRkcsQ0FBUDtBQUlIOztBQUNELFNBQVNJLE9BQVQsQ0FBaUJFLE9BQWpCLEVBQTBCQyxRQUExQixFQUFvQ3RPLE9BQXBDLEVBQTZDO0FBQ3pDLFFBQU07QUFBRStGLElBQUFBLEVBQUY7QUFBT3dJLElBQUFBLFFBQVA7QUFBa0JDLElBQUFBO0FBQWxCLE1BQWdDQyxjQUFjLENBQUN6TyxPQUFELENBQXBEO0FBQ0F3TyxFQUFBQSxRQUFRLENBQUN2SCxHQUFULENBQWFvSCxPQUFiLEVBQXNCQyxRQUF0QjtBQUNBQyxFQUFBQSxRQUFRLENBQUNKLE9BQVQsQ0FBaUJFLE9BQWpCO0FBQ0EsU0FBTyxTQUFTUCxTQUFULEdBQXFCO0FBQ3hCVSxJQUFBQSxRQUFRLENBQUNFLE1BQVQsQ0FBZ0JMLE9BQWhCO0FBQ0FFLElBQUFBLFFBQVEsQ0FBQ1QsU0FBVCxDQUFtQk8sT0FBbkIsRUFGd0IsQ0FHeEI7O0FBQ0EsUUFBSUcsUUFBUSxDQUFDRyxJQUFULEtBQWtCLENBQXRCLEVBQXlCO0FBQ3JCSixNQUFBQSxRQUFRLENBQUNLLFVBQVQ7QUFDQUMsTUFBQUEsU0FBUyxDQUFDSCxNQUFWLENBQWlCM0ksRUFBakI7QUFDSDtBQUNKLEdBUkQ7QUFTSDs7QUFDRCxNQUFNOEksU0FBUyxHQUFHLElBQUk5RSxHQUFKLEVBQWxCOztBQUNBLFNBQVMwRSxjQUFULENBQXdCek8sT0FBeEIsRUFBaUM7QUFDN0IsUUFBTStGLEVBQUUsR0FBRy9GLE9BQU8sQ0FBQ21ELFVBQVIsSUFBc0IsRUFBakM7QUFDQSxNQUFJbUssUUFBUSxHQUFHdUIsU0FBUyxDQUFDbEksR0FBVixDQUFjWixFQUFkLENBQWY7O0FBQ0EsTUFBSXVILFFBQUosRUFBYztBQUNWLFdBQU9BLFFBQVA7QUFDSDs7QUFDRCxRQUFNa0IsUUFBUSxHQUFHLElBQUl6RSxHQUFKLEVBQWpCO0FBQ0EsUUFBTXdFLFFBQVEsR0FBRyxJQUFJWixvQkFBSixDQUEwQm1CLE9BQUQsSUFBVztBQUNqREEsSUFBQUEsT0FBTyxDQUFDbE4sT0FBUixDQUFpQjhFLEtBQUQsSUFBUztBQUNyQixZQUFNNEgsUUFBUSxHQUFHRSxRQUFRLENBQUM3SCxHQUFULENBQWFELEtBQUssQ0FBQ3BPLE1BQW5CLENBQWpCO0FBQ0EsWUFBTTJLLFNBQVMsR0FBR3lELEtBQUssQ0FBQ3FJLGNBQU4sSUFBd0JySSxLQUFLLENBQUNzSSxpQkFBTixHQUEwQixDQUFwRTs7QUFDQSxVQUFJVixRQUFRLElBQUlyTCxTQUFoQixFQUEyQjtBQUN2QnFMLFFBQUFBLFFBQVEsQ0FBQ3JMLFNBQUQsQ0FBUjtBQUNIO0FBQ0osS0FORDtBQU9ILEdBUmdCLEVBUWRqRCxPQVJjLENBQWpCO0FBU0E2TyxFQUFBQSxTQUFTLENBQUM1SCxHQUFWLENBQWNsQixFQUFkLEVBQWtCdUgsUUFBUSxHQUFHO0FBQ3pCdkgsSUFBQUEsRUFEeUI7QUFFekJ3SSxJQUFBQSxRQUZ5QjtBQUd6QkMsSUFBQUE7QUFIeUIsR0FBN0I7QUFLQSxTQUFPbEIsUUFBUDtBQUNIOzs7Ozs7Ozs7OztBQ25GWTs7QUFDYnBPLDhDQUE2QztBQUN6QzNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBNkcsZUFBQSxHQUFrQjZQLFVBQWxCOztBQUNBLElBQUk1UCxNQUFNLEdBQUdDLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBbkM7O0FBQ0EsSUFBSUMsT0FBTyxHQUFHRCxtQkFBTyxDQUFDLDJEQUFELENBQXJCOztBQUNBLFNBQVNELHNCQUFULENBQWdDSyxHQUFoQyxFQUFxQztBQUNqQyxTQUFPQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsVUFBWCxHQUF3QkQsR0FBeEIsR0FBOEI7QUFDakNqSixJQUFBQSxPQUFPLEVBQUVpSjtBQUR3QixHQUFyQztBQUdIOztBQUNELFNBQVNzUCxVQUFULENBQW9CQyxpQkFBcEIsRUFBdUM7QUFDbkMsV0FBU0MsaUJBQVQsQ0FBMkJwYSxLQUEzQixFQUFrQztBQUM5QixXQUFPLGFBQWNzSyxNQUFNLENBQUMzSSxPQUFQLENBQWVnTSxhQUFmLENBQTZCd00saUJBQTdCLEVBQWdEaFEsTUFBTSxDQUFDcU0sTUFBUCxDQUFjO0FBQy9FOVQsTUFBQUEsTUFBTSxFQUFFLENBQUMsR0FBRytILE9BQUosRUFBYXJJLFNBQWI7QUFEdUUsS0FBZCxFQUVsRXBDLEtBRmtFLENBQWhELENBQXJCO0FBR0g7O0FBQ0RvYSxFQUFBQSxpQkFBaUIsQ0FBQ0MsZUFBbEIsR0FBb0NGLGlCQUFpQixDQUFDRSxlQUF0RDtBQUNBRCxFQUFBQSxpQkFBaUIsQ0FBQ0UsbUJBQWxCLEdBQXdDSCxpQkFBaUIsQ0FBQ0csbUJBQTFEOztBQUNBLFlBQTJDO0FBQ3ZDLFVBQU1DLElBQUksR0FBR0osaUJBQWlCLENBQUNLLFdBQWxCLElBQWlDTCxpQkFBaUIsQ0FBQ0ksSUFBbkQsSUFBMkQsU0FBeEU7QUFDQUgsSUFBQUEsaUJBQWlCLENBQUNJLFdBQWxCLEdBQWlDLGNBQWFELElBQUssR0FBbkQ7QUFDSDs7QUFDRCxTQUFPSCxpQkFBUDtBQUNIOzs7Ozs7Ozs7OztBQ3pCWTs7QUFDYmpRLDhDQUE2QztBQUN6QzNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBNkcsdUJBQUEsR0FBMEI0RSxlQUExQjtBQUNBNUUsaUJBQUEsR0FBb0JnRixTQUFwQjtBQUNBaEYsaUJBQUEsR0FBb0JvUSxTQUFwQjtBQUNBcFEsbUJBQUEsR0FBc0JxUSxXQUF0QjtBQUNBclEsbUJBQUEsR0FBc0IrRSxXQUF0QjtBQUNBL0UsbUJBQUEsR0FBc0JzUSxXQUF0QjtBQUNBdFEsa0JBQUEsR0FBcUJhLFVBQXJCO0FBQ0FiLHFCQUFBLEdBQXdCdVEsYUFBeEI7QUFDQXZRLG1CQUFBLEdBQXNCcUQsV0FBdEI7QUFDQXJELGVBQUEsR0FBa0IsS0FBSyxDQUF2Qjs7QUFDQSxJQUFJd1EsdUJBQXVCLEdBQUdyUSxtQkFBTyxDQUFDLDZHQUFELENBQXJDOztBQUNBLElBQUlzUSxZQUFZLEdBQUd0USxtQkFBTyxDQUFDLHFGQUFELENBQTFCOztBQUNBLElBQUl1USxvQkFBb0IsR0FBR3ZRLG1CQUFPLENBQUMsb0ZBQUQsQ0FBbEM7O0FBQ0EsSUFBSXdRLG9CQUFvQixHQUFHeFEsbUJBQU8sQ0FBQyxvRUFBRCxDQUFsQzs7QUFDQSxJQUFJeVEsS0FBSyxHQUFHMVEsc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsd0JBQUQsQ0FBUixDQUFsQzs7QUFDQSxJQUFJMFEsTUFBTSxHQUFHMVEsbUJBQU8sQ0FBQyxxQ0FBRCxDQUFwQjs7QUFDQSxJQUFJMlEsVUFBVSxHQUFHM1EsbUJBQU8sQ0FBQyw4Q0FBRCxDQUF4Qjs7QUFDQSxJQUFJNFEsaUJBQWlCLEdBQUc1USxtQkFBTyxDQUFDLDhEQUFELENBQS9COztBQUNBLElBQUk2USxZQUFZLEdBQUc3USxtQkFBTyxDQUFDLGdEQUFELENBQTFCOztBQUNBLElBQUk4USxnQkFBZ0IsR0FBRy9RLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLHVDQUFELENBQVIsQ0FBN0M7O0FBQ0EsSUFBSStRLGFBQWEsR0FBRy9RLG1CQUFPLENBQUMsb0RBQUQsQ0FBM0I7O0FBQ0EsSUFBSWdSLFdBQVcsR0FBR2hSLG1CQUFPLENBQUMsZ0RBQUQsQ0FBekI7O0FBQ0EsU0FBU0Qsc0JBQVQsQ0FBZ0NLLEdBQWhDLEVBQXFDO0FBQ2pDLFNBQU9BLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxVQUFYLEdBQXdCRCxHQUF4QixHQUE4QjtBQUNqQ2pKLElBQUFBLE9BQU8sRUFBRWlKO0FBRHdCLEdBQXJDO0FBR0g7O0FBQ0QsSUFBSTZRLGtCQUFKOztBQUNBLElBQUkzTCxLQUFKLEVBQXFDLEVBRXBDOztBQUNELE1BQU02TCxRQUFRLEdBQUc3TCxNQUFBLElBQXNDLEVBQXZEOztBQUNBLFNBQVMrTCxzQkFBVCxHQUFrQztBQUM5QixTQUFPMVIsTUFBTSxDQUFDcU0sTUFBUCxDQUFjLElBQUlsSyxLQUFKLENBQVUsaUJBQVYsQ0FBZCxFQUE0QztBQUMvQzJILElBQUFBLFNBQVMsRUFBRTtBQURvQyxHQUE1QyxDQUFQO0FBR0g7O0FBQ0QsU0FBUzZILGFBQVQsQ0FBdUJuTSxJQUF2QixFQUE2Qm9NLE1BQTdCLEVBQXFDO0FBQ2pDLFNBQU9BLE1BQU0sSUFBSXBNLElBQUksQ0FBQ3FNLFVBQUwsQ0FBZ0IsR0FBaEIsQ0FBVixHQUFpQ3JNLElBQUksS0FBSyxHQUFULEdBQWUsQ0FBQyxHQUFHa0wsdUJBQUosRUFBNkJuTCwwQkFBN0IsQ0FBd0RxTSxNQUF4RCxDQUFmLEdBQWtGLEdBQUVBLE1BQU8sR0FBRUUsZUFBZSxDQUFDdE0sSUFBRCxDQUFmLEtBQTBCLEdBQTFCLEdBQWdDQSxJQUFJLENBQUNzSSxTQUFMLENBQWUsQ0FBZixDQUFoQyxHQUFvRHRJLElBQUssRUFBdkwsR0FBMkxBLElBQWxNO0FBQ0g7O0FBQ0QsU0FBU1YsZUFBVCxDQUF5QlUsSUFBekIsRUFBK0JyTSxNQUEvQixFQUF1QzRMLE9BQXZDLEVBQWdEQyxhQUFoRCxFQUErRDtBQUMzRCxNQUFJVyxLQUFKLEVBQXFDLEVBQXJDLE1BT087QUFDSCxXQUFPLEtBQVA7QUFDSDtBQUNKOztBQUNELFNBQVNULFNBQVQsQ0FBbUJNLElBQW5CLEVBQXlCck0sTUFBekIsRUFBaUNnTSxhQUFqQyxFQUFnRDtBQUM1QyxNQUFJUSxLQUFKLEVBQXFDLEVBS3BDOztBQUNELFNBQU9ILElBQVA7QUFDSDs7QUFDRCxTQUFTOEssU0FBVCxDQUFtQjlLLElBQW5CLEVBQXlCck0sTUFBekIsRUFBaUM7QUFDN0IsTUFBSXdNLEtBQUosRUFBcUMsRUFLcEM7O0FBQ0QsU0FBT0gsSUFBUDtBQUNIOztBQUNELFNBQVNzTSxlQUFULENBQXlCdE0sSUFBekIsRUFBK0I7QUFDM0IsUUFBTWlOLFVBQVUsR0FBR2pOLElBQUksQ0FBQ3hELE9BQUwsQ0FBYSxHQUFiLENBQW5CO0FBQ0EsUUFBTTBRLFNBQVMsR0FBR2xOLElBQUksQ0FBQ3hELE9BQUwsQ0FBYSxHQUFiLENBQWxCOztBQUNBLE1BQUl5USxVQUFVLEdBQUcsQ0FBQyxDQUFkLElBQW1CQyxTQUFTLEdBQUcsQ0FBQyxDQUFwQyxFQUF1QztBQUNuQ2xOLElBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDc0ksU0FBTCxDQUFlLENBQWYsRUFBa0IyRSxVQUFVLEdBQUcsQ0FBQyxDQUFkLEdBQWtCQSxVQUFsQixHQUErQkMsU0FBakQsQ0FBUDtBQUNIOztBQUNELFNBQU9sTixJQUFQO0FBQ0g7O0FBQ0QsU0FBUytLLFdBQVQsQ0FBcUIvSyxJQUFyQixFQUEyQjtBQUN2QkEsRUFBQUEsSUFBSSxHQUFHc00sZUFBZSxDQUFDdE0sSUFBRCxDQUF0QjtBQUNBLFNBQU9BLElBQUksS0FBS2dNLFFBQVQsSUFBcUJoTSxJQUFJLENBQUNxTSxVQUFMLENBQWdCTCxRQUFRLEdBQUcsR0FBM0IsQ0FBNUI7QUFDSDs7QUFDRCxTQUFTdk0sV0FBVCxDQUFxQk8sSUFBckIsRUFBMkI7QUFDdkI7QUFDQSxTQUFPbU0sYUFBYSxDQUFDbk0sSUFBRCxFQUFPZ00sUUFBUCxDQUFwQjtBQUNIOztBQUNELFNBQVNoQixXQUFULENBQXFCaEwsSUFBckIsRUFBMkI7QUFDdkJBLEVBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDRSxLQUFMLENBQVc4TCxRQUFRLENBQUNlLE1BQXBCLENBQVA7QUFDQSxNQUFJLENBQUMvTSxJQUFJLENBQUNxTSxVQUFMLENBQWdCLEdBQWhCLENBQUwsRUFBMkJyTSxJQUFJLEdBQUksSUFBR0EsSUFBSyxFQUFoQjtBQUMzQixTQUFPQSxJQUFQO0FBQ0g7O0FBQ0QsU0FBU3pFLFVBQVQsQ0FBb0I0UixHQUFwQixFQUF5QjtBQUNyQjtBQUNBLE1BQUlBLEdBQUcsQ0FBQ2QsVUFBSixDQUFlLEdBQWYsS0FBdUJjLEdBQUcsQ0FBQ2QsVUFBSixDQUFlLEdBQWYsQ0FBdkIsSUFBOENjLEdBQUcsQ0FBQ2QsVUFBSixDQUFlLEdBQWYsQ0FBbEQsRUFBdUUsT0FBTyxJQUFQOztBQUN2RSxNQUFJO0FBQ0E7QUFDQSxVQUFNZSxjQUFjLEdBQUcsQ0FBQyxHQUFHN0IsTUFBSixFQUFZOEIsaUJBQVosRUFBdkI7QUFDQSxVQUFNQyxRQUFRLEdBQUcsSUFBSUMsR0FBSixDQUFRSixHQUFSLEVBQWFDLGNBQWIsQ0FBakI7QUFDQSxXQUFPRSxRQUFRLENBQUNFLE1BQVQsS0FBb0JKLGNBQXBCLElBQXNDckMsV0FBVyxDQUFDdUMsUUFBUSxDQUFDdlosUUFBVixDQUF4RDtBQUNILEdBTEQsQ0FLRSxPQUFPb0osQ0FBUCxFQUFVO0FBQ1IsV0FBTyxLQUFQO0FBQ0g7QUFDSjs7QUFDRCxTQUFTOE4sYUFBVCxDQUF1QnBHLEtBQXZCLEVBQThCNEksVUFBOUIsRUFBMEN4YSxLQUExQyxFQUFpRDtBQUM3QyxNQUFJeWEsaUJBQWlCLEdBQUcsRUFBeEI7QUFDQSxRQUFNQyxZQUFZLEdBQUcsQ0FBQyxHQUFHOUIsV0FBSixFQUFpQitCLGFBQWpCLENBQStCL0ksS0FBL0IsQ0FBckI7QUFDQSxRQUFNZ0osYUFBYSxHQUFHRixZQUFZLENBQUNHLE1BQW5DO0FBQ0EsUUFBTUMsY0FBYyxHQUFHO0FBQ3ZCLEdBQUNOLFVBQVUsS0FBSzVJLEtBQWYsR0FBdUIsQ0FBQyxHQUFHK0csYUFBSixFQUFtQm9DLGVBQW5CLENBQW1DTCxZQUFuQyxFQUFpREYsVUFBakQsQ0FBdkIsR0FBc0YsRUFBdkYsS0FBOEY7QUFDOUY7QUFDQXhhLEVBQUFBLEtBSEE7QUFJQXlhLEVBQUFBLGlCQUFpQixHQUFHN0ksS0FBcEI7QUFDQSxRQUFNb0osTUFBTSxHQUFHelQsTUFBTSxDQUFDeUMsSUFBUCxDQUFZNFEsYUFBWixDQUFmOztBQUNBLE1BQUksQ0FBQ0ksTUFBTSxDQUFDQyxLQUFQLENBQWNDLEtBQUQsSUFBUztBQUN2QixRQUFJdGEsS0FBSyxHQUFHa2EsY0FBYyxDQUFDSSxLQUFELENBQWQsSUFBeUIsRUFBckM7QUFDQSxVQUFNO0FBQUVDLE1BQUFBLE1BQUY7QUFBV0MsTUFBQUE7QUFBWCxRQUF5QlIsYUFBYSxDQUFDTSxLQUFELENBQTVDLENBRnVCLENBR3ZCO0FBQ0E7O0FBQ0EsUUFBSUcsUUFBUSxHQUFJLElBQUdGLE1BQU0sR0FBRyxLQUFILEdBQVcsRUFBRyxHQUFFRCxLQUFNLEdBQS9DOztBQUNBLFFBQUlFLFFBQUosRUFBYztBQUNWQyxNQUFBQSxRQUFRLEdBQUksR0FBRSxDQUFDemEsS0FBRCxHQUFTLEdBQVQsR0FBZSxFQUFHLElBQUd5YSxRQUFTLEdBQTVDO0FBQ0g7O0FBQ0QsUUFBSUYsTUFBTSxJQUFJLENBQUN0RixLQUFLLENBQUNDLE9BQU4sQ0FBY2xWLEtBQWQsQ0FBZixFQUFxQ0EsS0FBSyxHQUFHLENBQ3pDQSxLQUR5QyxDQUFSO0FBR3JDLFdBQU8sQ0FBQ3dhLFFBQVEsSUFBSUYsS0FBSyxJQUFJSixjQUF0QixNQUNOTCxpQkFBaUIsR0FBR0EsaUJBQWlCLENBQUNyUixPQUFsQixDQUEwQmlTLFFBQTFCLEVBQW9DRixNQUFNLEdBQUd2YSxLQUFLLENBQUNVLEdBQU4sRUFBVTtBQUM1RTtBQUNBO0FBQ0E7QUFDQ2dhLElBQUFBLE9BQUQsSUFBV0Msa0JBQWtCLENBQUNELE9BQUQsQ0FKcUMsRUFLaEVFLElBTGdFLENBSzNELEdBTDJELENBQUgsR0FLakRELGtCQUFrQixDQUFDM2EsS0FBRCxDQUxYLEtBS3VCLEdBTnJDLENBQVA7QUFPSCxHQW5CSSxDQUFMLEVBbUJJO0FBQ0E2WixJQUFBQSxpQkFBaUIsR0FBRyxFQUFwQixDQUF1QjtBQUF2QixLQURBLENBR0o7QUFDQTtBQUNDOztBQUNELFNBQU87QUFDSE8sSUFBQUEsTUFERztBQUVIUyxJQUFBQSxNQUFNLEVBQUVoQjtBQUZMLEdBQVA7QUFJSDs7QUFDRCxTQUFTaUIsa0JBQVQsQ0FBNEIxYixLQUE1QixFQUFtQ2diLE1BQW5DLEVBQTJDO0FBQ3ZDLFFBQU1XLGFBQWEsR0FBRyxFQUF0QjtBQUVBcFUsRUFBQUEsTUFBTSxDQUFDeUMsSUFBUCxDQUFZaEssS0FBWixFQUFtQmlLLE9BQW5CLENBQTRCTixHQUFELElBQU87QUFDOUIsUUFBSSxDQUFDcVIsTUFBTSxDQUFDWSxRQUFQLENBQWdCalMsR0FBaEIsQ0FBTCxFQUEyQjtBQUN2QmdTLE1BQUFBLGFBQWEsQ0FBQ2hTLEdBQUQsQ0FBYixHQUFxQjNKLEtBQUssQ0FBQzJKLEdBQUQsQ0FBMUI7QUFDSDtBQUNKLEdBSkQ7QUFLQSxTQUFPZ1MsYUFBUDtBQUNIOztBQUNELFNBQVM3USxXQUFULENBQXFCaEwsTUFBckIsRUFBNkJaLElBQTdCLEVBQW1DMmMsU0FBbkMsRUFBOEM7QUFDMUM7QUFDQSxNQUFJQyxJQUFKO0FBQ0EsTUFBSUMsV0FBVyxHQUFHLE9BQU83YyxJQUFQLEtBQWdCLFFBQWhCLEdBQTJCQSxJQUEzQixHQUFrQyxDQUFDLEdBQUdvWixNQUFKLEVBQVkwRCxvQkFBWixDQUFpQzljLElBQWpDLENBQXBELENBSDBDLENBSTFDO0FBQ0E7O0FBQ0EsUUFBTStjLGFBQWEsR0FBR0YsV0FBVyxDQUFDRyxLQUFaLENBQWtCLG9CQUFsQixDQUF0QjtBQUNBLFFBQU1DLGtCQUFrQixHQUFHRixhQUFhLEdBQUdGLFdBQVcsQ0FBQ2hDLE1BQVosQ0FBbUJrQyxhQUFhLENBQUMsQ0FBRCxDQUFiLENBQWlCbkMsTUFBcEMsQ0FBSCxHQUFpRGlDLFdBQXpGO0FBQ0EsUUFBTUssUUFBUSxHQUFHRCxrQkFBa0IsQ0FBQ0UsS0FBbkIsQ0FBeUIsR0FBekIsQ0FBakI7O0FBQ0EsTUFBSSxDQUFDRCxRQUFRLENBQUMsQ0FBRCxDQUFSLElBQWUsRUFBaEIsRUFBb0JGLEtBQXBCLENBQTBCLFdBQTFCLENBQUosRUFBNEM7QUFDeEM5YSxJQUFBQSxPQUFPLENBQUMrUixLQUFSLENBQWUsdUNBQXNDNEksV0FBWSw2RUFBakU7QUFDQSxVQUFNTyxhQUFhLEdBQUcsQ0FBQyxHQUFHaEUsTUFBSixFQUFZaUUsd0JBQVosQ0FBcUNKLGtCQUFyQyxDQUF0QjtBQUNBSixJQUFBQSxXQUFXLEdBQUcsQ0FBQ0UsYUFBYSxHQUFHQSxhQUFhLENBQUMsQ0FBRCxDQUFoQixHQUFzQixFQUFwQyxJQUEwQ0ssYUFBeEQ7QUFDSCxHQWJ5QyxDQWMxQzs7O0FBQ0EsTUFBSSxDQUFDaFUsVUFBVSxDQUFDeVQsV0FBRCxDQUFmLEVBQThCO0FBQzFCLFdBQU9GLFNBQVMsR0FBRyxDQUNmRSxXQURlLENBQUgsR0FFWkEsV0FGSjtBQUdIOztBQUNELE1BQUk7QUFDQUQsSUFBQUEsSUFBSSxHQUFHLElBQUl4QixHQUFKLENBQVF5QixXQUFXLENBQUMzQyxVQUFaLENBQXVCLEdBQXZCLElBQThCdFosTUFBTSxDQUFDaUIsTUFBckMsR0FBOENqQixNQUFNLENBQUNnQixRQUE3RCxFQUF1RSxVQUF2RSxDQUFQO0FBQ0gsR0FGRCxDQUVFLE9BQU9vSixDQUFQLEVBQVU7QUFDUjtBQUNBNFIsSUFBQUEsSUFBSSxHQUFHLElBQUl4QixHQUFKLENBQVEsR0FBUixFQUFhLFVBQWIsQ0FBUDtBQUNIOztBQUNELE1BQUk7QUFDQSxVQUFNa0MsUUFBUSxHQUFHLElBQUlsQyxHQUFKLENBQVF5QixXQUFSLEVBQXFCRCxJQUFyQixDQUFqQjtBQUNBVSxJQUFBQSxRQUFRLENBQUMxYixRQUFULEdBQW9CLENBQUMsR0FBR21YLHVCQUFKLEVBQTZCbkwsMEJBQTdCLENBQXdEMFAsUUFBUSxDQUFDMWIsUUFBakUsQ0FBcEI7QUFDQSxRQUFJMmIsY0FBYyxHQUFHLEVBQXJCOztBQUNBLFFBQUksQ0FBQyxHQUFHbEUsVUFBSixFQUFnQm1FLGNBQWhCLENBQStCRixRQUFRLENBQUMxYixRQUF4QyxLQUFxRDBiLFFBQVEsQ0FBQ0csWUFBOUQsSUFBOEVkLFNBQWxGLEVBQTZGO0FBQ3pGLFlBQU03YixLQUFLLEdBQUcsQ0FBQyxHQUFHeVksWUFBSixFQUFrQm1FLHNCQUFsQixDQUF5Q0osUUFBUSxDQUFDRyxZQUFsRCxDQUFkO0FBQ0EsWUFBTTtBQUFFbEIsUUFBQUEsTUFBRjtBQUFXVCxRQUFBQTtBQUFYLFVBQXVCaEQsYUFBYSxDQUFDd0UsUUFBUSxDQUFDMWIsUUFBVixFQUFvQjBiLFFBQVEsQ0FBQzFiLFFBQTdCLEVBQXVDZCxLQUF2QyxDQUExQzs7QUFDQSxVQUFJeWIsTUFBSixFQUFZO0FBQ1JnQixRQUFBQSxjQUFjLEdBQUcsQ0FBQyxHQUFHbkUsTUFBSixFQUFZMEQsb0JBQVosQ0FBaUM7QUFDOUNsYixVQUFBQSxRQUFRLEVBQUUyYSxNQURvQztBQUU5Q29CLFVBQUFBLElBQUksRUFBRUwsUUFBUSxDQUFDSyxJQUYrQjtBQUc5QzdjLFVBQUFBLEtBQUssRUFBRTBiLGtCQUFrQixDQUFDMWIsS0FBRCxFQUFRZ2IsTUFBUjtBQUhxQixTQUFqQyxDQUFqQjtBQUtIO0FBQ0osS0FkRCxDQWVBOzs7QUFDQSxVQUFNcFEsWUFBWSxHQUFHNFIsUUFBUSxDQUFDakMsTUFBVCxLQUFvQnVCLElBQUksQ0FBQ3ZCLE1BQXpCLEdBQWtDaUMsUUFBUSxDQUFDdGQsSUFBVCxDQUFjK04sS0FBZCxDQUFvQnVQLFFBQVEsQ0FBQ2pDLE1BQVQsQ0FBZ0JULE1BQXBDLENBQWxDLEdBQWdGMEMsUUFBUSxDQUFDdGQsSUFBOUc7QUFDQSxXQUFPMmMsU0FBUyxHQUFHLENBQ2ZqUixZQURlLEVBRWY2UixjQUFjLElBQUk3UixZQUZILENBQUgsR0FHWkEsWUFISjtBQUlILEdBckJELENBcUJFLE9BQU9WLENBQVAsRUFBVTtBQUNSLFdBQU8yUixTQUFTLEdBQUcsQ0FDZkUsV0FEZSxDQUFILEdBRVpBLFdBRko7QUFHSDtBQUNKOztBQUNELFNBQVNlLFdBQVQsQ0FBcUI1QyxHQUFyQixFQUEwQjtBQUN0QixRQUFNSyxNQUFNLEdBQUcsQ0FBQyxHQUFHakMsTUFBSixFQUFZOEIsaUJBQVosRUFBZjtBQUNBLFNBQU9GLEdBQUcsQ0FBQ2QsVUFBSixDQUFlbUIsTUFBZixJQUF5QkwsR0FBRyxDQUFDN0UsU0FBSixDQUFja0YsTUFBTSxDQUFDVCxNQUFyQixDQUF6QixHQUF3REksR0FBL0Q7QUFDSDs7QUFDRCxTQUFTNkMsWUFBVCxDQUFzQmpkLE1BQXRCLEVBQThCb2EsR0FBOUIsRUFBbUM5UixFQUFuQyxFQUF1QztBQUNuQztBQUNBO0FBQ0EsTUFBSSxDQUFDd0MsWUFBRCxFQUFlQyxVQUFmLElBQTZCQyxXQUFXLENBQUNoTCxNQUFELEVBQVNvYSxHQUFULEVBQWMsSUFBZCxDQUE1QztBQUNBLFFBQU1LLE1BQU0sR0FBRyxDQUFDLEdBQUdqQyxNQUFKLEVBQVk4QixpQkFBWixFQUFmO0FBQ0EsUUFBTTRDLGFBQWEsR0FBR3BTLFlBQVksQ0FBQ3dPLFVBQWIsQ0FBd0JtQixNQUF4QixDQUF0QjtBQUNBLFFBQU0wQyxXQUFXLEdBQUdwUyxVQUFVLElBQUlBLFVBQVUsQ0FBQ3VPLFVBQVgsQ0FBc0JtQixNQUF0QixDQUFsQztBQUNBM1AsRUFBQUEsWUFBWSxHQUFHa1MsV0FBVyxDQUFDbFMsWUFBRCxDQUExQjtBQUNBQyxFQUFBQSxVQUFVLEdBQUdBLFVBQVUsR0FBR2lTLFdBQVcsQ0FBQ2pTLFVBQUQsQ0FBZCxHQUE2QkEsVUFBcEQ7QUFDQSxRQUFNcVMsV0FBVyxHQUFHRixhQUFhLEdBQUdwUyxZQUFILEdBQWtCNEIsV0FBVyxDQUFDNUIsWUFBRCxDQUE5RDtBQUNBLFFBQU11UyxVQUFVLEdBQUcvVSxFQUFFLEdBQUcwVSxXQUFXLENBQUNoUyxXQUFXLENBQUNoTCxNQUFELEVBQVNzSSxFQUFULENBQVosQ0FBZCxHQUEwQ3lDLFVBQVUsSUFBSUQsWUFBN0U7QUFDQSxTQUFPO0FBQ0hzUCxJQUFBQSxHQUFHLEVBQUVnRCxXQURGO0FBRUg5VSxJQUFBQSxFQUFFLEVBQUU2VSxXQUFXLEdBQUdFLFVBQUgsR0FBZ0IzUSxXQUFXLENBQUMyUSxVQUFEO0FBRnZDLEdBQVA7QUFJSDs7QUFDRCxTQUFTQyxtQkFBVCxDQUE2QnRjLFFBQTdCLEVBQXVDdWMsS0FBdkMsRUFBOEM7QUFDMUMsUUFBTUMsYUFBYSxHQUFHLENBQUMsR0FBR3JGLHVCQUFKLEVBQTZCcEwsdUJBQTdCLENBQXFELENBQUMsR0FBR3NMLG9CQUFKLEVBQTBCb0YsbUJBQTFCLENBQThDemMsUUFBOUMsQ0FBckQsQ0FBdEI7O0FBQ0EsTUFBSXdjLGFBQWEsS0FBSyxNQUFsQixJQUE0QkEsYUFBYSxLQUFLLFNBQWxELEVBQTZEO0FBQ3pELFdBQU94YyxRQUFQO0FBQ0gsR0FKeUMsQ0FLMUM7OztBQUNBLE1BQUksQ0FBQ3VjLEtBQUssQ0FBQ3pCLFFBQU4sQ0FBZTBCLGFBQWYsQ0FBTCxFQUFvQztBQUNoQztBQUNBRCxJQUFBQSxLQUFLLENBQUNHLElBQU4sQ0FBWUMsSUFBRCxJQUFRO0FBQ2YsVUFBSSxDQUFDLEdBQUdsRixVQUFKLEVBQWdCbUUsY0FBaEIsQ0FBK0JlLElBQS9CLEtBQXdDLENBQUMsR0FBRzdFLFdBQUosRUFBaUIrQixhQUFqQixDQUErQjhDLElBQS9CLEVBQXFDQyxFQUFyQyxDQUF3Q3JRLElBQXhDLENBQTZDaVEsYUFBN0MsQ0FBNUMsRUFBeUc7QUFDckd4YyxRQUFBQSxRQUFRLEdBQUcyYyxJQUFYO0FBQ0EsZUFBTyxJQUFQO0FBQ0g7QUFDSixLQUxEO0FBTUg7O0FBQ0QsU0FBTyxDQUFDLEdBQUd4Rix1QkFBSixFQUE2QnBMLHVCQUE3QixDQUFxRC9MLFFBQXJELENBQVA7QUFDSDs7QUFDRCxNQUFNNmMsdUJBQXVCLEdBQUd6USxNQUFBLElBQW1ILENBQW5KO0FBUUEsTUFBTWdSLGtCQUFrQixHQUFHdE4sTUFBTSxDQUFDLG9CQUFELENBQWpDOztBQUNBLFNBQVN1TixVQUFULENBQW9CakUsR0FBcEIsRUFBeUJrRSxRQUF6QixFQUFtQztBQUMvQixTQUFPMUwsS0FBSyxDQUFDd0gsR0FBRCxFQUFNO0FBQ2Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBbUUsSUFBQUEsV0FBVyxFQUFFO0FBWkMsR0FBTixDQUFMLENBYUo5TyxJQWJJLENBYUVVLEdBQUQsSUFBTztBQUNYLFFBQUksQ0FBQ0EsR0FBRyxDQUFDMEMsRUFBVCxFQUFhO0FBQ1QsVUFBSXlMLFFBQVEsR0FBRyxDQUFYLElBQWdCbk8sR0FBRyxDQUFDcU8sTUFBSixJQUFjLEdBQWxDLEVBQXVDO0FBQ25DLGVBQU9ILFVBQVUsQ0FBQ2pFLEdBQUQsRUFBTWtFLFFBQVEsR0FBRyxDQUFqQixDQUFqQjtBQUNIOztBQUNELFVBQUluTyxHQUFHLENBQUNxTyxNQUFKLEtBQWUsR0FBbkIsRUFBd0I7QUFDcEIsZUFBT3JPLEdBQUcsQ0FBQ3NPLElBQUosR0FBV2hQLElBQVgsQ0FBaUJpUCxJQUFELElBQVE7QUFDM0IsY0FBSUEsSUFBSSxDQUFDQyxRQUFULEVBQW1CO0FBQ2YsbUJBQU87QUFDSEEsY0FBQUEsUUFBUSxFQUFFUDtBQURQLGFBQVA7QUFHSDs7QUFDRCxnQkFBTSxJQUFJeFUsS0FBSixDQUFXLDZCQUFYLENBQU47QUFDSCxTQVBNLENBQVA7QUFRSDs7QUFDRCxZQUFNLElBQUlBLEtBQUosQ0FBVyw2QkFBWCxDQUFOO0FBQ0g7O0FBQ0QsV0FBT3VHLEdBQUcsQ0FBQ3NPLElBQUosRUFBUDtBQUNILEdBL0JNLENBQVA7QUFnQ0g7O0FBQ0QsU0FBU0csYUFBVCxDQUF1QkMsUUFBdkIsRUFBaUNDLGNBQWpDLEVBQWlEO0FBQzdDLFNBQU9ULFVBQVUsQ0FBQ1EsUUFBRCxFQUFXQyxjQUFjLEdBQUcsQ0FBSCxHQUFPLENBQWhDLENBQVYsQ0FBNkNyVyxLQUE3QyxDQUFvREMsR0FBRCxJQUFPO0FBQzdEO0FBQ0E7QUFDQTtBQUNBLFFBQUksQ0FBQ29XLGNBQUwsRUFBcUI7QUFDakIsT0FBQyxHQUFHMUcsWUFBSixFQUFrQjVKLGNBQWxCLENBQWlDOUYsR0FBakM7QUFDSDs7QUFDRCxVQUFNQSxHQUFOO0FBQ0gsR0FSTSxDQUFQO0FBU0g7O0FBQ0QsTUFBTXFXLE1BQU4sQ0FBYTtBQUNUQyxFQUFBQSxXQUFXLENBQUNDLFNBQUQsRUFBWUMsTUFBWixFQUFvQkMsR0FBcEIsRUFBeUI7QUFBRUMsSUFBQUEsWUFBRjtBQUFpQkMsSUFBQUEsVUFBakI7QUFBOEJDLElBQUFBLEdBQTlCO0FBQW9DQyxJQUFBQSxPQUFwQztBQUE4Q0MsSUFBQUEsU0FBUyxFQUFFQyxVQUF6RDtBQUFzRS9XLElBQUFBLEdBQUcsRUFBRWdYLElBQTNFO0FBQWtGQyxJQUFBQSxZQUFsRjtBQUFpR0MsSUFBQUEsVUFBakc7QUFBOEdoZixJQUFBQSxNQUE5RztBQUF1SDRMLElBQUFBLE9BQXZIO0FBQWlJSSxJQUFBQSxhQUFqSTtBQUFpSkgsSUFBQUEsYUFBako7QUFBaUtvVCxJQUFBQTtBQUFqSyxHQUF6QixFQUF1TTtBQUM5TTtBQUNBLFNBQUtDLEdBQUwsR0FBVyxFQUFYLENBRjhNLENBSTlNOztBQUNBLFNBQUtDLEdBQUwsR0FBVyxFQUFYO0FBRUEsU0FBS0MsSUFBTCxHQUFZLENBQVo7O0FBQ0EsU0FBS0MsVUFBTCxHQUFtQnRmLENBQUQsSUFBSztBQUNuQixZQUFNMEUsS0FBSyxHQUFHMUUsQ0FBQyxDQUFDMEUsS0FBaEI7O0FBQ0EsVUFBSSxDQUFDQSxLQUFMLEVBQVk7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFNO0FBQUVyRSxVQUFBQSxRQUFRLEVBQUVpZSxTQUFaO0FBQXdCL2UsVUFBQUEsS0FBSyxFQUFFZ2Y7QUFBL0IsWUFBMkMsSUFBakQ7QUFDQSxhQUFLZ0IsV0FBTCxDQUFpQixjQUFqQixFQUFpQyxDQUFDLEdBQUcxSCxNQUFKLEVBQVkwRCxvQkFBWixDQUFpQztBQUM5RGxiLFVBQUFBLFFBQVEsRUFBRTBMLFdBQVcsQ0FBQ3VTLFNBQUQsQ0FEeUM7QUFFOUQvZSxVQUFBQSxLQUFLLEVBQUVnZjtBQUZ1RCxTQUFqQyxDQUFqQyxFQUdJLENBQUMsR0FBRzFHLE1BQUosRUFBWTJILE1BQVosRUFISjtBQUlBO0FBQ0g7O0FBQ0QsVUFBSSxDQUFDOWEsS0FBSyxDQUFDK2EsR0FBWCxFQUFnQjtBQUNaO0FBQ0g7O0FBQ0QsVUFBSUMsWUFBSjtBQUNBLFlBQU07QUFBRWpHLFFBQUFBLEdBQUY7QUFBUTlSLFFBQUFBLEVBQUUsRUFBRTZXLEdBQVo7QUFBa0I1VyxRQUFBQSxPQUFsQjtBQUE0QitYLFFBQUFBO0FBQTVCLFVBQXFDamIsS0FBM0M7O0FBQ0EsVUFBSStILEtBQUosRUFBMkMsRUF1QjFDOztBQUNELFdBQUs0UyxJQUFMLEdBQVlNLEdBQVo7QUFDQSxZQUFNO0FBQUV0ZixRQUFBQSxRQUFRLEVBQUVpZTtBQUFaLFVBQTJCLENBQUMsR0FBR3ZHLGlCQUFKLEVBQXVCcUksZ0JBQXZCLENBQXdDM0csR0FBeEMsQ0FBakMsQ0FqRG1CLENBa0RuQjtBQUNBOztBQUNBLFVBQUksS0FBSzRHLEtBQUwsSUFBYzdCLEdBQUcsS0FBSyxLQUFLbGUsTUFBM0IsSUFBcUNnZSxTQUFTLEtBQUssS0FBS2plLFFBQTVELEVBQXNFO0FBQ2xFO0FBQ0gsT0F0RGtCLENBdURuQjtBQUNBOzs7QUFDQSxVQUFJLEtBQUtpZ0IsSUFBTCxJQUFhLENBQUMsS0FBS0EsSUFBTCxDQUFVNWIsS0FBVixDQUFsQixFQUFvQztBQUNoQztBQUNIOztBQUNELFdBQUs2YixNQUFMLENBQVksY0FBWixFQUE0QjlHLEdBQTVCLEVBQWlDK0UsR0FBakMsRUFBc0MxWCxNQUFNLENBQUNxTSxNQUFQLENBQWMsRUFBZCxFQUNuQ3ZMLE9BRG1DLEVBQzFCO0FBQ1JnQixRQUFBQSxPQUFPLEVBQUVoQixPQUFPLENBQUNnQixPQUFSLElBQW1CLEtBQUs0WCxRQUR6QjtBQUVSdmdCLFFBQUFBLE1BQU0sRUFBRTJILE9BQU8sQ0FBQzNILE1BQVIsSUFBa0IsS0FBS2dNO0FBRnZCLE9BRDBCLENBQXRDLEVBSUl5VCxZQUpKO0FBS0gsS0FqRUQsQ0FSOE0sQ0EwRTlNOzs7QUFDQSxTQUFLdk8sS0FBTCxHQUFhLENBQUMsR0FBR3FHLHVCQUFKLEVBQTZCcEwsdUJBQTdCLENBQXFEa1MsU0FBckQsQ0FBYixDQTNFOE0sQ0E0RTlNOztBQUNBLFNBQUttQyxVQUFMLEdBQWtCLEVBQWxCLENBN0U4TSxDQStFOU07QUFDQTtBQUNBOztBQUNBLFFBQUluQyxTQUFTLEtBQUssU0FBbEIsRUFBNkI7QUFDekIsV0FBS21DLFVBQUwsQ0FBZ0IsS0FBS3RQLEtBQXJCLElBQThCO0FBQzFCME4sUUFBQUEsU0FBUyxFQUFFQyxVQURlO0FBRTFCNEIsUUFBQUEsT0FBTyxFQUFFLElBRmlCO0FBRzFCL2pCLFFBQUFBLEtBQUssRUFBRThoQixZQUhtQjtBQUkxQjFXLFFBQUFBLEdBQUcsRUFBRWdYLElBSnFCO0FBSzFCNEIsUUFBQUEsT0FBTyxFQUFFbEMsWUFBWSxJQUFJQSxZQUFZLENBQUNrQyxPQUxaO0FBTTFCQyxRQUFBQSxPQUFPLEVBQUVuQyxZQUFZLElBQUlBLFlBQVksQ0FBQ21DO0FBTlosT0FBOUI7QUFRSDs7QUFDRCxTQUFLSCxVQUFMLENBQWdCLE9BQWhCLElBQTJCO0FBQ3ZCNUIsTUFBQUEsU0FBUyxFQUFFRixHQURZO0FBRXZCOU0sTUFBQUEsV0FBVyxFQUFFO0FBRlUsS0FBM0IsQ0E1RjhNLENBZ0c5TTtBQUNBOztBQUNBLFNBQUt3QyxNQUFMLEdBQWMrSixNQUFNLENBQUMvSixNQUFyQjtBQUNBLFNBQUtxSyxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLFNBQUtyZSxRQUFMLEdBQWdCaWUsU0FBaEI7QUFDQSxTQUFLL2UsS0FBTCxHQUFhZ2YsTUFBYixDQXJHOE0sQ0FzRzlNO0FBQ0E7O0FBQ0EsVUFBTXNDLGlCQUFpQixHQUFHLENBQUMsR0FBRy9JLFVBQUosRUFBZ0JtRSxjQUFoQixDQUErQnFDLFNBQS9CLEtBQTZDdlIsSUFBSSxDQUFDK1QsYUFBTCxDQUFtQkMsVUFBMUY7O0FBQ0EsU0FBS3pnQixNQUFMLEdBQWN1Z0IsaUJBQWlCLEdBQUd2QyxTQUFILEdBQWVFLEdBQTlDO0FBQ0EsU0FBS2xHLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0EsU0FBSzBJLEdBQUwsR0FBV2hDLFlBQVg7QUFDQSxTQUFLaUMsR0FBTCxHQUFXLElBQVg7QUFDQSxTQUFLQyxRQUFMLEdBQWdCdEMsT0FBaEIsQ0E3RzhNLENBOEc5TTtBQUNBOztBQUNBLFNBQUt5QixLQUFMLEdBQWEsSUFBYjtBQUNBLFNBQUtwQixVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLFNBQUtrQyxPQUFMLEdBQWUsQ0FBQyxFQUFFcFUsSUFBSSxDQUFDK1QsYUFBTCxDQUFtQk0sSUFBbkIsSUFBMkJyVSxJQUFJLENBQUMrVCxhQUFMLENBQW1CTyxHQUE5QyxJQUFxRHRVLElBQUksQ0FBQytULGFBQUwsQ0FBbUJRLE1BQW5CLElBQTZCLENBQUN2VSxJQUFJLENBQUMrVCxhQUFMLENBQW1CUyxHQUF0RyxJQUE2RyxDQUFDVixpQkFBRCxJQUFzQixDQUFDOVQsSUFBSSxDQUFDeVUsUUFBTCxDQUFjQyxNQUFyQyxJQUErQyxDQUFDaFYsS0FBL0osQ0FBaEI7QUFDQSxTQUFLeVMsU0FBTCxHQUFpQixDQUFDLENBQUNBLFNBQW5CO0FBQ0EsU0FBS3ZULGNBQUwsR0FBc0IsS0FBdEI7O0FBQ0EsUUFBSWMsS0FBSixFQUFxQyxFQU1wQzs7QUFDRCxlQUFtQyxFQXVCbEM7QUFDSjs7QUFDRHNWLEVBQUFBLE1BQU0sR0FBRztBQUNMOVUsSUFBQUEsTUFBTSxDQUFDdVUsUUFBUCxDQUFnQk8sTUFBaEI7QUFDSDtBQUNEO0FBQ0o7QUFDQTs7O0FBQU1DLEVBQUFBLElBQUksR0FBRztBQUNML1UsSUFBQUEsTUFBTSxDQUFDbVEsT0FBUCxDQUFlNEUsSUFBZjtBQUNIO0FBQ0Q7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFBTTVoQixFQUFBQSxJQUFJLENBQUNxWixHQUFELEVBQU05UixFQUFOLEVBQVVDLE9BQU8sR0FBRyxFQUFwQixFQUNIO0FBQ0MsUUFBSTZFLEtBQUosRUFBMkMsRUFhMUM7O0FBQ0QsS0FBQztBQUFFZ04sTUFBQUEsR0FBRjtBQUFROVIsTUFBQUE7QUFBUixRQUFnQjJVLFlBQVksQ0FBQyxJQUFELEVBQU83QyxHQUFQLEVBQVk5UixFQUFaLENBQTdCO0FBQ0EsV0FBTyxLQUFLNFksTUFBTCxDQUFZLFdBQVosRUFBeUI5RyxHQUF6QixFQUE4QjlSLEVBQTlCLEVBQWtDQyxPQUFsQyxDQUFQO0FBQ0g7QUFDRDtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUFNZSxFQUFBQSxPQUFPLENBQUM4USxHQUFELEVBQU05UixFQUFOLEVBQVVDLE9BQU8sR0FBRyxFQUFwQixFQUNOO0FBQ0MsS0FBQztBQUFFNlIsTUFBQUEsR0FBRjtBQUFROVIsTUFBQUE7QUFBUixRQUFnQjJVLFlBQVksQ0FBQyxJQUFELEVBQU83QyxHQUFQLEVBQVk5UixFQUFaLENBQTdCO0FBQ0EsV0FBTyxLQUFLNFksTUFBTCxDQUFZLGNBQVosRUFBNEI5RyxHQUE1QixFQUFpQzlSLEVBQWpDLEVBQXFDQyxPQUFyQyxDQUFQO0FBQ0g7O0FBQ1csUUFBTjJZLE1BQU0sQ0FBQzBCLE1BQUQsRUFBU3hJLEdBQVQsRUFBYzlSLEVBQWQsRUFBa0JDLE9BQWxCLEVBQTJCOFgsWUFBM0IsRUFBeUM7QUFDakQsUUFBSSxDQUFDN1gsVUFBVSxDQUFDNFIsR0FBRCxDQUFmLEVBQXNCO0FBQ2xCeE0sTUFBQUEsTUFBTSxDQUFDdVUsUUFBUCxDQUFnQi9pQixJQUFoQixHQUF1QmdiLEdBQXZCO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7O0FBQ0QsVUFBTXlJLGlCQUFpQixHQUFHekksR0FBRyxLQUFLOVIsRUFBUixJQUFjQyxPQUFPLENBQUN1YSxFQUF0QixJQUE0QnZhLE9BQU8sQ0FBQ2dhLGtCQUE5RCxDQUxpRCxDQU1qRDtBQUNBOztBQUNBLFFBQUloYSxPQUFPLENBQUN1YSxFQUFaLEVBQWdCO0FBQ1osV0FBS2hCLE9BQUwsR0FBZSxJQUFmO0FBQ0g7O0FBQ0QsVUFBTWlCLFVBQVUsR0FBRyxLQUFLbmlCLE1BQXhCOztBQUNBLFFBQUl3TSxLQUFKLEVBQXFDLFlBNkNwQzs7QUFDRCxRQUFJLENBQUM3RSxPQUFPLENBQUN1YSxFQUFiLEVBQWlCO0FBQ2IsV0FBSzlCLEtBQUwsR0FBYSxLQUFiO0FBQ0gsS0E1RGdELENBNkRqRDs7O0FBQ0EsUUFBSXhJLE1BQU0sQ0FBQzRLLEVBQVgsRUFBZTtBQUNYQyxNQUFBQSxXQUFXLENBQUNDLElBQVosQ0FBaUIsYUFBakI7QUFDSDs7QUFDRCxVQUFNO0FBQUUvWixNQUFBQSxPQUFPLEdBQUU7QUFBWCxRQUFzQmhCLE9BQTVCO0FBQ0EsVUFBTWdiLFVBQVUsR0FBRztBQUNmaGEsTUFBQUE7QUFEZSxLQUFuQjs7QUFHQSxRQUFJLEtBQUtpYSxjQUFULEVBQXlCO0FBQ3JCLFdBQUtDLGtCQUFMLENBQXdCLEtBQUtELGNBQTdCLEVBQTZDRCxVQUE3QztBQUNIOztBQUNEamIsSUFBQUEsRUFBRSxHQUFHb0UsV0FBVyxDQUFDQyxTQUFTLENBQUNxTCxXQUFXLENBQUMxUCxFQUFELENBQVgsR0FBa0IyUCxXQUFXLENBQUMzUCxFQUFELENBQTdCLEdBQW9DQSxFQUFyQyxFQUF5Q0MsT0FBTyxDQUFDM0gsTUFBakQsRUFBeUQsS0FBS2dNLGFBQTlELENBQVYsQ0FBaEI7QUFDQSxVQUFNOFcsU0FBUyxHQUFHM0wsU0FBUyxDQUFDQyxXQUFXLENBQUMxUCxFQUFELENBQVgsR0FBa0IyUCxXQUFXLENBQUMzUCxFQUFELENBQTdCLEdBQW9DQSxFQUFyQyxFQUF5QyxLQUFLMUgsTUFBOUMsQ0FBM0I7QUFDQSxTQUFLNGlCLGNBQUwsR0FBc0JsYixFQUF0QjtBQUNBLFFBQUlxYixZQUFZLEdBQUdaLFVBQVUsS0FBSyxLQUFLbmlCLE1BQXZDLENBM0VpRCxDQTRFakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxRQUFJLENBQUMySCxPQUFPLENBQUN1YSxFQUFULElBQWUsS0FBS2MsZUFBTCxDQUFxQkYsU0FBckIsQ0FBZixJQUFrRCxDQUFDQyxZQUF2RCxFQUFxRTtBQUNqRSxXQUFLMWlCLE1BQUwsR0FBY3lpQixTQUFkO0FBQ0EzRSxNQUFBQSxNQUFNLENBQUMvSixNQUFQLENBQWM2TyxJQUFkLENBQW1CLGlCQUFuQixFQUFzQ3ZiLEVBQXRDLEVBQTBDaWIsVUFBMUMsRUFGaUUsQ0FHakU7O0FBQ0EsV0FBS3JELFdBQUwsQ0FBaUIwQyxNQUFqQixFQUF5QnhJLEdBQXpCLEVBQThCOVIsRUFBOUIsRUFBa0NDLE9BQWxDO0FBQ0EsV0FBS3ViLFlBQUwsQ0FBa0JKLFNBQWxCO0FBQ0EsV0FBS0ssTUFBTCxDQUFZLEtBQUszQyxVQUFMLENBQWdCLEtBQUt0UCxLQUFyQixDQUFaLEVBQXlDLElBQXpDO0FBQ0FpTixNQUFBQSxNQUFNLENBQUMvSixNQUFQLENBQWM2TyxJQUFkLENBQW1CLG9CQUFuQixFQUF5Q3ZiLEVBQXpDLEVBQTZDaWIsVUFBN0M7QUFDQSxhQUFPLElBQVA7QUFDSDs7QUFDRCxRQUFJUyxNQUFNLEdBQUcsQ0FBQyxHQUFHdEwsaUJBQUosRUFBdUJxSSxnQkFBdkIsQ0FBd0MzRyxHQUF4QyxDQUFiO0FBQ0EsUUFBSTtBQUFFcFosTUFBQUEsUUFBUSxFQUFFaWUsU0FBWjtBQUF3Qi9lLE1BQUFBLEtBQUssRUFBRWdmO0FBQS9CLFFBQTJDOEUsTUFBL0MsQ0E1RmlELENBNkZqRDtBQUNBO0FBQ0E7O0FBQ0EsUUFBSXpHLEtBQUosRUFBVzBHLFFBQVg7O0FBQ0EsUUFBSTtBQUNBMUcsTUFBQUEsS0FBSyxHQUFHLE1BQU0sS0FBSzhCLFVBQUwsQ0FBZ0I2RSxXQUFoQixFQUFkO0FBQ0EsT0FBQztBQUFFQyxRQUFBQSxVQUFVLEVBQUVGO0FBQWQsVUFBNEIsTUFBTSxDQUFDLEdBQUc3TCxZQUFKLEVBQWtCMUosc0JBQWxCLEVBQW5DO0FBQ0gsS0FIRCxDQUdFLE9BQU9nUixJQUFQLEVBQWE7QUFDWDtBQUNBO0FBQ0E5UixNQUFBQSxNQUFNLENBQUN1VSxRQUFQLENBQWdCL2lCLElBQWhCLEdBQXVCa0osRUFBdkI7QUFDQSxhQUFPLEtBQVA7QUFDSCxLQXpHZ0QsQ0EwR2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFFBQUksQ0FBQyxLQUFLOGIsUUFBTCxDQUFjVixTQUFkLENBQUQsSUFBNkIsQ0FBQ0MsWUFBbEMsRUFBZ0Q7QUFDNUNmLE1BQUFBLE1BQU0sR0FBRyxjQUFUO0FBQ0gsS0FqSGdELENBa0hqRDtBQUNBOzs7QUFDQSxRQUFJN1gsVUFBVSxHQUFHekMsRUFBakIsQ0FwSGlELENBcUhqRDtBQUNBO0FBQ0E7O0FBQ0EyVyxJQUFBQSxTQUFTLEdBQUdBLFNBQVMsR0FBRyxDQUFDLEdBQUc5Ryx1QkFBSixFQUE2QnBMLHVCQUE3QixDQUFxRGtMLFdBQVcsQ0FBQ2dILFNBQUQsQ0FBaEUsQ0FBSCxHQUFrRkEsU0FBdkc7O0FBQ0EsUUFBSTRELGlCQUFpQixJQUFJNUQsU0FBUyxLQUFLLFNBQXZDLEVBQWtEO0FBQzlDMVcsTUFBQUEsT0FBTyxDQUFDZ2Esa0JBQVIsR0FBNkIsSUFBN0I7O0FBQ0EsVUFBSW5WLEtBQUosRUFBMkQsRUFBM0QsTUFXTztBQUNINFcsUUFBQUEsTUFBTSxDQUFDaGpCLFFBQVAsR0FBa0JzYyxtQkFBbUIsQ0FBQzJCLFNBQUQsRUFBWTFCLEtBQVosQ0FBckM7O0FBQ0EsWUFBSXlHLE1BQU0sQ0FBQ2hqQixRQUFQLEtBQW9CaWUsU0FBeEIsRUFBbUM7QUFDL0JBLFVBQUFBLFNBQVMsR0FBRytFLE1BQU0sQ0FBQ2hqQixRQUFuQjtBQUNBZ2pCLFVBQUFBLE1BQU0sQ0FBQ2hqQixRQUFQLEdBQWtCMEwsV0FBVyxDQUFDdVMsU0FBRCxDQUE3QjtBQUNBN0UsVUFBQUEsR0FBRyxHQUFHLENBQUMsR0FBRzVCLE1BQUosRUFBWTBELG9CQUFaLENBQWlDOEgsTUFBakMsQ0FBTjtBQUNIO0FBQ0o7QUFDSjs7QUFDRCxVQUFNbFMsS0FBSyxHQUFHLENBQUMsR0FBR3FHLHVCQUFKLEVBQTZCcEwsdUJBQTdCLENBQXFEa1MsU0FBckQsQ0FBZDs7QUFDQSxRQUFJLENBQUN6VyxVQUFVLENBQUNGLEVBQUQsQ0FBZixFQUFxQjtBQUNqQixnQkFBMkM7QUFDdkMsY0FBTSxJQUFJc0IsS0FBSixDQUFXLGtCQUFpQndRLEdBQUksY0FBYTlSLEVBQUcsMkNBQXRDLEdBQW9GLG9GQUE5RixDQUFOO0FBQ0g7O0FBQ0RzRixNQUFBQSxNQUFNLENBQUN1VSxRQUFQLENBQWdCL2lCLElBQWhCLEdBQXVCa0osRUFBdkI7QUFDQSxhQUFPLEtBQVA7QUFDSDs7QUFDRHlDLElBQUFBLFVBQVUsR0FBR2dOLFNBQVMsQ0FBQ0UsV0FBVyxDQUFDbE4sVUFBRCxDQUFaLEVBQTBCLEtBQUtuSyxNQUEvQixDQUF0Qjs7QUFDQSxRQUFJLENBQUMsR0FBRzZYLFVBQUosRUFBZ0JtRSxjQUFoQixDQUErQjlLLEtBQS9CLENBQUosRUFBMkM7QUFDdkMsWUFBTWtSLFFBQVEsR0FBRyxDQUFDLEdBQUd0SyxpQkFBSixFQUF1QnFJLGdCQUF2QixDQUF3Q2hXLFVBQXhDLENBQWpCO0FBQ0EsWUFBTTJQLFVBQVUsR0FBR3NJLFFBQVEsQ0FBQ2hpQixRQUE1QjtBQUNBLFlBQU11akIsVUFBVSxHQUFHLENBQUMsR0FBR3pMLFdBQUosRUFBaUIrQixhQUFqQixDQUErQi9JLEtBQS9CLENBQW5CO0FBQ0EsWUFBTTBTLFVBQVUsR0FBRyxDQUFDLEdBQUczTCxhQUFKLEVBQW1Cb0MsZUFBbkIsQ0FBbUNzSixVQUFuQyxFQUErQzdKLFVBQS9DLENBQW5CO0FBQ0EsWUFBTStKLGlCQUFpQixHQUFHM1MsS0FBSyxLQUFLNEksVUFBcEM7QUFDQSxZQUFNaUMsY0FBYyxHQUFHOEgsaUJBQWlCLEdBQUd2TSxhQUFhLENBQUNwRyxLQUFELEVBQVE0SSxVQUFSLEVBQW9Cd0UsTUFBcEIsQ0FBaEIsR0FBOEMsRUFBdEY7O0FBRUEsVUFBSSxDQUFDc0YsVUFBRCxJQUFlQyxpQkFBaUIsSUFBSSxDQUFDOUgsY0FBYyxDQUFDaEIsTUFBeEQsRUFBZ0U7QUFDNUQsY0FBTStJLGFBQWEsR0FBR2pkLE1BQU0sQ0FBQ3lDLElBQVAsQ0FBWXFhLFVBQVUsQ0FBQ3hKLE1BQXZCLEVBQStCNUksTUFBL0IsQ0FBdUNpSixLQUFELElBQVMsQ0FBQzhELE1BQU0sQ0FBQzlELEtBQUQsQ0FBdEQsQ0FBdEI7O0FBRUEsWUFBSXNKLGFBQWEsQ0FBQzFLLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDMUIsb0JBQTJDO0FBQ3ZDMVksWUFBQUEsT0FBTyxDQUFDc0osSUFBUixDQUFjLEdBQUU2WixpQkFBaUIsR0FBSSxvQkFBSixHQUEyQixpQ0FBaUMsOEJBQWhGLEdBQWlILGVBQWNDLGFBQWEsQ0FBQ2hKLElBQWQsQ0FBbUIsSUFBbkIsQ0FBeUIsOEJBQXJLO0FBQ0g7O0FBQ0QsZ0JBQU0sSUFBSTlSLEtBQUosQ0FBVSxDQUFDNmEsaUJBQWlCLEdBQUksMEJBQXlCckssR0FBSSxvQ0FBbUNzSyxhQUFhLENBQUNoSixJQUFkLENBQW1CLElBQW5CLENBQXlCLGlDQUE3RixHQUFpSSw4QkFBNkJoQixVQUFXLDhDQUE2QzVJLEtBQU0sS0FBOU8sSUFBdVAsK0NBQThDMlMsaUJBQWlCLEdBQUcsMkJBQUgsR0FBaUMsc0JBQXVCLEVBQXhYLENBQU47QUFDSDtBQUNKLE9BVEQsTUFTTyxJQUFJQSxpQkFBSixFQUF1QjtBQUMxQm5jLFFBQUFBLEVBQUUsR0FBRyxDQUFDLEdBQUdrUSxNQUFKLEVBQVkwRCxvQkFBWixDQUFpQ3pVLE1BQU0sQ0FBQ3FNLE1BQVAsQ0FBYyxFQUFkLEVBQ25Da1AsUUFEbUMsRUFDekI7QUFDVGhpQixVQUFBQSxRQUFRLEVBQUUyYixjQUFjLENBQUNoQixNQURoQjtBQUVUemIsVUFBQUEsS0FBSyxFQUFFMGIsa0JBQWtCLENBQUNzRCxNQUFELEVBQVN2QyxjQUFjLENBQUN6QixNQUF4QjtBQUZoQixTQUR5QixDQUFqQyxDQUFMO0FBS0gsT0FOTSxNQU1BO0FBQ0g7QUFDQXpULFFBQUFBLE1BQU0sQ0FBQ3FNLE1BQVAsQ0FBY29MLE1BQWQsRUFBc0JzRixVQUF0QjtBQUNIO0FBQ0o7O0FBQ0R6RixJQUFBQSxNQUFNLENBQUMvSixNQUFQLENBQWM2TyxJQUFkLENBQW1CLGtCQUFuQixFQUF1Q3ZiLEVBQXZDLEVBQTJDaWIsVUFBM0M7O0FBQ0EsUUFBSTtBQUNBLFVBQUlqWSxHQUFKLEVBQVNxWixJQUFUO0FBQ0EsVUFBSUMsU0FBUyxHQUFHLE1BQU0sS0FBS0MsWUFBTCxDQUFrQi9TLEtBQWxCLEVBQXlCbU4sU0FBekIsRUFBb0NDLE1BQXBDLEVBQTRDNVcsRUFBNUMsRUFBZ0R5QyxVQUFoRCxFQUE0RHdZLFVBQTVELENBQXRCO0FBQ0EsVUFBSTtBQUFFbFEsUUFBQUEsS0FBRjtBQUFVL1YsUUFBQUEsS0FBVjtBQUFrQmdrQixRQUFBQSxPQUFsQjtBQUE0QkMsUUFBQUE7QUFBNUIsVUFBeUNxRCxTQUE3QyxDQUhBLENBSUE7O0FBQ0EsVUFBSSxDQUFDdEQsT0FBTyxJQUFJQyxPQUFaLEtBQXdCamtCLEtBQTVCLEVBQW1DO0FBQy9CLFlBQUlBLEtBQUssQ0FBQ3duQixTQUFOLElBQW1CeG5CLEtBQUssQ0FBQ3duQixTQUFOLENBQWdCQyxZQUF2QyxFQUFxRDtBQUNqRCxnQkFBTUMsV0FBVyxHQUFHMW5CLEtBQUssQ0FBQ3duQixTQUFOLENBQWdCQyxZQUFwQyxDQURpRCxDQUVqRDtBQUNBO0FBQ0E7O0FBQ0EsY0FBSUMsV0FBVyxDQUFDMUwsVUFBWixDQUF1QixHQUF2QixDQUFKLEVBQWlDO0FBQzdCLGtCQUFNMkwsVUFBVSxHQUFHLENBQUMsR0FBR3ZNLGlCQUFKLEVBQXVCcUksZ0JBQXZCLENBQXdDaUUsV0FBeEMsQ0FBbkI7QUFDQUMsWUFBQUEsVUFBVSxDQUFDamtCLFFBQVgsR0FBc0JzYyxtQkFBbUIsQ0FBQzJILFVBQVUsQ0FBQ2prQixRQUFaLEVBQXNCdWMsS0FBdEIsQ0FBekM7QUFDQSxrQkFBTTtBQUFFbkQsY0FBQUEsR0FBRyxFQUFFOEssTUFBUDtBQUFnQjVjLGNBQUFBLEVBQUUsRUFBRTZjO0FBQXBCLGdCQUErQmxJLFlBQVksQ0FBQyxJQUFELEVBQU8rSCxXQUFQLEVBQW9CQSxXQUFwQixDQUFqRDtBQUNBLG1CQUFPLEtBQUs5RCxNQUFMLENBQVkwQixNQUFaLEVBQW9Cc0MsTUFBcEIsRUFBNEJDLEtBQTVCLEVBQW1DNWMsT0FBbkMsQ0FBUDtBQUNIOztBQUNEcUYsVUFBQUEsTUFBTSxDQUFDdVUsUUFBUCxDQUFnQi9pQixJQUFoQixHQUF1QjRsQixXQUF2QjtBQUNBLGlCQUFPLElBQUk1VixPQUFKLENBQVksTUFBSSxDQUN0QixDQURNLENBQVA7QUFFSDs7QUFDRCxhQUFLeVEsU0FBTCxHQUFpQixDQUFDLENBQUN2aUIsS0FBSyxDQUFDOG5CLFdBQXpCLENBaEIrQixDQWlCL0I7O0FBQ0EsWUFBSTluQixLQUFLLENBQUNxaEIsUUFBTixLQUFtQlAsa0JBQXZCLEVBQTJDO0FBQ3ZDLGNBQUlpSCxhQUFKOztBQUNBLGNBQUk7QUFDQSxrQkFBTSxLQUFLQyxjQUFMLENBQW9CLE1BQXBCLENBQU47QUFDQUQsWUFBQUEsYUFBYSxHQUFHLE1BQWhCO0FBQ0gsV0FIRCxDQUdFLE9BQU9qYixDQUFQLEVBQVU7QUFDUmliLFlBQUFBLGFBQWEsR0FBRyxTQUFoQjtBQUNIOztBQUNEVCxVQUFBQSxTQUFTLEdBQUcsTUFBTSxLQUFLQyxZQUFMLENBQWtCUSxhQUFsQixFQUFpQ0EsYUFBakMsRUFBZ0RuRyxNQUFoRCxFQUF3RDVXLEVBQXhELEVBQTREeUMsVUFBNUQsRUFBd0U7QUFDdEZ4QixZQUFBQSxPQUFPLEVBQUU7QUFENkUsV0FBeEUsQ0FBbEI7QUFHSDtBQUNKOztBQUNEd1YsTUFBQUEsTUFBTSxDQUFDL0osTUFBUCxDQUFjNk8sSUFBZCxDQUFtQixxQkFBbkIsRUFBMEN2YixFQUExQyxFQUE4Q2liLFVBQTlDO0FBQ0EsV0FBS3JELFdBQUwsQ0FBaUIwQyxNQUFqQixFQUF5QnhJLEdBQXpCLEVBQThCOVIsRUFBOUIsRUFBa0NDLE9BQWxDOztBQUNBLGdCQUEyQztBQUN2QyxjQUFNZ2QsT0FBTyxHQUFHLEtBQUtuRSxVQUFMLENBQWdCLE9BQWhCLEVBQXlCNUIsU0FBekM7QUFDQTVSLFFBQUFBLE1BQU0sQ0FBQzRYLElBQVAsQ0FBWUMsYUFBWixHQUE0QkYsT0FBTyxDQUFDNU4sZUFBUixLQUE0QjROLE9BQU8sQ0FBQzNOLG1CQUFwQyxJQUEyRCxDQUFDZ04sU0FBUyxDQUFDcEYsU0FBVixDQUFvQjdILGVBQTVHO0FBQ0g7O0FBQ0QsVUFBSXBQLE9BQU8sQ0FBQ3VhLEVBQVIsSUFBYzdELFNBQVMsS0FBSyxTQUE1QixJQUF5QyxDQUFDLENBQUMzVCxHQUFHLEdBQUdvQyxJQUFJLENBQUMrVCxhQUFMLENBQW1CbmtCLEtBQTFCLE1BQXFDLElBQXJDLElBQTZDZ08sR0FBRyxLQUFLLEtBQUssQ0FBMUQsR0FBOEQsS0FBSyxDQUFuRSxHQUF1RSxDQUFDcVosSUFBSSxHQUFHclosR0FBRyxDQUFDd1osU0FBWixNQUEyQixJQUEzQixJQUFtQ0gsSUFBSSxLQUFLLEtBQUssQ0FBakQsR0FBcUQsS0FBSyxDQUExRCxHQUE4REEsSUFBSSxDQUFDZSxVQUEzSSxNQUEySixHQUFwTSxLQUE0TXBvQixLQUFLLEtBQUssSUFBVixJQUFrQkEsS0FBSyxLQUFLLEtBQUssQ0FBakMsR0FBcUMsS0FBSyxDQUExQyxHQUE4Q0EsS0FBSyxDQUFDd25CLFNBQWhRLENBQUosRUFBZ1I7QUFDNVE7QUFDQTtBQUNBeG5CLFFBQUFBLEtBQUssQ0FBQ3duQixTQUFOLENBQWdCWSxVQUFoQixHQUE2QixHQUE3QjtBQUNILE9BOUNELENBK0NBOzs7QUFDQSxZQUFNQyxtQkFBbUIsR0FBR3BkLE9BQU8sQ0FBQ2dCLE9BQVIsSUFBbUIsS0FBS3VJLEtBQUwsS0FBZUEsS0FBOUQ7O0FBQ0EsVUFBSThULE9BQUo7O0FBQ0EsWUFBTUMsWUFBWSxHQUFHLENBQUNELE9BQU8sR0FBR3JkLE9BQU8sQ0FBQ3JILE1BQW5CLE1BQStCLElBQS9CLElBQXVDMGtCLE9BQU8sS0FBSyxLQUFLLENBQXhELEdBQTREQSxPQUE1RCxHQUFzRSxDQUFDRCxtQkFBNUY7QUFDQSxZQUFNRyxXQUFXLEdBQUdELFlBQVksR0FBRztBQUMvQnBGLFFBQUFBLENBQUMsRUFBRSxDQUQ0QjtBQUUvQkUsUUFBQUEsQ0FBQyxFQUFFO0FBRjRCLE9BQUgsR0FHNUIsSUFISjtBQUlBLFlBQU0sS0FBS25SLEdBQUwsQ0FBU3NDLEtBQVQsRUFBZ0JtTixTQUFoQixFQUEyQkMsTUFBM0IsRUFBbUN3RSxTQUFuQyxFQUE4Q2tCLFNBQTlDLEVBQXlEdkUsWUFBWSxLQUFLLElBQWpCLElBQXlCQSxZQUFZLEtBQUssS0FBSyxDQUEvQyxHQUFtREEsWUFBbkQsR0FBa0V5RixXQUEzSCxFQUF3SXJkLEtBQXhJLENBQStJOUgsQ0FBRCxJQUFLO0FBQ3JKLFlBQUlBLENBQUMsQ0FBQzRRLFNBQU4sRUFBaUI4QixLQUFLLEdBQUdBLEtBQUssSUFBSTFTLENBQWpCLENBQWpCLEtBQ0ssTUFBTUEsQ0FBTjtBQUNSLE9BSEssQ0FBTjs7QUFJQSxVQUFJMFMsS0FBSixFQUFXO0FBQ1AwTCxRQUFBQSxNQUFNLENBQUMvSixNQUFQLENBQWM2TyxJQUFkLENBQW1CLGtCQUFuQixFQUF1Q3hRLEtBQXZDLEVBQThDcVEsU0FBOUMsRUFBeURILFVBQXpEO0FBQ0EsY0FBTWxRLEtBQU47QUFDSDs7QUFDRCxVQUFJakcsS0FBSixFQUFxQyxFQUlwQzs7QUFDRDJSLE1BQUFBLE1BQU0sQ0FBQy9KLE1BQVAsQ0FBYzZPLElBQWQsQ0FBbUIscUJBQW5CLEVBQTBDdmIsRUFBMUMsRUFBOENpYixVQUE5QztBQUNBLGFBQU8sSUFBUDtBQUNILEtBdEVELENBc0VFLE9BQU83RCxJQUFQLEVBQWE7QUFDWCxVQUFJQSxJQUFJLENBQUNuTyxTQUFULEVBQW9CO0FBQ2hCLGVBQU8sS0FBUDtBQUNIOztBQUNELFlBQU1tTyxJQUFOO0FBQ0g7QUFDSjs7QUFDRFEsRUFBQUEsV0FBVyxDQUFDMEMsTUFBRCxFQUFTeEksR0FBVCxFQUFjOVIsRUFBZCxFQUFrQkMsT0FBTyxHQUFHLEVBQTVCLEVBQ1I7QUFDQyxjQUEyQztBQUN2QyxVQUFJLE9BQU9xRixNQUFNLENBQUNtUSxPQUFkLEtBQTBCLFdBQTlCLEVBQTJDO0FBQ3ZDemMsUUFBQUEsT0FBTyxDQUFDK1IsS0FBUixDQUFlLDJDQUFmO0FBQ0E7QUFDSDs7QUFDRCxVQUFJLE9BQU96RixNQUFNLENBQUNtUSxPQUFQLENBQWU2RSxNQUFmLENBQVAsS0FBa0MsV0FBdEMsRUFBbUQ7QUFDL0N0aEIsUUFBQUEsT0FBTyxDQUFDK1IsS0FBUixDQUFlLDJCQUEwQnVQLE1BQU8sbUJBQWhEO0FBQ0E7QUFDSDtBQUNKOztBQUNELFFBQUlBLE1BQU0sS0FBSyxXQUFYLElBQTBCLENBQUMsR0FBR3BLLE1BQUosRUFBWTJILE1BQVosT0FBeUI3WCxFQUF2RCxFQUEyRDtBQUN2RCxXQUFLNlksUUFBTCxHQUFnQjVZLE9BQU8sQ0FBQ2dCLE9BQXhCO0FBQ0FxRSxNQUFBQSxNQUFNLENBQUNtUSxPQUFQLENBQWU2RSxNQUFmLEVBQXVCO0FBQ25CeEksUUFBQUEsR0FEbUI7QUFFbkI5UixRQUFBQSxFQUZtQjtBQUduQkMsUUFBQUEsT0FIbUI7QUFJbkI2WCxRQUFBQSxHQUFHLEVBQUUsSUFKYztBQUtuQkUsUUFBQUEsR0FBRyxFQUFFLEtBQUtOLElBQUwsR0FBWTRDLE1BQU0sS0FBSyxXQUFYLEdBQXlCLEtBQUs1QyxJQUE5QixHQUFxQyxLQUFLQSxJQUFMLEdBQVk7QUFML0MsT0FBdkIsRUFNRztBQUNIO0FBQ0E7QUFDQSxRQVRBLEVBU0kxWCxFQVRKO0FBVUg7QUFDSjs7QUFDeUIsUUFBcEIyZCxvQkFBb0IsQ0FBQ3ZkLEdBQUQsRUFBTTFILFFBQU4sRUFBZ0JkLEtBQWhCLEVBQXVCb0ksRUFBdkIsRUFBMkJpYixVQUEzQixFQUF1QzJDLGFBQXZDLEVBQXNEO0FBQzVFLFFBQUl4ZCxHQUFHLENBQUM2SSxTQUFSLEVBQW1CO0FBQ2Y7QUFDQSxZQUFNN0ksR0FBTjtBQUNIOztBQUNELFFBQUksQ0FBQyxHQUFHMFAsWUFBSixFQUFrQjNKLFlBQWxCLENBQStCL0YsR0FBL0IsS0FBdUN3ZCxhQUEzQyxFQUEwRDtBQUN0RG5ILE1BQUFBLE1BQU0sQ0FBQy9KLE1BQVAsQ0FBYzZPLElBQWQsQ0FBbUIsa0JBQW5CLEVBQXVDbmIsR0FBdkMsRUFBNENKLEVBQTVDLEVBQWdEaWIsVUFBaEQsRUFEc0QsQ0FFdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTNWLE1BQUFBLE1BQU0sQ0FBQ3VVLFFBQVAsQ0FBZ0IvaUIsSUFBaEIsR0FBdUJrSixFQUF2QixDQVBzRCxDQVF0RDtBQUNBOztBQUNBLFlBQU02USxzQkFBc0IsRUFBNUI7QUFDSDs7QUFDRCxRQUFJO0FBQ0EsVUFBSXNHLFVBQUo7QUFDQSxVQUFJak4sV0FBSjtBQUNBLFVBQUlsVixLQUFKOztBQUNBLFVBQUksT0FBT21pQixVQUFQLEtBQXNCLFdBQXRCLElBQXFDLE9BQU9qTixXQUFQLEtBQXVCLFdBQWhFLEVBQTZFO0FBQ3pFLFNBQUM7QUFBRW1MLFVBQUFBLElBQUksRUFBRThCLFVBQVI7QUFBcUJqTixVQUFBQTtBQUFyQixZQUFzQyxNQUFNLEtBQUs4UyxjQUFMLENBQW9CLFNBQXBCLENBQTdDO0FBQ0g7O0FBQ0QsWUFBTVYsU0FBUyxHQUFHO0FBQ2R0bkIsUUFBQUEsS0FEYztBQUVka2lCLFFBQUFBLFNBQVMsRUFBRUMsVUFGRztBQUdkak4sUUFBQUEsV0FIYztBQUlkOUosUUFBQUEsR0FKYztBQUtkMkssUUFBQUEsS0FBSyxFQUFFM0s7QUFMTyxPQUFsQjs7QUFPQSxVQUFJLENBQUNrYyxTQUFTLENBQUN0bkIsS0FBZixFQUFzQjtBQUNsQixZQUFJO0FBQ0FzbkIsVUFBQUEsU0FBUyxDQUFDdG5CLEtBQVYsR0FBa0IsTUFBTSxLQUFLcWEsZUFBTCxDQUFxQjhILFVBQXJCLEVBQWlDO0FBQ3JEL1csWUFBQUEsR0FEcUQ7QUFFckQxSCxZQUFBQSxRQUZxRDtBQUdyRGQsWUFBQUE7QUFIcUQsV0FBakMsQ0FBeEI7QUFLSCxTQU5ELENBTUUsT0FBT2ltQixNQUFQLEVBQWU7QUFDYjdrQixVQUFBQSxPQUFPLENBQUMrUixLQUFSLENBQWMseUNBQWQsRUFBeUQ4UyxNQUF6RDtBQUNBdkIsVUFBQUEsU0FBUyxDQUFDdG5CLEtBQVYsR0FBa0IsRUFBbEI7QUFFSDtBQUNKOztBQUNELGFBQU9zbkIsU0FBUDtBQUNILEtBNUJELENBNEJFLE9BQU93QixZQUFQLEVBQXFCO0FBQ25CLGFBQU8sS0FBS0gsb0JBQUwsQ0FBMEJHLFlBQTFCLEVBQXdDcGxCLFFBQXhDLEVBQWtEZCxLQUFsRCxFQUF5RG9JLEVBQXpELEVBQTZEaWIsVUFBN0QsRUFBeUUsSUFBekUsQ0FBUDtBQUNIO0FBQ0o7O0FBQ2lCLFFBQVpzQixZQUFZLENBQUMvUyxLQUFELEVBQVE5USxRQUFSLEVBQWtCZCxLQUFsQixFQUF5Qm9JLEVBQXpCLEVBQTZCeUMsVUFBN0IsRUFBeUN3WSxVQUF6QyxFQUFxRDtBQUNuRSxRQUFJO0FBQ0EsWUFBTThDLGlCQUFpQixHQUFHLEtBQUtqRixVQUFMLENBQWdCdFAsS0FBaEIsQ0FBMUI7O0FBQ0EsVUFBSXlSLFVBQVUsQ0FBQ2hhLE9BQVgsSUFBc0I4YyxpQkFBdEIsSUFBMkMsS0FBS3ZVLEtBQUwsS0FBZUEsS0FBOUQsRUFBcUU7QUFDakUsZUFBT3VVLGlCQUFQO0FBQ0g7O0FBQ0QsWUFBTUMsZUFBZSxHQUFHRCxpQkFBaUIsSUFBSSxhQUFhQSxpQkFBbEMsR0FBc0Q3UCxTQUF0RCxHQUFrRTZQLGlCQUExRjtBQUNBLFlBQU16QixTQUFTLEdBQUcwQixlQUFlLEdBQUdBLGVBQUgsR0FBcUIsTUFBTSxLQUFLaEIsY0FBTCxDQUFvQnhULEtBQXBCLEVBQTJCckMsSUFBM0IsQ0FBaUNVLEdBQUQsS0FBUTtBQUM1RnFQLFFBQUFBLFNBQVMsRUFBRXJQLEdBQUcsQ0FBQ3dOLElBRDZFO0FBRTVGbkwsUUFBQUEsV0FBVyxFQUFFckMsR0FBRyxDQUFDcUMsV0FGMkU7QUFHNUY4TyxRQUFBQSxPQUFPLEVBQUVuUixHQUFHLENBQUNvVyxHQUFKLENBQVFqRixPQUgyRTtBQUk1RkMsUUFBQUEsT0FBTyxFQUFFcFIsR0FBRyxDQUFDb1csR0FBSixDQUFRaEY7QUFKMkUsT0FBUixDQUFoQyxDQUE1RDtBQU9BLFlBQU07QUFBRS9CLFFBQUFBLFNBQVMsRUFBRUMsVUFBYjtBQUEwQjZCLFFBQUFBLE9BQTFCO0FBQW9DQyxRQUFBQTtBQUFwQyxVQUFpRHFELFNBQXZEOztBQUNBLGdCQUEyQztBQUN2QyxjQUFNO0FBQUU0QixVQUFBQTtBQUFGLFlBQTBCMWUsbUJBQU8sQ0FBQywwQkFBRCxDQUF2Qzs7QUFDQSxZQUFJLENBQUMwZSxrQkFBa0IsQ0FBQy9HLFVBQUQsQ0FBdkIsRUFBcUM7QUFDakMsZ0JBQU0sSUFBSTdWLEtBQUosQ0FBVyx5REFBd0Q1SSxRQUFTLEdBQTVFLENBQU47QUFDSDtBQUNKOztBQUNELFVBQUk2ZCxRQUFKOztBQUNBLFVBQUl5QyxPQUFPLElBQUlDLE9BQWYsRUFBd0I7QUFDcEIxQyxRQUFBQSxRQUFRLEdBQUcsS0FBS1EsVUFBTCxDQUFnQm9ILFdBQWhCLENBQTRCLENBQUMsR0FBR2pPLE1BQUosRUFBWTBELG9CQUFaLENBQWlDO0FBQ3BFbGIsVUFBQUEsUUFEb0U7QUFFcEVkLFVBQUFBO0FBRm9FLFNBQWpDLENBQTVCLEVBR1A2SyxVQUhPLEVBR0t1VyxPQUhMLEVBR2MsS0FBSzFnQixNQUhuQixDQUFYO0FBSUg7O0FBQ0QsWUFBTXRELEtBQUssR0FBRyxNQUFNLEtBQUtvcEIsUUFBTCxDQUFjLE1BQUlwRixPQUFPLEdBQUcsS0FBS3FGLGNBQUwsQ0FBb0I5SCxRQUFwQixDQUFILEdBQW1DMEMsT0FBTyxHQUFHLEtBQUtxRixjQUFMLENBQW9CL0gsUUFBcEIsQ0FBSCxHQUFtQyxLQUFLbEgsZUFBTCxDQUFxQjhILFVBQXJCLEVBQWlDO0FBQ3ZKO0FBQ0l6ZSxRQUFBQSxRQURKO0FBRUlkLFFBQUFBLEtBRko7QUFHSWUsUUFBQUEsTUFBTSxFQUFFcUgsRUFIWjtBQUlJMUgsUUFBQUEsTUFBTSxFQUFFLEtBQUtBLE1BSmpCO0FBS0k0TCxRQUFBQSxPQUFPLEVBQUUsS0FBS0EsT0FMbEI7QUFNSUksUUFBQUEsYUFBYSxFQUFFLEtBQUtBO0FBTnhCLE9BRHNILENBQXRHLENBQXBCO0FBVUFnWSxNQUFBQSxTQUFTLENBQUN0bkIsS0FBVixHQUFrQkEsS0FBbEI7QUFDQSxXQUFLOGpCLFVBQUwsQ0FBZ0J0UCxLQUFoQixJQUF5QjhTLFNBQXpCO0FBQ0EsYUFBT0EsU0FBUDtBQUNILEtBeENELENBd0NFLE9BQU9pQyxJQUFQLEVBQWE7QUFDWCxhQUFPLEtBQUtaLG9CQUFMLENBQTBCWSxJQUExQixFQUFnQzdsQixRQUFoQyxFQUEwQ2QsS0FBMUMsRUFBaURvSSxFQUFqRCxFQUFxRGliLFVBQXJELENBQVA7QUFDSDtBQUNKOztBQUNEL1QsRUFBQUEsR0FBRyxDQUFDc0MsS0FBRCxFQUFROVEsUUFBUixFQUFrQmQsS0FBbEIsRUFBeUJvSSxFQUF6QixFQUE2Qm9XLElBQTdCLEVBQW1Db0gsV0FBbkMsRUFBZ0Q7QUFDL0MsU0FBS2xHLFVBQUwsR0FBa0IsS0FBbEI7QUFDQSxTQUFLOU4sS0FBTCxHQUFhQSxLQUFiO0FBQ0EsU0FBSzlRLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0EsU0FBS2QsS0FBTCxHQUFhQSxLQUFiO0FBQ0EsU0FBS2UsTUFBTCxHQUFjcUgsRUFBZDtBQUNBLFdBQU8sS0FBS3liLE1BQUwsQ0FBWXJGLElBQVosRUFBa0JvSCxXQUFsQixDQUFQO0FBQ0g7QUFDRDtBQUNKO0FBQ0E7QUFDQTs7O0FBQU1nQixFQUFBQSxjQUFjLENBQUNqWixFQUFELEVBQUs7QUFDakIsU0FBS29ULElBQUwsR0FBWXBULEVBQVo7QUFDSDs7QUFDRCtWLEVBQUFBLGVBQWUsQ0FBQ3RiLEVBQUQsRUFBSztBQUNoQixRQUFJLENBQUMsS0FBS3JILE1BQVYsRUFBa0IsT0FBTyxLQUFQO0FBQ2xCLFVBQU0sQ0FBQzhsQixZQUFELEVBQWVDLE9BQWYsSUFBMEIsS0FBSy9sQixNQUFMLENBQVlzYixLQUFaLENBQWtCLEdBQWxCLENBQWhDO0FBQ0EsVUFBTSxDQUFDMEssWUFBRCxFQUFlQyxPQUFmLElBQTBCNWUsRUFBRSxDQUFDaVUsS0FBSCxDQUFTLEdBQVQsQ0FBaEMsQ0FIZ0IsQ0FJaEI7O0FBQ0EsUUFBSTJLLE9BQU8sSUFBSUgsWUFBWSxLQUFLRSxZQUE1QixJQUE0Q0QsT0FBTyxLQUFLRSxPQUE1RCxFQUFxRTtBQUNqRSxhQUFPLElBQVA7QUFDSCxLQVBlLENBUWhCOzs7QUFDQSxRQUFJSCxZQUFZLEtBQUtFLFlBQXJCLEVBQW1DO0FBQy9CLGFBQU8sS0FBUDtBQUNILEtBWGUsQ0FZaEI7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFdBQU9ELE9BQU8sS0FBS0UsT0FBbkI7QUFDSDs7QUFDRHBELEVBQUFBLFlBQVksQ0FBQ3hiLEVBQUQsRUFBSztBQUNiLFVBQU0sR0FBR3lVLElBQUgsSUFBV3pVLEVBQUUsQ0FBQ2lVLEtBQUgsQ0FBUyxHQUFULENBQWpCLENBRGEsQ0FFYjtBQUNBOztBQUNBLFFBQUlRLElBQUksS0FBSyxFQUFULElBQWVBLElBQUksS0FBSyxLQUE1QixFQUFtQztBQUMvQm5QLE1BQUFBLE1BQU0sQ0FBQ3VaLFFBQVAsQ0FBZ0IsQ0FBaEIsRUFBbUIsQ0FBbkI7QUFDQTtBQUNILEtBUFksQ0FRYjs7O0FBQ0EsVUFBTUMsSUFBSSxHQUFHeFgsUUFBUSxDQUFDeVgsY0FBVCxDQUF3QnRLLElBQXhCLENBQWI7O0FBQ0EsUUFBSXFLLElBQUosRUFBVTtBQUNOQSxNQUFBQSxJQUFJLENBQUNFLGNBQUw7QUFDQTtBQUNILEtBYlksQ0FjYjtBQUNBOzs7QUFDQSxVQUFNQyxNQUFNLEdBQUczWCxRQUFRLENBQUM0WCxpQkFBVCxDQUEyQnpLLElBQTNCLEVBQWlDLENBQWpDLENBQWY7O0FBQ0EsUUFBSXdLLE1BQUosRUFBWTtBQUNSQSxNQUFBQSxNQUFNLENBQUNELGNBQVA7QUFDSDtBQUNKOztBQUNEbEQsRUFBQUEsUUFBUSxDQUFDbmpCLE1BQUQsRUFBUztBQUNiLFdBQU8sS0FBS0EsTUFBTCxLQUFnQkEsTUFBdkI7QUFDSDtBQUNEO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQW9CLFFBQVJvSCxRQUFRLENBQUMrUixHQUFELEVBQU1uWixNQUFNLEdBQUdtWixHQUFmLEVBQW9CN1IsT0FBTyxHQUFHLEVBQTlCLEVBQ2I7QUFDQyxRQUFJeWIsTUFBTSxHQUFHLENBQUMsR0FBR3RMLGlCQUFKLEVBQXVCcUksZ0JBQXZCLENBQXdDM0csR0FBeEMsQ0FBYjtBQUNBLFFBQUk7QUFBRXBaLE1BQUFBLFFBQVEsRUFBRXltQjtBQUFaLFFBQTJCekQsTUFBL0I7O0FBQ0EsUUFBSTVXLEtBQUosRUFBcUMsRUFXcEM7O0FBQ0QsVUFBTW1RLEtBQUssR0FBRyxNQUFNLEtBQUs4QixVQUFMLENBQWdCNkUsV0FBaEIsRUFBcEI7QUFDQSxRQUFJblosVUFBVSxHQUFHOUosTUFBakI7O0FBQ0EsUUFBSW1NLEtBQUosRUFBK0QsRUFBL0QsTUFhTztBQUNINFcsTUFBQUEsTUFBTSxDQUFDaGpCLFFBQVAsR0FBa0JzYyxtQkFBbUIsQ0FBQzBHLE1BQU0sQ0FBQ2hqQixRQUFSLEVBQWtCdWMsS0FBbEIsQ0FBckM7O0FBQ0EsVUFBSXlHLE1BQU0sQ0FBQ2hqQixRQUFQLEtBQW9CeW1CLFNBQXhCLEVBQW1DO0FBQy9CQSxRQUFBQSxTQUFTLEdBQUd6RCxNQUFNLENBQUNoakIsUUFBbkI7QUFDQWdqQixRQUFBQSxNQUFNLENBQUNoakIsUUFBUCxHQUFrQnltQixTQUFsQjtBQUNBck4sUUFBQUEsR0FBRyxHQUFHLENBQUMsR0FBRzVCLE1BQUosRUFBWTBELG9CQUFaLENBQWlDOEgsTUFBakMsQ0FBTjtBQUNIO0FBQ0o7O0FBQ0QsVUFBTWxTLEtBQUssR0FBRyxDQUFDLEdBQUdxRyx1QkFBSixFQUE2QnBMLHVCQUE3QixDQUFxRDBhLFNBQXJELENBQWQsQ0F0Q0QsQ0F1Q0M7O0FBQ0EsY0FBMkM7QUFDdkM7QUFDSDs7QUFDRCxVQUFNclksT0FBTyxDQUFDc0UsR0FBUixDQUFZLENBQ2QsS0FBSzJMLFVBQUwsQ0FBZ0JxSSxNQUFoQixDQUF1QjVWLEtBQXZCLEVBQThCckMsSUFBOUIsQ0FBb0NrWSxLQUFELElBQVM7QUFDeEMsYUFBT0EsS0FBSyxHQUFHLEtBQUtoQixjQUFMLENBQW9CLEtBQUt0SCxVQUFMLENBQWdCb0gsV0FBaEIsQ0FBNEJyTSxHQUE1QixFQUFpQ3JQLFVBQWpDLEVBQTZDLElBQTdDLEVBQW1ELE9BQU94QyxPQUFPLENBQUMzSCxNQUFmLEtBQTBCLFdBQTFCLEdBQXdDMkgsT0FBTyxDQUFDM0gsTUFBaEQsR0FBeUQsS0FBS0EsTUFBakgsQ0FBcEIsQ0FBSCxHQUFtSixLQUEvSjtBQUNILEtBRkQsQ0FEYyxFQUlkLEtBQUt5ZSxVQUFMLENBQWdCOVcsT0FBTyxDQUFDNkQsUUFBUixHQUFtQixVQUFuQixHQUFnQyxVQUFoRCxFQUE0RDBGLEtBQTVELENBSmMsQ0FBWixDQUFOO0FBTUg7O0FBQ21CLFFBQWR3VCxjQUFjLENBQUN4VCxLQUFELEVBQVE7QUFDeEIsUUFBSVAsU0FBUyxHQUFHLEtBQWhCOztBQUNBLFVBQU1xVyxNQUFNLEdBQUcsS0FBS2hHLEdBQUwsR0FBVyxNQUFJO0FBQzFCclEsTUFBQUEsU0FBUyxHQUFHLElBQVo7QUFDSCxLQUZEOztBQUdBLFVBQU1zVyxlQUFlLEdBQUcsTUFBTSxLQUFLeEksVUFBTCxDQUFnQnlJLFFBQWhCLENBQXlCaFcsS0FBekIsQ0FBOUI7O0FBQ0EsUUFBSVAsU0FBSixFQUFlO0FBQ1gsWUFBTThCLEtBQUssR0FBRyxJQUFJekosS0FBSixDQUFXLHdDQUF1Q2tJLEtBQU0sR0FBeEQsQ0FBZDtBQUNBdUIsTUFBQUEsS0FBSyxDQUFDOUIsU0FBTixHQUFrQixJQUFsQjtBQUNBLFlBQU04QixLQUFOO0FBQ0g7O0FBQ0QsUUFBSXVVLE1BQU0sS0FBSyxLQUFLaEcsR0FBcEIsRUFBeUI7QUFDckIsV0FBS0EsR0FBTCxHQUFXLElBQVg7QUFDSDs7QUFDRCxXQUFPaUcsZUFBUDtBQUNIOztBQUNEbkIsRUFBQUEsUUFBUSxDQUFDdlQsRUFBRCxFQUFLO0FBQ1QsUUFBSTVCLFNBQVMsR0FBRyxLQUFoQjs7QUFDQSxVQUFNcVcsTUFBTSxHQUFHLE1BQUk7QUFDZnJXLE1BQUFBLFNBQVMsR0FBRyxJQUFaO0FBQ0gsS0FGRDs7QUFHQSxTQUFLcVEsR0FBTCxHQUFXZ0csTUFBWDtBQUNBLFdBQU96VSxFQUFFLEdBQUcxRCxJQUFMLENBQVdpUCxJQUFELElBQVE7QUFDckIsVUFBSWtKLE1BQU0sS0FBSyxLQUFLaEcsR0FBcEIsRUFBeUI7QUFDckIsYUFBS0EsR0FBTCxHQUFXLElBQVg7QUFDSDs7QUFDRCxVQUFJclEsU0FBSixFQUFlO0FBQ1gsY0FBTXNWLElBQUksR0FBRyxJQUFJamQsS0FBSixDQUFVLGlDQUFWLENBQWI7QUFDQWlkLFFBQUFBLElBQUksQ0FBQ3RWLFNBQUwsR0FBaUIsSUFBakI7QUFDQSxjQUFNc1YsSUFBTjtBQUNIOztBQUNELGFBQU9uSSxJQUFQO0FBQ0gsS0FWTSxDQUFQO0FBV0g7O0FBQ0RpSSxFQUFBQSxjQUFjLENBQUM5SCxRQUFELEVBQVc7QUFDckIsVUFBTTtBQUFFemYsTUFBQUEsSUFBSSxFQUFFMm9CO0FBQVIsUUFBc0IsSUFBSXZOLEdBQUosQ0FBUXFFLFFBQVIsRUFBa0JqUixNQUFNLENBQUN1VSxRQUFQLENBQWdCL2lCLElBQWxDLENBQTVCOztBQUNBLFFBQUksS0FBSixFQUFvRixFQUVuRjs7QUFDRCxXQUFPd2YsYUFBYSxDQUFDQyxRQUFELEVBQVcsS0FBS21DLEtBQWhCLENBQWIsQ0FBb0N2UixJQUFwQyxDQUEwQ2lQLElBQUQsSUFBUTtBQUNwRCxXQUFLb0IsR0FBTCxDQUFTaUksUUFBVCxJQUFxQnJKLElBQXJCO0FBQ0EsYUFBT0EsSUFBUDtBQUNILEtBSE0sQ0FBUDtBQUlIOztBQUNEa0ksRUFBQUEsY0FBYyxDQUFDL0gsUUFBRCxFQUFXO0FBQ3JCLFVBQU07QUFBRXpmLE1BQUFBLElBQUksRUFBRTRvQjtBQUFSLFFBQXlCLElBQUl4TixHQUFKLENBQVFxRSxRQUFSLEVBQWtCalIsTUFBTSxDQUFDdVUsUUFBUCxDQUFnQi9pQixJQUFsQyxDQUEvQjs7QUFDQSxRQUFJLEtBQUsyZ0IsR0FBTCxDQUFTaUksV0FBVCxDQUFKLEVBQTJCO0FBQ3ZCLGFBQU8sS0FBS2pJLEdBQUwsQ0FBU2lJLFdBQVQsQ0FBUDtBQUNIOztBQUNELFdBQU8sS0FBS2pJLEdBQUwsQ0FBU2lJLFdBQVQsSUFBd0JwSixhQUFhLENBQUNDLFFBQUQsRUFBVyxLQUFLbUMsS0FBaEIsQ0FBYixDQUFvQ3ZSLElBQXBDLENBQTBDaVAsSUFBRCxJQUFRO0FBQzVFLGFBQU8sS0FBS3FCLEdBQUwsQ0FBU2lJLFdBQVQsQ0FBUDtBQUNBLGFBQU90SixJQUFQO0FBQ0gsS0FIOEIsRUFHNUJqVyxLQUg0QixDQUdyQm9lLElBQUQsSUFBUTtBQUNiLGFBQU8sS0FBSzlHLEdBQUwsQ0FBU2lJLFdBQVQsQ0FBUDtBQUNBLFlBQU1uQixJQUFOO0FBQ0gsS0FOOEIsQ0FBL0I7QUFPSDs7QUFDRGxQLEVBQUFBLGVBQWUsQ0FBQzZILFNBQUQsRUFBWXlJLEdBQVosRUFBaUI7QUFDNUIsVUFBTTtBQUFFekksTUFBQUEsU0FBUyxFQUFFMEk7QUFBYixRQUF1QixLQUFLOUcsVUFBTCxDQUFnQixPQUFoQixDQUE3Qjs7QUFDQSxVQUFNK0csT0FBTyxHQUFHLEtBQUt0RyxRQUFMLENBQWNxRyxJQUFkLENBQWhCOztBQUNBRCxJQUFBQSxHQUFHLENBQUNFLE9BQUosR0FBY0EsT0FBZDtBQUNBLFdBQU8sQ0FBQyxHQUFHM1AsTUFBSixFQUFZNFAsbUJBQVosQ0FBZ0NGLElBQWhDLEVBQXNDO0FBQ3pDQyxNQUFBQSxPQUR5QztBQUV6QzNJLE1BQUFBLFNBRnlDO0FBR3pDeGYsTUFBQUEsTUFBTSxFQUFFLElBSGlDO0FBSXpDaW9CLE1BQUFBO0FBSnlDLEtBQXRDLENBQVA7QUFNSDs7QUFDRHhFLEVBQUFBLGtCQUFrQixDQUFDbmIsRUFBRCxFQUFLaWIsVUFBTCxFQUFpQjtBQUMvQixRQUFJLEtBQUszQixHQUFULEVBQWM7QUFDVjdDLE1BQUFBLE1BQU0sQ0FBQy9KLE1BQVAsQ0FBYzZPLElBQWQsQ0FBbUIsa0JBQW5CLEVBQXVDMUssc0JBQXNCLEVBQTdELEVBQWlFN1EsRUFBakUsRUFBcUVpYixVQUFyRTtBQUNBLFdBQUszQixHQUFMO0FBQ0EsV0FBS0EsR0FBTCxHQUFXLElBQVg7QUFDSDtBQUNKOztBQUNEbUMsRUFBQUEsTUFBTSxDQUFDckYsSUFBRCxFQUFPb0gsV0FBUCxFQUFvQjtBQUN0QixXQUFPLEtBQUtuRSxHQUFMLENBQVNqRCxJQUFULEVBQWUsS0FBSzBDLFVBQUwsQ0FBZ0IsT0FBaEIsRUFBeUI1QixTQUF4QyxFQUFtRHNHLFdBQW5ELENBQVA7QUFDSDs7QUF2dkJROztBQXl2QmIvRyxNQUFNLENBQUMvSixNQUFQLEdBQWdCLENBQUMsR0FBR3VELEtBQUosRUFBV3RaLE9BQVgsRUFBaEI7QUFDQTBJLGVBQUEsR0FBa0JvWCxNQUFsQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2aUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQSxNQUFNdmUsR0FBRyxHQUFHdkQsOERBQVc7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUxBO0FBT0EsTUFBTXFyQixTQUFTLEdBQUdwaEIsa0RBQUk7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQXZCQTtBQXdCQSxNQUFNcWhCLE1BQU0sR0FBR3JoQixrREFBSTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQWhCQTtBQWlCQSxNQUFNc2hCLFFBQVEsR0FBR3ZyQiw2REFBVTtBQUMzQjtBQUNBO0FBQ0E7QUFDQSxDQUpBOztBQU1BLE1BQU13ckIsS0FBSyxHQUFHLE1BQU07QUFDaEIsTUFBSS9KLElBQUksR0FBRzVXLG1CQUFPLENBQUMsc0ZBQUQsQ0FBbEI7O0FBQ0E0VyxFQUFBQSxJQUFJLEdBQUdBLElBQUksQ0FBQ2dLLFNBQUwsQ0FBZUMsTUFBZixDQUFzQmpLLElBQUksQ0FBQ2tLLEtBQTNCLEVBQWtDbEssSUFBSSxDQUFDbUssVUFBdkMsRUFBbURuSyxJQUFJLENBQUNvSyxPQUF4RCxFQUFpRXBLLElBQUksQ0FBQ3FLLElBQXRFLEVBQTRFckssSUFBSSxDQUFDc0ssZUFBakYsQ0FBUDtBQUNBLFFBQU05UixJQUFJLEdBQUcsQ0FBQyxDQUFDLE1BQUQsRUFBUSxNQUFSLENBQUQsRUFBbUIsQ0FBQyxNQUFELEVBQVMsTUFBVCxDQUFuQixFQUFxQyxDQUFDLE1BQUQsRUFBUyxNQUFULENBQXJDLENBQWI7QUFDQSxRQUFNbFgsTUFBTSxHQUFHTixzREFBUyxFQUF4QjtBQUNBLHNCQUNJO0FBQUEsNEJBQ0ksOERBQUMsNkNBQUQ7QUFBTSxXQUFLLEVBQUM7QUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBRUksOERBQUMsK0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGSixlQUdJO0FBQUEsZ0JBQVM0b0I7QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUhKLGVBSUk7QUFBQSxnQkFBU0M7QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpKLGVBS0ksOERBQUMsaUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMSixlQU1JLDhEQUFDLEdBQUQ7QUFBQSw4QkFDSSw4REFBQyxtRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUk7QUFBSyxpQkFBUyxFQUFDLGNBQWY7QUFBQSxnQ0FDSSw4REFBQyxRQUFEO0FBQVUsZUFBSyxFQUFFO0FBQUVVLFlBQUFBLE9BQU8sRUFBRztBQUFaLFdBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLEVBR1F2SyxJQUFJLENBQUNsZCxHQUFMLENBQVMsQ0FBRTBuQixLQUFGLEVBQVN4bkIsS0FBVCxLQUFrQjtBQUN2QixjQUFJeW5CLE9BQU8sR0FBR2pTLElBQUksQ0FBQzlJLElBQUksQ0FBQ2diLEtBQUwsQ0FBV2hiLElBQUksQ0FBQ2liLE1BQUwsS0FBYyxDQUF6QixDQUFELENBQWxCO0FBQ0EsOEJBQVE7QUFBbUIscUJBQVMsRUFBQyxZQUE3QjtBQUEwQyxpQkFBSyxFQUFFO0FBQUUzbUIsY0FBQUEsVUFBVSxFQUFHLE9BQU13bUIsS0FBSyxDQUFDamMsSUFBSyxHQUFoQztBQUFvQ3FjLGNBQUFBLGNBQWMsRUFBRSxPQUFwRDtBQUE2REMsY0FBQUEsS0FBSyxFQUFHLEdBQUVKLE9BQU8sQ0FBQyxDQUFELENBQUksRUFBbEY7QUFBcUYzbUIsY0FBQUEsTUFBTSxFQUFHLEdBQUUybUIsT0FBTyxDQUFDLENBQUQsQ0FBSTtBQUEzRztBQUFqRCxhQUFXem5CLEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBUjtBQUNILFNBSEQsQ0FIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5KLGVBa0JJLDhEQUFDLCtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbEJKO0FBQUEsa0JBREo7QUFzQkgsQ0EzQkQ7O0FBNkJBLGlFQUFlK21CLEtBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdGQTtBQUNBOztBQUVBLE1BQU1lLGVBQWUsR0FBR3ZzQiw4REFBVztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNd0kseURBQWM7QUFDcEI7QUFDQTtBQUNBLENBVkE7O0FBWUEsTUFBTUMsU0FBUyxHQUFHLE1BQU07QUFDcEIsc0JBQ0ksOERBQUMsZUFBRDtBQUFpQixXQUFPLEVBQUMsV0FBekI7QUFBQSwyQkFDSTtBQUFNLE9BQUMsRUFBQztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFLSCxDQU5EOztBQVFBLGlFQUFlQSxTQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2QkE7QUFDQTs7QUFFQSxNQUFNK2pCLGFBQWEsR0FBR3hzQiw4REFBVztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNdUksK0NBQVM7QUFDZjtBQUNBO0FBQ0EsQ0FWQTs7QUFZQSxNQUFNRCxlQUFlLEdBQUcsTUFBTTtBQUMxQixzQkFDSSw4REFBQyxhQUFEO0FBQWUsV0FBTyxFQUFDLFdBQXZCO0FBQUEsMkJBQ0k7QUFBTSxjQUFRLEVBQUMsU0FBZjtBQUF5QixPQUFDLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsaUVBQWVBLGVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZCQTtBQUNBOztBQUVBLE1BQU1ra0IsYUFBYSxHQUFHeHNCLDhEQUFXO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU13SSx5REFBYztBQUNwQjtBQUNBO0FBQ0EsQ0FWQTs7QUFZQSxNQUFNRyxVQUFVLEdBQUcsTUFBTTtBQUNyQixzQkFDSSw4REFBQyxhQUFEO0FBQWUsV0FBTyxFQUFDLFdBQXZCO0FBQUEsMkJBQ0k7QUFBTSxjQUFRLEVBQUMsU0FBZjtBQUF5QixPQUFDLEVBQUM7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQUtILENBTkQ7O0FBUUEsaUVBQWVBLFVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkJBO0FBRU8sTUFBTUgsYUFBYSxHQUFHeEksOERBQVc7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBZk87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQO0FBQ0E7OztBQUVBLE1BQU1jLFVBQVUsR0FBR2QsOERBQVc7QUFDOUI7QUFDQTtBQUNBLENBSEE7QUFLQSxNQUFNeXNCLGVBQWUsR0FBR3pzQixpRUFBYztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTtBQVFBLE1BQU11c0IsZUFBZSxHQUFHdnNCLDhEQUFXO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTXlzQixlQUFnQjtBQUN0QjtBQUNBO0FBQ0EsQ0FYQTs7QUFhQSxNQUFNaGtCLFNBQVMsR0FBRyxNQUFNO0FBQ3BCLHNCQUNJLDhEQUFDLGVBQUQ7QUFBaUIsV0FBTyxFQUFDLFdBQXpCO0FBQUEsMkJBQ0k7QUFBTSxPQUFDLEVBQUM7QUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBS0gsQ0FORDs7QUFRQSxNQUFNckIsUUFBUSxHQUFHLENBQUM7QUFBRXNsQixFQUFBQSxhQUFGO0FBQWlCeG1CLEVBQUFBLE9BQWpCO0FBQTBCZ0QsRUFBQUE7QUFBMUIsQ0FBRCxLQUE4QztBQUMzRCxzQkFDSTtBQUFBLDRCQUNJLDhEQUFDLGVBQUQ7QUFBaUIsYUFBTyxFQUFFaEQsT0FBMUI7QUFBQSw4QkFDSSw4REFBQyxVQUFEO0FBQVksZUFBTyxFQUFDLFdBQXBCO0FBQWdDLFlBQUksRUFBQyxNQUFyQztBQUFBLCtCQUNJO0FBQU0sV0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFJSSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBT0ksOERBQUMsc0VBQUQ7QUFBYyxZQUFNLEVBQUV3bUIsYUFBdEI7QUFBcUMsa0JBQVksRUFBRXhqQjtBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBKO0FBQUEsa0JBREo7QUFXSCxDQVpEOztBQWNBLGlFQUFlOUIsUUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuREE7QUFFTyxNQUFNbUIsUUFBUSxHQUFHdkksNkRBQVU7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBTk87Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRlA7QUFFTyxNQUFNNkksVUFBVSxHQUFHN0ksNERBQVM7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBWk87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGUDtBQUNBOztBQUVBLE1BQU1jLFVBQVUsR0FBR2QsOERBQVc7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBTkE7O0FBUUEsTUFBTW1ILFlBQVksR0FBRyxDQUFDO0FBQUVoRixFQUFBQTtBQUFGLENBQUQsS0FBYztBQUMvQixzQkFDSSw4REFBQyxrREFBRDtBQUFNLFFBQUksRUFBRUEsSUFBWjtBQUFrQixZQUFRLE1BQTFCO0FBQUEsMkJBQ0k7QUFBQSw2QkFDSSw4REFBQyxVQUFEO0FBQVksZUFBTyxFQUFDLGFBQXBCO0FBQWtDLFlBQUksRUFBQyxNQUF2QztBQUFBLCtCQUNJO0FBQU0sV0FBQyxFQUFDO0FBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBU0gsQ0FWRDs7QUFZQSxpRUFBZWdGLFlBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNOQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNIQSx5R0FBOEM7Ozs7Ozs7Ozs7OztBQ0E5Qzs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvQnV0dG9uL0J1dHRvbi5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvRm9vdGVyL0Zpc3RMb2dvLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9Gb290ZXIvRm9vdGVyLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9Gb290ZXIvRm9vdGVyTGF5b3V0LmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9Gb290ZXIvSWNvbi9GYWNlYm9va0ljb24uanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL0Zvb3Rlci9JY29uL0luc3RhZ3JhbUljb24uanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL0Zvb3Rlci9JY29uL1lvdXR1YmVJY29uLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9Gb290ZXIvSWNvbi9pbmRleC5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9Gb290ZXIvTGlua0hvdmVyLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9Gb290ZXIvUmlvdEdhbWVzTG9nby5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvSGVhZC5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTWVkaWFDb21wb25lbnQvQ2F0ZWdvcnlCYXIuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL01lZGlhQ29tcG9uZW50L0ZpbHRlckRyb3Bib3guanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL01lZGlhQ29tcG9uZW50L01lZGlhSGVhZC5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTWVkaWFDb21wb25lbnQvaW5kZXguanMiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L0xhbmdCdXR0b24uanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9MYW5nU2VsZWN0b3IuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9OYXZCYXIuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9OYXZEcm9wZG93bi9FeHRlcm5hbExpLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9OYXYvTmF2RHJvcGRvd24vTGkuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9OYXZEcm9wZG93bi9OYXZEcm9wZG93bi5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L05hdkRyb3Bkb3duL1VsLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9OYXYvTmF2RHJvcGRvd24vaW5kZXguanMiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvTmF2L05hdkV4dGVybmFsTGluay9OYXZFeHRlcm5hbExpbmsuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9OYXZJdGVtL05hdkl0ZW0uanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9OYXZMYXlvdXQuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9OYXZTZXBhcmF0b3IuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9QbGF5QnV0dG9uLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9OYXYvUGxheVBvcHVwLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9OYXYvUmlnaHROYXYuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL05hdi9SaW90R2FtZXNCYXIuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9jb21wb25lbnRzL1RleHRCZy5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL2NvbXBvbmVudHMvVGV4dFRpdGxlLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vY29tcG9uZW50cy9pbmRleC5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvbGluay5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvbm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoLmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9yZXF1ZXN0LWlkbGUtY2FsbGJhY2suanMiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3JvdXRlLWxvYWRlci5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvcm91dGVyLmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC91c2UtaW50ZXJzZWN0aW9uLmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC93aXRoLXJvdXRlci5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci9yb3V0ZXIuanMiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL3BhZ2VzL21lZGlhL2luZGV4LmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL25hdl9jb21wb25lbnRzL0NhcmV0RG93bi5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL3N0eWxlcy9uYXZfY29tcG9uZW50cy9Ecm9wZG93bkFycm93VXAuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9zdHlsZXMvbmF2X2NvbXBvbmVudHMvTmF2QXJyb3dVcC5qc3giLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC8uL3N0eWxlcy9uYXZfY29tcG9uZW50cy9OYXZJdGVtTGF5b3V0LmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL25hdl9jb21wb25lbnRzL1Jpb3RMb2dvLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL25hdl9jb21wb25lbnRzL1N0eWxlZExpLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL25hdl9jb21wb25lbnRzL1N0eWxlZExpbmsuanN4Iiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9zdHlsZXMvbmF2X2NvbXBvbmVudHMvVmFsb3JhbnRMb2dvLmpzeCIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vc3R5bGVzL25hdl9jb21wb25lbnRzL2luZGV4LmpzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9zdHlsZXMvTmV3cy5tb2R1bGUuY3NzIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvLi9zdHlsZXMvbWVkaWEubW9kdWxlLmNzcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoLy4vbm9kZV9tb2R1bGVzL25leHQvbGluay5qcyIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGguanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvaTE4bi9ub3JtYWxpemUtbG9jYWxlLXBhdGguanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvbWl0dC5qc1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXItY29udGV4dC5qc1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvZ2V0LWFzc2V0LXBhdGgtZnJvbS1yb3V0ZS5qc1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvaXMtZHluYW1pYy5qc1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcGFyc2UtcmVsYXRpdmUtdXJsLmpzXCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9xdWVyeXN0cmluZy5qc1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtbWF0Y2hlci5qc1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtcmVnZXguanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvdXRpbHMuanNcIiIsIndlYnBhY2s6Ly92YWxvcmFudC13ZWJ0ZWNoL2V4dGVybmFsIFwibmV4dC9oZWFkXCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcIm5leHQvcm91dGVyXCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcInJlYWN0LWlzXCIiLCJ3ZWJwYWNrOi8vdmFsb3JhbnQtd2VidGVjaC9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvZXh0ZXJuYWwgXCJzdHlsZWQtY29tcG9uZW50c1wiIiwid2VicGFjazovL3ZhbG9yYW50LXdlYnRlY2gvaWdub3JlZHxDOlxcVXNlcnNcXFVzZXJcXERlc2t0b3BcXHZhbG9yYW50XFx2YWxvcmFudF93ZWJcXG15bmV4dGFwcFxcbm9kZV9tb2R1bGVzXFxuZXh0XFxkaXN0XFxzaGFyZWRcXGxpYlxccm91dGVyfC4vdXRpbHMvcmVzb2x2ZS1yZXdyaXRlcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuY29uc3QgU3R5bGVkQnV0dG9uV3JhcHBlciA9IHN0eWxlZC5idXR0b25gXHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICB3aWR0aDogMjcwcHg7XHJcbiAgICBoZWlnaHQ6IDY4cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgcGFkZGluZzogNnB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5gXHJcblxyXG5jb25zdCBDb250ZW50ID0gc3R5bGVkLmRpdmBcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMuaXNXaGl0ZSA/IFwiI2VjZThlMVwiIDogXCIjZmY0NjU1XCJ9O1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmb250LWZhbWlseTogJ0JhaSBKYW1qdXJlZScsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMuaXNXaGl0ZSA/IFwiIzBmMTkyM1wiIDogXCJ3aGl0ZVwifTtcclxuICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgZWFzZS1pbiAuMnMsIGJvcmRlciAuMnM7XHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjMGYxOTIzO1xyXG4gICAgICAgIG91dGxpbmU6ICR7cHJvcHMgPT4gcHJvcHMuaXNCb3JkZXJlZCA/IGBzb2xpZCAke3Byb3BzLmlzV2hpdGUgPyBcIiNlY2U4ZTE0NFwiIDogXCIjZmY0NjU1NDRcIn0gMXB4YCA6IFwibm9uZVwifTtcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5gXHJcblxyXG5jb25zdCBXaGl0ZUJveCA9IHN0eWxlZC5kaXZgXHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGYxOTIzO1xyXG4gICAgd2lkdGg6IDVweDtcclxuICAgIGhlaWdodDogNXB4O1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIGVhc2UtaW4gLjNzO1xyXG4gICAgJHtDb250ZW50fTpob3ZlciAmIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIH1cclxuYFxyXG5cclxuY29uc3QgQnV0dG9uQm9yZGVyID0gc3R5bGVkLmRpdmBcclxuICAgIGJvcmRlci1sZWZ0OiBzb2xpZCAjYmRiY2I3IDFweDtcclxuICAgIGJvcmRlci1yaWdodDogc29saWQgI2JkYmNiNyAxcHg7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDI5cHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbmBcclxuXHJcbmNvbnN0IFRvcEJvcmRlciA9IHN0eWxlZChCdXR0b25Cb3JkZXIpYFxyXG4gICAgYm9yZGVyLXRvcDogc29saWQgI2JkYmNiNyAxcHg7XHJcbiAgICB0b3A6IDA7XHJcbmBcclxuXHJcbmNvbnN0IEJvdHRvbUJvcmRlciA9IHN0eWxlZChCdXR0b25Cb3JkZXIpYFxyXG4gICAgYm9yZGVyLWJvdHRvbTogc29saWQgI2JkYmNiNyAxcHg7XHJcbiAgICBib3R0b206IDA7XHJcbmBcclxuXHJcbmNvbnN0IEJ1dHRvbiA9ICh7IGNoaWxkcmVuLCBpc1doaXRlLCBpc0JvcmRlcmVkIH0pID0+IChcclxuICAgIDxTdHlsZWRCdXR0b25XcmFwcGVyPlxyXG4gICAgICAgIDxUb3BCb3JkZXIgLz5cclxuICAgICAgICA8Qm90dG9tQm9yZGVyIC8+XHJcbiAgICAgICAgPENvbnRlbnQgaXNXaGl0ZT17aXNXaGl0ZX0gaXNCb3JkZXJlZD17aXNCb3JkZXJlZH0+XHJcbiAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICAgICAgPFdoaXRlQm94IC8+XHJcbiAgICAgICAgPC9Db250ZW50PlxyXG4gICAgPC9TdHlsZWRCdXR0b25XcmFwcGVyPlxyXG4pXHJcblxyXG5leHBvcnQgZGVmYXVsdCBCdXR0b247XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcclxuXHJcbmNvbnN0IFN0eWxlZExvZ28gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDMwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDZweDtcclxuYFxyXG5cclxuY29uc3QgRmlzdExvZ28gPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRMb2dvIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwiI0U2RTZFNlwiPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwiTTEyLjUzNCAyMS43N2wtMS4wOS0yLjgxIDEwLjUyLjU0LS40NTEgNC41ek0xNS4wNiAwTC4zMDcgNi45NjkgMi41OSAxNy40NzFINS42bC0uNTItNy41MTIuNDYxLS4xNDQgMS44MSA3LjY1NmgzLjEyNmwtLjExNi05LjE1LjQ2Mi0uMTQ0IDEuNTgyIDkuMjk0aDMuMzFsLjc4LTExLjA1My40NjItLjE0NC44MiAxMS4xOTdoNC4zNzZsMS41NC0xNS4zN1pcIiAvPlxyXG4gICAgICAgIDwvU3R5bGVkTG9nbz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRmlzdExvZ287XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCB7IEZvb3RlckxheW91dCB9IGZyb20gXCIuL0Zvb3RlckxheW91dFwiO1xyXG5pbXBvcnQgUmlvdEdhbWVzTG9nbyBmcm9tIFwiLi9SaW90R2FtZXNMb2dvXCI7XHJcbmltcG9ydCBGaXN0TG9nbyBmcm9tIFwiLi9GaXN0TG9nb1wiO1xyXG5pbXBvcnQgQnV0dG9uV3JhcHBlciBmcm9tIFwiLi9MaW5rSG92ZXJcIjtcclxuaW1wb3J0IHsgRmFjZWJvb2tJY29uLCBJbnN0YWdyYW1JY29uLCBZb3V0dWJlSWNvbiB9IGZyb20gJy4vSWNvbidcclxuXHJcbmNvbnN0IFAgPSBzdHlsZWQucGBcclxuICAgIHVzZXItc2VsZWN0OiBub25lO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG5gXHJcblxyXG5jb25zdCBSZXNlcnZlZCA9IHN0eWxlZChQKWBcclxuICAgIG1heC13aWR0aDogNTAwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjdXJzb3I6IGRlZmF1bHQ7XHJcbmBcclxuXHJcbmNvbnN0IExvZ29XcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbmBcclxuXHJcbmNvbnN0IFVuZGVybGluZSA9IHN0eWxlZChQKWBcclxuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG5gXHJcblxyXG5jb25zdCBMaW5rV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgY29sdW1uLWdhcDogMTJweDtcclxuYFxyXG5cclxuY29uc3QgU29jaWFsV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgY29sdW1uLWdhcDogMjRweDtcclxuYFxyXG5cclxuY29uc3QgRm9vdGVyID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Rm9vdGVyTGF5b3V0PlxyXG4gICAgICAgICAgICA8QnV0dG9uV3JhcHBlcj5cclxuICAgICAgICAgICAgICAgIDxQPuC4lOC4suC4p+C4meC5jOC5guC4q+C4peC4lOC5gOC4geC4oTwvUD5cclxuICAgICAgICAgICAgPC9CdXR0b25XcmFwcGVyPlxyXG4gICAgICAgICAgICA8TG9nb1dyYXBwZXI+XHJcbiAgICAgICAgICAgICAgICA8RmlzdExvZ28gLz5cclxuICAgICAgICAgICAgICAgIDxSaW90R2FtZXNMb2dvIC8+XHJcbiAgICAgICAgICAgIDwvTG9nb1dyYXBwZXI+XHJcbiAgICAgICAgICAgIDxTb2NpYWxXcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgPEZhY2Vib29rSWNvbi8+XHJcbiAgICAgICAgICAgICAgICA8WW91dHViZUljb24vPlxyXG4gICAgICAgICAgICAgICAgPEluc3RhZ3JhbUljb24vPlxyXG4gICAgICAgICAgICA8L1NvY2lhbFdyYXBwZXI+XHJcbiAgICAgICAgICAgIDxSZXNlcnZlZD7CqSDguKrguIfguKfguJnguKXguLTguILguKrguLTguJfguJjguLTguYzguJXguLLguKHguIHguI/guKvguKHguLLguKIg4LieLuC4qC4gMjU2MyDguJrguKPguLTguKnguLHguJcgUmlvdCwgVkFMT1JBTlQg4LmB4Lil4Liw4LmC4Lil4LmC4LiB4LmJ4LmA4LiE4Lij4Li34LmI4Lit4LiH4Lir4Lih4Liy4Lii4LiB4Liy4Lij4LiE4LmJ4LiyIOC5gOC4hOC4o+C4t+C5iOC4reC4h+C4q+C4oeC4suC4ouC4muC4o+C4tOC4geC4suC4o+C5geC4peC4sC/guKvguKPguLfguK0g4LmA4LiE4Lij4Li34LmI4Lit4LiH4Lir4Lih4Liy4Lii4LiB4Liy4Lij4LiE4LmJ4Liy4LiI4LiU4LiX4Liw4LmA4Lia4Li14Lii4LiZ4LiX4Li14LmI4LmA4LiB4Li14LmI4Lii4Lin4LiC4LmJ4Lit4LiHIOC4luC4t+C4reC5gOC4m+C5h+C4meC4geC4o+C4o+C4oeC4quC4tOC4l+C4mOC4tOC5jOC4guC4reC4hyBSaW90IEdhbWVzLCBJbmMuPC9SZXNlcnZlZD5cclxuICAgICAgICAgICAgPExpbmtXcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgPFVuZGVybGluZT7guJnguYLguKLguJrguLLguKLguITguKfguLLguKHguYDguJvguYfguJnguKrguYjguKfguJnguJXguLHguKc8L1VuZGVybGluZT5cclxuICAgICAgICAgICAgICAgIDxVbmRlcmxpbmU+4LiC4LmJ4Lit4LiB4Liz4Lir4LiZ4LiU4LiB4Liy4Lij4LmD4LiK4LmJPC9VbmRlcmxpbmU+XHJcbiAgICAgICAgICAgICAgICA8VW5kZXJsaW5lPuC4geC4suC4o+C4leC4seC5ieC4h+C4hOC5iOC4suC4hOC4uOC4geC4geC4teC5iTwvVW5kZXJsaW5lPlxyXG4gICAgICAgICAgICA8L0xpbmtXcmFwcGVyPlxyXG4gICAgICAgIDwvRm9vdGVyTGF5b3V0PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGb290ZXI7XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcclxuXHJcbmV4cG9ydCBjb25zdCBGb290ZXJMYXlvdXQgPSBzdHlsZWQuZm9vdGVyYFxyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDU3MHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzExMTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjN2U3ZTdlO1xyXG4gICAgZmlsbDogIzdlN2U3ZTtcclxuICAgIHJvdy1nYXA6IDMycHg7XHJcbiAgICBwYWRkaW5nOiAyOHB4O1xyXG4gICAgZm9udC1mYW1pbHk6ICdCYWkgSmFtanVyZWUnLCBzYW5zLXNlcmlmO1xyXG5gIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmNvbnN0IFN0eWxlZExvZ28gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IDI0cHg7XHJcbiAgICB0cmFuc2l0aW9uOiBmaWxsIC4zcztcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICY6aG92ZXIge1xyXG4gICAgICAgIGZpbGw6IHdoaXRlO1xyXG4gICAgfVxyXG5gXHJcblxyXG5jb25zdCBGYWNlYm9va0ljb24gPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRMb2dvIHZpZXdCb3g9XCIwIDAgMTYgMTZcIj5cclxuICAgICAgICAgICAgPHBhdGggZD1cIk0xNiA4LjA0OWMwLTQuNDQ2LTMuNTgyLTguMDUtOC04LjA1QzMuNTggMC0uMDAyIDMuNjAzLS4wMDIgOC4wNWMwIDQuMDE3IDIuOTI2IDcuMzQ3IDYuNzUgNy45NTF2LTUuNjI1aC0yLjAzVjguMDVINi43NVY2LjI3NWMwLTIuMDE3IDEuMTk1LTMuMTMxIDMuMDIyLTMuMTMxLjg3NiAwIDEuNzkxLjE1NyAxLjc5MS4xNTd2MS45OGgtMS4wMDljLS45OTMgMC0xLjMwMy42MjEtMS4zMDMgMS4yNTh2MS41MWgyLjIxOGwtLjM1NCAyLjMyNkg5LjI1VjE2YzMuODI0LS42MDQgNi43NS0zLjkzNCA2Ljc1LTcuOTUxelwiLz5cclxuICAgICAgICA8L1N0eWxlZExvZ28+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZhY2Vib29rSWNvbjtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmNvbnN0IFN0eWxlZExvZ28gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IDI0cHg7XHJcbiAgICB0cmFuc2l0aW9uOiBmaWxsIC4zcztcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICY6aG92ZXIge1xyXG4gICAgICAgIGZpbGw6IHdoaXRlO1xyXG4gICAgfVxyXG5gXHJcblxyXG5jb25zdCBJbnN0YWdyYW1JY29uID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkTG9nbyB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGZpbGxSdWxlPVwiZXZlbm9kZFwiIGNsaXBSdWxlPVwiZXZlbm9kZFwiIGQ9XCJNMTIgMjRjNi42MjcgMCAxMi01LjM3MyAxMi0xMlMxOC42MjcgMCAxMiAwIDAgNS4zNzMgMCAxMnM1LjM3MyAxMiAxMiAxMnptMi44MjktMTcuNjk4Yy0uNzM5LS4wMzQtLjk2LS4wNC0yLjgyOS0uMDQtMS44NyAwLTIuMDkuMDA2LTIuODI5LjA0LS42ODIuMDMxLTEuMDUzLjE0NS0xLjMuMjQxLS4zMjYuMTI3LS41Ni4yNzgtLjgwNS41MjNhMi4xNzEgMi4xNzEgMCAwMC0uNTIzLjgwNWMtLjA5Ni4yNDctLjIxLjYxOC0uMjQgMS4zLS4wMzUuNzM5LS4wNDIuOTYtLjA0MiAyLjgyOSAwIDEuODcuMDA3IDIuMDkuMDQxIDIuODI5LjAzMS42ODIuMTQ1IDEuMDUzLjI0MSAxLjMuMTI3LjMyNi4yNzguNTYuNTIzLjgwNC4yNDYuMjQ1LjQ3OS4zOTcuODA1LjUyNC4yNDcuMDk2LjYxOC4yMSAxLjMuMjQuNzM4LjAzNS45Ni4wNDIgMi44MjkuMDQyIDEuODcgMCAyLjA5LS4wMDggMi44MjktLjA0MS42ODItLjAzMSAxLjA1My0uMTQ1IDEuMy0uMjQxLjMyNi0uMTI3LjU2LS4yNzguODA0LS41MjQuMjQ1LS4yNDUuMzk3LS40NzguNTI0LS44MDUuMDk2LS4yNDYuMjEtLjYxNy4yNC0xLjMuMDM1LS43MzguMDQyLS45NTkuMDQyLTIuODI4IDAtMS44Ny0uMDA4LTIuMDktLjA0MS0yLjgyOS0uMDMxLS42ODItLjE0NS0xLjA1My0uMjQxLTEuM2EyLjE2NCAyLjE2NCAwIDAwLS41MjQtLjgwNSAyLjE3MiAyLjE3MiAwIDAwLS44MDUtLjUyM2MtLjI0Ni0uMDk2LS42MTctLjIxLTEuMy0uMjR6bS01LjcxNS0xLjI2QzkuODYgNS4wMDggMTAuMDk5IDUgMTIgNWMxLjkwMSAwIDIuMTQuMDA4IDIuODg2LjA0Mi43NDUuMDM0IDEuMjU0LjE1MyAxLjcuMzI1LjQ2LjE4Ljg1LjQxOSAxLjI0LjgwOC4zODkuMzg5LjYyOC43OC44MDcgMS4yNC4xNzMuNDQ1LjI5MS45NTQuMzI1IDEuNjk5LjAzNS43NDYuMDQzLjk4NS4wNDMgMi44ODYgMCAxLjkwMS0uMDA5IDIuMTQtLjA0MyAyLjg4Ni0uMDM0Ljc0NS0uMTUyIDEuMjU0LS4zMjUgMS43YTMuNDMgMy40MyAwIDAxLS44MDcgMS4yNGMtLjM5LjM4OS0uNzguNjI4LTEuMjQuODA3LS40NDUuMTczLS45NTUuMjkxLTEuNy4zMjUtLjc0Ni4wMzQtLjk4NS4wNDItMi44ODYuMDQyLTEuOSAwLTIuMTQtLjAwOC0yLjg4Ni0uMDQyLS43NDUtLjAzNC0xLjI1NC0uMTUyLTEuNy0uMzI1YTMuNDMgMy40MyAwIDAxLTEuMjM5LS44MDggMy40MjggMy40MjggMCAwMS0uODA3LTEuMjRjLS4xNzMtLjQ0NS0uMjkyLS45NTQtLjMyNi0xLjY5OUM1LjAwOCAxNC4xNCA1IDEzLjkwMSA1IDEyYzAtMS45MDEuMDA4LTIuMTQuMDQyLTIuODg2LjAzNC0uNzQ1LjE1My0xLjI1NC4zMjYtMS43LjE3OC0uNDYuNDE4LS44NS44MDctMS4yMzkuMzg5LS4zOS43OC0uNjI4IDEuMjQtLjgwNy40NDUtLjE3My45NTQtLjI5MiAxLjY5OS0uMzI2ek0xMiA4LjQwNWEzLjU5NCAzLjU5NCAwIDEwMCA3LjE5IDMuNTk0IDMuNTk0IDAgMDAwLTcuMTl6bTAgNS45MjhhMi4zMzMgMi4zMzMgMCAxMTAtNC42NjYgMi4zMzMgMi4zMzMgMCAwMTAgNC42NjZ6bTQuNTc3LTYuMDdhLjg0Ljg0IDAgMTEtMS42OCAwIC44NC44NCAwIDAxMS42OCAwelwiIC8+XHJcbiAgICAgICAgPC9TdHlsZWRMb2dvPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbnN0YWdyYW1JY29uO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5cclxuY29uc3QgU3R5bGVkTG9nbyA9IHN0eWxlZC5zdmdgXHJcbiAgICB3aWR0aDogMjRweDtcclxuICAgIGhlaWdodDogMjRweDtcclxuICAgIHRyYW5zaXRpb246IGZpbGwgLjNzO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgZmlsbDogd2hpdGU7XHJcbiAgICB9XHJcbmBcclxuXHJcbmNvbnN0IFlvdXR1YmVJY29uID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkTG9nbyB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGZpbGxSdWxlPVwiZXZlbm9kZFwiIGNsaXBSdWxlPVwiZXZlbm9kZFwiIGQ9XCJNMTIgMjRjNi42MjcgMCAxMi01LjM3MyAxMi0xMlMxOC42MjcgMCAxMiAwIDAgNS4zNzMgMCAxMnM1LjM3MyAxMiAxMiAxMnptNS40Ny0xNi4yMzFjLjYwMi4xNDggMS4wNzcuNTgzIDEuMjM3IDEuMTM2QzE5IDkuOTA4IDE5IDEyIDE5IDEyczAgMi4wOTItLjI5MyAzLjA5NWMtLjE2LjU1My0uNjM1Ljk4OC0xLjIzOCAxLjEzNkMxNi4zOCAxNi41IDEyIDE2LjUgMTIgMTYuNXMtNC4zNzggMC01LjQ3LS4yNjhjLS42MDItLjE0OS0xLjA3Ny0uNTg0LTEuMjM3LTEuMTM3QzUgMTQuMDkyIDUgMTIgNSAxMnMwLTIuMDkyLjI5My0zLjA5NWMuMTYtLjU1My42MzUtLjk4OCAxLjIzNy0xLjEzNkM3LjYyMiA3LjUgMTIgNy41IDEyIDcuNXM0LjM3OCAwIDUuNDcuMjY5ek0xNC4yMjYgMTJsLTMuNjU5LTEuOXYzLjhsMy42Ni0xLjl6XCIgLz5cclxuICAgICAgICA8L1N0eWxlZExvZ28+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFlvdXR1YmVJY29uO1xyXG4iLCJleHBvcnQge2RlZmF1bHQgYXMgRmFjZWJvb2tJY29ufSBmcm9tICcuL0ZhY2Vib29rSWNvbidcclxuZXhwb3J0IHtkZWZhdWx0IGFzIEluc3RhZ3JhbUljb259IGZyb20gJy4vSW5zdGFncmFtSWNvbidcclxuZXhwb3J0IHtkZWZhdWx0IGFzIFlvdXR1YmVJY29ufSBmcm9tICcuL1lvdXR1YmVJY29uJyIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcblxyXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmFgXHJcbiAgICB0cmFuc2l0aW9uOiBjb2xvciAuM3M7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG5gXHJcblxyXG5jb25zdCBCdXR0b25XcmFwcGVyID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8V3JhcHBlcj5cclxuICAgICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgIDwvV3JhcHBlcj5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQnV0dG9uV3JhcHBlcjtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmNvbnN0IFN0eWxlZExvZ28gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDYwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbmBcclxuXHJcbmNvbnN0IFJpb3RHYW1lc0xvZ28gPSAoeyBocmVmIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFN0eWxlZExvZ28gdmlld0JveD1cIjAgMCA2MDAgMzA1LjQxXCIgZmlsbD1cIiNFNkU2RTZcIj5cclxuICAgICAgICAgICAgPHBhdGggZD1cIm00MDQuODIgMjkwLjYxLS4zOTIyNS0xMS4yOTEgMzkuMDMyLS40NjEyOC4zNTgxNC0xMi4zMDUtMzkuODUxLS40OTUzOC0uMzk3OTMtMTEuNDMxIDUyLjUwMy0xLjIyOTEuNDMyODUtMTMuNWgtNzAuODMzbC0yLjExMTUgNjUuNTFoNzQuMjUxbC0uNTIxMzgtMTMuNTI1em0tMzUzLjE4LTI0LjA4Ni0uODMzNzIgMTIuMjU2IDE5LjY5OS42NTg2Mi0uMjQ5MzIgMTIuNDQyLTQxLjIzMi0xLjIwOSAxLjc5NjMtMzUuOTM4IDU2LjY5Mi0xLjMxMjEtLjgxOTM0LTEzLjUyNWgtNzMuMjI4bC02LjU2NjUgNjUuNTFoODMuNDM2bC0yLjE2MzEtMzkuNTE5em01MTYuODEgNS4wNjgxLTU0LjExNi05LjE0NzguMjM0Ny03LjA5MDcgNTEuNzctMS45MzEtMS4zMDY0LTEzLjUyNWgtNjYuNTQ3bC0zLjQwMzYgMzMuOTU1IDU1LjAxNiA5LjU2Ni4yNDkzMiA2LjIzOTktNTcuMjQyIDIuMjIzMi0xLjQwMzggMTMuNTI1aDgwLjExNXpcIi8+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJtMzQ3LjYzIDMwNS40MS02LjU2NjQtNjUuNTFoLTE4Ljg1MWwtMjcuMDgyIDMxLjIyOC0yNy4wODUtMzEuMjI4aC0xOC44NTFsLTYuNTY2NCA2NS41MWgyMi4xNDZsMi4xMjAxLTQyLjQ5OSAyOC4yMzcgMjguOTczIDI4LjIzMS0yOC45NzMgMi4xMjU4IDQyLjQ5OXpcIi8+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJtMjU0LjU1IDBoLTQ0LjMyNGwtNC4wMzM4IDIwMi41OWg1My41NTJ6XCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBkPVwibTM5MS44OSAxNTguNTItNDguOTA3IDEuNTc4Ni0xLjYyMTUtMTE5LjE1IDUxLjE1MSAxLjU0OTl6bTQyLjg2Mi0xNTguNDNoLTEzOC4xOWwtNS4zODA0IDIwMi41aDE1My4zOHpcIi8+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJtNjAwIDQ0LjMzNi00LjkzNjMtNDQuMzM1aC0xMzYuMTVsMS4xNTE3IDM5LjQ5MyA0My41NDcgMS41MDcgNC40NjM1IDE2MS41OWg1My42NmwtMTYuMDUyLTE2MC4xNHpcIi8+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJtNzMuNjQgNDEuNDQ0IDQyLjcxMS0xLjQyOTYgNC44Njc1IDQwLjM2NC00OS4yOTcgMjMuMjg2em00OS44OTkgMTYxLjE1aDU4LjE2N2wtMzcuOTA5LTkwLjkyNSAzMC4yNTEtMTYuNTI4LTIwLjY2OC05NS4xMzloLTE0OC40OGwtNC44ODc1IDQzLjkwNSAzMy4yMTYtMS4xMDg4LTE2LjAxOCAxNTkuOGg1MS45ODRsMS40MDY3LTUwLjkzOSAzNy40NTYtMjAuNDYyelwiLz5cclxuICAgICAgICAgICAgPHBhdGggZD1cIm0xNTEuODIgMjc1Ljg5IDQuNTAzNy0yMS40MzMgMjEuNjI1LS45NzY5OCA0LjUxOCAyMS41MDd6bTM3LjA0NCAyOS41MjZoMjIuNDI0bC0xNy43NDMtNjUuNTEzaC01Mi42MTVsLTE3Ljc0IDY1LjUxM2gyMi40MjRsMy40NzIzLTE2LjUyOCAzNi40MDIuNDcwMjF6XCIvPlxyXG4gICAgICAgIDwvU3R5bGVkTG9nbz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmlvdEdhbWVzTG9nbzsiLCJpbXBvcnQgTmV4dEhlYWQgZnJvbSAnbmV4dC9oZWFkJztcclxuXHJcbmNvbnN0IEhlYWQgPSAoeyB0aXRsZSB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxOZXh0SGVhZD5cclxuICAgICAgICAgICAgPG1ldGEgY2hhclNldD1cIlVURi04XCIgLz5cclxuICAgICAgICAgICAgPG1ldGEgaHR0cEVxdWl2PVwiWC1VQS1Db21wYXRpYmxlXCIgY29udGVudD1cIklFPWVkZ2VcIiAvPlxyXG4gICAgICAgICAgICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMFwiIC8+XHJcbiAgICAgICAgICAgIDxsaW5rIHJlbD1cInNob3J0Y3V0IGljb25cIiBocmVmPVwiZmF2aWNvbi5zdmdcIiB0eXBlPVwiaW1hZ2UveC1zdmdcIiAvPlxyXG4gICAgICAgICAgICA8dGl0bGU+e3RpdGxlfTwvdGl0bGU+XHJcbiAgICAgICAgPC9OZXh0SGVhZD5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGVhZDsiLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB7IEZpbHRlckRyb3Bib3ggfSBmcm9tICcuJ1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcidcclxuY29uc3QgQmFyID0gc3R5bGVkLnVsYFxyXG4gICAgaGVpZ2h0OiAxMHZoO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB9XHJcbmBcclxuY29uc3QgQ2F0ZWdvcnkgPSBzdHlsZWQubGlgXHJcbmZsb2F0OiBsZWZ0O1xyXG5tYXJnaW4tbGVmdDogNTBweDtcclxubGlzdC1zdHlsZS10eXBlOiBub25lOyBcclxuaGVpZ2h0OiA1dmg7XHJcbmBcclxuY29uc3QgQ2F0ZWdvcnlCYXIgPSAoKSA9PiB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICAgIGNvbnN0IHsgY2F0ZWdvcnkgfSA9IHJvdXRlci5xdWVyeTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgICA8QmFyPlxyXG4gICAgICAgICAgICA8Q2F0ZWdvcnkgc3R5bGU9e3sgY29sb3I6IGAkeyBjYXRlZ29yeSA9PSBcImFsbFwiP1wiYmxhY2tcIjogXCIjOGI5NzhmXCJ9YCwgYm9yZGVyQm90dG9tOiBgJHsgY2F0ZWdvcnkgPT0gXCJhbGxcIj9cIjFweCBzb2xpZCBibGFja1wiOiBcIm5vbmVcIn1gIH19ID48TGluayBocmVmPVwiL21lZGlhL2FsbFwiIHNjcm9sbD17ZmFsc2V9PuC4l+C4seC5ieC4h+C4q+C4oeC4lDwvTGluaz48L0NhdGVnb3J5PlxyXG4gICAgICAgICAgICA8Q2F0ZWdvcnkgc3R5bGU9e3sgY29sb3I6IGAkeyBjYXRlZ29yeSA9PSBcIndhbGxwYXBlclwiP1wiYmxhY2tcIjogXCIjOGI5NzhmXCJ9YCwgYm9yZGVyQm90dG9tOiBgJHsgY2F0ZWdvcnkgPT0gXCJ3YWxscGFwZXJcIj9cIjFweCBzb2xpZCBibGFja1wiOiBcIm5vbmVcIn1gIH19ID48TGluayBocmVmPVwiL21lZGlhL3dhbGxwYXBlclwiIHNjcm9sbD17ZmFsc2V9PuC4p+C4reC4peC5gOC4m+C5gOC4m+C4reC4o+C5jDwvTGluaz48L0NhdGVnb3J5PlxyXG4gICAgICAgICAgICA8Q2F0ZWdvcnkgc3R5bGU9e3sgY29sb3I6IGAkeyBjYXRlZ29yeSA9PSBcInZpZGVvXCI/XCJibGFja1wiOiBcIiM4Yjk3OGZcIn1gLCBib3JkZXJCb3R0b206IGAkeyBjYXRlZ29yeSA9PSBcInZpZGVvXCI/XCIxcHggc29saWQgYmxhY2tcIjogXCJub25lXCJ9YCB9fSA+PExpbmsgaHJlZj1cIi9tZWRpYS92aWRlb1wiIHNjcm9sbD17ZmFsc2V9PuC4p+C4tOC4lOC4teC5guC4rTwvTGluaz48L0NhdGVnb3J5PlxyXG4gICAgICAgICAgICA8Q2F0ZWdvcnkgc3R5bGU9e3sgY29sb3I6IGAkeyBjYXRlZ29yeSA9PSBcInNjcmVlbnNob3RcIj9cImJsYWNrXCI6IFwiIzhiOTc4ZlwifWAsIGJvcmRlckJvdHRvbTogYCR7IGNhdGVnb3J5ID09IFwic2NyZWVuc2hvdFwiP1wiMXB4IHNvbGlkIGJsYWNrXCI6IFwibm9uZVwifWAgfX0gPjxMaW5rIGhyZWY9XCIvbWVkaWEvc2NyZWVuc2hvdFwiIHNjcm9sbD17ZmFsc2V9PuC4quC4geC4o+C4teC4meC4iuC5h+C4reC4lTwvTGluaz48L0NhdGVnb3J5PlxyXG4gICAgICAgICAgICA8Q2F0ZWdvcnkgc3R5bGU9e3sgY29sb3I6IGAkeyBjYXRlZ29yeSA9PSBcImFydHdvcmtcIj9cImJsYWNrXCI6IFwiIzhiOTc4ZlwifWAsIGJvcmRlckJvdHRvbTogYCR7IGNhdGVnb3J5ID09IFwiYXJ0d29ya1wiP1wiMXB4IHNvbGlkIGJsYWNrXCI6IFwibm9uZVwifWAgfX0gPjxMaW5rIGhyZWY9XCIvbWVkaWEvYXJ0d29ya1wiIHNjcm9sbD17ZmFsc2V9PuC4reC4suC4o+C5jOC4l+C5gOC4p+C4tOC4o+C5jOC4gTwvTGluaz48L0NhdGVnb3J5PlxyXG4gICAgICAgICAgICA8Q2F0ZWdvcnkgc3R5bGU9e3sgY29sb3I6IGAkeyBjYXRlZ29yeSA9PSBcImxvZ29cIj9cImJsYWNrXCI6IFwiIzhiOTc4ZlwifWAsIGJvcmRlckJvdHRvbTogYCR7IGNhdGVnb3J5ID09IFwibG9nb1wiP1wiMXB4IHNvbGlkIGJsYWNrXCI6IFwibm9uZVwifWAgfX0gPjxMaW5rIGhyZWY9XCIvbWVkaWEvbG9nb1wiIHNjcm9sbD17ZmFsc2V9PuC5guC4peC5guC4geC5iTwvTGluaz48L0NhdGVnb3J5PlxyXG4gICAgICAgICAgICA8Q2F0ZWdvcnkgc3R5bGU9e3sgY29sb3I6IGAkeyBjYXRlZ29yeSA9PSBcImNvbnRlbnRfY3JlYXRvclwiP1wiYmxhY2tcIjogXCIjOGI5NzhmXCJ9YCwgYm9yZGVyQm90dG9tOiBgJHsgY2F0ZWdvcnkgPT0gXCJjb250ZW50X2NyZWF0b3JcIj9cIjFweCBzb2xpZCBibGFja1wiOiBcIm5vbmVcIn1gIH19ID48TGluayBocmVmPVwiL21lZGlhL2NvbnRlbnRfY3JlYXRvclwiIHNjcm9sbD17ZmFsc2V9PuC4hOC4reC4meC5gOC4l+C4meC4leC5jOC4hOC4o+C4teC5gOC4reC5gOC4leC4reC4o+C5jDwvTGluaz48L0NhdGVnb3J5PlxyXG4gICAgICAgICAgICA8RmlsdGVyRHJvcGJveD48L0ZpbHRlckRyb3Bib3g+XHJcbiAgICAgICAgPC9CYXI+XHJcblxyXG4gICAgPC8+KVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYXRlZ29yeUJhcjsiLCJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5jb25zdCBUZXh0ID0gc3R5bGVkLmRpdmBcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJhY2tncm91bmQ6IGFudGlxdWV3aGl0ZTtcclxuICAgIHdpZHRoOiAxMHZ3O1xyXG4gICAgaGVpZ2h0OiAxMHZoO1xyXG5gXHJcblxyXG5cclxuY29uc3QgQm94ID0gc3R5bGVkLmRpdmBcclxuICAgIHdpZHRoOiAxMHZ3O1xyXG4gICAgaGVpZ2h0OiAxMHZoO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDEwdnc7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzhiOTc4ZjtcclxuXHJcbmBcclxuXHJcbmNvbnN0IEZpbHRlckRyb3Bib3ggPSAoKSA9PiB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICAgIGxldCB7IGNhdGVnb3J5LCB0eXBlIH0gPSByb3V0ZXIucXVlcnk7XHJcbiAgICBpZih0eXBlb2YgdHlwZSA9PT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgIHR5cGUgPSBgYWxsYFxyXG4gICAgfVxyXG4gICAgY29uc3Qgb25TZWxlY3RDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgICAgIGxldCBsb2NhbGUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgICAgICBpZih0eXBlb2YgY2F0ZWdvcnkgPT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgY2F0ZWdvcnkgPSBgYWxsYDtcclxuICAgICAgICAgICAgbG9jYWxlID0gYG1lZGlhLyR7IGNhdGVnb3J5IH0vJHsgbG9jYWxlIH1gXHJcbiAgICAgICAgICAgIHJvdXRlci5wdXNoKGxvY2FsZSlcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYodHlwZW9mIHR5cGUgPT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgbG9jYWxlID0gYCR7IGNhdGVnb3J5IH0vJHsgbG9jYWxlIH1gXHJcbiAgICAgICAgICAgIHJvdXRlci5wdXNoKGxvY2FsZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZXtcclxuICAgICAgICAgICAgbG9jYWxlID0ge1xyXG4gICAgICAgICAgICAgICAgcGF0aG5hbWU6ICcvbWVkaWEvW2NhdGVnb3J5XS9bdHlwZV0nLFxyXG4gICAgICAgICAgICAgICAgcXVlcnk6IHtjYXRlZ29yeTogYCR7IGNhdGVnb3J5IH1gLCBcInR5cGVcIjogYCR7IGxvY2FsZSB9YH0sXHJcbiAgICAgICAgICAgICAgICBhc1BhdGg6IGAvbWVkaWEvJHsgY2F0ZWdvcnkgfS8keyBsb2NhbGUgfWBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByb3V0ZXIucHVzaChsb2NhbGUuYXNQYXRoLCBsb2NhbGUuYXNQYXRoLHtcclxuICAgICAgICAgICAgICAgIHNjcm9sbDogZmFsc2VcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBsZXQgY29udmVydCA9IHtcclxuICAgICAgICBcImFsbFwiOiBcIuC4l+C4seC5ieC4h+C4q+C4oeC4lFwiLFxyXG4gICAgICAgIFwiYWdlbnRzXCI6IFwi4LmA4Lit4LmA4LiI4LiZ4LiX4LmMXCIsXHJcbiAgICAgICAgXCJtYXBzXCI6IFwi4LmB4Lic4LiZ4LiX4Li14LmIXCIsXHJcbiAgICAgICAgXCJhcnNlbmFsc1wiOiBcIuC4hOC4peC4seC4h+C5geC4quC4h1wiLFxyXG4gICAgfVxyXG4gICAgbGV0IGl0ZW1MaXN0ID0gW3tcInR5cGVcIiA6IFwi4LiX4Lix4LmJ4LiH4Lir4Lih4LiUXCIsIFwidmFsdWVcIiA6IGBhbGxgfSxcclxuICAgICB7XCJ0eXBlXCIgOiBcIuC5gOC4reC5gOC4iOC4meC4l+C5jFwiLCBcInZhbHVlXCIgOiBgYWdlbnRzYH0sXHJcbiAgICAge1widHlwZVwiIDogXCLguYHguJzguJnguJfguLXguYhcIiwgXCJ2YWx1ZVwiIDogYG1hcHNgfSxcclxuICAgICB7XCJ0eXBlXCIgOiBcIuC4hOC4peC4seC4h+C5geC4quC4h1wiLCBcInZhbHVlXCIgOiBgYXJzZW5hbHNgfV1cclxuICAgIGNvbnN0IG9wZW5Ecm9wYm94ID0gKGUpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlLnRhcmdldClcclxuICAgIH1cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEJveCBvbkNsaWNrPXsgb3BlbkRyb3Bib3ggfT5cclxuICAgICAgICAgICAgICAgIDxUZXh0IHZhbHVlPXtgLyR7dHlwZX1gfT57IGNvbnZlcnRbdHlwZV0gfTwvVGV4dD5cclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBpdGVtTGlzdC5tYXAoKGl0ZW0sIGluZGV4KT0+e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZihpdGVtLnR5cGUgIT0gY29udmVydFt0eXBlXSl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gPFRleHQga2V5PXsgaW5kZXggfSB2YWx1ZT17aXRlbS52YWx1ZX0+e2l0ZW0udHlwZX08L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvPlxyXG5cclxuICAgIClcclxufVxyXG5leHBvcnQgZGVmYXVsdCBGaWx0ZXJEcm9wYm94OyIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcclxuaW1wb3J0IHtUeHQsIFRleHRCZ0NvbnRhaW5lcn0gZnJvbSAnLi4vVGV4dEJnJ1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uLy4uL3N0eWxlcy9tZWRpYS5tb2R1bGUuY3NzJ1xyXG5cclxuY29uc3QgQm94ID0gc3R5bGVkLmRpdmBcclxucG9zaXRpb246IHJlbGF0aXZlO1xyXG53aWR0aDogMTAwdnc7XHJcbmRpc3BsYXk6IGJsb2NrO1xyXG5ib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG5gXHJcbmNvbnN0IE1lZGlhSGVhZGVyID0gc3R5bGVkLmRpdmBcclxud2lkdGg6IDYwdnc7XHJcbmhlaWdodDogOTB2aDtcclxuYmFja2dyb3VuZDogI2ZmNDY1NTtcclxucG9zaXRpb246IHJlbGF0aXZlO1xyXG5cclxuJjphZnRlcntcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgaGVpZ2h0OiA3LjV2aDtcclxuICAgIGJhY2tncm91bmQ6IGFudGlxdWV3aGl0ZTtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtMTAlKSBza2V3WCg1MGRlZyk7XHJcbn1cclxuYFxyXG5jb25zdCBNZWRpYVRvcGljQ29udGlhbmVyID0gc3R5bGVkLmRpdmBcclxucG9zaXRpb246IGFic29sdXRlO1xyXG5oZWlnaHQ6IDYwJTtcclxud2lkdGg6IDkwJTtcclxucmlnaHQ6IDA7XHJcbmJvdHRvbTogMjAlO1xyXG5ib3JkZXItdG9wOiAxcHggc29saWQgd2hpdGU7XHJcbnotaW5kZXg6IDE7XHJcbiY6YmVmb3Jle1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgaGVpZ2h0OiAyMCU7XHJcbiAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkIHdoaXRlO1xyXG4gICAgYm90dG9tOiAtMjAlO1xyXG59XHJcblxyXG5gXHJcbmNvbnN0IE1lZGlhVG9waWMgPSBzdHlsZWQuaDFgXHJcbmZvbnQtc2l6ZTogMTB2aDtcclxuY29sb3I6IHdoaXRlO1xyXG5wb3NpdGlvbjogcmVsYXRpdmU7XHJcbm1hcmdpbi10b3A6IDMwcHg7XHJcbm1hcmdpbi1ib3R0b206IDMwcHg7XHJcbm92ZXJmbG93OiBoaWRkZW47XHJcbmBcclxuY29uc3QgTWVkaWFUb3BpY0NvbnRlbnQgPSBzdHlsZWQuZGl2YFxyXG53aWR0aDogNTUlO1xyXG5jb2xvcjogd2hpdGU7XHJcbmZvbnQtc2l6ZTogMi41dmg7XHJcbm1hcmdpbi1ib3R0b206IDN2aDtcclxub3ZlcmZsb3c6IGhpZGRlbjtcclxuYFxyXG5jb25zdCBNZWRpYUhlYWRlckltZyA9IHN0eWxlZC5zcGFuYFxyXG5iYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi8uLi8uLi9tZWRpYV9jb250ZW50L3BpYy9NZWRpYV9IZWFkZXIuanBnXCIpO1xyXG5iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG53aWR0aDogNTIuNzV2dztcclxuaGVpZ2h0OiA3NC41dmg7XHJcbnBvc2l0aW9uOiBhYnNvbHV0ZTtcclxucmlnaHQ6IDcuNSU7XHJcbmJvdHRvbTogLTFweDtcclxuei1pbmRleDogMTtcclxudHJhbnNmb3JtLW9yaWdpbjogYm90dG9tO1xyXG4mOmJlZm9yZXtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICB3aWR0aDogNTBweDtcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgIGJhY2tncm91bmQ6ICNmZjQ2NTU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbn1cclxuJjphZnRlcntcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBiYWNrZ3JvdW5kOiBhbnRpcXVld2hpdGU7XHJcbiAgICB3aWR0aDogNnZ3O1xyXG4gICAgaGVpZ2h0OiAxMHZoO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgdHJhbnNmb3JtOiBza2V3WCg0MGRlZykgdHJhbnNsYXRlWCgtNHZ3KTtcclxufVxyXG5gXHJcbmNvbnN0IEJvdExlZnRJbWcgPSBzdHlsZWQuZGl2YFxyXG5wb3NpdGlvbjogYWJzb2x1dGU7XHJcbndpZHRoOiAxMDBweDtcclxuaGVpZ2h0OiAxMDBweDtcclxuYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XHJcbm9wYWNpdHk6IC41O1xyXG5ib3R0b206IDA7XHJcbnJpZ2h0OiAwO1xyXG4mOmJlZm9yZXtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB3aWR0aDogNTAlO1xyXG4gICAgaGVpZ2h0OiA1MCU7XHJcbiAgICByaWdodDogLTcuNXB4O1xyXG4gICAgdG9wOiAyNSU7XHJcbiAgICB0cmFuc2Zvcm06IHNrZXdYKC00NWRlZyk7XHJcbiAgICBib3JkZXItbGVmdDogM3B4IHNvbGlkIHdoaXRlO1xyXG59XHJcbiY6YWZ0ZXJ7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDVweDtcclxuICAgIGhlaWdodDogNXB4O1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbn1cclxuYFxyXG5jb25zdCBMaW5lID0gc3R5bGVkLmRpdmBcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHdpZHRoOiAzMy42MzEzdnc7XHJcbiAgICBoZWlnaHQ6IDEwcHg7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgd2hpdGU7XHJcbiAgICAmOmFmdGVye1xyXG4gICAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIHdpZHRoOiAyMCU7XHJcbiAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNmZjQ2NTU7XHJcbiAgICAgICAgYm90dG9tOiAtMXB4O1xyXG4gICAgICAgIGxlZnQ6IDEwJTtcclxuICAgIH1cclxuXHJcbmBcclxuXHJcbmNvbnN0IE1lZGlhSGVhZCA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEJveCBzdHlsZT17eyBoZWlnaHQ6IFwiOTIuNXZoXCIsIG92ZXJmbG93OiBcImhpZGRlblwifX0+XHJcbiAgICAgICAgICAgIDxUZXh0QmdDb250YWluZXIgc3R5bGU9e3sgYmFja2dyb3VuZDogXCJub25lXCIsIHpJbmRleDogMSwgdG9wOiBcIjM1dmhcIn19PlxyXG4gICAgICAgICAgICAgICAgPFR4dCBjbGFzc05hbWU9eyBzdHlsZXMudGV4dEJhY2tncm91bmQsIHN0eWxlcy5zdHJva2UgfSBzdHlsZT17eyBmb250U2l6ZTogXCIxNXZ3XCJ9fT5WQUxPUkFOVDwvVHh0PlxyXG4gICAgICAgICAgICA8L1RleHRCZ0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgPE1lZGlhSGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgPE1lZGlhVG9waWNDb250aWFuZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPE1lZGlhVG9waWM+PGRpdiBjbGFzc05hbWU9XCJNb3ZlVXBcIj7guKrguLfguYjguK08L2Rpdj48L01lZGlhVG9waWM+XHJcbiAgICAgICAgICAgICAgICAgICAgPE1lZGlhVG9waWNDb250ZW50PjxkaXYgY2xhc3NOYW1lPVwiTW92ZVVwXCI+4LiH4Liy4LiZ4LiC4Lit4LiH4LmA4Lij4Liy4LiE4Li34Lit4LiB4Liy4Lij4LmA4Lil4LmI4LiZ4LiC4Lit4LiH4LiE4Li44LiTIOC5hOC4oeC5iOC4p+C5iOC4suC4hOC4uOC4k+C4iOC4sOC5gOC4m+C5h+C4meC4quC4t+C5iOC4rSDguITguK3guJnguYDguJfguJnguJXguYzguITguKPguLXguYDguK3guYDguJXguK3guKPguYwg4Lir4Lij4Li34Lit4LiX4Lix4LmJ4LiH4Liq4Lit4LiHIOC4hOC4uOC4k+C4quC4suC4oeC4suC4o+C4luC5g+C4iuC5ieC4l+C4uOC4geC4reC4ouC5iOC4suC4h+C4l+C4teC5iOC4hOC4uOC4k+C5gOC4q+C5h+C4meC4l+C4teC5iOC4meC4teC5iOC5hOC4lOC5ieC5gOC4peC4ojwvZGl2PjwvTWVkaWFUb3BpY0NvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPE1lZGlhVG9waWNDb250ZW50PjxkaXYgY2xhc3NOYW1lPVwiTW92ZVVwXCI+4LmC4Lib4Lij4LiU4Lit4Lii4LmI4Liy4Lil4Li34Lih4LmB4LiX4LmH4LiBIEBQbGF5VkFMT1JBTlQg4Lia4LiZ4LmC4LiL4LmA4LiK4Li14Lii4Lil4Lih4Li14LmA4LiU4Li14Lii4Lir4Liy4LiB4LiE4Li44LiT4LmE4LiU4LmJ4Liq4Lij4LmJ4Liy4LiH4Lic4Lil4LiH4Liy4LiZ4LiU4LmJ4Lin4Lii4LmE4Lif4Lil4LmM4LiZ4Li14LmJIOC5gOC4o+C4suC4reC4lOC5g+C4iOC4o+C4reC5geC4l+C4muC5hOC4oeC5iOC5hOC4q+C4p+C4l+C4teC5iOC4iOC4sOC5hOC4lOC5ieC4o+C4seC4muC4iuC4oeC4quC4tOC5iOC4h+C4l+C4teC5iOC4hOC4uOC4k+C4quC4o+C5ieC4suC4h+C4guC4tuC5ieC4meC4oeC4siDguYHguJXguYjguK3guKLguYjguLLguKXguLfguKHguYDguIHguLXguYjguKLguKfguIHguLHguJo8YSBjbGFzc05hbWU9XCJjb25kaXRpb25cIiBocmVmPVwiI1wiPuC5gOC4h+C4t+C5iOC4reC4meC5hOC4guC4geC4suC4o+C5g+C4iuC5ieC4h+C4suC4mSDguILguK3guIfguYDguKPguLLguKXguYjguLA8L2E+PC9kaXY+PC9NZWRpYVRvcGljQ29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICA8TGluZS8+XHJcbiAgICAgICAgICAgICAgICA8L01lZGlhVG9waWNDb250aWFuZXI+XHJcbiAgICAgICAgICAgIDwvTWVkaWFIZWFkZXI+XHJcbiAgICAgICAgICAgIDxNZWRpYUhlYWRlckltZyBjbGFzc05hbWU9XCJNb3ZlVXBcIj48Qm90TGVmdEltZy8+PC9NZWRpYUhlYWRlckltZz5cclxuXHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICA8Lz5cclxuXHJcbiAgICApXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgTWVkaWFIZWFkOyIsImV4cG9ydCB7ZGVmYXVsdCBhcyBGaWx0ZXJEcm9wYm94IH0gZnJvbSAnLi9GaWx0ZXJEcm9wYm94JztcclxuZXhwb3J0IHtkZWZhdWx0IGFzIE1lZGlhSGVhZCB9IGZyb20gJy4vTWVkaWFIZWFkJztcclxuZXhwb3J0IHtkZWZhdWx0IGFzIENhdGVnb3J5QmFyIH0gZnJvbSAnLi9DYXRlZ29yeUJhcic7XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcbmltcG9ydCB7IExhbmdTZWxlY3RvciB9IGZyb20gJy4vTGFuZ1NlbGVjdG9yJ1xyXG5cclxuY29uc3QgU3R5bGVkTG9nbyA9IHN0eWxlZC5zdmdgXHJcbiAgICB3aWR0aDogMzJweDtcclxuICAgIGhlaWdodDogMzJweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMnB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xyXG4gICAgcGFkZGluZzogOHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzMzMzMzMzc3O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgcmlnaHQ6IDE2NHB4O1xyXG5gXHJcblxyXG5jb25zdCBCdXR0b25XcmFwcGVyID0gc3R5bGVkLmJ1dHRvbmBcclxuICAgIGJhY2tncm91bmQ6IG5vbmU7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG5gXHJcblxyXG5jb25zdCBMYW5nQnV0dG9uID0gKHsgaXNPcGVuLCBvbkNsaWNrIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEJ1dHRvbldyYXBwZXIgb25DbGljaz17b25DbGlja30+XHJcbiAgICAgICAgICAgICAgICA8U3R5bGVkTG9nbyB2aWV3Qm94PVwiMCAwIDE2IDE2XCIgZmlsbD1cIiNmZmZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTAgOGE4IDggMCAxIDEgMTYgMEE4IDggMCAwIDEgMCA4em03LjUtNi45MjNjLS42Ny4yMDQtMS4zMzUuODItMS44ODcgMS44NTVBNy45NyA3Ljk3IDAgMCAwIDUuMTQ1IDRINy41VjEuMDc3ek00LjA5IDRhOS4yNjcgOS4yNjcgMCAwIDEgLjY0LTEuNTM5IDYuNyA2LjcgMCAwIDEgLjU5Ny0uOTMzQTcuMDI1IDcuMDI1IDAgMCAwIDIuMjU1IDRINC4wOXptLS41ODIgMy41Yy4wMy0uODc3LjEzOC0xLjcxOC4zMTItMi41SDEuNjc0YTYuOTU4IDYuOTU4IDAgMCAwLS42NTYgMi41aDIuNDl6TTQuODQ3IDVhMTIuNSAxMi41IDAgMCAwLS4zMzggMi41SDcuNVY1SDQuODQ3ek04LjUgNXYyLjVoMi45OWExMi40OTUgMTIuNDk1IDAgMCAwLS4zMzctMi41SDguNXpNNC41MSA4LjVhMTIuNSAxMi41IDAgMCAwIC4zMzcgMi41SDcuNVY4LjVINC41MXptMy45OSAwVjExaDIuNjUzYy4xODctLjc2NS4zMDYtMS42MDguMzM4LTIuNUg4LjV6TTUuMTQ1IDEyYy4xMzguMzg2LjI5NS43NDQuNDY4IDEuMDY4LjU1MiAxLjAzNSAxLjIxOCAxLjY1IDEuODg3IDEuODU1VjEySDUuMTQ1em0uMTgyIDIuNDcyYTYuNjk2IDYuNjk2IDAgMCAxLS41OTctLjkzM0E5LjI2OCA5LjI2OCAwIDAgMSA0LjA5IDEySDIuMjU1YTcuMDI0IDcuMDI0IDAgMCAwIDMuMDcyIDIuNDcyek0zLjgyIDExYTEzLjY1MiAxMy42NTIgMCAwIDEtLjMxMi0yLjVoLTIuNDljLjA2Mi44OS4yOTEgMS43MzMuNjU2IDIuNUgzLjgyem02Ljg1MyAzLjQ3MkE3LjAyNCA3LjAyNCAwIDAgMCAxMy43NDUgMTJIMTEuOTFhOS4yNyA5LjI3IDAgMCAxLS42NCAxLjUzOSA2LjY4OCA2LjY4OCAwIDAgMS0uNTk3LjkzM3pNOC41IDEydjIuOTIzYy42Ny0uMjA0IDEuMzM1LS44MiAxLjg4Ny0xLjg1NS4xNzMtLjMyNC4zMy0uNjgyLjQ2OC0xLjA2OEg4LjV6bTMuNjgtMWgyLjE0NmMuMzY1LS43NjcuNTk0LTEuNjEuNjU2LTIuNWgtMi40OWExMy42NSAxMy42NSAwIDAgMS0uMzEyIDIuNXptMi44MDItMy41YTYuOTU5IDYuOTU5IDAgMCAwLS42NTYtMi41SDEyLjE4Yy4xNzQuNzgyLjI4MiAxLjYyMy4zMTIgMi41aDIuNDl6TTExLjI3IDIuNDYxYy4yNDcuNDY0LjQ2Mi45OC42NCAxLjUzOWgxLjgzNWE3LjAyNCA3LjAyNCAwIDAgMC0zLjA3Mi0yLjQ3MmMuMjE4LjI4NC40MTguNTk4LjU5Ny45MzN6TTEwLjg1NSA0YTcuOTY2IDcuOTY2IDAgMCAwLS40NjgtMS4wNjhDOS44MzUgMS44OTcgOS4xNyAxLjI4MiA4LjUgMS4wNzdWNGgyLjM1NXpcIi8+XHJcbiAgICAgICAgICAgICAgICA8L1N0eWxlZExvZ28+XHJcbiAgICAgICAgICAgIDwvQnV0dG9uV3JhcHBlcj5cclxuICAgICAgICAgICAgPExhbmdTZWxlY3RvciBpc09wZW49e2lzT3Blbn0gLz5cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTGFuZ0J1dHRvbjsiLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuY29uc3QgU3R5bGVkTGF5b3V0ID0gc3R5bGVkLmRpdmBcclxuICAgIHdpZHRoOiAyNDBweDtcclxuICAgIGhlaWdodDogMzYwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHJpZ2h0OiA3MHB4O1xyXG4gICAgdG9wOiA5NHB4O1xyXG4gICAgei1pbmRleDogNTAwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGRpc3BsYXk6ICR7cHJvcHMgPT4gcHJvcHMuaXNPcGVuID8gXCJibG9ja1wiIDogXCJub25lXCJ9O1xyXG5gXHJcblxyXG5jb25zdCBTdHlsZWRDaGVja2VkSWNvbiA9IHN0eWxlZC5zdmdgXHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIGhlaWdodDogMjBweDtcclxuICAgIGZpbGw6ICNjNDIwMmI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogMTZweDtcclxuYFxyXG5cclxuY29uc3QgQ2hlY2tlZEljb24gPSAoKSA9PiAoXHJcbiAgICA8U3R5bGVkQ2hlY2tlZEljb24gdmlld0JveD1cIjAgMCAxNiAxNlwiPlxyXG4gICAgICAgIDxwYXRoIGQ9XCJNMTIuNzM2IDMuOTdhLjczMy43MzMgMCAwIDEgMS4wNDcgMGMuMjg2LjI4OS4yOS43NTYuMDEgMS4wNUw3Ljg4IDEyLjAxYS43MzMuNzMzIDAgMCAxLTEuMDY1LjAyTDMuMjE3IDguMzg0YS43NTcuNzU3IDAgMCAxIDAtMS4wNi43MzMuNzMzIDAgMCAxIDEuMDQ3IDBsMy4wNTIgMy4wOTMgNS40LTYuNDI1YS4yNDcuMjQ3IDAgMCAxIC4wMi0uMDIyWlwiLz5cclxuICAgIDwvU3R5bGVkQ2hlY2tlZEljb24+XHJcbilcclxuXHJcbmNvbnN0IFN0eWxlZFRyaWFuZ2xlVXAgPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDMycHg7XHJcbiAgICBoZWlnaHQ6IDMycHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IC0xNHB4O1xyXG4gICAgbGVmdDogMTA0cHg7XHJcbmBcclxuXHJcbmNvbnN0IFRyaWFuZ2xlVXAgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRUcmlhbmdsZVVwIHZpZXdCb3g9XCIwIDAgMTYgMTZcIiBmaWxsPVwiI2ZmZlwiPlxyXG4gICAgICAgICAgICA8cGF0aCBmaWxsUnVsZT1cImV2ZW5vZGRcIiBkPVwiTTcuMDIyIDEuNTY2YTEuMTMgMS4xMyAwIDAgMSAxLjk2IDBsNi44NTcgMTEuNjY3Yy40NTcuNzc4LS4wOTIgMS43NjctLjk4IDEuNzY3SDEuMTQ0Yy0uODg5IDAtMS40MzctLjk5LS45OC0xLjc2N0w3LjAyMiAxLjU2NnpcIi8+XHJcbiAgICAgICAgPC9TdHlsZWRUcmlhbmdsZVVwPlxyXG4gICAgKVxyXG59XHJcblxyXG5jb25zdCBMYW5ndWFnZVN1cHBvcnQgPSBbXHJcbiAgICBcIkVOR0xJU0ggKE5BKVwiLFxyXG4gICAgXCJFTkdMSVNIIChFVVcpXCIsXHJcbiAgICBcIkRFVVRTQ0hcIixcclxuICAgIFwiRVNQQcORT0wgKEVVVylcIixcclxuICAgIFwiRlJBTsOHQUlTXCIsXHJcbiAgICBcIklUQUxJQU5PXCIsXHJcbiAgICBcIlBPTFNLSVwiLFxyXG4gICAgXCLQoNCj0KHQodCa0JjQmVwiLFxyXG4gICAgXCJUw5xSS8OHRVwiLFxyXG4gICAgXCJFU1BBw5FPTCAoTEFUQU0pXCIsXHJcbiAgICBcIklORE9ORVNJQU5cIixcclxuICAgIFwi5pel5pys6KqeXCIsXHJcbiAgICBcIu2VnOq1reyWtFwiLFxyXG4gICAgXCJQT1JUVUdVw4pTXCIsXHJcbiAgICBcIuC4oOC4suC4qeC4suC5hOC4l+C4olwiLFxyXG4gICAgXCJUaeG6v25nIFZp4buHdFwiLFxyXG4gICAgXCLnuYHpq5TkuK3mlodcIixcclxuICAgIFwi2KfZhNi52LHYqNmK2KlcIlxyXG5dXHJcblxyXG5jb25zdCBTdHlsZUxhbmdJdGVtID0gc3R5bGVkLmRpdmBcclxuICAgIGZvbnQtZmFtaWx5OiAnS2FuaXQnLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIHBhZGRpbmc6IDEwcHggMjRweDtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgY29sb3I6ICR7cHJvcHMgPT4gcHJvcHMuc2VsZWN0ZWQgPyBcIiNjNDIwMmJcIiA6IFwiIzk5OVwifTtcclxuICAgIHRyYW5zaXRpb246IGNvbG9yIC40cztcclxuICAgIGN1cnNvcjogJHtwcm9wcyA9PiBwcm9wcy5zZWxlY3RlZCA/IFwiZGVmYXVsdFwiIDogXCJwb2ludGVyXCJ9O1xyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgY29sb3I6ICMxMTE7XHJcbiAgICB9XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGZsZXgtZW5kO1xyXG5gXHJcblxyXG5jb25zdCBMYW5nSXRlbSA9ICh7IGNoaWxkcmVuLCBzZWxlY3RlZCB9KSA9PiAoXHJcbiAgICA8U3R5bGVMYW5nSXRlbSBzZWxlY3RlZD17Y2hpbGRyZW4gPT09IHNlbGVjdGVkfT5cclxuICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAge2NoaWxkcmVuID09PSBzZWxlY3RlZCA/ICg8Q2hlY2tlZEljb24vPikgOiBudWxsfVxyXG4gICAgPC9TdHlsZUxhbmdJdGVtPlxyXG4pXHJcblxyXG5jb25zdCBDb250ZW50ID0gc3R5bGVkLmRpdmBcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBwYWRkaW5nOiAxMHB4IDA7XHJcbmBcclxuXHJcbmV4cG9ydCBjb25zdCBMYW5nU2VsZWN0b3IgPSAoeyBpc09wZW4gfSkgPT4gKFxyXG4gICAgPD5cclxuICAgICAgICA8U3R5bGVkTGF5b3V0IGlzT3Blbj17aXNPcGVufT5cclxuICAgICAgICAgICAgPENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICB7TGFuZ3VhZ2VTdXBwb3J0Lm1hcCgoZSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxMYW5nSXRlbSBzZWxlY3RlZD1cIuC4oOC4suC4qeC4suC5hOC4l+C4olwiIGtleT17aX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGFuZ0l0ZW0+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9Db250ZW50PlxyXG4gICAgICAgICAgICA8VHJpYW5nbGVVcCAvPlxyXG4gICAgICAgIDwvU3R5bGVkTGF5b3V0PlxyXG4gICAgPC8+XHJcbikiLCJpbXBvcnQgTmF2TGF5b3V0IGZyb20gXCIuL05hdkxheW91dFwiO1xyXG5pbXBvcnQgeyBOYXZJdGVtIH0gZnJvbSBcIi4vTmF2SXRlbVwiO1xyXG5pbXBvcnQgeyBEcm9wZG93biwgRXh0ZXJuYWxMaSwgTGkgfSBmcm9tIFwiLi9OYXZEcm9wZG93blwiO1xyXG5pbXBvcnQgeyBFeHRlcm5hbCB9IGZyb20gXCIuL05hdkV4dGVybmFsTGlua1wiO1xyXG5pbXBvcnQgeyBWYWxvcmFudExvZ28sIFJpb3RMb2dvIH0gZnJvbSBcIi4uLy4uL3N0eWxlcy9uYXZfY29tcG9uZW50c1wiO1xyXG5pbXBvcnQgU2VwYXJhdG9yIGZyb20gJy4vTmF2U2VwYXJhdG9yJ1xyXG5pbXBvcnQgTGFuZ0J1dHRvbiBmcm9tIFwiLi9MYW5nQnV0dG9uXCI7XHJcbmltcG9ydCBQbGF5QnV0dG9uIGZyb20gXCIuL1BsYXlCdXR0b25cIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgUmlnaHROYXYgfSBmcm9tICcuL1JpZ2h0TmF2J1xyXG5cclxuY29uc3QgTmF2QmFyID0gKCkgPT4ge1xyXG4gICAgY29uc3QgW29wZW5SaW90R2FtZUJhciwgc2V0T3BlblJpb3RHYW1lQmFyXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW29wZW5MYW5nU2VsZWN0b3IsIHNldE9wZW5MYW5nU2VsZWN0b3JdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbb3BlblBsYXlQb3B1cCwgc2V0T3BlblBsYXlQb3B1cF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IGhhbmRsZVJpb3RHYW1lQmFyQ2xpY2sgPSBlID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgc2V0T3BlblJpb3RHYW1lQmFyKCFvcGVuUmlvdEdhbWVCYXIpXHJcbiAgICAgICAgc2V0T3BlbkxhbmdTZWxlY3RvcihmYWxzZSlcclxuICAgIH1cclxuICAgIGNvbnN0IGhhbmRsZUxhbmdDbGljayA9IGUgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBzZXRPcGVuTGFuZ1NlbGVjdG9yKCFvcGVuTGFuZ1NlbGVjdG9yKVxyXG4gICAgICAgIHNldE9wZW5SaW90R2FtZUJhcihmYWxzZSlcclxuICAgIH1cclxuICAgIGNvbnN0IGhhbmRsZVBsYXlQb3B1cENsaWNrID0gZSA9PiB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIHNldE9wZW5QbGF5UG9wdXAoIW9wZW5QbGF5UG9wdXApXHJcbiAgICAgICAgc2V0T3BlblJpb3RHYW1lQmFyKGZhbHNlKVxyXG4gICAgICAgIHNldE9wZW5MYW5nU2VsZWN0b3IoZmFsc2UpXHJcbiAgICB9XHJcbiAgICBjb25zdCBSaW90R2FtZUJhclN0YXRlQ29udHJvbCA9IHN0YXRlID0+IHtcclxuICAgICAgICBzZXRPcGVuUmlvdEdhbWVCYXIoc3RhdGUpXHJcbiAgICB9XHJcbiAgICBjb25zdCBQbGF5UG9wdXBTdGF0ZUNvbnRyb2wgPSBzdGF0ZSA9PiB7XHJcbiAgICAgICAgc2V0T3BlblBsYXlQb3B1cChzdGF0ZSlcclxuICAgIH1cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPE5hdkxheW91dD5cclxuICAgICAgICAgICAgPFJpb3RMb2dvIGlzR2FtZUJhck9wZW49e29wZW5SaW90R2FtZUJhcn0gb25DbGljaz17aGFuZGxlUmlvdEdhbWVCYXJDbGlja30gc3RhdGVDb250cm9sPXtSaW90R2FtZUJhclN0YXRlQ29udHJvbH0gLz5cclxuICAgICAgICAgICAgPFNlcGFyYXRvciAvPlxyXG4gICAgICAgICAgICA8VmFsb3JhbnRMb2dvIGhyZWY9XCIvXCIgLz5cclxuICAgICAgICAgICAgPERyb3Bkb3duIHRpdGxlPVwi4LiC4LmJ4Lit4Lih4Li54Lil4LmA4LiB4LihXCI+XHJcbiAgICAgICAgICAgICAgICA8TGkgaHJlZj1cIi9hZ2VudHNcIiB0aXRsZT1cIuC5gOC4reC5gOC4iOC4meC4l+C5jFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8TGkgaHJlZj1cIi9tYXBzXCIgdGl0bGU9XCLguYHguJzguJnguJfguLXguYhcIiAvPlxyXG4gICAgICAgICAgICAgICAgPExpIGhyZWY9XCIvYXJzZW5hbFwiIHRpdGxlPVwi4LiE4Lil4Lix4LiH4LmB4Liq4LiHXCIgLz5cclxuICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPE5hdkl0ZW0gaHJlZj1cIi9tZWRpYVwiIHRpdGxlPVwi4Liq4Li34LmI4LitXCIgLz5cclxuICAgICAgICAgICAgPE5hdkl0ZW0gaHJlZj1cIi9uZXdzXCIgdGl0bGU9XCLguILguYjguLLguKfguKrguLLguKNcIiAvPlxyXG4gICAgICAgICAgICA8TmF2SXRlbSBocmVmPVwiL2xlYWRlcmJvYXJkc1wiIHRpdGxlPVwi4LiB4Lij4Liw4LiU4Liy4LiZ4Lic4Li54LmJ4LiZ4LizXCIgLz5cclxuICAgICAgICAgICAgPERyb3Bkb3duIHRpdGxlPVwi4LiL4Lix4Lie4Lie4Lit4Lij4LmM4LiVXCI+XHJcbiAgICAgICAgICAgICAgICA8TGkgaHJlZj1cIi9zcGVjc1wiIHRpdGxlPVwi4Liq4LmA4Lib4LiEXCIgLz5cclxuICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpIHRpdGxlPVwi4LiL4Lix4Lie4Lie4Lit4Lij4LmM4LiVXCIgLz5cclxuICAgICAgICAgICAgICAgIDxMaSBocmVmPVwiL2NvbW11bml0eS1jb2RlXCIgdGl0bGU9XCLguIHguI/guKPguLDguYDguJrguLXguKLguJpcIiAvPlxyXG4gICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICA8RHJvcGRvd24gdGl0bGU9XCLguYLguIvguYDguIrguLXguKLguKVcIj5cclxuICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpIHRpdGxlPVwiRkFDRUJPT0tcIiAvPlxyXG4gICAgICAgICAgICAgICAgPEV4dGVybmFsTGkgdGl0bGU9XCJZT1VUVUJFXCIgLz5cclxuICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpIHRpdGxlPVwiSU5TVEFHUkFNXCIgLz5cclxuICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPEV4dGVybmFsIHRpdGxlPVwi4Lit4Li14Liq4Lib4Lit4Lij4LmM4LiVXCIgLz5cclxuICAgICAgICAgICAgPFJpZ2h0TmF2PlxyXG4gICAgICAgICAgICAgICAgPExhbmdCdXR0b24gaXNPcGVuPXtvcGVuTGFuZ1NlbGVjdG9yfSBvbkNsaWNrPXtoYW5kbGVMYW5nQ2xpY2t9IC8+XHJcbiAgICAgICAgICAgICAgICA8UGxheUJ1dHRvbiBpc09wZW49e29wZW5QbGF5UG9wdXB9IG9uQ2xpY2s9e2hhbmRsZVBsYXlQb3B1cENsaWNrfSBzdGF0ZUNvbnRyb2w9e1BsYXlQb3B1cFN0YXRlQ29udHJvbH0+4LmA4Lil4LmI4LiZ4LmA4Lil4LiiPC9QbGF5QnV0dG9uPlxyXG4gICAgICAgICAgICA8L1JpZ2h0TmF2PlxyXG4gICAgICAgIDwvTmF2TGF5b3V0PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOYXZCYXI7XHJcbiIsImltcG9ydCB7IERyb3Bkb3duQXJyb3dVcCwgU3R5bGVkTGkgfSBmcm9tIFwiLi4vLi4vLi4vc3R5bGVzL25hdl9jb21wb25lbnRzXCI7XHJcblxyXG5jb25zdCBFeHRlcm5hbExpID0gKHsgdGl0bGUgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkTGk+XHJcbiAgICAgICAgICAgIHt0aXRsZX1cclxuICAgICAgICAgICAgPERyb3Bkb3duQXJyb3dVcCAvPlxyXG4gICAgICAgIDwvU3R5bGVkTGk+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEV4dGVybmFsTGk7XHJcbiIsImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHsgU3R5bGVkTGkgfSBmcm9tICcuLi8uLi8uLi9zdHlsZXMvbmF2X2NvbXBvbmVudHMnO1xyXG5cclxuY29uc3QgTGkgPSAoeyBocmVmLCB0aXRsZSB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxMaW5rIGhyZWY9e2hyZWZ9IHBhc3NIcmVmPlxyXG4gICAgICAgICAgICA8U3R5bGVkTGk+XHJcbiAgICAgICAgICAgICAgICA8YT57dGl0bGV9PC9hPlxyXG4gICAgICAgICAgICA8L1N0eWxlZExpPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTGk7XHJcbiIsImltcG9ydCB7IE5hdkl0ZW1MYXlvdXQsIENhcmV0RG93biB9IGZyb20gJy4uLy4uLy4uL3N0eWxlcy9uYXZfY29tcG9uZW50cydcclxuaW1wb3J0IHsgVWwgfSBmcm9tICcuL1VsJztcclxuXHJcbmNvbnN0IERyb3Bkb3duID0gKHsgdGl0bGUsIGNoaWxkcmVuIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPE5hdkl0ZW1MYXlvdXQ+XHJcbiAgICAgICAgICAgIHt0aXRsZX1cclxuICAgICAgICAgICAgPENhcmV0RG93biAvPlxyXG4gICAgICAgICAgICA8VWw+XHJcbiAgICAgICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICAgIDwvVWw+XHJcbiAgICAgICAgPC9OYXZJdGVtTGF5b3V0PlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEcm9wZG93bjtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIlxyXG5pbXBvcnQgeyBOYXZJdGVtTGF5b3V0IH0gZnJvbSBcIi4uLy4uLy4uL3N0eWxlcy9uYXZfY29tcG9uZW50c1wiXHJcblxyXG5leHBvcnQgY29uc3QgVWwgPSBzdHlsZWQudWxgXHJcbiAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICBtaW4td2lkdGg6IDIwMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzExMTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogODBweDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICAgICR7TmF2SXRlbUxheW91dH06aG92ZXIgJiB7XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB9XHJcbmAiLCJleHBvcnQge2RlZmF1bHQgYXMgTGl9IGZyb20gJy4vTGknXHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBEcm9wZG93bn0gZnJvbSAnLi9OYXZEcm9wZG93bidcclxuZXhwb3J0IHtkZWZhdWx0IGFzIEV4dGVybmFsTGl9IGZyb20gJy4vRXh0ZXJuYWxMaSdcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgTmF2SXRlbUxheW91dCwgTmF2QXJyb3dVcCB9IGZyb20gXCIuLi8uLi8uLi9zdHlsZXMvbmF2X2NvbXBvbmVudHNcIjtcclxuXHJcbmNvbnN0IEV4dGVybmFsTGluayA9ICh7IHRpdGxlLCBjaGlsZHJlbiB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxOYXZJdGVtTGF5b3V0PlxyXG4gICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICAgICAgPE5hdkFycm93VXAgLz5cclxuICAgICAgICA8L05hdkl0ZW1MYXlvdXQ+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEV4dGVybmFsTGluaztcclxuIiwiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJ1xyXG5pbXBvcnQge1N0eWxlZExpbmt9IGZyb20gJy4uLy4uLy4uL3N0eWxlcy9uYXZfY29tcG9uZW50cydcclxuXHJcbmNvbnN0IE5hdkl0ZW0gPSAoeyBocmVmLCB0aXRsZSwgY2hpbGRyZW4gfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8TGluayBocmVmPXtocmVmfSBwYXNzSHJlZj5cclxuICAgICAgICAgICAgPFN0eWxlZExpbms+e3RpdGxlfXtjaGlsZHJlbn08L1N0eWxlZExpbms+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOYXZJdGVtO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiXHJcblxyXG5jb25zdCBOYXYgPSBzdHlsZWQubmF2YFxyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTExO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIHotaW5kZXg6IDQwMDA7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDI2cHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAyNnB4O1xyXG5gXHJcblxyXG5jb25zdCBOYXZMYXlvdXQgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxoZWFkZXI+XHJcbiAgICAgICAgICAgIDxOYXY+XHJcbiAgICAgICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICAgIDwvTmF2PlxyXG4gICAgICAgIDwvaGVhZGVyPlxyXG4gICAgKSAgICBcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2TGF5b3V0O1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuY29uc3QgTmF2U2VwYXJhdG9yID0gc3R5bGVkLmRpdmBcclxuICAgIGhlaWdodDogMzBweDtcclxuICAgIHdpZHRoOiAycHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjN2U3ZTdlO1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMnB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xyXG4gICAgb3BhY2l0eTogLjQ7XHJcbmBcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5hdlNlcGFyYXRvcjtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuaW1wb3J0IHsgUGxheVBvcHVwIH0gZnJvbSBcIi4vUGxheVBvcHVwXCI7XHJcblxyXG5jb25zdCBCdXR0b24gPSBzdHlsZWQuYnV0dG9uYFxyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI1NSwgNzAsIDg1KTtcclxuICAgIG1hcmdpbi1sZWZ0OiA0cHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDRweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIHdpZHRoOiAxMzBweDtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtZmFtaWx5OiAnQmFpIEphbWp1cmVlJywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICByaWdodDogMjZweDtcclxuYFxyXG5cclxuY29uc3QgUGxheUJ1dHRvbiA9ICh7IGNoaWxkcmVuLCBvbkNsaWNrLCBpc09wZW4sIHN0YXRlQ29udHJvbCB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17b25DbGlja30+XHJcbiAgICAgICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8UGxheVBvcHVwIGlzT3Blbj17aXNPcGVufSBzdGF0ZUNvbnRyb2w9e3N0YXRlQ29udHJvbH0gLz5cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGxheUJ1dHRvbjtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIlxyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuLi9CdXR0b24nXHJcblxyXG5jb25zdCBQb3B1cFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG4gICAgaGVpZ2h0OiAxMDB2aDtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBkaXNwbGF5OiAke3Byb3BzID0+IHByb3BzLmlzT3BlbiA/IFwiZmxleFwiIDogXCJub25lXCJ9O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5gXHJcblxyXG5jb25zdCBEaW1tZWRCYWNrZ3JvdW5kID0gc3R5bGVkLmRpdmBcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzExMTtcclxuICAgIG9wYWNpdHk6IC43O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgei1pbmRleDogNDAwMDtcclxuICAgIHRvcDogMDtcclxuYFxyXG5cclxuY29uc3QgUG9wdXAgPSBzdHlsZWQuZGl2YFxyXG4gICAgd2lkdGg6IDEwMHB4O1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjOTY4ZDhjO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICM5NjhkOGM7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMGYxOTIzO1xyXG4gICAgei1pbmRleDogNjAwMDtcclxuICAgIGhlaWdodDogNDB2aDtcclxuICAgIHdpZHRoOiBjYWxjKDIvMyoxMDAlKTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG5gXHJcblxyXG5jb25zdCBQb3B1cFRpdGxlV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBoZWlnaHQ6IDcwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC1mYW1pbHk6ICdLYW5pdCcsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXNpemU6IDMycHg7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGNvbHVtbi1nYXA6IDI0cHg7XHJcbmBcclxuXHJcbmNvbnN0IFBvcHVwQnV0dG9uV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGNvbHVtbi1nYXA6IDQwcHg7XHJcbmBcclxuXHJcbmNvbnN0IEJ1dHRvbkxhYmVsID0gc3R5bGVkLnBgXHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogMzAwO1xyXG5gXHJcblxyXG5jb25zdCBCdXR0b25XcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuYFxyXG5cclxuY29uc3QgRXhpdEJ1dHRvbldyYXBwZXIgPSBzdHlsZWQuYnV0dG9uYFxyXG4gICAgd2lkdGg6IDYwcHg7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICBib3JkZXI6IHNvbGlkIHdoaXRlIDFweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMTVweDtcclxuICAgIHJpZ2h0OiAxNXB4O1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbmBcclxuXHJcbmNvbnN0IEV4aXRCdXR0b24gPSAoeyBvbkNsaWNrIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEV4aXRCdXR0b25XcmFwcGVyIG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICAgICAgICA8RXhpdEJ1dHRvblN0eWxlIC8+XHJcbiAgICAgICAgPC9FeGl0QnV0dG9uV3JhcHBlcj5cclxuICAgIClcclxufVxyXG5cclxuY29uc3QgU3ZnRXhpdCA9IHN0eWxlZC5zdmdgXHJcbiAgICB3aWR0aDogNDhweDtcclxuICAgIGhlaWdodDogNDhweDtcclxuICAgIHRyYW5zaXRpb246IHNjYWxlIC4ycztcclxuICAgICR7RXhpdEJ1dHRvbldyYXBwZXJ9OmhvdmVyICYge1xyXG4gICAgICAgIHNjYWxlOiAxLjE1O1xyXG4gICAgfVxyXG5gXHJcblxyXG5jb25zdCBFeGl0QnV0dG9uU3R5bGUgPSAoKSA9PiAoXHJcbiAgICA8U3ZnRXhpdCB2aWV3Qm94PVwiMCAwIDcyIDcyXCI+XHJcbiAgICAgICAgPHBhdGggZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjZWNlOGUxXCIgZD1cIk02MS41IDkuNWwtNyA3bS0zOCAzOGwtNyA3TTMwLjMgNDJsMi44LTNtOC42IDNMMzAuMyAzMG0xMS40IDBsLTIuNiAyLjhcIiAvPlxyXG4gICAgPC9TdmdFeGl0PlxyXG4pXHJcblxyXG5leHBvcnQgY29uc3QgUGxheVBvcHVwID0gKHsgaXNPcGVuLCBzdGF0ZUNvbnRyb2wgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8UG9wdXBXcmFwcGVyIGlzT3Blbj17aXNPcGVufT5cclxuICAgICAgICAgICAgICAgIDxQb3B1cD5cclxuICAgICAgICAgICAgICAgICAgICA8UG9wdXBUaXRsZVdyYXBwZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlxcPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD7guYDguJXguKPguLXguKLguKHguJXguLHguKfguYPguKvguYnguJ7guKPguYnguK3guKE8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPlxcPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUG9wdXBUaXRsZVdyYXBwZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBvcHVwQnV0dG9uV3JhcHBlcj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbldyYXBwZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uTGFiZWw+4LiJ4Lix4LiZ4Lii4Lix4LiH4LmE4Lih4LmI4Lih4Li14Lia4Lix4LiN4LiK4Li1IFJpb3Q8L0J1dHRvbkxhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBpc1doaXRlIGlzQm9yZGVyZWQ+4Liq4Lij4LmJ4Liy4LiH4LiX4Lix4LiZ4LiX4Li1PC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uV3JhcHBlcj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbldyYXBwZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uTGFiZWw+4LiJ4Lix4LiZ4Lih4Li14Lia4Lix4LiN4LiK4Li1IFJpb3Qg4LmB4Lil4LmJ4LinPC9CdXR0b25MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gaXNCb3JkZXJlZD7guKXguIfguIrguLfguYjguK3guYDguILguYnguLLguYPguIrguYk8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b25XcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUG9wdXBCdXR0b25XcmFwcGVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxFeGl0QnV0dG9uIG9uQ2xpY2s9eygpID0+IHN0YXRlQ29udHJvbChmYWxzZSl9IC8+XHJcbiAgICAgICAgICAgICAgICA8L1BvcHVwPlxyXG4gICAgICAgICAgICAgICAgPERpbW1lZEJhY2tncm91bmQgb25DbGljaz17KCkgPT4gc3RhdGVDb250cm9sKGZhbHNlKX0gLz5cclxuICAgICAgICAgICAgPC9Qb3B1cFdyYXBwZXI+XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn0iLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJpZ2h0TmF2ID0gc3R5bGVkLmRpdmBcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBtYXJnaW46IDAgMjRweCAwIDA7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICByaWdodDogMDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG5gXHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcblxyXG5jb25zdCBHYW1lc0JhciA9IHN0eWxlZC5kaXZgXHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgaGVpZ2h0OiAzNzBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICB6LWluZGV4OiAxMDAwMDtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgICBwYWRkaW5nOiAyNHB4IDQwcHg7XHJcbmBcclxuXHJcbmNvbnN0IERpbW1lZEJhY2tncm91bmQgPSBzdHlsZWQuZGl2YFxyXG4gICAgei1pbmRleDogOTAwMDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMxMTE7XHJcbiAgICBvcGFjaXR5OiAuNztcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBtYXJnaW4tdG9wOiA4MHB4O1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG4gICAgaGVpZ2h0OiAxMDB2aDtcclxuYFxyXG5cclxuY29uc3QgR2FtZXNCYXJXcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBtYXJnaW4tdG9wOiA4MHB4O1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG4gICAgaGVpZ2h0OiAxMDB2aDtcclxuICAgIGRpc3BsYXk6ICR7cHJvcHMgPT4gcHJvcHMuaXNPcGVuID8gXCJibG9ja1wiIDogXCJub25lXCJ9O1xyXG5gXHJcblxyXG5jb25zdCBTdHlsZWRUcmlhbmdsZVVwID0gc3R5bGVkLnN2Z2BcclxuICAgIHdpZHRoOiAzMnB4O1xyXG4gICAgaGVpZ2h0OiAzMnB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAtMTRweDtcclxuICAgIGxlZnQ6IDM4cHg7XHJcbmBcclxuXHJcbmNvbnN0IFRpdGxlUmlvdEdhbWVzID0gc3R5bGVkLnBgXHJcbiAgICBmb250LWZhbWlseTogJ0thbml0Jywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbmBcclxuXHJcbmNvbnN0IFRyaWFuZ2xlVXAgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRUcmlhbmdsZVVwIHZpZXdCb3g9XCIwIDAgMTYgMTZcIiBmaWxsPVwiI2ZmZlwiPlxyXG4gICAgICAgICAgICA8cGF0aCBmaWxsUnVsZT1cImV2ZW5vZGRcIiBkPVwiTTcuMDIyIDEuNTY2YTEuMTMgMS4xMyAwIDAgMSAxLjk2IDBsNi44NTcgMTEuNjY3Yy40NTcuNzc4LS4wOTIgMS43NjctLjk4IDEuNzY3SDEuMTQ0Yy0uODg5IDAtMS40MzctLjk5LS45OC0xLjc2N0w3LjAyMiAxLjU2NnpcIi8+XHJcbiAgICAgICAgPC9TdHlsZWRUcmlhbmdsZVVwPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgY29uc3QgUmlvdEdhbWVzQmFyID0gKHsgaXNPcGVuLCBzdGF0ZUNvbnRyb2x9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxHYW1lc0JhcldyYXBwZXIgaXNPcGVuPXtpc09wZW59PlxyXG4gICAgICAgICAgICA8VHJpYW5nbGVVcCAvPlxyXG4gICAgICAgICAgICA8R2FtZXNCYXI+XHJcbiAgICAgICAgICAgICAgICA8VGl0bGVSaW90R2FtZXM+UklPVCBHQU1FUzwvVGl0bGVSaW90R2FtZXM+XHJcbiAgICAgICAgICAgIDwvR2FtZXNCYXI+XHJcbiAgICAgICAgICAgIDxEaW1tZWRCYWNrZ3JvdW5kIG9uQ2xpY2s9eygpID0+IHN0YXRlQ29udHJvbChmYWxzZSl9IC8+XHJcbiAgICAgICAgPC9HYW1lc0JhcldyYXBwZXI+XHJcbiAgICApXHJcbn1cclxuIiwiaW1wb3J0IHN0eWxlZCwgeyBjc3MgfSBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuLi9zdHlsZXMvTmV3cy5tb2R1bGUuY3NzJ1xyXG5cclxuXHJcbmNvbnN0IFRleHRCZ0NvbnRhaW5lciA9IHN0eWxlZC5kaXZgXHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbiAgICBoZWlnaHQ6IDE1MHZoO1xyXG4gICAgYmFja2dyb3VuZDogIzBmMTkyMztcclxuYFxyXG5jb25zdCBUeHQgPSBzdHlsZWQuc3BhbmBcclxuICAgIGZvbnQtZmFtaWx5OiBESU5OZXh0TFRXMDQtTWVkaXVtO1xyXG4gICAgZm9udC1zaXplOiAyMi42NXZ3O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIFotaW5kZXg6IDE7XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogODAwcHgpe1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjcuNjV2dztcclxuICAgIH1cclxuYFxyXG5jb25zdCBUZXh0QkcgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgPFRleHRCZ0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT17IHN0eWxlcy5zdHJva2UgfT5cclxuICAgICAgICAgICAgICAgIDxUeHQgY2xhc3NOYW1lPXsgc3R5bGVzLnRleHRCYWNrZ3JvdW5kMSB9PldFIEFSRTwvVHh0PlxyXG4gICAgICAgICAgICAgICAgPFR4dCBjbGFzc05hbWU9eyBzdHlsZXMudGV4dEJhY2tncm91bmQyIH0+VkFMT1JBTlQ8L1R4dD5cclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICA8L1RleHRCZ0NvbnRhaW5lcj5cclxuICAgICAgICA8Lz5cclxuXHJcbiAgICApXHJcbiAgICBcclxuXHJcbn1cclxuZXhwb3J0IGRlZmF1bHQgVGV4dEJHO1xyXG5leHBvcnQge1R4dCwgVGV4dEJnQ29udGFpbmVyfTtcclxuXHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcblxyXG5jb25zdCBTdHlsZWRUaXRsZSA9IHN0eWxlZC5wYFxyXG4gIGZvbnQtc2l6ZTogNC4yNXJlbTtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBmb250LWZhbWlseTogJ0thbml0Jywgc2Fucy1zZXJpZjtcclxuICBjb2xvcjogJHtwcm9wcyA9PiBwcm9wcy5jb2xvcn07XHJcbiAgbWFyZ2luOiAwO1xyXG4gIHdpZHRoOiA2MCU7XHJcbiAgbGluZS1oZWlnaHQ6IDEuMztcclxuYFxyXG5cclxuZXhwb3J0IGRlZmF1bHQgKHsgdGV4dENvbG9yLCBjaGlsZHJlbiB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRUaXRsZSBjb2xvcj17dGV4dENvbG9yfT5cclxuICAgICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgIDwvU3R5bGVkVGl0bGU+XHJcbiAgICApXHJcbn1cclxuIiwiZXhwb3J0IHtkZWZhdWx0IGFzIEhlYWR9IGZyb20gJy4vSGVhZCdcclxuZXhwb3J0IHtkZWZhdWx0IGFzIFRpdGxlfSBmcm9tICcuL1RleHRUaXRsZSdcclxuZXhwb3J0IHtOYXZCYXJ9IGZyb20gJy4vTmF2J1xyXG5leHBvcnQge0Zvb3Rlcn0gZnJvbSAnLi9Gb290ZXInXHJcbmV4cG9ydCB7QnV0dG9ufSBmcm9tICcuL0J1dHRvbidcclxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLmRlZmF1bHQgPSB2b2lkIDA7XG52YXIgX3JlYWN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3RcIikpO1xudmFyIF9yb3V0ZXIgPSByZXF1aXJlKFwiLi4vc2hhcmVkL2xpYi9yb3V0ZXIvcm91dGVyXCIpO1xudmFyIF9yb3V0ZXIxID0gcmVxdWlyZShcIi4vcm91dGVyXCIpO1xudmFyIF91c2VJbnRlcnNlY3Rpb24gPSByZXF1aXJlKFwiLi91c2UtaW50ZXJzZWN0aW9uXCIpO1xuZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgICAgICBkZWZhdWx0OiBvYmpcbiAgICB9O1xufVxuY29uc3QgcHJlZmV0Y2hlZCA9IHtcbn07XG5mdW5jdGlvbiBwcmVmZXRjaChyb3V0ZXIsIGhyZWYsIGFzLCBvcHRpb25zKSB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnIHx8ICFyb3V0ZXIpIHJldHVybjtcbiAgICBpZiAoISgwLCBfcm91dGVyKS5pc0xvY2FsVVJMKGhyZWYpKSByZXR1cm47XG4gICAgLy8gUHJlZmV0Y2ggdGhlIEpTT04gcGFnZSBpZiBhc2tlZCAob25seSBpbiB0aGUgY2xpZW50KVxuICAgIC8vIFdlIG5lZWQgdG8gaGFuZGxlIGEgcHJlZmV0Y2ggZXJyb3IgaGVyZSBzaW5jZSB3ZSBtYXkgYmVcbiAgICAvLyBsb2FkaW5nIHdpdGggcHJpb3JpdHkgd2hpY2ggY2FuIHJlamVjdCBidXQgd2UgZG9uJ3RcbiAgICAvLyB3YW50IHRvIGZvcmNlIG5hdmlnYXRpb24gc2luY2UgdGhpcyBpcyBvbmx5IGEgcHJlZmV0Y2hcbiAgICByb3V0ZXIucHJlZmV0Y2goaHJlZiwgYXMsIG9wdGlvbnMpLmNhdGNoKChlcnIpPT57XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICAvLyByZXRocm93IHRvIHNob3cgaW52YWxpZCBVUkwgZXJyb3JzXG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBjb25zdCBjdXJMb2NhbGUgPSBvcHRpb25zICYmIHR5cGVvZiBvcHRpb25zLmxvY2FsZSAhPT0gJ3VuZGVmaW5lZCcgPyBvcHRpb25zLmxvY2FsZSA6IHJvdXRlciAmJiByb3V0ZXIubG9jYWxlO1xuICAgIC8vIEpvaW4gb24gYW4gaW52YWxpZCBVUkkgY2hhcmFjdGVyXG4gICAgcHJlZmV0Y2hlZFtocmVmICsgJyUnICsgYXMgKyAoY3VyTG9jYWxlID8gJyUnICsgY3VyTG9jYWxlIDogJycpXSA9IHRydWU7XG59XG5mdW5jdGlvbiBpc01vZGlmaWVkRXZlbnQoZXZlbnQpIHtcbiAgICBjb25zdCB7IHRhcmdldCAgfSA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgcmV0dXJuIHRhcmdldCAmJiB0YXJnZXQgIT09ICdfc2VsZicgfHwgZXZlbnQubWV0YUtleSB8fCBldmVudC5jdHJsS2V5IHx8IGV2ZW50LnNoaWZ0S2V5IHx8IGV2ZW50LmFsdEtleSB8fCBldmVudC5uYXRpdmVFdmVudCAmJiBldmVudC5uYXRpdmVFdmVudC53aGljaCA9PT0gMjtcbn1cbmZ1bmN0aW9uIGxpbmtDbGlja2VkKGUsIHJvdXRlciwgaHJlZiwgYXMsIHJlcGxhY2UsIHNoYWxsb3csIHNjcm9sbCwgbG9jYWxlKSB7XG4gICAgY29uc3QgeyBub2RlTmFtZSAgfSA9IGUuY3VycmVudFRhcmdldDtcbiAgICBpZiAobm9kZU5hbWUgPT09ICdBJyAmJiAoaXNNb2RpZmllZEV2ZW50KGUpIHx8ICEoMCwgX3JvdXRlcikuaXNMb2NhbFVSTChocmVmKSkpIHtcbiAgICAgICAgLy8gaWdub3JlIGNsaWNrIGZvciBicm93c2Vy4oCZcyBkZWZhdWx0IGJlaGF2aW9yXG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIC8vICBhdm9pZCBzY3JvbGwgZm9yIHVybHMgd2l0aCBhbmNob3IgcmVmc1xuICAgIGlmIChzY3JvbGwgPT0gbnVsbCAmJiBhcy5pbmRleE9mKCcjJykgPj0gMCkge1xuICAgICAgICBzY3JvbGwgPSBmYWxzZTtcbiAgICB9XG4gICAgLy8gcmVwbGFjZSBzdGF0ZSBpbnN0ZWFkIG9mIHB1c2ggaWYgcHJvcCBpcyBwcmVzZW50XG4gICAgcm91dGVyW3JlcGxhY2UgPyAncmVwbGFjZScgOiAncHVzaCddKGhyZWYsIGFzLCB7XG4gICAgICAgIHNoYWxsb3csXG4gICAgICAgIGxvY2FsZSxcbiAgICAgICAgc2Nyb2xsXG4gICAgfSk7XG59XG5mdW5jdGlvbiBMaW5rKHByb3BzKSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgZnVuY3Rpb24gY3JlYXRlUHJvcEVycm9yKGFyZ3MpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgRXJyb3IoYEZhaWxlZCBwcm9wIHR5cGU6IFRoZSBwcm9wIFxcYCR7YXJncy5rZXl9XFxgIGV4cGVjdHMgYSAke2FyZ3MuZXhwZWN0ZWR9IGluIFxcYDxMaW5rPlxcYCwgYnV0IGdvdCBcXGAke2FyZ3MuYWN0dWFsfVxcYCBpbnN0ZWFkLmAgKyAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyBcIlxcbk9wZW4geW91ciBicm93c2VyJ3MgY29uc29sZSB0byB2aWV3IHRoZSBDb21wb25lbnQgc3RhY2sgdHJhY2UuXCIgOiAnJykpO1xuICAgICAgICB9XG4gICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgIGNvbnN0IHJlcXVpcmVkUHJvcHNHdWFyZCA9IHtcbiAgICAgICAgICAgIGhyZWY6IHRydWVcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgcmVxdWlyZWRQcm9wcyA9IE9iamVjdC5rZXlzKHJlcXVpcmVkUHJvcHNHdWFyZCk7XG4gICAgICAgIHJlcXVpcmVkUHJvcHMuZm9yRWFjaCgoa2V5KT0+e1xuICAgICAgICAgICAgaWYgKGtleSA9PT0gJ2hyZWYnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzW2tleV0gPT0gbnVsbCB8fCB0eXBlb2YgcHJvcHNba2V5XSAhPT0gJ3N0cmluZycgJiYgdHlwZW9mIHByb3BzW2tleV0gIT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZVByb3BFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZDogJ2BzdHJpbmdgIG9yIGBvYmplY3RgJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdHVhbDogcHJvcHNba2V5XSA9PT0gbnVsbCA/ICdudWxsJyA6IHR5cGVvZiBwcm9wc1trZXldXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gVHlwZVNjcmlwdCB0cmljayBmb3IgdHlwZS1ndWFyZGluZzpcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVudXNlZC12YXJzXG4gICAgICAgICAgICAgICAgY29uc3QgXyA9IGtleTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgIGNvbnN0IG9wdGlvbmFsUHJvcHNHdWFyZCA9IHtcbiAgICAgICAgICAgIGFzOiB0cnVlLFxuICAgICAgICAgICAgcmVwbGFjZTogdHJ1ZSxcbiAgICAgICAgICAgIHNjcm9sbDogdHJ1ZSxcbiAgICAgICAgICAgIHNoYWxsb3c6IHRydWUsXG4gICAgICAgICAgICBwYXNzSHJlZjogdHJ1ZSxcbiAgICAgICAgICAgIHByZWZldGNoOiB0cnVlLFxuICAgICAgICAgICAgbG9jYWxlOiB0cnVlXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IG9wdGlvbmFsUHJvcHMgPSBPYmplY3Qua2V5cyhvcHRpb25hbFByb3BzR3VhcmQpO1xuICAgICAgICBvcHRpb25hbFByb3BzLmZvckVhY2goKGtleSk9PntcbiAgICAgICAgICAgIGNvbnN0IHZhbFR5cGUgPSB0eXBlb2YgcHJvcHNba2V5XTtcbiAgICAgICAgICAgIGlmIChrZXkgPT09ICdhcycpIHtcbiAgICAgICAgICAgICAgICBpZiAocHJvcHNba2V5XSAmJiB2YWxUeXBlICE9PSAnc3RyaW5nJyAmJiB2YWxUeXBlICE9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBjcmVhdGVQcm9wRXJyb3Ioe1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwZWN0ZWQ6ICdgc3RyaW5nYCBvciBgb2JqZWN0YCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3R1YWw6IHZhbFR5cGVcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmIChrZXkgPT09ICdsb2NhbGUnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzW2tleV0gJiYgdmFsVHlwZSAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgY3JlYXRlUHJvcEVycm9yKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkOiAnYHN0cmluZ2AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0dWFsOiB2YWxUeXBlXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSAncmVwbGFjZScgfHwga2V5ID09PSAnc2Nyb2xsJyB8fCBrZXkgPT09ICdzaGFsbG93JyB8fCBrZXkgPT09ICdwYXNzSHJlZicgfHwga2V5ID09PSAncHJlZmV0Y2gnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzW2tleV0gIT0gbnVsbCAmJiB2YWxUeXBlICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgY3JlYXRlUHJvcEVycm9yKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkOiAnYGJvb2xlYW5gJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdHVhbDogdmFsVHlwZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgICAgICAgICAgICAgIGNvbnN0IF8gPSBrZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBUaGlzIGhvb2sgaXMgaW4gYSBjb25kaXRpb25hbCBidXQgdGhhdCBpcyBvayBiZWNhdXNlIGBwcm9jZXNzLmVudi5OT0RFX0VOVmAgbmV2ZXIgY2hhbmdlc1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvcnVsZXMtb2YtaG9va3NcbiAgICAgICAgY29uc3QgaGFzV2FybmVkID0gX3JlYWN0LmRlZmF1bHQudXNlUmVmKGZhbHNlKTtcbiAgICAgICAgaWYgKHByb3BzLnByZWZldGNoICYmICFoYXNXYXJuZWQuY3VycmVudCkge1xuICAgICAgICAgICAgaGFzV2FybmVkLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdOZXh0LmpzIGF1dG8tcHJlZmV0Y2hlcyBhdXRvbWF0aWNhbGx5IGJhc2VkIG9uIHZpZXdwb3J0LiBUaGUgcHJlZmV0Y2ggYXR0cmlidXRlIGlzIG5vIGxvbmdlciBuZWVkZWQuIE1vcmU6IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL3ByZWZldGNoLXRydWUtZGVwcmVjYXRlZCcpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHAgPSBwcm9wcy5wcmVmZXRjaCAhPT0gZmFsc2U7XG4gICAgY29uc3Qgcm91dGVyID0gKDAsIF9yb3V0ZXIxKS51c2VSb3V0ZXIoKTtcbiAgICBjb25zdCB7IGhyZWYgLCBhcyAgfSA9IF9yZWFjdC5kZWZhdWx0LnVzZU1lbW8oKCk9PntcbiAgICAgICAgY29uc3QgW3Jlc29sdmVkSHJlZiwgcmVzb2x2ZWRBc10gPSAoMCwgX3JvdXRlcikucmVzb2x2ZUhyZWYocm91dGVyLCBwcm9wcy5ocmVmLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGhyZWY6IHJlc29sdmVkSHJlZixcbiAgICAgICAgICAgIGFzOiBwcm9wcy5hcyA/ICgwLCBfcm91dGVyKS5yZXNvbHZlSHJlZihyb3V0ZXIsIHByb3BzLmFzKSA6IHJlc29sdmVkQXMgfHwgcmVzb2x2ZWRIcmVmXG4gICAgICAgIH07XG4gICAgfSwgW1xuICAgICAgICByb3V0ZXIsXG4gICAgICAgIHByb3BzLmhyZWYsXG4gICAgICAgIHByb3BzLmFzXG4gICAgXSk7XG4gICAgbGV0IHsgY2hpbGRyZW4gLCByZXBsYWNlICwgc2hhbGxvdyAsIHNjcm9sbCAsIGxvY2FsZSAgfSA9IHByb3BzO1xuICAgIC8vIERlcHJlY2F0ZWQuIFdhcm5pbmcgc2hvd24gYnkgcHJvcFR5cGUgY2hlY2suIElmIHRoZSBjaGlsZHJlbiBwcm92aWRlZCBpcyBhIHN0cmluZyAoPExpbms+ZXhhbXBsZTwvTGluaz4pIHdlIHdyYXAgaXQgaW4gYW4gPGE+IHRhZ1xuICAgIGlmICh0eXBlb2YgY2hpbGRyZW4gPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNoaWxkcmVuID0gLyojX19QVVJFX18qLyBfcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiYVwiLCBudWxsLCBjaGlsZHJlbik7XG4gICAgfVxuICAgIC8vIFRoaXMgd2lsbCByZXR1cm4gdGhlIGZpcnN0IGNoaWxkLCBpZiBtdWx0aXBsZSBhcmUgcHJvdmlkZWQgaXQgd2lsbCB0aHJvdyBhbiBlcnJvclxuICAgIGxldCBjaGlsZDtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNoaWxkID0gX3JlYWN0LmRlZmF1bHQuQ2hpbGRyZW4ub25seShjaGlsZHJlbik7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBNdWx0aXBsZSBjaGlsZHJlbiB3ZXJlIHBhc3NlZCB0byA8TGluaz4gd2l0aCBcXGBocmVmXFxgIG9mIFxcYCR7cHJvcHMuaHJlZn1cXGAgYnV0IG9ubHkgb25lIGNoaWxkIGlzIHN1cHBvcnRlZCBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9saW5rLW11bHRpcGxlLWNoaWxkcmVuYCArICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IFwiIFxcbk9wZW4geW91ciBicm93c2VyJ3MgY29uc29sZSB0byB2aWV3IHRoZSBDb21wb25lbnQgc3RhY2sgdHJhY2UuXCIgOiAnJykpO1xuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgY2hpbGQgPSBfcmVhY3QuZGVmYXVsdC5DaGlsZHJlbi5vbmx5KGNoaWxkcmVuKTtcbiAgICB9XG4gICAgY29uc3QgY2hpbGRSZWYgPSBjaGlsZCAmJiB0eXBlb2YgY2hpbGQgPT09ICdvYmplY3QnICYmIGNoaWxkLnJlZjtcbiAgICBjb25zdCBbc2V0SW50ZXJzZWN0aW9uUmVmLCBpc1Zpc2libGVdID0gKDAsIF91c2VJbnRlcnNlY3Rpb24pLnVzZUludGVyc2VjdGlvbih7XG4gICAgICAgIHJvb3RNYXJnaW46ICcyMDBweCdcbiAgICB9KTtcbiAgICBjb25zdCBzZXRSZWYgPSBfcmVhY3QuZGVmYXVsdC51c2VDYWxsYmFjaygoZWwpPT57XG4gICAgICAgIHNldEludGVyc2VjdGlvblJlZihlbCk7XG4gICAgICAgIGlmIChjaGlsZFJlZikge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBjaGlsZFJlZiA9PT0gJ2Z1bmN0aW9uJykgY2hpbGRSZWYoZWwpO1xuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGNoaWxkUmVmID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgIGNoaWxkUmVmLmN1cnJlbnQgPSBlbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFtcbiAgICAgICAgY2hpbGRSZWYsXG4gICAgICAgIHNldEludGVyc2VjdGlvblJlZlxuICAgIF0pO1xuICAgIF9yZWFjdC5kZWZhdWx0LnVzZUVmZmVjdCgoKT0+e1xuICAgICAgICBjb25zdCBzaG91bGRQcmVmZXRjaCA9IGlzVmlzaWJsZSAmJiBwICYmICgwLCBfcm91dGVyKS5pc0xvY2FsVVJMKGhyZWYpO1xuICAgICAgICBjb25zdCBjdXJMb2NhbGUgPSB0eXBlb2YgbG9jYWxlICE9PSAndW5kZWZpbmVkJyA/IGxvY2FsZSA6IHJvdXRlciAmJiByb3V0ZXIubG9jYWxlO1xuICAgICAgICBjb25zdCBpc1ByZWZldGNoZWQgPSBwcmVmZXRjaGVkW2hyZWYgKyAnJScgKyBhcyArIChjdXJMb2NhbGUgPyAnJScgKyBjdXJMb2NhbGUgOiAnJyldO1xuICAgICAgICBpZiAoc2hvdWxkUHJlZmV0Y2ggJiYgIWlzUHJlZmV0Y2hlZCkge1xuICAgICAgICAgICAgcHJlZmV0Y2gocm91dGVyLCBocmVmLCBhcywge1xuICAgICAgICAgICAgICAgIGxvY2FsZTogY3VyTG9jYWxlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sIFtcbiAgICAgICAgYXMsXG4gICAgICAgIGhyZWYsXG4gICAgICAgIGlzVmlzaWJsZSxcbiAgICAgICAgbG9jYWxlLFxuICAgICAgICBwLFxuICAgICAgICByb3V0ZXJcbiAgICBdKTtcbiAgICBjb25zdCBjaGlsZFByb3BzID0ge1xuICAgICAgICByZWY6IHNldFJlZixcbiAgICAgICAgb25DbGljazogKGUpPT57XG4gICAgICAgICAgICBpZiAoY2hpbGQucHJvcHMgJiYgdHlwZW9mIGNoaWxkLnByb3BzLm9uQ2xpY2sgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICBjaGlsZC5wcm9wcy5vbkNsaWNrKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFlLmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgICAgICAgICBsaW5rQ2xpY2tlZChlLCByb3V0ZXIsIGhyZWYsIGFzLCByZXBsYWNlLCBzaGFsbG93LCBzY3JvbGwsIGxvY2FsZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNoaWxkUHJvcHMub25Nb3VzZUVudGVyID0gKGUpPT57XG4gICAgICAgIGlmICghKDAsIF9yb3V0ZXIpLmlzTG9jYWxVUkwoaHJlZikpIHJldHVybjtcbiAgICAgICAgaWYgKGNoaWxkLnByb3BzICYmIHR5cGVvZiBjaGlsZC5wcm9wcy5vbk1vdXNlRW50ZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGNoaWxkLnByb3BzLm9uTW91c2VFbnRlcihlKTtcbiAgICAgICAgfVxuICAgICAgICBwcmVmZXRjaChyb3V0ZXIsIGhyZWYsIGFzLCB7XG4gICAgICAgICAgICBwcmlvcml0eTogdHJ1ZVxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIC8vIElmIGNoaWxkIGlzIGFuIDxhPiB0YWcgYW5kIGRvZXNuJ3QgaGF2ZSBhIGhyZWYgYXR0cmlidXRlLCBvciBpZiB0aGUgJ3Bhc3NIcmVmJyBwcm9wZXJ0eSBpc1xuICAgIC8vIGRlZmluZWQsIHdlIHNwZWNpZnkgdGhlIGN1cnJlbnQgJ2hyZWYnLCBzbyB0aGF0IHJlcGV0aXRpb24gaXMgbm90IG5lZWRlZCBieSB0aGUgdXNlclxuICAgIGlmIChwcm9wcy5wYXNzSHJlZiB8fCBjaGlsZC50eXBlID09PSAnYScgJiYgISgnaHJlZicgaW4gY2hpbGQucHJvcHMpKSB7XG4gICAgICAgIGNvbnN0IGN1ckxvY2FsZSA9IHR5cGVvZiBsb2NhbGUgIT09ICd1bmRlZmluZWQnID8gbG9jYWxlIDogcm91dGVyICYmIHJvdXRlci5sb2NhbGU7XG4gICAgICAgIC8vIHdlIG9ubHkgcmVuZGVyIGRvbWFpbiBsb2NhbGVzIGlmIHdlIGFyZSBjdXJyZW50bHkgb24gYSBkb21haW4gbG9jYWxlXG4gICAgICAgIC8vIHNvIHRoYXQgbG9jYWxlIGxpbmtzIGFyZSBzdGlsbCB2aXNpdGFibGUgaW4gZGV2ZWxvcG1lbnQvcHJldmlldyBlbnZzXG4gICAgICAgIGNvbnN0IGxvY2FsZURvbWFpbiA9IHJvdXRlciAmJiByb3V0ZXIuaXNMb2NhbGVEb21haW4gJiYgKDAsIF9yb3V0ZXIpLmdldERvbWFpbkxvY2FsZShhcywgY3VyTG9jYWxlLCByb3V0ZXIgJiYgcm91dGVyLmxvY2FsZXMsIHJvdXRlciAmJiByb3V0ZXIuZG9tYWluTG9jYWxlcyk7XG4gICAgICAgIGNoaWxkUHJvcHMuaHJlZiA9IGxvY2FsZURvbWFpbiB8fCAoMCwgX3JvdXRlcikuYWRkQmFzZVBhdGgoKDAsIF9yb3V0ZXIpLmFkZExvY2FsZShhcywgY3VyTG9jYWxlLCByb3V0ZXIgJiYgcm91dGVyLmRlZmF1bHRMb2NhbGUpKTtcbiAgICB9XG4gICAgcmV0dXJuKC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY2xvbmVFbGVtZW50KGNoaWxkLCBjaGlsZFByb3BzKSk7XG59XG52YXIgX2RlZmF1bHQgPSBMaW5rO1xuZXhwb3J0cy5kZWZhdWx0ID0gX2RlZmF1bHQ7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxpbmsuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLnJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoID0gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2g7XG5leHBvcnRzLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoID0gdm9pZCAwO1xuZnVuY3Rpb24gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aCkge1xuICAgIHJldHVybiBwYXRoLmVuZHNXaXRoKCcvJykgJiYgcGF0aCAhPT0gJy8nID8gcGF0aC5zbGljZSgwLCAtMSkgOiBwYXRoO1xufVxuY29uc3Qgbm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2ggPSBwcm9jZXNzLmVudi5fX05FWFRfVFJBSUxJTkdfU0xBU0ggPyAocGF0aCk9PntcbiAgICBpZiAoL1xcLlteL10rXFwvPyQvLnRlc3QocGF0aCkpIHtcbiAgICAgICAgcmV0dXJuIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGgpO1xuICAgIH0gZWxzZSBpZiAocGF0aC5lbmRzV2l0aCgnLycpKSB7XG4gICAgICAgIHJldHVybiBwYXRoO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBwYXRoICsgJy8nO1xuICAgIH1cbn0gOiByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaDtcbmV4cG9ydHMubm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2ggPSBub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaDtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5yZXF1ZXN0SWRsZUNhbGxiYWNrID0gZXhwb3J0cy5jYW5jZWxJZGxlQ2FsbGJhY2sgPSB2b2lkIDA7XG5jb25zdCByZXF1ZXN0SWRsZUNhbGxiYWNrID0gdHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnICYmIHNlbGYucmVxdWVzdElkbGVDYWxsYmFjayAmJiBzZWxmLnJlcXVlc3RJZGxlQ2FsbGJhY2suYmluZCh3aW5kb3cpIHx8IGZ1bmN0aW9uKGNiKSB7XG4gICAgbGV0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICByZXR1cm4gc2V0VGltZW91dChmdW5jdGlvbigpIHtcbiAgICAgICAgY2Ioe1xuICAgICAgICAgICAgZGlkVGltZW91dDogZmFsc2UsXG4gICAgICAgICAgICB0aW1lUmVtYWluaW5nOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gTWF0aC5tYXgoMCwgNTAgLSAoRGF0ZS5ub3coKSAtIHN0YXJ0KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0sIDEpO1xufTtcbmV4cG9ydHMucmVxdWVzdElkbGVDYWxsYmFjayA9IHJlcXVlc3RJZGxlQ2FsbGJhY2s7XG5jb25zdCBjYW5jZWxJZGxlQ2FsbGJhY2sgPSB0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgJiYgc2VsZi5jYW5jZWxJZGxlQ2FsbGJhY2sgJiYgc2VsZi5jYW5jZWxJZGxlQ2FsbGJhY2suYmluZCh3aW5kb3cpIHx8IGZ1bmN0aW9uKGlkKSB7XG4gICAgcmV0dXJuIGNsZWFyVGltZW91dChpZCk7XG59O1xuZXhwb3J0cy5jYW5jZWxJZGxlQ2FsbGJhY2sgPSBjYW5jZWxJZGxlQ2FsbGJhY2s7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlcXVlc3QtaWRsZS1jYWxsYmFjay5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMubWFya0Fzc2V0RXJyb3IgPSBtYXJrQXNzZXRFcnJvcjtcbmV4cG9ydHMuaXNBc3NldEVycm9yID0gaXNBc3NldEVycm9yO1xuZXhwb3J0cy5nZXRDbGllbnRCdWlsZE1hbmlmZXN0ID0gZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdDtcbmV4cG9ydHMuY3JlYXRlUm91dGVMb2FkZXIgPSBjcmVhdGVSb3V0ZUxvYWRlcjtcbnZhciBfZ2V0QXNzZXRQYXRoRnJvbVJvdXRlID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvZ2V0LWFzc2V0LXBhdGgtZnJvbS1yb3V0ZVwiKSk7XG52YXIgX3JlcXVlc3RJZGxlQ2FsbGJhY2sgPSByZXF1aXJlKFwiLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2tcIik7XG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iaikge1xuICAgIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgICAgIGRlZmF1bHQ6IG9ialxuICAgIH07XG59XG4vLyAzLjhzIHdhcyBhcmJpdHJhcmlseSBjaG9zZW4gYXMgaXQncyB3aGF0IGh0dHBzOi8vd2ViLmRldi9pbnRlcmFjdGl2ZVxuLy8gY29uc2lkZXJzIGFzIFwiR29vZFwiIHRpbWUtdG8taW50ZXJhY3RpdmUuIFdlIG11c3QgYXNzdW1lIHNvbWV0aGluZyB3ZW50XG4vLyB3cm9uZyBiZXlvbmQgdGhpcyBwb2ludCwgYW5kIHRoZW4gZmFsbC1iYWNrIHRvIGEgZnVsbCBwYWdlIHRyYW5zaXRpb24gdG9cbi8vIHNob3cgdGhlIHVzZXIgc29tZXRoaW5nIG9mIHZhbHVlLlxuY29uc3QgTVNfTUFYX0lETEVfREVMQVkgPSAzODAwO1xuZnVuY3Rpb24gd2l0aEZ1dHVyZShrZXksIG1hcCwgZ2VuZXJhdG9yKSB7XG4gICAgbGV0IGVudHJ5ID0gbWFwLmdldChrZXkpO1xuICAgIGlmIChlbnRyeSkge1xuICAgICAgICBpZiAoJ2Z1dHVyZScgaW4gZW50cnkpIHtcbiAgICAgICAgICAgIHJldHVybiBlbnRyeS5mdXR1cmU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShlbnRyeSk7XG4gICAgfVxuICAgIGxldCByZXNvbHZlcjtcbiAgICBjb25zdCBwcm9tID0gbmV3IFByb21pc2UoKHJlc29sdmUpPT57XG4gICAgICAgIHJlc29sdmVyID0gcmVzb2x2ZTtcbiAgICB9KTtcbiAgICBtYXAuc2V0KGtleSwgZW50cnkgPSB7XG4gICAgICAgIHJlc29sdmU6IHJlc29sdmVyLFxuICAgICAgICBmdXR1cmU6IHByb21cbiAgICB9KTtcbiAgICByZXR1cm4gZ2VuZXJhdG9yID8gZ2VuZXJhdG9yKCkudGhlbigodmFsdWUpPT4ocmVzb2x2ZXIodmFsdWUpLCB2YWx1ZSlcbiAgICApIDogcHJvbTtcbn1cbmZ1bmN0aW9uIGhhc1ByZWZldGNoKGxpbmspIHtcbiAgICB0cnkge1xuICAgICAgICBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGluaycpO1xuICAgICAgICByZXR1cm4oLy8gZGV0ZWN0IElFMTEgc2luY2UgaXQgc3VwcG9ydHMgcHJlZmV0Y2ggYnV0IGlzbid0IGRldGVjdGVkXG4gICAgICAgIC8vIHdpdGggcmVsTGlzdC5zdXBwb3J0XG4gICAgICAgICghIXdpbmRvdy5NU0lucHV0TWV0aG9kQ29udGV4dCAmJiAhIWRvY3VtZW50LmRvY3VtZW50TW9kZSkgfHwgbGluay5yZWxMaXN0LnN1cHBvcnRzKCdwcmVmZXRjaCcpKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG5jb25zdCBjYW5QcmVmZXRjaCA9IGhhc1ByZWZldGNoKCk7XG5mdW5jdGlvbiBwcmVmZXRjaFZpYURvbShocmVmLCBhcywgbGluaykge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzLCByZWopPT57XG4gICAgICAgIGlmIChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBsaW5rW3JlbD1cInByZWZldGNoXCJdW2hyZWZePVwiJHtocmVmfVwiXWApKSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzKCk7XG4gICAgICAgIH1cbiAgICAgICAgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKTtcbiAgICAgICAgLy8gVGhlIG9yZGVyIG9mIHByb3BlcnR5IGFzc2lnbm1lbnQgaGVyZSBpcyBpbnRlbnRpb25hbDpcbiAgICAgICAgaWYgKGFzKSBsaW5rLmFzID0gYXM7XG4gICAgICAgIGxpbmsucmVsID0gYHByZWZldGNoYDtcbiAgICAgICAgbGluay5jcm9zc09yaWdpbiA9IHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU47XG4gICAgICAgIGxpbmsub25sb2FkID0gcmVzO1xuICAgICAgICBsaW5rLm9uZXJyb3IgPSByZWo7XG4gICAgICAgIC8vIGBocmVmYCBzaG91bGQgYWx3YXlzIGJlIGxhc3Q6XG4gICAgICAgIGxpbmsuaHJlZiA9IGhyZWY7XG4gICAgICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgfSk7XG59XG5jb25zdCBBU1NFVF9MT0FEX0VSUk9SID0gU3ltYm9sKCdBU1NFVF9MT0FEX0VSUk9SJyk7XG5mdW5jdGlvbiBtYXJrQXNzZXRFcnJvcihlcnIpIHtcbiAgICByZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KGVyciwgQVNTRVRfTE9BRF9FUlJPUiwge1xuICAgIH0pO1xufVxuZnVuY3Rpb24gaXNBc3NldEVycm9yKGVycikge1xuICAgIHJldHVybiBlcnIgJiYgQVNTRVRfTE9BRF9FUlJPUiBpbiBlcnI7XG59XG5mdW5jdGlvbiBhcHBlbmRTY3JpcHQoc3JjLCBzY3JpcHQpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCk9PntcbiAgICAgICAgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG4gICAgICAgIC8vIFRoZSBvcmRlciBvZiBwcm9wZXJ0eSBhc3NpZ25tZW50IGhlcmUgaXMgaW50ZW50aW9uYWwuXG4gICAgICAgIC8vIDEuIFNldHVwIHN1Y2Nlc3MvZmFpbHVyZSBob29rcyBpbiBjYXNlIHRoZSBicm93c2VyIHN5bmNocm9ub3VzbHlcbiAgICAgICAgLy8gICAgZXhlY3V0ZXMgd2hlbiBgc3JjYCBpcyBzZXQuXG4gICAgICAgIHNjcmlwdC5vbmxvYWQgPSByZXNvbHZlO1xuICAgICAgICBzY3JpcHQub25lcnJvciA9ICgpPT5yZWplY3QobWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKGBGYWlsZWQgdG8gbG9hZCBzY3JpcHQ6ICR7c3JjfWApKSlcbiAgICAgICAgO1xuICAgICAgICAvLyAyLiBDb25maWd1cmUgdGhlIGNyb3NzLW9yaWdpbiBhdHRyaWJ1dGUgYmVmb3JlIHNldHRpbmcgYHNyY2AgaW4gY2FzZSB0aGVcbiAgICAgICAgLy8gICAgYnJvd3NlciBiZWdpbnMgdG8gZmV0Y2guXG4gICAgICAgIHNjcmlwdC5jcm9zc09yaWdpbiA9IHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU47XG4gICAgICAgIC8vIDMuIEZpbmFsbHksIHNldCB0aGUgc291cmNlIGFuZCBpbmplY3QgaW50byB0aGUgRE9NIGluIGNhc2UgdGhlIGNoaWxkXG4gICAgICAgIC8vICAgIG11c3QgYmUgYXBwZW5kZWQgZm9yIGZldGNoaW5nIHRvIHN0YXJ0LlxuICAgICAgICBzY3JpcHQuc3JjID0gc3JjO1xuICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHNjcmlwdCk7XG4gICAgfSk7XG59XG4vLyBXZSB3YWl0IGZvciBwYWdlcyB0byBiZSBidWlsdCBpbiBkZXYgYmVmb3JlIHdlIHN0YXJ0IHRoZSByb3V0ZSB0cmFuc2l0aW9uXG4vLyB0aW1lb3V0IHRvIHByZXZlbnQgYW4gdW4tbmVjZXNzYXJ5IGhhcmQgbmF2aWdhdGlvbiBpbiBkZXZlbG9wbWVudC5cbmxldCBkZXZCdWlsZFByb21pc2U7XG4vLyBSZXNvbHZlIGEgcHJvbWlzZSB0aGF0IHRpbWVzIG91dCBhZnRlciBnaXZlbiBhbW91bnQgb2YgbWlsbGlzZWNvbmRzLlxuZnVuY3Rpb24gcmVzb2x2ZVByb21pc2VXaXRoVGltZW91dChwLCBtcywgZXJyKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpPT57XG4gICAgICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcbiAgICAgICAgcC50aGVuKChyKT0+e1xuICAgICAgICAgICAgLy8gUmVzb2x2ZWQsIGNhbmNlbCB0aGUgdGltZW91dFxuICAgICAgICAgICAgY2FuY2VsbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHJlc29sdmUocik7XG4gICAgICAgIH0pLmNhdGNoKHJlamVjdCk7XG4gICAgICAgIC8vIFdlIHdyYXAgdGhlc2UgY2hlY2tzIHNlcGFyYXRlbHkgZm9yIGJldHRlciBkZWFkLWNvZGUgZWxpbWluYXRpb24gaW5cbiAgICAgICAgLy8gcHJvZHVjdGlvbiBidW5kbGVzLlxuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICAgICAgICAgIChkZXZCdWlsZFByb21pc2UgfHwgUHJvbWlzZS5yZXNvbHZlKCkpLnRoZW4oKCk9PntcbiAgICAgICAgICAgICAgICAoMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLnJlcXVlc3RJZGxlQ2FsbGJhY2soKCk9PnNldFRpbWVvdXQoKCk9PntcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0sIG1zKVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICAgICAgICAgICgwLCBfcmVxdWVzdElkbGVDYWxsYmFjaykucmVxdWVzdElkbGVDYWxsYmFjaygoKT0+c2V0VGltZW91dCgoKT0+e1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LCBtcylcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cbmZ1bmN0aW9uIGdldENsaWVudEJ1aWxkTWFuaWZlc3QoKSB7XG4gICAgaWYgKHNlbGYuX19CVUlMRF9NQU5JRkVTVCkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHNlbGYuX19CVUlMRF9NQU5JRkVTVCk7XG4gICAgfVxuICAgIGNvbnN0IG9uQnVpbGRNYW5pZmVzdCA9IG5ldyBQcm9taXNlKChyZXNvbHZlKT0+e1xuICAgICAgICAvLyBNYW5kYXRvcnkgYmVjYXVzZSB0aGlzIGlzIG5vdCBjb25jdXJyZW50IHNhZmU6XG4gICAgICAgIGNvbnN0IGNiID0gc2VsZi5fX0JVSUxEX01BTklGRVNUX0NCO1xuICAgICAgICBzZWxmLl9fQlVJTERfTUFOSUZFU1RfQ0IgPSAoKT0+e1xuICAgICAgICAgICAgcmVzb2x2ZShzZWxmLl9fQlVJTERfTUFOSUZFU1QpO1xuICAgICAgICAgICAgY2IgJiYgY2IoKTtcbiAgICAgICAgfTtcbiAgICB9KTtcbiAgICByZXR1cm4gcmVzb2x2ZVByb21pc2VXaXRoVGltZW91dChvbkJ1aWxkTWFuaWZlc3QsIE1TX01BWF9JRExFX0RFTEFZLCBtYXJrQXNzZXRFcnJvcihuZXcgRXJyb3IoJ0ZhaWxlZCB0byBsb2FkIGNsaWVudCBidWlsZCBtYW5pZmVzdCcpKSk7XG59XG5mdW5jdGlvbiBnZXRGaWxlc0ZvclJvdXRlKGFzc2V0UHJlZml4LCByb3V0ZSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50Jykge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHtcbiAgICAgICAgICAgIHNjcmlwdHM6IFtcbiAgICAgICAgICAgICAgICBhc3NldFByZWZpeCArICcvX25leHQvc3RhdGljL2NodW5rcy9wYWdlcycgKyBlbmNvZGVVUkkoKDAsIF9nZXRBc3NldFBhdGhGcm9tUm91dGUpLmRlZmF1bHQocm91dGUsICcuanMnKSksIFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIC8vIFN0eWxlcyBhcmUgaGFuZGxlZCBieSBgc3R5bGUtbG9hZGVyYCBpbiBkZXZlbG9wbWVudDpcbiAgICAgICAgICAgIGNzczogW11cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBnZXRDbGllbnRCdWlsZE1hbmlmZXN0KCkudGhlbigobWFuaWZlc3QpPT57XG4gICAgICAgIGlmICghKHJvdXRlIGluIG1hbmlmZXN0KSkge1xuICAgICAgICAgICAgdGhyb3cgbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKGBGYWlsZWQgdG8gbG9va3VwIHJvdXRlOiAke3JvdXRlfWApKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBhbGxGaWxlcyA9IG1hbmlmZXN0W3JvdXRlXS5tYXAoKGVudHJ5KT0+YXNzZXRQcmVmaXggKyAnL19uZXh0LycgKyBlbmNvZGVVUkkoZW50cnkpXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzY3JpcHRzOiBhbGxGaWxlcy5maWx0ZXIoKHYpPT52LmVuZHNXaXRoKCcuanMnKVxuICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIGNzczogYWxsRmlsZXMuZmlsdGVyKCh2KT0+di5lbmRzV2l0aCgnLmNzcycpXG4gICAgICAgICAgICApXG4gICAgICAgIH07XG4gICAgfSk7XG59XG5mdW5jdGlvbiBjcmVhdGVSb3V0ZUxvYWRlcihhc3NldFByZWZpeCkge1xuICAgIGNvbnN0IGVudHJ5cG9pbnRzID0gbmV3IE1hcCgpO1xuICAgIGNvbnN0IGxvYWRlZFNjcmlwdHMgPSBuZXcgTWFwKCk7XG4gICAgY29uc3Qgc3R5bGVTaGVldHMgPSBuZXcgTWFwKCk7XG4gICAgY29uc3Qgcm91dGVzID0gbmV3IE1hcCgpO1xuICAgIGZ1bmN0aW9uIG1heWJlRXhlY3V0ZVNjcmlwdChzcmMpIHtcbiAgICAgICAgbGV0IHByb20gPSBsb2FkZWRTY3JpcHRzLmdldChzcmMpO1xuICAgICAgICBpZiAocHJvbSkge1xuICAgICAgICAgICAgcmV0dXJuIHByb207XG4gICAgICAgIH1cbiAgICAgICAgLy8gU2tpcCBleGVjdXRpbmcgc2NyaXB0IGlmIGl0J3MgYWxyZWFkeSBpbiB0aGUgRE9NOlxuICAgICAgICBpZiAoZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihgc2NyaXB0W3NyY149XCIke3NyY31cIl1gKSkge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICB9XG4gICAgICAgIGxvYWRlZFNjcmlwdHMuc2V0KHNyYywgcHJvbSA9IGFwcGVuZFNjcmlwdChzcmMpKTtcbiAgICAgICAgcmV0dXJuIHByb207XG4gICAgfVxuICAgIGZ1bmN0aW9uIGZldGNoU3R5bGVTaGVldChocmVmKSB7XG4gICAgICAgIGxldCBwcm9tID0gc3R5bGVTaGVldHMuZ2V0KGhyZWYpO1xuICAgICAgICBpZiAocHJvbSkge1xuICAgICAgICAgICAgcmV0dXJuIHByb207XG4gICAgICAgIH1cbiAgICAgICAgc3R5bGVTaGVldHMuc2V0KGhyZWYsIHByb20gPSBmZXRjaChocmVmKS50aGVuKChyZXMpPT57XG4gICAgICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3R5bGVzaGVldDogJHtocmVmfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlcy50ZXh0KCkudGhlbigodGV4dCk9Pih7XG4gICAgICAgICAgICAgICAgICAgIGhyZWY6IGhyZWYsXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IHRleHRcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSkuY2F0Y2goKGVycik9PntcbiAgICAgICAgICAgIHRocm93IG1hcmtBc3NldEVycm9yKGVycik7XG4gICAgICAgIH0pKTtcbiAgICAgICAgcmV0dXJuIHByb207XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHdoZW5FbnRyeXBvaW50IChyb3V0ZSkge1xuICAgICAgICAgICAgcmV0dXJuIHdpdGhGdXR1cmUocm91dGUsIGVudHJ5cG9pbnRzKTtcbiAgICAgICAgfSxcbiAgICAgICAgb25FbnRyeXBvaW50IChyb3V0ZSwgZXhlY3V0ZSkge1xuICAgICAgICAgICAgUHJvbWlzZS5yZXNvbHZlKGV4ZWN1dGUpLnRoZW4oKGZuKT0+Zm4oKVxuICAgICAgICAgICAgKS50aGVuKChleHBvcnRzKT0+KHtcbiAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50OiBleHBvcnRzICYmIGV4cG9ydHMuZGVmYXVsdCB8fCBleHBvcnRzLFxuICAgICAgICAgICAgICAgICAgICBleHBvcnRzOiBleHBvcnRzXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICwgKGVycik9Pih7XG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBlcnJcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgKS50aGVuKChpbnB1dCk9PntcbiAgICAgICAgICAgICAgICBjb25zdCBvbGQgPSBlbnRyeXBvaW50cy5nZXQocm91dGUpO1xuICAgICAgICAgICAgICAgIGVudHJ5cG9pbnRzLnNldChyb3V0ZSwgaW5wdXQpO1xuICAgICAgICAgICAgICAgIGlmIChvbGQgJiYgJ3Jlc29sdmUnIGluIG9sZCkgb2xkLnJlc29sdmUoaW5wdXQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGxvYWRSb3V0ZSAocm91dGUsIHByZWZldGNoKSB7XG4gICAgICAgICAgICByZXR1cm4gd2l0aEZ1dHVyZShyb3V0ZSwgcm91dGVzLCAoKT0+e1xuICAgICAgICAgICAgICAgIGNvbnN0IHJvdXRlRmlsZXNQcm9taXNlID0gZ2V0RmlsZXNGb3JSb3V0ZShhc3NldFByZWZpeCwgcm91dGUpLnRoZW4oKHsgc2NyaXB0cyAsIGNzcyAgfSk9PntcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5cG9pbnRzLmhhcyhyb3V0ZSkgPyBbXSA6IFByb21pc2UuYWxsKHNjcmlwdHMubWFwKG1heWJlRXhlY3V0ZVNjcmlwdCkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgUHJvbWlzZS5hbGwoY3NzLm1hcChmZXRjaFN0eWxlU2hlZXQpKSwgXG4gICAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgIH0pLnRoZW4oKHJlcyk9PntcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud2hlbkVudHJ5cG9pbnQocm91dGUpLnRoZW4oKGVudHJ5cG9pbnQpPT4oe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5cG9pbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGVzOiByZXNbMV1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAnZGV2ZWxvcG1lbnQnKSB7XG4gICAgICAgICAgICAgICAgICAgIGRldkJ1aWxkUHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlKT0+e1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJvdXRlRmlsZXNQcm9taXNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJvdXRlRmlsZXNQcm9taXNlLmZpbmFsbHkoKCk9PntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmVQcm9taXNlV2l0aFRpbWVvdXQocm91dGVGaWxlc1Byb21pc2UsIE1TX01BWF9JRExFX0RFTEFZLCBtYXJrQXNzZXRFcnJvcihuZXcgRXJyb3IoYFJvdXRlIGRpZCBub3QgY29tcGxldGUgbG9hZGluZzogJHtyb3V0ZX1gKSkpLnRoZW4oKHsgZW50cnlwb2ludCAsIHN0eWxlcyAgfSk9PntcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzID0gT2JqZWN0LmFzc2lnbih7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZXM6IHN0eWxlc1xuICAgICAgICAgICAgICAgICAgICB9LCBlbnRyeXBvaW50KTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICdlcnJvcicgaW4gZW50cnlwb2ludCA/IGVudHJ5cG9pbnQgOiByZXM7XG4gICAgICAgICAgICAgICAgfSkuY2F0Y2goKGVycik9PntcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByZWZldGNoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB3ZSBkb24ndCB3YW50IHRvIGNhY2hlIGVycm9ycyBkdXJpbmcgcHJlZmV0Y2hcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3I6IGVyclxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIHByZWZldGNoIChyb3V0ZSkge1xuICAgICAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZUxhYnMvcXVpY2tsaW5rL2Jsb2IvNDUzYTY2MWZhMWZhOTQwZTJkMmUwNDQ0NTIzOThlMzhjNjdhOThmYi9zcmMvaW5kZXgubWpzI0wxMTUtTDExOFxuICAgICAgICAgICAgLy8gTGljZW5zZTogQXBhY2hlIDIuMFxuICAgICAgICAgICAgbGV0IGNuO1xuICAgICAgICAgICAgaWYgKGNuID0gbmF2aWdhdG9yLmNvbm5lY3Rpb24pIHtcbiAgICAgICAgICAgICAgICAvLyBEb24ndCBwcmVmZXRjaCBpZiB1c2luZyAyRyBvciBpZiBTYXZlLURhdGEgaXMgZW5hYmxlZC5cbiAgICAgICAgICAgICAgICBpZiAoY24uc2F2ZURhdGEgfHwgLzJnLy50ZXN0KGNuLmVmZmVjdGl2ZVR5cGUpKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZ2V0RmlsZXNGb3JSb3V0ZShhc3NldFByZWZpeCwgcm91dGUpLnRoZW4oKG91dHB1dCk9PlByb21pc2UuYWxsKGNhblByZWZldGNoID8gb3V0cHV0LnNjcmlwdHMubWFwKChzY3JpcHQpPT5wcmVmZXRjaFZpYURvbShzY3JpcHQsICdzY3JpcHQnKVxuICAgICAgICAgICAgICAgICkgOiBbXSlcbiAgICAgICAgICAgICkudGhlbigoKT0+e1xuICAgICAgICAgICAgICAgICgwLCBfcmVxdWVzdElkbGVDYWxsYmFjaykucmVxdWVzdElkbGVDYWxsYmFjaygoKT0+dGhpcy5sb2FkUm91dGUocm91dGUsIHRydWUpLmNhdGNoKCgpPT57XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pLmNhdGNoKC8vIHN3YWxsb3cgcHJlZmV0Y2ggZXJyb3JzXG4gICAgICAgICAgICAoKT0+e1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xufVxuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZS1sb2FkZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJSb3V0ZXJcIiwge1xuICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIF9yb3V0ZXIuZGVmYXVsdDtcbiAgICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIndpdGhSb3V0ZXJcIiwge1xuICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIF93aXRoUm91dGVyLmRlZmF1bHQ7XG4gICAgfVxufSk7XG5leHBvcnRzLnVzZVJvdXRlciA9IHVzZVJvdXRlcjtcbmV4cG9ydHMuY3JlYXRlUm91dGVyID0gY3JlYXRlUm91dGVyO1xuZXhwb3J0cy5tYWtlUHVibGljUm91dGVySW5zdGFuY2UgPSBtYWtlUHVibGljUm91dGVySW5zdGFuY2U7XG5leHBvcnRzLmRlZmF1bHQgPSB2b2lkIDA7XG52YXIgX3JlYWN0ID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3RcIikpO1xudmFyIF9yb3V0ZXIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuLi9zaGFyZWQvbGliL3JvdXRlci9yb3V0ZXJcIikpO1xudmFyIF9yb3V0ZXJDb250ZXh0ID0gcmVxdWlyZShcIi4uL3NoYXJlZC9saWIvcm91dGVyLWNvbnRleHRcIik7XG52YXIgX3dpdGhSb3V0ZXIgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuL3dpdGgtcm91dGVyXCIpKTtcbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmNvbnN0IHNpbmdsZXRvblJvdXRlciA9IHtcbiAgICByb3V0ZXI6IG51bGwsXG4gICAgcmVhZHlDYWxsYmFja3M6IFtdLFxuICAgIHJlYWR5IChjYikge1xuICAgICAgICBpZiAodGhpcy5yb3V0ZXIpIHJldHVybiBjYigpO1xuICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIHRoaXMucmVhZHlDYWxsYmFja3MucHVzaChjYik7XG4gICAgICAgIH1cbiAgICB9XG59O1xuLy8gQ3JlYXRlIHB1YmxpYyBwcm9wZXJ0aWVzIGFuZCBtZXRob2RzIG9mIHRoZSByb3V0ZXIgaW4gdGhlIHNpbmdsZXRvblJvdXRlclxuY29uc3QgdXJsUHJvcGVydHlGaWVsZHMgPSBbXG4gICAgJ3BhdGhuYW1lJyxcbiAgICAncm91dGUnLFxuICAgICdxdWVyeScsXG4gICAgJ2FzUGF0aCcsXG4gICAgJ2NvbXBvbmVudHMnLFxuICAgICdpc0ZhbGxiYWNrJyxcbiAgICAnYmFzZVBhdGgnLFxuICAgICdsb2NhbGUnLFxuICAgICdsb2NhbGVzJyxcbiAgICAnZGVmYXVsdExvY2FsZScsXG4gICAgJ2lzUmVhZHknLFxuICAgICdpc1ByZXZpZXcnLFxuICAgICdpc0xvY2FsZURvbWFpbicsXG4gICAgJ2RvbWFpbkxvY2FsZXMnLCBcbl07XG5jb25zdCByb3V0ZXJFdmVudHMgPSBbXG4gICAgJ3JvdXRlQ2hhbmdlU3RhcnQnLFxuICAgICdiZWZvcmVIaXN0b3J5Q2hhbmdlJyxcbiAgICAncm91dGVDaGFuZ2VDb21wbGV0ZScsXG4gICAgJ3JvdXRlQ2hhbmdlRXJyb3InLFxuICAgICdoYXNoQ2hhbmdlU3RhcnQnLFxuICAgICdoYXNoQ2hhbmdlQ29tcGxldGUnLCBcbl07XG5jb25zdCBjb3JlTWV0aG9kRmllbGRzID0gW1xuICAgICdwdXNoJyxcbiAgICAncmVwbGFjZScsXG4gICAgJ3JlbG9hZCcsXG4gICAgJ2JhY2snLFxuICAgICdwcmVmZXRjaCcsXG4gICAgJ2JlZm9yZVBvcFN0YXRlJywgXG5dO1xuLy8gRXZlbnRzIGlzIGEgc3RhdGljIHByb3BlcnR5IG9uIHRoZSByb3V0ZXIsIHRoZSByb3V0ZXIgZG9lc24ndCBoYXZlIHRvIGJlIGluaXRpYWxpemVkIHRvIHVzZSBpdFxuT2JqZWN0LmRlZmluZVByb3BlcnR5KHNpbmdsZXRvblJvdXRlciwgJ2V2ZW50cycsIHtcbiAgICBnZXQgKCkge1xuICAgICAgICByZXR1cm4gX3JvdXRlci5kZWZhdWx0LmV2ZW50cztcbiAgICB9XG59KTtcbnVybFByb3BlcnR5RmllbGRzLmZvckVhY2goKGZpZWxkKT0+e1xuICAgIC8vIEhlcmUgd2UgbmVlZCB0byB1c2UgT2JqZWN0LmRlZmluZVByb3BlcnR5IGJlY2F1c2Ugd2UgbmVlZCB0byByZXR1cm5cbiAgICAvLyB0aGUgcHJvcGVydHkgYXNzaWduZWQgdG8gdGhlIGFjdHVhbCByb3V0ZXJcbiAgICAvLyBUaGUgdmFsdWUgbWlnaHQgZ2V0IGNoYW5nZWQgYXMgd2UgY2hhbmdlIHJvdXRlcyBhbmQgdGhpcyBpcyB0aGVcbiAgICAvLyBwcm9wZXIgd2F5IHRvIGFjY2VzcyBpdFxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShzaW5nbGV0b25Sb3V0ZXIsIGZpZWxkLCB7XG4gICAgICAgIGdldCAoKSB7XG4gICAgICAgICAgICBjb25zdCByb3V0ZXIgPSBnZXRSb3V0ZXIoKTtcbiAgICAgICAgICAgIHJldHVybiByb3V0ZXJbZmllbGRdO1xuICAgICAgICB9XG4gICAgfSk7XG59KTtcbmNvcmVNZXRob2RGaWVsZHMuZm9yRWFjaCgoZmllbGQpPT57XG4gICAgc2luZ2xldG9uUm91dGVyW2ZpZWxkXSA9ICguLi5hcmdzKT0+e1xuICAgICAgICBjb25zdCByb3V0ZXIgPSBnZXRSb3V0ZXIoKTtcbiAgICAgICAgcmV0dXJuIHJvdXRlcltmaWVsZF0oLi4uYXJncyk7XG4gICAgfTtcbn0pO1xucm91dGVyRXZlbnRzLmZvckVhY2goKGV2ZW50KT0+e1xuICAgIHNpbmdsZXRvblJvdXRlci5yZWFkeSgoKT0+e1xuICAgICAgICBfcm91dGVyLmRlZmF1bHQuZXZlbnRzLm9uKGV2ZW50LCAoLi4uYXJncyk9PntcbiAgICAgICAgICAgIGNvbnN0IGV2ZW50RmllbGQgPSBgb24ke2V2ZW50LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfSR7ZXZlbnQuc3Vic3RyaW5nKDEpfWA7XG4gICAgICAgICAgICBjb25zdCBfc2luZ2xldG9uUm91dGVyID0gc2luZ2xldG9uUm91dGVyO1xuICAgICAgICAgICAgaWYgKF9zaW5nbGV0b25Sb3V0ZXJbZXZlbnRGaWVsZF0pIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBfc2luZ2xldG9uUm91dGVyW2V2ZW50RmllbGRdKC4uLmFyZ3MpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciB3aGVuIHJ1bm5pbmcgdGhlIFJvdXRlciBldmVudDogJHtldmVudEZpZWxkfWApO1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGAke2Vyci5tZXNzYWdlfVxcbiR7ZXJyLnN0YWNrfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG59KTtcbmZ1bmN0aW9uIGdldFJvdXRlcigpIHtcbiAgICBpZiAoIXNpbmdsZXRvblJvdXRlci5yb3V0ZXIpIHtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9ICdObyByb3V0ZXIgaW5zdGFuY2UgZm91bmQuXFxuJyArICdZb3Ugc2hvdWxkIG9ubHkgdXNlIFwibmV4dC9yb3V0ZXJcIiBvbiB0aGUgY2xpZW50IHNpZGUgb2YgeW91ciBhcHAuXFxuJztcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xuICAgIH1cbiAgICByZXR1cm4gc2luZ2xldG9uUm91dGVyLnJvdXRlcjtcbn1cbnZhciBfZGVmYXVsdCA9IHNpbmdsZXRvblJvdXRlcjtcbmV4cG9ydHMuZGVmYXVsdCA9IF9kZWZhdWx0O1xuZnVuY3Rpb24gdXNlUm91dGVyKCkge1xuICAgIHJldHVybiBfcmVhY3QuZGVmYXVsdC51c2VDb250ZXh0KF9yb3V0ZXJDb250ZXh0LlJvdXRlckNvbnRleHQpO1xufVxuZnVuY3Rpb24gY3JlYXRlUm91dGVyKC4uLmFyZ3MpIHtcbiAgICBzaW5nbGV0b25Sb3V0ZXIucm91dGVyID0gbmV3IF9yb3V0ZXIuZGVmYXVsdCguLi5hcmdzKTtcbiAgICBzaW5nbGV0b25Sb3V0ZXIucmVhZHlDYWxsYmFja3MuZm9yRWFjaCgoY2IpPT5jYigpXG4gICAgKTtcbiAgICBzaW5nbGV0b25Sb3V0ZXIucmVhZHlDYWxsYmFja3MgPSBbXTtcbiAgICByZXR1cm4gc2luZ2xldG9uUm91dGVyLnJvdXRlcjtcbn1cbmZ1bmN0aW9uIG1ha2VQdWJsaWNSb3V0ZXJJbnN0YW5jZShyb3V0ZXIpIHtcbiAgICBjb25zdCBfcm91dGVyMSA9IHJvdXRlcjtcbiAgICBjb25zdCBpbnN0YW5jZSA9IHtcbiAgICB9O1xuICAgIGZvciAoY29uc3QgcHJvcGVydHkgb2YgdXJsUHJvcGVydHlGaWVsZHMpe1xuICAgICAgICBpZiAodHlwZW9mIF9yb3V0ZXIxW3Byb3BlcnR5XSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgIGluc3RhbmNlW3Byb3BlcnR5XSA9IE9iamVjdC5hc3NpZ24oQXJyYXkuaXNBcnJheShfcm91dGVyMVtwcm9wZXJ0eV0pID8gW10gOiB7XG4gICAgICAgICAgICB9LCBfcm91dGVyMVtwcm9wZXJ0eV0pIC8vIG1ha2VzIHN1cmUgcXVlcnkgaXMgbm90IHN0YXRlZnVsXG4gICAgICAgICAgICA7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpbnN0YW5jZVtwcm9wZXJ0eV0gPSBfcm91dGVyMVtwcm9wZXJ0eV07XG4gICAgfVxuICAgIC8vIEV2ZW50cyBpcyBhIHN0YXRpYyBwcm9wZXJ0eSBvbiB0aGUgcm91dGVyLCB0aGUgcm91dGVyIGRvZXNuJ3QgaGF2ZSB0byBiZSBpbml0aWFsaXplZCB0byB1c2UgaXRcbiAgICBpbnN0YW5jZS5ldmVudHMgPSBfcm91dGVyLmRlZmF1bHQuZXZlbnRzO1xuICAgIGNvcmVNZXRob2RGaWVsZHMuZm9yRWFjaCgoZmllbGQpPT57XG4gICAgICAgIGluc3RhbmNlW2ZpZWxkXSA9ICguLi5hcmdzKT0+e1xuICAgICAgICAgICAgcmV0dXJuIF9yb3V0ZXIxW2ZpZWxkXSguLi5hcmdzKTtcbiAgICAgICAgfTtcbiAgICB9KTtcbiAgICByZXR1cm4gaW5zdGFuY2U7XG59XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlci5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMudXNlSW50ZXJzZWN0aW9uID0gdXNlSW50ZXJzZWN0aW9uO1xudmFyIF9yZWFjdCA9IHJlcXVpcmUoXCJyZWFjdFwiKTtcbnZhciBfcmVxdWVzdElkbGVDYWxsYmFjayA9IHJlcXVpcmUoXCIuL3JlcXVlc3QtaWRsZS1jYWxsYmFja1wiKTtcbmNvbnN0IGhhc0ludGVyc2VjdGlvbk9ic2VydmVyID0gdHlwZW9mIEludGVyc2VjdGlvbk9ic2VydmVyICE9PSAndW5kZWZpbmVkJztcbmZ1bmN0aW9uIHVzZUludGVyc2VjdGlvbih7IHJvb3RNYXJnaW4gLCBkaXNhYmxlZCAgfSkge1xuICAgIGNvbnN0IGlzRGlzYWJsZWQgPSBkaXNhYmxlZCB8fCAhaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXI7XG4gICAgY29uc3QgdW5vYnNlcnZlID0gKDAsIF9yZWFjdCkudXNlUmVmKCk7XG4gICAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gKDAsIF9yZWFjdCkudXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IHNldFJlZiA9ICgwLCBfcmVhY3QpLnVzZUNhbGxiYWNrKChlbCk9PntcbiAgICAgICAgaWYgKHVub2JzZXJ2ZS5jdXJyZW50KSB7XG4gICAgICAgICAgICB1bm9ic2VydmUuY3VycmVudCgpO1xuICAgICAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQgPSB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzRGlzYWJsZWQgfHwgdmlzaWJsZSkgcmV0dXJuO1xuICAgICAgICBpZiAoZWwgJiYgZWwudGFnTmFtZSkge1xuICAgICAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQgPSBvYnNlcnZlKGVsLCAoaXNWaXNpYmxlKT0+aXNWaXNpYmxlICYmIHNldFZpc2libGUoaXNWaXNpYmxlKVxuICAgICAgICAgICAgLCB7XG4gICAgICAgICAgICAgICAgcm9vdE1hcmdpblxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIGlzRGlzYWJsZWQsXG4gICAgICAgIHJvb3RNYXJnaW4sXG4gICAgICAgIHZpc2libGVcbiAgICBdKTtcbiAgICAoMCwgX3JlYWN0KS51c2VFZmZlY3QoKCk9PntcbiAgICAgICAgaWYgKCFoYXNJbnRlcnNlY3Rpb25PYnNlcnZlcikge1xuICAgICAgICAgICAgaWYgKCF2aXNpYmxlKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaWRsZUNhbGxiYWNrID0gKDAsIF9yZXF1ZXN0SWRsZUNhbGxiYWNrKS5yZXF1ZXN0SWRsZUNhbGxiYWNrKCgpPT5zZXRWaXNpYmxlKHRydWUpXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gKCk9PigwLCBfcmVxdWVzdElkbGVDYWxsYmFjaykuY2FuY2VsSWRsZUNhbGxiYWNrKGlkbGVDYWxsYmFjaylcbiAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbXG4gICAgICAgIHZpc2libGVcbiAgICBdKTtcbiAgICByZXR1cm4gW1xuICAgICAgICBzZXRSZWYsXG4gICAgICAgIHZpc2libGVcbiAgICBdO1xufVxuZnVuY3Rpb24gb2JzZXJ2ZShlbGVtZW50LCBjYWxsYmFjaywgb3B0aW9ucykge1xuICAgIGNvbnN0IHsgaWQgLCBvYnNlcnZlciAsIGVsZW1lbnRzICB9ID0gY3JlYXRlT2JzZXJ2ZXIob3B0aW9ucyk7XG4gICAgZWxlbWVudHMuc2V0KGVsZW1lbnQsIGNhbGxiYWNrKTtcbiAgICBvYnNlcnZlci5vYnNlcnZlKGVsZW1lbnQpO1xuICAgIHJldHVybiBmdW5jdGlvbiB1bm9ic2VydmUoKSB7XG4gICAgICAgIGVsZW1lbnRzLmRlbGV0ZShlbGVtZW50KTtcbiAgICAgICAgb2JzZXJ2ZXIudW5vYnNlcnZlKGVsZW1lbnQpO1xuICAgICAgICAvLyBEZXN0cm95IG9ic2VydmVyIHdoZW4gdGhlcmUncyBub3RoaW5nIGxlZnQgdG8gd2F0Y2g6XG4gICAgICAgIGlmIChlbGVtZW50cy5zaXplID09PSAwKSB7XG4gICAgICAgICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgICAgICAgICBvYnNlcnZlcnMuZGVsZXRlKGlkKTtcbiAgICAgICAgfVxuICAgIH07XG59XG5jb25zdCBvYnNlcnZlcnMgPSBuZXcgTWFwKCk7XG5mdW5jdGlvbiBjcmVhdGVPYnNlcnZlcihvcHRpb25zKSB7XG4gICAgY29uc3QgaWQgPSBvcHRpb25zLnJvb3RNYXJnaW4gfHwgJyc7XG4gICAgbGV0IGluc3RhbmNlID0gb2JzZXJ2ZXJzLmdldChpZCk7XG4gICAgaWYgKGluc3RhbmNlKSB7XG4gICAgICAgIHJldHVybiBpbnN0YW5jZTtcbiAgICB9XG4gICAgY29uc3QgZWxlbWVudHMgPSBuZXcgTWFwKCk7XG4gICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKGVudHJpZXMpPT57XG4gICAgICAgIGVudHJpZXMuZm9yRWFjaCgoZW50cnkpPT57XG4gICAgICAgICAgICBjb25zdCBjYWxsYmFjayA9IGVsZW1lbnRzLmdldChlbnRyeS50YXJnZXQpO1xuICAgICAgICAgICAgY29uc3QgaXNWaXNpYmxlID0gZW50cnkuaXNJbnRlcnNlY3RpbmcgfHwgZW50cnkuaW50ZXJzZWN0aW9uUmF0aW8gPiAwO1xuICAgICAgICAgICAgaWYgKGNhbGxiYWNrICYmIGlzVmlzaWJsZSkge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKGlzVmlzaWJsZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0sIG9wdGlvbnMpO1xuICAgIG9ic2VydmVycy5zZXQoaWQsIGluc3RhbmNlID0ge1xuICAgICAgICBpZCxcbiAgICAgICAgb2JzZXJ2ZXIsXG4gICAgICAgIGVsZW1lbnRzXG4gICAgfSk7XG4gICAgcmV0dXJuIGluc3RhbmNlO1xufVxuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2UtaW50ZXJzZWN0aW9uLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy5kZWZhdWx0ID0gd2l0aFJvdXRlcjtcbnZhciBfcmVhY3QgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJyZWFjdFwiKSk7XG52YXIgX3JvdXRlciA9IHJlcXVpcmUoXCIuL3JvdXRlclwiKTtcbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmZ1bmN0aW9uIHdpdGhSb3V0ZXIoQ29tcG9zZWRDb21wb25lbnQpIHtcbiAgICBmdW5jdGlvbiBXaXRoUm91dGVyV3JhcHBlcihwcm9wcykge1xuICAgICAgICByZXR1cm4oLyojX19QVVJFX18qLyBfcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KENvbXBvc2VkQ29tcG9uZW50LCBPYmplY3QuYXNzaWduKHtcbiAgICAgICAgICAgIHJvdXRlcjogKDAsIF9yb3V0ZXIpLnVzZVJvdXRlcigpXG4gICAgICAgIH0sIHByb3BzKSkpO1xuICAgIH1cbiAgICBXaXRoUm91dGVyV3JhcHBlci5nZXRJbml0aWFsUHJvcHMgPSBDb21wb3NlZENvbXBvbmVudC5nZXRJbml0aWFsUHJvcHM7XG4gICAgV2l0aFJvdXRlcldyYXBwZXIub3JpZ0dldEluaXRpYWxQcm9wcyA9IENvbXBvc2VkQ29tcG9uZW50Lm9yaWdHZXRJbml0aWFsUHJvcHM7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgY29uc3QgbmFtZSA9IENvbXBvc2VkQ29tcG9uZW50LmRpc3BsYXlOYW1lIHx8IENvbXBvc2VkQ29tcG9uZW50Lm5hbWUgfHwgJ1Vua25vd24nO1xuICAgICAgICBXaXRoUm91dGVyV3JhcHBlci5kaXNwbGF5TmFtZSA9IGB3aXRoUm91dGVyKCR7bmFtZX0pYDtcbiAgICB9XG4gICAgcmV0dXJuIFdpdGhSb3V0ZXJXcmFwcGVyO1xufVxuXG4vLyMgc291cmNlTWFwcGluZ1VSTD13aXRoLXJvdXRlci5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMuZ2V0RG9tYWluTG9jYWxlID0gZ2V0RG9tYWluTG9jYWxlO1xuZXhwb3J0cy5hZGRMb2NhbGUgPSBhZGRMb2NhbGU7XG5leHBvcnRzLmRlbExvY2FsZSA9IGRlbExvY2FsZTtcbmV4cG9ydHMuaGFzQmFzZVBhdGggPSBoYXNCYXNlUGF0aDtcbmV4cG9ydHMuYWRkQmFzZVBhdGggPSBhZGRCYXNlUGF0aDtcbmV4cG9ydHMuZGVsQmFzZVBhdGggPSBkZWxCYXNlUGF0aDtcbmV4cG9ydHMuaXNMb2NhbFVSTCA9IGlzTG9jYWxVUkw7XG5leHBvcnRzLmludGVycG9sYXRlQXMgPSBpbnRlcnBvbGF0ZUFzO1xuZXhwb3J0cy5yZXNvbHZlSHJlZiA9IHJlc29sdmVIcmVmO1xuZXhwb3J0cy5kZWZhdWx0ID0gdm9pZCAwO1xudmFyIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoID0gcmVxdWlyZShcIi4uLy4uLy4uL2NsaWVudC9ub3JtYWxpemUtdHJhaWxpbmctc2xhc2hcIik7XG52YXIgX3JvdXRlTG9hZGVyID0gcmVxdWlyZShcIi4uLy4uLy4uL2NsaWVudC9yb3V0ZS1sb2FkZXJcIik7XG52YXIgX2Rlbm9ybWFsaXplUGFnZVBhdGggPSByZXF1aXJlKFwiLi4vLi4vLi4vc2VydmVyL2Rlbm9ybWFsaXplLXBhZ2UtcGF0aFwiKTtcbnZhciBfbm9ybWFsaXplTG9jYWxlUGF0aCA9IHJlcXVpcmUoXCIuLi9pMThuL25vcm1hbGl6ZS1sb2NhbGUtcGF0aFwiKTtcbnZhciBfbWl0dCA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4uL21pdHRcIikpO1xudmFyIF91dGlscyA9IHJlcXVpcmUoXCIuLi91dGlsc1wiKTtcbnZhciBfaXNEeW5hbWljID0gcmVxdWlyZShcIi4vdXRpbHMvaXMtZHluYW1pY1wiKTtcbnZhciBfcGFyc2VSZWxhdGl2ZVVybCA9IHJlcXVpcmUoXCIuL3V0aWxzL3BhcnNlLXJlbGF0aXZlLXVybFwiKTtcbnZhciBfcXVlcnlzdHJpbmcgPSByZXF1aXJlKFwiLi91dGlscy9xdWVyeXN0cmluZ1wiKTtcbnZhciBfcmVzb2x2ZVJld3JpdGVzID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi91dGlscy9yZXNvbHZlLXJld3JpdGVzXCIpKTtcbnZhciBfcm91dGVNYXRjaGVyID0gcmVxdWlyZShcIi4vdXRpbHMvcm91dGUtbWF0Y2hlclwiKTtcbnZhciBfcm91dGVSZWdleCA9IHJlcXVpcmUoXCIuL3V0aWxzL3JvdXRlLXJlZ2V4XCIpO1xuZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgICByZXR1cm4gb2JqICYmIG9iai5fX2VzTW9kdWxlID8gb2JqIDoge1xuICAgICAgICBkZWZhdWx0OiBvYmpcbiAgICB9O1xufVxubGV0IGRldGVjdERvbWFpbkxvY2FsZTtcbmlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgZGV0ZWN0RG9tYWluTG9jYWxlID0gcmVxdWlyZSgnLi4vaTE4bi9kZXRlY3QtZG9tYWluLWxvY2FsZScpLmRldGVjdERvbWFpbkxvY2FsZTtcbn1cbmNvbnN0IGJhc2VQYXRoID0gcHJvY2Vzcy5lbnYuX19ORVhUX1JPVVRFUl9CQVNFUEFUSCB8fCAnJztcbmZ1bmN0aW9uIGJ1aWxkQ2FuY2VsbGF0aW9uRXJyb3IoKSB7XG4gICAgcmV0dXJuIE9iamVjdC5hc3NpZ24obmV3IEVycm9yKCdSb3V0ZSBDYW5jZWxsZWQnKSwge1xuICAgICAgICBjYW5jZWxsZWQ6IHRydWVcbiAgICB9KTtcbn1cbmZ1bmN0aW9uIGFkZFBhdGhQcmVmaXgocGF0aCwgcHJlZml4KSB7XG4gICAgcmV0dXJuIHByZWZpeCAmJiBwYXRoLnN0YXJ0c1dpdGgoJy8nKSA/IHBhdGggPT09ICcvJyA/ICgwLCBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCkubm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2gocHJlZml4KSA6IGAke3ByZWZpeH0ke3BhdGhOb1F1ZXJ5SGFzaChwYXRoKSA9PT0gJy8nID8gcGF0aC5zdWJzdHJpbmcoMSkgOiBwYXRofWAgOiBwYXRoO1xufVxuZnVuY3Rpb24gZ2V0RG9tYWluTG9jYWxlKHBhdGgsIGxvY2FsZSwgbG9jYWxlcywgZG9tYWluTG9jYWxlcykge1xuICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgIGxvY2FsZSA9IGxvY2FsZSB8fCAoMCwgX25vcm1hbGl6ZUxvY2FsZVBhdGgpLm5vcm1hbGl6ZUxvY2FsZVBhdGgocGF0aCwgbG9jYWxlcykuZGV0ZWN0ZWRMb2NhbGU7XG4gICAgICAgIGNvbnN0IGRldGVjdGVkRG9tYWluID0gZGV0ZWN0RG9tYWluTG9jYWxlKGRvbWFpbkxvY2FsZXMsIHVuZGVmaW5lZCwgbG9jYWxlKTtcbiAgICAgICAgaWYgKGRldGVjdGVkRG9tYWluKSB7XG4gICAgICAgICAgICByZXR1cm4gYGh0dHAke2RldGVjdGVkRG9tYWluLmh0dHAgPyAnJyA6ICdzJ306Ly8ke2RldGVjdGVkRG9tYWluLmRvbWFpbn0ke2Jhc2VQYXRoIHx8ICcnfSR7bG9jYWxlID09PSBkZXRlY3RlZERvbWFpbi5kZWZhdWx0TG9jYWxlID8gJycgOiBgLyR7bG9jYWxlfWB9JHtwYXRofWA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG5mdW5jdGlvbiBhZGRMb2NhbGUocGF0aCwgbG9jYWxlLCBkZWZhdWx0TG9jYWxlKSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgICAgY29uc3QgcGF0aG5hbWUgPSBwYXRoTm9RdWVyeUhhc2gocGF0aCk7XG4gICAgICAgIGNvbnN0IHBhdGhMb3dlciA9IHBhdGhuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGNvbnN0IGxvY2FsZUxvd2VyID0gbG9jYWxlICYmIGxvY2FsZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICByZXR1cm4gbG9jYWxlICYmIGxvY2FsZSAhPT0gZGVmYXVsdExvY2FsZSAmJiAhcGF0aExvd2VyLnN0YXJ0c1dpdGgoJy8nICsgbG9jYWxlTG93ZXIgKyAnLycpICYmIHBhdGhMb3dlciAhPT0gJy8nICsgbG9jYWxlTG93ZXIgPyBhZGRQYXRoUHJlZml4KHBhdGgsICcvJyArIGxvY2FsZSkgOiBwYXRoO1xuICAgIH1cbiAgICByZXR1cm4gcGF0aDtcbn1cbmZ1bmN0aW9uIGRlbExvY2FsZShwYXRoLCBsb2NhbGUpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCkge1xuICAgICAgICBjb25zdCBwYXRobmFtZSA9IHBhdGhOb1F1ZXJ5SGFzaChwYXRoKTtcbiAgICAgICAgY29uc3QgcGF0aExvd2VyID0gcGF0aG5hbWUudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgY29uc3QgbG9jYWxlTG93ZXIgPSBsb2NhbGUgJiYgbG9jYWxlLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIHJldHVybiBsb2NhbGUgJiYgKHBhdGhMb3dlci5zdGFydHNXaXRoKCcvJyArIGxvY2FsZUxvd2VyICsgJy8nKSB8fCBwYXRoTG93ZXIgPT09ICcvJyArIGxvY2FsZUxvd2VyKSA/IChwYXRobmFtZS5sZW5ndGggPT09IGxvY2FsZS5sZW5ndGggKyAxID8gJy8nIDogJycpICsgcGF0aC5zdWJzdHIobG9jYWxlLmxlbmd0aCArIDEpIDogcGF0aDtcbiAgICB9XG4gICAgcmV0dXJuIHBhdGg7XG59XG5mdW5jdGlvbiBwYXRoTm9RdWVyeUhhc2gocGF0aCkge1xuICAgIGNvbnN0IHF1ZXJ5SW5kZXggPSBwYXRoLmluZGV4T2YoJz8nKTtcbiAgICBjb25zdCBoYXNoSW5kZXggPSBwYXRoLmluZGV4T2YoJyMnKTtcbiAgICBpZiAocXVlcnlJbmRleCA+IC0xIHx8IGhhc2hJbmRleCA+IC0xKSB7XG4gICAgICAgIHBhdGggPSBwYXRoLnN1YnN0cmluZygwLCBxdWVyeUluZGV4ID4gLTEgPyBxdWVyeUluZGV4IDogaGFzaEluZGV4KTtcbiAgICB9XG4gICAgcmV0dXJuIHBhdGg7XG59XG5mdW5jdGlvbiBoYXNCYXNlUGF0aChwYXRoKSB7XG4gICAgcGF0aCA9IHBhdGhOb1F1ZXJ5SGFzaChwYXRoKTtcbiAgICByZXR1cm4gcGF0aCA9PT0gYmFzZVBhdGggfHwgcGF0aC5zdGFydHNXaXRoKGJhc2VQYXRoICsgJy8nKTtcbn1cbmZ1bmN0aW9uIGFkZEJhc2VQYXRoKHBhdGgpIHtcbiAgICAvLyB3ZSBvbmx5IGFkZCB0aGUgYmFzZXBhdGggb24gcmVsYXRpdmUgdXJsc1xuICAgIHJldHVybiBhZGRQYXRoUHJlZml4KHBhdGgsIGJhc2VQYXRoKTtcbn1cbmZ1bmN0aW9uIGRlbEJhc2VQYXRoKHBhdGgpIHtcbiAgICBwYXRoID0gcGF0aC5zbGljZShiYXNlUGF0aC5sZW5ndGgpO1xuICAgIGlmICghcGF0aC5zdGFydHNXaXRoKCcvJykpIHBhdGggPSBgLyR7cGF0aH1gO1xuICAgIHJldHVybiBwYXRoO1xufVxuZnVuY3Rpb24gaXNMb2NhbFVSTCh1cmwpIHtcbiAgICAvLyBwcmV2ZW50IGEgaHlkcmF0aW9uIG1pc21hdGNoIG9uIGhyZWYgZm9yIHVybCB3aXRoIGFuY2hvciByZWZzXG4gICAgaWYgKHVybC5zdGFydHNXaXRoKCcvJykgfHwgdXJsLnN0YXJ0c1dpdGgoJyMnKSB8fCB1cmwuc3RhcnRzV2l0aCgnPycpKSByZXR1cm4gdHJ1ZTtcbiAgICB0cnkge1xuICAgICAgICAvLyBhYnNvbHV0ZSB1cmxzIGNhbiBiZSBsb2NhbCBpZiB0aGV5IGFyZSBvbiB0aGUgc2FtZSBvcmlnaW5cbiAgICAgICAgY29uc3QgbG9jYXRpb25PcmlnaW4gPSAoMCwgX3V0aWxzKS5nZXRMb2NhdGlvbk9yaWdpbigpO1xuICAgICAgICBjb25zdCByZXNvbHZlZCA9IG5ldyBVUkwodXJsLCBsb2NhdGlvbk9yaWdpbik7XG4gICAgICAgIHJldHVybiByZXNvbHZlZC5vcmlnaW4gPT09IGxvY2F0aW9uT3JpZ2luICYmIGhhc0Jhc2VQYXRoKHJlc29sdmVkLnBhdGhuYW1lKTtcbiAgICB9IGNhdGNoIChfKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG5mdW5jdGlvbiBpbnRlcnBvbGF0ZUFzKHJvdXRlLCBhc1BhdGhuYW1lLCBxdWVyeSkge1xuICAgIGxldCBpbnRlcnBvbGF0ZWRSb3V0ZSA9ICcnO1xuICAgIGNvbnN0IGR5bmFtaWNSZWdleCA9ICgwLCBfcm91dGVSZWdleCkuZ2V0Um91dGVSZWdleChyb3V0ZSk7XG4gICAgY29uc3QgZHluYW1pY0dyb3VwcyA9IGR5bmFtaWNSZWdleC5ncm91cHM7XG4gICAgY29uc3QgZHluYW1pY01hdGNoZXMgPSAvLyBUcnkgdG8gbWF0Y2ggdGhlIGR5bmFtaWMgcm91dGUgYWdhaW5zdCB0aGUgYXNQYXRoXG4gICAgKGFzUGF0aG5hbWUgIT09IHJvdXRlID8gKDAsIF9yb3V0ZU1hdGNoZXIpLmdldFJvdXRlTWF0Y2hlcihkeW5hbWljUmVnZXgpKGFzUGF0aG5hbWUpIDogJycpIHx8IC8vIEZhbGwgYmFjayB0byByZWFkaW5nIHRoZSB2YWx1ZXMgZnJvbSB0aGUgaHJlZlxuICAgIC8vIFRPRE86IHNob3VsZCB0aGlzIHRha2UgcHJpb3JpdHk7IGFsc28gbmVlZCB0byBjaGFuZ2UgaW4gdGhlIHJvdXRlci5cbiAgICBxdWVyeTtcbiAgICBpbnRlcnBvbGF0ZWRSb3V0ZSA9IHJvdXRlO1xuICAgIGNvbnN0IHBhcmFtcyA9IE9iamVjdC5rZXlzKGR5bmFtaWNHcm91cHMpO1xuICAgIGlmICghcGFyYW1zLmV2ZXJ5KChwYXJhbSk9PntcbiAgICAgICAgbGV0IHZhbHVlID0gZHluYW1pY01hdGNoZXNbcGFyYW1dIHx8ICcnO1xuICAgICAgICBjb25zdCB7IHJlcGVhdCAsIG9wdGlvbmFsICB9ID0gZHluYW1pY0dyb3Vwc1twYXJhbV07XG4gICAgICAgIC8vIHN1cHBvcnQgc2luZ2xlLWxldmVsIGNhdGNoLWFsbFxuICAgICAgICAvLyBUT0RPOiBtb3JlIHJvYnVzdCBoYW5kbGluZyBmb3IgdXNlci1lcnJvciAocGFzc2luZyBgL2ApXG4gICAgICAgIGxldCByZXBsYWNlZCA9IGBbJHtyZXBlYXQgPyAnLi4uJyA6ICcnfSR7cGFyYW19XWA7XG4gICAgICAgIGlmIChvcHRpb25hbCkge1xuICAgICAgICAgICAgcmVwbGFjZWQgPSBgJHshdmFsdWUgPyAnLycgOiAnJ31bJHtyZXBsYWNlZH1dYDtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVwZWF0ICYmICFBcnJheS5pc0FycmF5KHZhbHVlKSkgdmFsdWUgPSBbXG4gICAgICAgICAgICB2YWx1ZVxuICAgICAgICBdO1xuICAgICAgICByZXR1cm4gKG9wdGlvbmFsIHx8IHBhcmFtIGluIGR5bmFtaWNNYXRjaGVzKSAmJiAvLyBJbnRlcnBvbGF0ZSBncm91cCBpbnRvIGRhdGEgVVJMIGlmIHByZXNlbnRcbiAgICAgICAgKGludGVycG9sYXRlZFJvdXRlID0gaW50ZXJwb2xhdGVkUm91dGUucmVwbGFjZShyZXBsYWNlZCwgcmVwZWF0ID8gdmFsdWUubWFwKC8vIHRoZXNlIHZhbHVlcyBzaG91bGQgYmUgZnVsbHkgZW5jb2RlZCBpbnN0ZWFkIG9mIGp1c3RcbiAgICAgICAgLy8gcGF0aCBkZWxpbWl0ZXIgZXNjYXBlZCBzaW5jZSB0aGV5IGFyZSBiZWluZyBpbnNlcnRlZFxuICAgICAgICAvLyBpbnRvIHRoZSBVUkwgYW5kIHdlIGV4cGVjdCBVUkwgZW5jb2RlZCBzZWdtZW50c1xuICAgICAgICAvLyB3aGVuIHBhcnNpbmcgZHluYW1pYyByb3V0ZSBwYXJhbXNcbiAgICAgICAgKHNlZ21lbnQpPT5lbmNvZGVVUklDb21wb25lbnQoc2VnbWVudClcbiAgICAgICAgKS5qb2luKCcvJykgOiBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpKSB8fCAnLycpO1xuICAgIH0pKSB7XG4gICAgICAgIGludGVycG9sYXRlZFJvdXRlID0gJycgLy8gZGlkIG5vdCBzYXRpc2Z5IGFsbCByZXF1aXJlbWVudHNcbiAgICAgICAgO1xuICAgIC8vIG4uYi4gV2UgaWdub3JlIHRoaXMgZXJyb3IgYmVjYXVzZSB3ZSBoYW5kbGUgd2FybmluZyBmb3IgdGhpcyBjYXNlIGluXG4gICAgLy8gZGV2ZWxvcG1lbnQgaW4gdGhlIGA8TGluaz5gIGNvbXBvbmVudCBkaXJlY3RseS5cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcGFyYW1zLFxuICAgICAgICByZXN1bHQ6IGludGVycG9sYXRlZFJvdXRlXG4gICAgfTtcbn1cbmZ1bmN0aW9uIG9taXRQYXJtc0Zyb21RdWVyeShxdWVyeSwgcGFyYW1zKSB7XG4gICAgY29uc3QgZmlsdGVyZWRRdWVyeSA9IHtcbiAgICB9O1xuICAgIE9iamVjdC5rZXlzKHF1ZXJ5KS5mb3JFYWNoKChrZXkpPT57XG4gICAgICAgIGlmICghcGFyYW1zLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgICAgICAgIGZpbHRlcmVkUXVlcnlba2V5XSA9IHF1ZXJ5W2tleV07XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gZmlsdGVyZWRRdWVyeTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVIcmVmKHJvdXRlciwgaHJlZiwgcmVzb2x2ZUFzKSB7XG4gICAgLy8gd2UgdXNlIGEgZHVtbXkgYmFzZSB1cmwgZm9yIHJlbGF0aXZlIHVybHNcbiAgICBsZXQgYmFzZTtcbiAgICBsZXQgdXJsQXNTdHJpbmcgPSB0eXBlb2YgaHJlZiA9PT0gJ3N0cmluZycgPyBocmVmIDogKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oaHJlZik7XG4gICAgLy8gcmVwZWF0ZWQgc2xhc2hlcyBhbmQgYmFja3NsYXNoZXMgaW4gdGhlIFVSTCBhcmUgY29uc2lkZXJlZFxuICAgIC8vIGludmFsaWQgYW5kIHdpbGwgbmV2ZXIgbWF0Y2ggYSBOZXh0LmpzIHBhZ2UvZmlsZVxuICAgIGNvbnN0IHVybFByb3RvTWF0Y2ggPSB1cmxBc1N0cmluZy5tYXRjaCgvXlthLXpBLVpdezEsfTpcXC9cXC8vKTtcbiAgICBjb25zdCB1cmxBc1N0cmluZ05vUHJvdG8gPSB1cmxQcm90b01hdGNoID8gdXJsQXNTdHJpbmcuc3Vic3RyKHVybFByb3RvTWF0Y2hbMF0ubGVuZ3RoKSA6IHVybEFzU3RyaW5nO1xuICAgIGNvbnN0IHVybFBhcnRzID0gdXJsQXNTdHJpbmdOb1Byb3RvLnNwbGl0KCc/Jyk7XG4gICAgaWYgKCh1cmxQYXJ0c1swXSB8fCAnJykubWF0Y2goLyhcXC9cXC98XFxcXCkvKSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBJbnZhbGlkIGhyZWYgcGFzc2VkIHRvIG5leHQvcm91dGVyOiAke3VybEFzU3RyaW5nfSwgcmVwZWF0ZWQgZm9yd2FyZC1zbGFzaGVzICgvLykgb3IgYmFja3NsYXNoZXMgXFxcXCBhcmUgbm90IHZhbGlkIGluIHRoZSBocmVmYCk7XG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRVcmwgPSAoMCwgX3V0aWxzKS5ub3JtYWxpemVSZXBlYXRlZFNsYXNoZXModXJsQXNTdHJpbmdOb1Byb3RvKTtcbiAgICAgICAgdXJsQXNTdHJpbmcgPSAodXJsUHJvdG9NYXRjaCA/IHVybFByb3RvTWF0Y2hbMF0gOiAnJykgKyBub3JtYWxpemVkVXJsO1xuICAgIH1cbiAgICAvLyBSZXR1cm4gYmVjYXVzZSBpdCBjYW5ub3QgYmUgcm91dGVkIGJ5IHRoZSBOZXh0LmpzIHJvdXRlclxuICAgIGlmICghaXNMb2NhbFVSTCh1cmxBc1N0cmluZykpIHtcbiAgICAgICAgcmV0dXJuIHJlc29sdmVBcyA/IFtcbiAgICAgICAgICAgIHVybEFzU3RyaW5nXG4gICAgICAgIF0gOiB1cmxBc1N0cmluZztcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgYmFzZSA9IG5ldyBVUkwodXJsQXNTdHJpbmcuc3RhcnRzV2l0aCgnIycpID8gcm91dGVyLmFzUGF0aCA6IHJvdXRlci5wYXRobmFtZSwgJ2h0dHA6Ly9uJyk7XG4gICAgfSBjYXRjaCAoXykge1xuICAgICAgICAvLyBmYWxsYmFjayB0byAvIGZvciBpbnZhbGlkIGFzUGF0aCB2YWx1ZXMgZS5nLiAvL1xuICAgICAgICBiYXNlID0gbmV3IFVSTCgnLycsICdodHRwOi8vbicpO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICBjb25zdCBmaW5hbFVybCA9IG5ldyBVUkwodXJsQXNTdHJpbmcsIGJhc2UpO1xuICAgICAgICBmaW5hbFVybC5wYXRobmFtZSA9ICgwLCBfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCkubm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2goZmluYWxVcmwucGF0aG5hbWUpO1xuICAgICAgICBsZXQgaW50ZXJwb2xhdGVkQXMgPSAnJztcbiAgICAgICAgaWYgKCgwLCBfaXNEeW5hbWljKS5pc0R5bmFtaWNSb3V0ZShmaW5hbFVybC5wYXRobmFtZSkgJiYgZmluYWxVcmwuc2VhcmNoUGFyYW1zICYmIHJlc29sdmVBcykge1xuICAgICAgICAgICAgY29uc3QgcXVlcnkgPSAoMCwgX3F1ZXJ5c3RyaW5nKS5zZWFyY2hQYXJhbXNUb1VybFF1ZXJ5KGZpbmFsVXJsLnNlYXJjaFBhcmFtcyk7XG4gICAgICAgICAgICBjb25zdCB7IHJlc3VsdCAsIHBhcmFtcyAgfSA9IGludGVycG9sYXRlQXMoZmluYWxVcmwucGF0aG5hbWUsIGZpbmFsVXJsLnBhdGhuYW1lLCBxdWVyeSk7XG4gICAgICAgICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgaW50ZXJwb2xhdGVkQXMgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lOiByZXN1bHQsXG4gICAgICAgICAgICAgICAgICAgIGhhc2g6IGZpbmFsVXJsLmhhc2gsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBvbWl0UGFybXNGcm9tUXVlcnkocXVlcnksIHBhcmFtcylcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBpZiB0aGUgb3JpZ2luIGRpZG4ndCBjaGFuZ2UsIGl0IG1lYW5zIHdlIHJlY2VpdmVkIGEgcmVsYXRpdmUgaHJlZlxuICAgICAgICBjb25zdCByZXNvbHZlZEhyZWYgPSBmaW5hbFVybC5vcmlnaW4gPT09IGJhc2Uub3JpZ2luID8gZmluYWxVcmwuaHJlZi5zbGljZShmaW5hbFVybC5vcmlnaW4ubGVuZ3RoKSA6IGZpbmFsVXJsLmhyZWY7XG4gICAgICAgIHJldHVybiByZXNvbHZlQXMgPyBbXG4gICAgICAgICAgICByZXNvbHZlZEhyZWYsXG4gICAgICAgICAgICBpbnRlcnBvbGF0ZWRBcyB8fCByZXNvbHZlZEhyZWZcbiAgICAgICAgXSA6IHJlc29sdmVkSHJlZjtcbiAgICB9IGNhdGNoIChfKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlQXMgPyBbXG4gICAgICAgICAgICB1cmxBc1N0cmluZ1xuICAgICAgICBdIDogdXJsQXNTdHJpbmc7XG4gICAgfVxufVxuZnVuY3Rpb24gc3RyaXBPcmlnaW4odXJsKSB7XG4gICAgY29uc3Qgb3JpZ2luID0gKDAsIF91dGlscykuZ2V0TG9jYXRpb25PcmlnaW4oKTtcbiAgICByZXR1cm4gdXJsLnN0YXJ0c1dpdGgob3JpZ2luKSA/IHVybC5zdWJzdHJpbmcob3JpZ2luLmxlbmd0aCkgOiB1cmw7XG59XG5mdW5jdGlvbiBwcmVwYXJlVXJsQXMocm91dGVyLCB1cmwsIGFzKSB7XG4gICAgLy8gSWYgdXJsIGFuZCBhcyBwcm92aWRlZCBhcyBhbiBvYmplY3QgcmVwcmVzZW50YXRpb24sXG4gICAgLy8gd2UnbGwgZm9ybWF0IHRoZW0gaW50byB0aGUgc3RyaW5nIHZlcnNpb24gaGVyZS5cbiAgICBsZXQgW3Jlc29sdmVkSHJlZiwgcmVzb2x2ZWRBc10gPSByZXNvbHZlSHJlZihyb3V0ZXIsIHVybCwgdHJ1ZSk7XG4gICAgY29uc3Qgb3JpZ2luID0gKDAsIF91dGlscykuZ2V0TG9jYXRpb25PcmlnaW4oKTtcbiAgICBjb25zdCBocmVmSGFkT3JpZ2luID0gcmVzb2x2ZWRIcmVmLnN0YXJ0c1dpdGgob3JpZ2luKTtcbiAgICBjb25zdCBhc0hhZE9yaWdpbiA9IHJlc29sdmVkQXMgJiYgcmVzb2x2ZWRBcy5zdGFydHNXaXRoKG9yaWdpbik7XG4gICAgcmVzb2x2ZWRIcmVmID0gc3RyaXBPcmlnaW4ocmVzb2x2ZWRIcmVmKTtcbiAgICByZXNvbHZlZEFzID0gcmVzb2x2ZWRBcyA/IHN0cmlwT3JpZ2luKHJlc29sdmVkQXMpIDogcmVzb2x2ZWRBcztcbiAgICBjb25zdCBwcmVwYXJlZFVybCA9IGhyZWZIYWRPcmlnaW4gPyByZXNvbHZlZEhyZWYgOiBhZGRCYXNlUGF0aChyZXNvbHZlZEhyZWYpO1xuICAgIGNvbnN0IHByZXBhcmVkQXMgPSBhcyA/IHN0cmlwT3JpZ2luKHJlc29sdmVIcmVmKHJvdXRlciwgYXMpKSA6IHJlc29sdmVkQXMgfHwgcmVzb2x2ZWRIcmVmO1xuICAgIHJldHVybiB7XG4gICAgICAgIHVybDogcHJlcGFyZWRVcmwsXG4gICAgICAgIGFzOiBhc0hhZE9yaWdpbiA/IHByZXBhcmVkQXMgOiBhZGRCYXNlUGF0aChwcmVwYXJlZEFzKVxuICAgIH07XG59XG5mdW5jdGlvbiByZXNvbHZlRHluYW1pY1JvdXRlKHBhdGhuYW1lLCBwYWdlcykge1xuICAgIGNvbnN0IGNsZWFuUGF0aG5hbWUgPSAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLnJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKCgwLCBfZGVub3JtYWxpemVQYWdlUGF0aCkuZGVub3JtYWxpemVQYWdlUGF0aChwYXRobmFtZSkpO1xuICAgIGlmIChjbGVhblBhdGhuYW1lID09PSAnLzQwNCcgfHwgY2xlYW5QYXRobmFtZSA9PT0gJy9fZXJyb3InKSB7XG4gICAgICAgIHJldHVybiBwYXRobmFtZTtcbiAgICB9XG4gICAgLy8gaGFuZGxlIHJlc29sdmluZyBocmVmIGZvciBkeW5hbWljIHJvdXRlc1xuICAgIGlmICghcGFnZXMuaW5jbHVkZXMoY2xlYW5QYXRobmFtZSkpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGFycmF5LWNhbGxiYWNrLXJldHVyblxuICAgICAgICBwYWdlcy5zb21lKChwYWdlKT0+e1xuICAgICAgICAgICAgaWYgKCgwLCBfaXNEeW5hbWljKS5pc0R5bmFtaWNSb3V0ZShwYWdlKSAmJiAoMCwgX3JvdXRlUmVnZXgpLmdldFJvdXRlUmVnZXgocGFnZSkucmUudGVzdChjbGVhblBhdGhuYW1lKSkge1xuICAgICAgICAgICAgICAgIHBhdGhuYW1lID0gcGFnZTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLnJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGhuYW1lKTtcbn1cbmNvbnN0IG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uID0gcHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTiAmJiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiAnc2Nyb2xsUmVzdG9yYXRpb24nIGluIHdpbmRvdy5oaXN0b3J5ICYmICEhZnVuY3Rpb24oKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGV0IHYgPSAnX19uZXh0JztcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXNlcXVlbmNlc1xuICAgICAgICByZXR1cm4gc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSh2LCB2KSwgc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbSh2KSwgdHJ1ZTtcbiAgICB9IGNhdGNoIChuKSB7XG4gICAgfVxufSgpO1xuY29uc3QgU1NHX0RBVEFfTk9UX0ZPVU5EID0gU3ltYm9sKCdTU0dfREFUQV9OT1RfRk9VTkQnKTtcbmZ1bmN0aW9uIGZldGNoUmV0cnkodXJsLCBhdHRlbXB0cykge1xuICAgIHJldHVybiBmZXRjaCh1cmwsIHtcbiAgICAgICAgLy8gQ29va2llcyBhcmUgcmVxdWlyZWQgdG8gYmUgcHJlc2VudCBmb3IgTmV4dC5qcycgU1NHIFwiUHJldmlldyBNb2RlXCIuXG4gICAgICAgIC8vIENvb2tpZXMgbWF5IGFsc28gYmUgcmVxdWlyZWQgZm9yIGBnZXRTZXJ2ZXJTaWRlUHJvcHNgLlxuICAgICAgICAvL1xuICAgICAgICAvLyA+IGBmZXRjaGAgd29u4oCZdCBzZW5kIGNvb2tpZXMsIHVubGVzcyB5b3Ugc2V0IHRoZSBjcmVkZW50aWFscyBpbml0XG4gICAgICAgIC8vID4gb3B0aW9uLlxuICAgICAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvRmV0Y2hfQVBJL1VzaW5nX0ZldGNoXG4gICAgICAgIC8vXG4gICAgICAgIC8vID4gRm9yIG1heGltdW0gYnJvd3NlciBjb21wYXRpYmlsaXR5IHdoZW4gaXQgY29tZXMgdG8gc2VuZGluZyAmXG4gICAgICAgIC8vID4gcmVjZWl2aW5nIGNvb2tpZXMsIGFsd2F5cyBzdXBwbHkgdGhlIGBjcmVkZW50aWFsczogJ3NhbWUtb3JpZ2luJ2BcbiAgICAgICAgLy8gPiBvcHRpb24gaW5zdGVhZCBvZiByZWx5aW5nIG9uIHRoZSBkZWZhdWx0LlxuICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZ2l0aHViL2ZldGNoI2NhdmVhdHNcbiAgICAgICAgY3JlZGVudGlhbHM6ICdzYW1lLW9yaWdpbidcbiAgICB9KS50aGVuKChyZXMpPT57XG4gICAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgICAgICBpZiAoYXR0ZW1wdHMgPiAxICYmIHJlcy5zdGF0dXMgPj0gNTAwKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZldGNoUmV0cnkodXJsLCBhdHRlbXB0cyAtIDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgICAgICAgICAgIHJldHVybiByZXMuanNvbigpLnRoZW4oKGRhdGEpPT57XG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhLm5vdEZvdW5kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kOiBTU0dfREFUQV9OT1RfRk9VTkRcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gbG9hZCBzdGF0aWMgcHJvcHNgKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3RhdGljIHByb3BzYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlcy5qc29uKCk7XG4gICAgfSk7XG59XG5mdW5jdGlvbiBmZXRjaE5leHREYXRhKGRhdGFIcmVmLCBpc1NlcnZlclJlbmRlcikge1xuICAgIHJldHVybiBmZXRjaFJldHJ5KGRhdGFIcmVmLCBpc1NlcnZlclJlbmRlciA/IDMgOiAxKS5jYXRjaCgoZXJyKT0+e1xuICAgICAgICAvLyBXZSBzaG91bGQgb25seSB0cmlnZ2VyIGEgc2VydmVyLXNpZGUgdHJhbnNpdGlvbiBpZiB0aGlzIHdhcyBjYXVzZWRcbiAgICAgICAgLy8gb24gYSBjbGllbnQtc2lkZSB0cmFuc2l0aW9uLiBPdGhlcndpc2UsIHdlJ2QgZ2V0IGludG8gYW4gaW5maW5pdGVcbiAgICAgICAgLy8gbG9vcC5cbiAgICAgICAgaWYgKCFpc1NlcnZlclJlbmRlcikge1xuICAgICAgICAgICAgKDAsIF9yb3V0ZUxvYWRlcikubWFya0Fzc2V0RXJyb3IoZXJyKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBlcnI7XG4gICAgfSk7XG59XG5jbGFzcyBSb3V0ZXIge1xuICAgIGNvbnN0cnVjdG9yKHBhdGhuYW1lMSwgcXVlcnkxLCBhczEsIHsgaW5pdGlhbFByb3BzICwgcGFnZUxvYWRlciAsIEFwcCAsIHdyYXBBcHAgLCBDb21wb25lbnQ6IENvbXBvbmVudDEgLCBlcnI6IGVycjEgLCBzdWJzY3JpcHRpb24gLCBpc0ZhbGxiYWNrICwgbG9jYWxlICwgbG9jYWxlcyAsIGRlZmF1bHRMb2NhbGUgLCBkb21haW5Mb2NhbGVzICwgaXNQcmV2aWV3ICB9KXtcbiAgICAgICAgLy8gU3RhdGljIERhdGEgQ2FjaGVcbiAgICAgICAgdGhpcy5zZGMgPSB7XG4gICAgICAgIH07XG4gICAgICAgIC8vIEluLWZsaWdodCBTZXJ2ZXIgRGF0YSBSZXF1ZXN0cywgZm9yIGRlZHVwaW5nXG4gICAgICAgIHRoaXMuc2RyID0ge1xuICAgICAgICB9O1xuICAgICAgICB0aGlzLl9pZHggPSAwO1xuICAgICAgICB0aGlzLm9uUG9wU3RhdGUgPSAoZSk9PntcbiAgICAgICAgICAgIGNvbnN0IHN0YXRlID0gZS5zdGF0ZTtcbiAgICAgICAgICAgIGlmICghc3RhdGUpIHtcbiAgICAgICAgICAgICAgICAvLyBXZSBnZXQgc3RhdGUgYXMgdW5kZWZpbmVkIGZvciB0d28gcmVhc29ucy5cbiAgICAgICAgICAgICAgICAvLyAgMS4gV2l0aCBvbGRlciBzYWZhcmkgKDwgOCkgYW5kIG9sZGVyIGNocm9tZSAoPCAzNClcbiAgICAgICAgICAgICAgICAvLyAgMi4gV2hlbiB0aGUgVVJMIGNoYW5nZWQgd2l0aCAjXG4gICAgICAgICAgICAgICAgLy9cbiAgICAgICAgICAgICAgICAvLyBJbiB0aGUgYm90aCBjYXNlcywgd2UgZG9uJ3QgbmVlZCB0byBwcm9jZWVkIGFuZCBjaGFuZ2UgdGhlIHJvdXRlLlxuICAgICAgICAgICAgICAgIC8vIChhcyBpdCdzIGFscmVhZHkgY2hhbmdlZClcbiAgICAgICAgICAgICAgICAvLyBCdXQgd2UgY2FuIHNpbXBseSByZXBsYWNlIHRoZSBzdGF0ZSB3aXRoIHRoZSBuZXcgY2hhbmdlcy5cbiAgICAgICAgICAgICAgICAvLyBBY3R1YWxseSwgZm9yICgxKSB3ZSBkb24ndCBuZWVkIHRvIG5vdGhpbmcuIEJ1dCBpdCdzIGhhcmQgdG8gZGV0ZWN0IHRoYXQgZXZlbnQuXG4gICAgICAgICAgICAgICAgLy8gU28sIGRvaW5nIHRoZSBmb2xsb3dpbmcgZm9yICgxKSBkb2VzIG5vIGhhcm0uXG4gICAgICAgICAgICAgICAgY29uc3QgeyBwYXRobmFtZTogcGF0aG5hbWUxICwgcXVlcnk6IHF1ZXJ5MSAgfSA9IHRoaXM7XG4gICAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZSgncmVwbGFjZVN0YXRlJywgKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZTogYWRkQmFzZVBhdGgocGF0aG5hbWUxKSxcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6IHF1ZXJ5MVxuICAgICAgICAgICAgICAgIH0pLCAoMCwgX3V0aWxzKS5nZXRVUkwoKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFzdGF0ZS5fX04pIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZm9yY2VkU2Nyb2xsO1xuICAgICAgICAgICAgY29uc3QgeyB1cmwgLCBhczogYXMxICwgb3B0aW9ucyAsIGlkeCAgfSA9IHN0YXRlO1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04pIHtcbiAgICAgICAgICAgICAgICBpZiAobWFudWFsU2Nyb2xsUmVzdG9yYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lkeCAhPT0gaWR4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTbmFwc2hvdCBjdXJyZW50IHNjcm9sbCBwb3NpdGlvbjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnX19uZXh0X3Njcm9sbF8nICsgdGhpcy5faWR4LCBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHg6IHNlbGYucGFnZVhPZmZzZXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHk6IHNlbGYucGFnZVlPZmZzZXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoICB7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBSZXN0b3JlIG9sZCBzY3JvbGwgcG9zaXRpb246XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHYgPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdfX25leHRfc2Nyb2xsXycgKyBpZHgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcmNlZFNjcm9sbCA9IEpTT04ucGFyc2Uodik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yY2VkU2Nyb2xsID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB4OiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5OiAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuX2lkeCA9IGlkeDtcbiAgICAgICAgICAgIGNvbnN0IHsgcGF0aG5hbWU6IHBhdGhuYW1lMSAgfSA9ICgwLCBfcGFyc2VSZWxhdGl2ZVVybCkucGFyc2VSZWxhdGl2ZVVybCh1cmwpO1xuICAgICAgICAgICAgLy8gTWFrZSBzdXJlIHdlIGRvbid0IHJlLXJlbmRlciBvbiBpbml0aWFsIGxvYWQsXG4gICAgICAgICAgICAvLyBjYW4gYmUgY2F1c2VkIGJ5IG5hdmlnYXRpbmcgYmFjayBmcm9tIGFuIGV4dGVybmFsIHNpdGVcbiAgICAgICAgICAgIGlmICh0aGlzLmlzU3NyICYmIGFzMSA9PT0gdGhpcy5hc1BhdGggJiYgcGF0aG5hbWUxID09PSB0aGlzLnBhdGhuYW1lKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gSWYgdGhlIGRvd25zdHJlYW0gYXBwbGljYXRpb24gcmV0dXJucyBmYWxzeSwgcmV0dXJuLlxuICAgICAgICAgICAgLy8gVGhleSB3aWxsIHRoZW4gYmUgcmVzcG9uc2libGUgZm9yIGhhbmRsaW5nIHRoZSBldmVudC5cbiAgICAgICAgICAgIGlmICh0aGlzLl9icHMgJiYgIXRoaXMuX2JwcyhzdGF0ZSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmNoYW5nZSgncmVwbGFjZVN0YXRlJywgdXJsLCBhczEsIE9iamVjdC5hc3NpZ24oe1xuICAgICAgICAgICAgfSwgb3B0aW9ucywge1xuICAgICAgICAgICAgICAgIHNoYWxsb3c6IG9wdGlvbnMuc2hhbGxvdyAmJiB0aGlzLl9zaGFsbG93LFxuICAgICAgICAgICAgICAgIGxvY2FsZTogb3B0aW9ucy5sb2NhbGUgfHwgdGhpcy5kZWZhdWx0TG9jYWxlXG4gICAgICAgICAgICB9KSwgZm9yY2VkU2Nyb2xsKTtcbiAgICAgICAgfTtcbiAgICAgICAgLy8gcmVwcmVzZW50cyB0aGUgY3VycmVudCBjb21wb25lbnQga2V5XG4gICAgICAgIHRoaXMucm91dGUgPSAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLnJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGhuYW1lMSk7XG4gICAgICAgIC8vIHNldCB1cCB0aGUgY29tcG9uZW50IGNhY2hlIChieSByb3V0ZSBrZXlzKVxuICAgICAgICB0aGlzLmNvbXBvbmVudHMgPSB7XG4gICAgICAgIH07XG4gICAgICAgIC8vIFdlIHNob3VsZCBub3Qga2VlcCB0aGUgY2FjaGUsIGlmIHRoZXJlJ3MgYW4gZXJyb3JcbiAgICAgICAgLy8gT3RoZXJ3aXNlLCB0aGlzIGNhdXNlIGlzc3VlcyB3aGVuIHdoZW4gZ29pbmcgYmFjayBhbmRcbiAgICAgICAgLy8gY29tZSBhZ2FpbiB0byB0aGUgZXJyb3JlZCBwYWdlLlxuICAgICAgICBpZiAocGF0aG5hbWUxICE9PSAnL19lcnJvcicpIHtcbiAgICAgICAgICAgIHRoaXMuY29tcG9uZW50c1t0aGlzLnJvdXRlXSA9IHtcbiAgICAgICAgICAgICAgICBDb21wb25lbnQ6IENvbXBvbmVudDEsXG4gICAgICAgICAgICAgICAgaW5pdGlhbDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBwcm9wczogaW5pdGlhbFByb3BzLFxuICAgICAgICAgICAgICAgIGVycjogZXJyMSxcbiAgICAgICAgICAgICAgICBfX05fU1NHOiBpbml0aWFsUHJvcHMgJiYgaW5pdGlhbFByb3BzLl9fTl9TU0csXG4gICAgICAgICAgICAgICAgX19OX1NTUDogaW5pdGlhbFByb3BzICYmIGluaXRpYWxQcm9wcy5fX05fU1NQXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY29tcG9uZW50c1snL19hcHAnXSA9IHtcbiAgICAgICAgICAgIENvbXBvbmVudDogQXBwLFxuICAgICAgICAgICAgc3R5bGVTaGVldHM6IFtdXG4gICAgICAgIH07XG4gICAgICAgIC8vIEJhY2t3YXJkcyBjb21wYXQgZm9yIFJvdXRlci5yb3V0ZXIuZXZlbnRzXG4gICAgICAgIC8vIFRPRE86IFNob3VsZCBiZSByZW1vdmUgdGhlIGZvbGxvd2luZyBtYWpvciB2ZXJzaW9uIGFzIGl0IHdhcyBuZXZlciBkb2N1bWVudGVkXG4gICAgICAgIHRoaXMuZXZlbnRzID0gUm91dGVyLmV2ZW50cztcbiAgICAgICAgdGhpcy5wYWdlTG9hZGVyID0gcGFnZUxvYWRlcjtcbiAgICAgICAgdGhpcy5wYXRobmFtZSA9IHBhdGhuYW1lMTtcbiAgICAgICAgdGhpcy5xdWVyeSA9IHF1ZXJ5MTtcbiAgICAgICAgLy8gaWYgYXV0byBwcmVyZW5kZXJlZCBhbmQgZHluYW1pYyByb3V0ZSB3YWl0IHRvIHVwZGF0ZSBhc1BhdGhcbiAgICAgICAgLy8gdW50aWwgYWZ0ZXIgbW91bnQgdG8gcHJldmVudCBoeWRyYXRpb24gbWlzbWF0Y2hcbiAgICAgICAgY29uc3QgYXV0b0V4cG9ydER5bmFtaWMgPSAoMCwgX2lzRHluYW1pYykuaXNEeW5hbWljUm91dGUocGF0aG5hbWUxKSAmJiBzZWxmLl9fTkVYVF9EQVRBX18uYXV0b0V4cG9ydDtcbiAgICAgICAgdGhpcy5hc1BhdGggPSBhdXRvRXhwb3J0RHluYW1pYyA/IHBhdGhuYW1lMSA6IGFzMTtcbiAgICAgICAgdGhpcy5iYXNlUGF0aCA9IGJhc2VQYXRoO1xuICAgICAgICB0aGlzLnN1YiA9IHN1YnNjcmlwdGlvbjtcbiAgICAgICAgdGhpcy5jbGMgPSBudWxsO1xuICAgICAgICB0aGlzLl93cmFwQXBwID0gd3JhcEFwcDtcbiAgICAgICAgLy8gbWFrZSBzdXJlIHRvIGlnbm9yZSBleHRyYSBwb3BTdGF0ZSBpbiBzYWZhcmkgb24gbmF2aWdhdGluZ1xuICAgICAgICAvLyBiYWNrIGZyb20gZXh0ZXJuYWwgc2l0ZVxuICAgICAgICB0aGlzLmlzU3NyID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5pc0ZhbGxiYWNrID0gaXNGYWxsYmFjaztcbiAgICAgICAgdGhpcy5pc1JlYWR5ID0gISEoc2VsZi5fX05FWFRfREFUQV9fLmdzc3AgfHwgc2VsZi5fX05FWFRfREFUQV9fLmdpcCB8fCBzZWxmLl9fTkVYVF9EQVRBX18uYXBwR2lwICYmICFzZWxmLl9fTkVYVF9EQVRBX18uZ3NwIHx8ICFhdXRvRXhwb3J0RHluYW1pYyAmJiAhc2VsZi5sb2NhdGlvbi5zZWFyY2ggJiYgIXByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMpO1xuICAgICAgICB0aGlzLmlzUHJldmlldyA9ICEhaXNQcmV2aWV3O1xuICAgICAgICB0aGlzLmlzTG9jYWxlRG9tYWluID0gZmFsc2U7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICB0aGlzLmxvY2FsZSA9IGxvY2FsZTtcbiAgICAgICAgICAgIHRoaXMubG9jYWxlcyA9IGxvY2FsZXM7XG4gICAgICAgICAgICB0aGlzLmRlZmF1bHRMb2NhbGUgPSBkZWZhdWx0TG9jYWxlO1xuICAgICAgICAgICAgdGhpcy5kb21haW5Mb2NhbGVzID0gZG9tYWluTG9jYWxlcztcbiAgICAgICAgICAgIHRoaXMuaXNMb2NhbGVEb21haW4gPSAhIWRldGVjdERvbWFpbkxvY2FsZShkb21haW5Mb2NhbGVzLCBzZWxmLmxvY2F0aW9uLmhvc3RuYW1lKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIC8vIG1ha2Ugc3VyZSBcImFzXCIgZG9lc24ndCBzdGFydCB3aXRoIGRvdWJsZSBzbGFzaGVzIG9yIGVsc2UgaXQgY2FuXG4gICAgICAgICAgICAvLyB0aHJvdyBhbiBlcnJvciBhcyBpdCdzIGNvbnNpZGVyZWQgaW52YWxpZFxuICAgICAgICAgICAgaWYgKGFzMS5zdWJzdHIoMCwgMikgIT09ICcvLycpIHtcbiAgICAgICAgICAgICAgICAvLyBpbiBvcmRlciBmb3IgYGUuc3RhdGVgIHRvIHdvcmsgb24gdGhlIGBvbnBvcHN0YXRlYCBldmVudFxuICAgICAgICAgICAgICAgIC8vIHdlIGhhdmUgdG8gcmVnaXN0ZXIgdGhlIGluaXRpYWwgcm91dGUgdXBvbiBpbml0aWFsaXphdGlvblxuICAgICAgICAgICAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgICAgICAgICAgICAgIGxvY2FsZVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgb3B0aW9ucy5fc2hvdWxkUmVzb2x2ZUhyZWYgPSBhczEgIT09IHBhdGhuYW1lMTtcbiAgICAgICAgICAgICAgICB0aGlzLmNoYW5nZVN0YXRlKCdyZXBsYWNlU3RhdGUnLCAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lOiBhZGRCYXNlUGF0aChwYXRobmFtZTEpLFxuICAgICAgICAgICAgICAgICAgICBxdWVyeTogcXVlcnkxXG4gICAgICAgICAgICAgICAgfSksICgwLCBfdXRpbHMpLmdldFVSTCgpLCBvcHRpb25zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdwb3BzdGF0ZScsIHRoaXMub25Qb3BTdGF0ZSk7XG4gICAgICAgICAgICAvLyBlbmFibGUgY3VzdG9tIHNjcm9sbCByZXN0b3JhdGlvbiBoYW5kbGluZyB3aGVuIGF2YWlsYWJsZVxuICAgICAgICAgICAgLy8gb3RoZXJ3aXNlIGZhbGxiYWNrIHRvIGJyb3dzZXIncyBkZWZhdWx0IGhhbmRsaW5nXG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTikge1xuICAgICAgICAgICAgICAgIGlmIChtYW51YWxTY3JvbGxSZXN0b3JhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cuaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9ICdtYW51YWwnO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZWxvYWQoKSB7XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICB9XG4gICAgLyoqXG4gICAqIEdvIGJhY2sgaW4gaGlzdG9yeVxuICAgKi8gYmFjaygpIHtcbiAgICAgICAgd2luZG93Lmhpc3RvcnkuYmFjaygpO1xuICAgIH1cbiAgICAvKipcbiAgICogUGVyZm9ybXMgYSBgcHVzaFN0YXRlYCB3aXRoIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gdXJsIG9mIHRoZSByb3V0ZVxuICAgKiBAcGFyYW0gYXMgbWFza3MgYHVybGAgZm9yIHRoZSBicm93c2VyXG4gICAqIEBwYXJhbSBvcHRpb25zIG9iamVjdCB5b3UgY2FuIGRlZmluZSBgc2hhbGxvd2AgYW5kIG90aGVyIG9wdGlvbnNcbiAgICovIHB1c2godXJsLCBhcywgb3B0aW9ucyA9IHtcbiAgICB9KSB7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OKSB7XG4gICAgICAgICAgICAvLyBUT0RPOiByZW1vdmUgaW4gdGhlIGZ1dHVyZSB3aGVuIHdlIHVwZGF0ZSBoaXN0b3J5IGJlZm9yZSByb3V0ZSBjaGFuZ2VcbiAgICAgICAgICAgIC8vIGlzIGNvbXBsZXRlLCBhcyB0aGUgcG9wc3RhdGUgZXZlbnQgc2hvdWxkIGhhbmRsZSB0aGlzIGNhcHR1cmUuXG4gICAgICAgICAgICBpZiAobWFudWFsU2Nyb2xsUmVzdG9yYXRpb24pIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAvLyBTbmFwc2hvdCBzY3JvbGwgcG9zaXRpb24gcmlnaHQgYmVmb3JlIG5hdmlnYXRpbmcgdG8gYSBuZXcgcGFnZTpcbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnX19uZXh0X3Njcm9sbF8nICsgdGhpcy5faWR4LCBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgICAgICAgICB4OiBzZWxmLnBhZ2VYT2Zmc2V0LFxuICAgICAgICAgICAgICAgICAgICAgICAgeTogc2VsZi5wYWdlWU9mZnNldFxuICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgfSBjYXRjaCAge1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAoeyB1cmwgLCBhcyAgfSA9IHByZXBhcmVVcmxBcyh0aGlzLCB1cmwsIGFzKSk7XG4gICAgICAgIHJldHVybiB0aGlzLmNoYW5nZSgncHVzaFN0YXRlJywgdXJsLCBhcywgb3B0aW9ucyk7XG4gICAgfVxuICAgIC8qKlxuICAgKiBQZXJmb3JtcyBhIGByZXBsYWNlU3RhdGVgIHdpdGggYXJndW1lbnRzXG4gICAqIEBwYXJhbSB1cmwgb2YgdGhlIHJvdXRlXG4gICAqIEBwYXJhbSBhcyBtYXNrcyBgdXJsYCBmb3IgdGhlIGJyb3dzZXJcbiAgICogQHBhcmFtIG9wdGlvbnMgb2JqZWN0IHlvdSBjYW4gZGVmaW5lIGBzaGFsbG93YCBhbmQgb3RoZXIgb3B0aW9uc1xuICAgKi8gcmVwbGFjZSh1cmwsIGFzLCBvcHRpb25zID0ge1xuICAgIH0pIHtcbiAgICAgICAgKHsgdXJsICwgYXMgIH0gPSBwcmVwYXJlVXJsQXModGhpcywgdXJsLCBhcykpO1xuICAgICAgICByZXR1cm4gdGhpcy5jaGFuZ2UoJ3JlcGxhY2VTdGF0ZScsIHVybCwgYXMsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBhc3luYyBjaGFuZ2UobWV0aG9kLCB1cmwsIGFzLCBvcHRpb25zLCBmb3JjZWRTY3JvbGwpIHtcbiAgICAgICAgaWYgKCFpc0xvY2FsVVJMKHVybCkpIHtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gdXJsO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNob3VsZFJlc29sdmVIcmVmID0gdXJsID09PSBhcyB8fCBvcHRpb25zLl9oIHx8IG9wdGlvbnMuX3Nob3VsZFJlc29sdmVIcmVmO1xuICAgICAgICAvLyBmb3Igc3RhdGljIHBhZ2VzIHdpdGggcXVlcnkgcGFyYW1zIGluIHRoZSBVUkwgd2UgZGVsYXlcbiAgICAgICAgLy8gbWFya2luZyB0aGUgcm91dGVyIHJlYWR5IHVudGlsIGFmdGVyIHRoZSBxdWVyeSBpcyB1cGRhdGVkXG4gICAgICAgIGlmIChvcHRpb25zLl9oKSB7XG4gICAgICAgICAgICB0aGlzLmlzUmVhZHkgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHByZXZMb2NhbGUgPSB0aGlzLmxvY2FsZTtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgICAgICAgIHRoaXMubG9jYWxlID0gb3B0aW9ucy5sb2NhbGUgPT09IGZhbHNlID8gdGhpcy5kZWZhdWx0TG9jYWxlIDogb3B0aW9ucy5sb2NhbGUgfHwgdGhpcy5sb2NhbGU7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG9wdGlvbnMubG9jYWxlID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIG9wdGlvbnMubG9jYWxlID0gdGhpcy5sb2NhbGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBwYXJzZWRBcyA9ICgwLCBfcGFyc2VSZWxhdGl2ZVVybCkucGFyc2VSZWxhdGl2ZVVybChoYXNCYXNlUGF0aChhcykgPyBkZWxCYXNlUGF0aChhcykgOiBhcyk7XG4gICAgICAgICAgICBjb25zdCBsb2NhbGVQYXRoUmVzdWx0ID0gKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKHBhcnNlZEFzLnBhdGhuYW1lLCB0aGlzLmxvY2FsZXMpO1xuICAgICAgICAgICAgaWYgKGxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGUpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxvY2FsZSA9IGxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGU7XG4gICAgICAgICAgICAgICAgcGFyc2VkQXMucGF0aG5hbWUgPSBhZGRCYXNlUGF0aChwYXJzZWRBcy5wYXRobmFtZSk7XG4gICAgICAgICAgICAgICAgYXMgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWRBcyk7XG4gICAgICAgICAgICAgICAgdXJsID0gYWRkQmFzZVBhdGgoKDAsIF9ub3JtYWxpemVMb2NhbGVQYXRoKS5ub3JtYWxpemVMb2NhbGVQYXRoKGhhc0Jhc2VQYXRoKHVybCkgPyBkZWxCYXNlUGF0aCh1cmwpIDogdXJsLCB0aGlzLmxvY2FsZXMpLnBhdGhuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBkaWROYXZpZ2F0ZSA9IGZhbHNlO1xuICAgICAgICAgICAgLy8gd2UgbmVlZCB0byB3cmFwIHRoaXMgaW4gdGhlIGVudiBjaGVjayBhZ2FpbiBzaW5jZSByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgICAvLyBtb3ZlcyB0aGlzIG9uIGl0cyBvd24gZHVlIHRvIHRoZSByZXR1cm5cbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICAgICAgdmFyIHJlZjtcbiAgICAgICAgICAgICAgICAvLyBpZiB0aGUgbG9jYWxlIGlzbid0IGNvbmZpZ3VyZWQgaGFyZCBuYXZpZ2F0ZSB0byBzaG93IDQwNCBwYWdlXG4gICAgICAgICAgICAgICAgaWYgKCEoKHJlZiA9IHRoaXMubG9jYWxlcykgPT09IG51bGwgfHwgcmVmID09PSB2b2lkIDAgPyB2b2lkIDAgOiByZWYuaW5jbHVkZXModGhpcy5sb2NhbGUpKSkge1xuICAgICAgICAgICAgICAgICAgICBwYXJzZWRBcy5wYXRobmFtZSA9IGFkZExvY2FsZShwYXJzZWRBcy5wYXRobmFtZSwgdGhpcy5sb2NhbGUpO1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZEFzKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcyB3YXMgcHJldmlvdXNseSBhIHJldHVybiBidXQgd2FzIHJlbW92ZWQgaW4gZmF2b3JcbiAgICAgICAgICAgICAgICAgICAgLy8gb2YgYmV0dGVyIGRlYWQgY29kZSBlbGltaW5hdGlvbiB3aXRoIHJlZ2VuZXJhdG9yIHJ1bnRpbWVcbiAgICAgICAgICAgICAgICAgICAgZGlkTmF2aWdhdGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGRldGVjdGVkRG9tYWluID0gZGV0ZWN0RG9tYWluTG9jYWxlKHRoaXMuZG9tYWluTG9jYWxlcywgdW5kZWZpbmVkLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgICAgICAvLyB3ZSBuZWVkIHRvIHdyYXAgdGhpcyBpbiB0aGUgZW52IGNoZWNrIGFnYWluIHNpbmNlIHJlZ2VuZXJhdG9yIHJ1bnRpbWVcbiAgICAgICAgICAgIC8vIG1vdmVzIHRoaXMgb24gaXRzIG93biBkdWUgdG8gdGhlIHJldHVyblxuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgICAgICAgICAgICAvLyBpZiB3ZSBhcmUgbmF2aWdhdGluZyB0byBhIGRvbWFpbiBsb2NhbGUgZW5zdXJlIHdlIHJlZGlyZWN0IHRvIHRoZVxuICAgICAgICAgICAgICAgIC8vIGNvcnJlY3QgZG9tYWluXG4gICAgICAgICAgICAgICAgaWYgKCFkaWROYXZpZ2F0ZSAmJiBkZXRlY3RlZERvbWFpbiAmJiB0aGlzLmlzTG9jYWxlRG9tYWluICYmIHNlbGYubG9jYXRpb24uaG9zdG5hbWUgIT09IGRldGVjdGVkRG9tYWluLmRvbWFpbikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBhc05vQmFzZVBhdGggPSBkZWxCYXNlUGF0aChhcyk7XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYGh0dHAke2RldGVjdGVkRG9tYWluLmh0dHAgPyAnJyA6ICdzJ306Ly8ke2RldGVjdGVkRG9tYWluLmRvbWFpbn0ke2FkZEJhc2VQYXRoKGAke3RoaXMubG9jYWxlID09PSBkZXRlY3RlZERvbWFpbi5kZWZhdWx0TG9jYWxlID8gJycgOiBgLyR7dGhpcy5sb2NhbGV9YH0ke2FzTm9CYXNlUGF0aCA9PT0gJy8nID8gJycgOiBhc05vQmFzZVBhdGh9YCB8fCAnLycpfWA7XG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMgd2FzIHByZXZpb3VzbHkgYSByZXR1cm4gYnV0IHdhcyByZW1vdmVkIGluIGZhdm9yXG4gICAgICAgICAgICAgICAgICAgIC8vIG9mIGJldHRlciBkZWFkIGNvZGUgZWxpbWluYXRpb24gd2l0aCByZWdlbmVyYXRvciBydW50aW1lXG4gICAgICAgICAgICAgICAgICAgIGRpZE5hdmlnYXRlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZGlkTmF2aWdhdGUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKCk9PntcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIW9wdGlvbnMuX2gpIHtcbiAgICAgICAgICAgIHRoaXMuaXNTc3IgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBtYXJraW5nIHJvdXRlIGNoYW5nZXMgYXMgYSBuYXZpZ2F0aW9uIHN0YXJ0IGVudHJ5XG4gICAgICAgIGlmIChfdXRpbHMuU1QpIHtcbiAgICAgICAgICAgIHBlcmZvcm1hbmNlLm1hcmsoJ3JvdXRlQ2hhbmdlJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBzaGFsbG93ID1mYWxzZSAgfSA9IG9wdGlvbnM7XG4gICAgICAgIGNvbnN0IHJvdXRlUHJvcHMgPSB7XG4gICAgICAgICAgICBzaGFsbG93XG4gICAgICAgIH07XG4gICAgICAgIGlmICh0aGlzLl9pbkZsaWdodFJvdXRlKSB7XG4gICAgICAgICAgICB0aGlzLmFib3J0Q29tcG9uZW50TG9hZCh0aGlzLl9pbkZsaWdodFJvdXRlLCByb3V0ZVByb3BzKTtcbiAgICAgICAgfVxuICAgICAgICBhcyA9IGFkZEJhc2VQYXRoKGFkZExvY2FsZShoYXNCYXNlUGF0aChhcykgPyBkZWxCYXNlUGF0aChhcykgOiBhcywgb3B0aW9ucy5sb2NhbGUsIHRoaXMuZGVmYXVsdExvY2FsZSkpO1xuICAgICAgICBjb25zdCBjbGVhbmVkQXMgPSBkZWxMb2NhbGUoaGFzQmFzZVBhdGgoYXMpID8gZGVsQmFzZVBhdGgoYXMpIDogYXMsIHRoaXMubG9jYWxlKTtcbiAgICAgICAgdGhpcy5faW5GbGlnaHRSb3V0ZSA9IGFzO1xuICAgICAgICBsZXQgbG9jYWxlQ2hhbmdlID0gcHJldkxvY2FsZSAhPT0gdGhpcy5sb2NhbGU7XG4gICAgICAgIC8vIElmIHRoZSB1cmwgY2hhbmdlIGlzIG9ubHkgcmVsYXRlZCB0byBhIGhhc2ggY2hhbmdlXG4gICAgICAgIC8vIFdlIHNob3VsZCBub3QgcHJvY2VlZC4gV2Ugc2hvdWxkIG9ubHkgY2hhbmdlIHRoZSBzdGF0ZS5cbiAgICAgICAgLy8gV0FSTklORzogYF9oYCBpcyBhbiBpbnRlcm5hbCBvcHRpb24gZm9yIGhhbmRpbmcgTmV4dC5qcyBjbGllbnQtc2lkZVxuICAgICAgICAvLyBoeWRyYXRpb24uIFlvdXIgYXBwIHNob3VsZCBfbmV2ZXJfIHVzZSB0aGlzIHByb3BlcnR5LiBJdCBtYXkgY2hhbmdlIGF0XG4gICAgICAgIC8vIGFueSB0aW1lIHdpdGhvdXQgbm90aWNlLlxuICAgICAgICBpZiAoIW9wdGlvbnMuX2ggJiYgdGhpcy5vbmx5QUhhc2hDaGFuZ2UoY2xlYW5lZEFzKSAmJiAhbG9jYWxlQ2hhbmdlKSB7XG4gICAgICAgICAgICB0aGlzLmFzUGF0aCA9IGNsZWFuZWRBcztcbiAgICAgICAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgnaGFzaENoYW5nZVN0YXJ0JywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgLy8gVE9ETzogZG8gd2UgbmVlZCB0aGUgcmVzb2x2ZWQgaHJlZiB3aGVuIG9ubHkgYSBoYXNoIGNoYW5nZT9cbiAgICAgICAgICAgIHRoaXMuY2hhbmdlU3RhdGUobWV0aG9kLCB1cmwsIGFzLCBvcHRpb25zKTtcbiAgICAgICAgICAgIHRoaXMuc2Nyb2xsVG9IYXNoKGNsZWFuZWRBcyk7XG4gICAgICAgICAgICB0aGlzLm5vdGlmeSh0aGlzLmNvbXBvbmVudHNbdGhpcy5yb3V0ZV0sIG51bGwpO1xuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdoYXNoQ2hhbmdlQ29tcGxldGUnLCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgcGFyc2VkID0gKDAsIF9wYXJzZVJlbGF0aXZlVXJsKS5wYXJzZVJlbGF0aXZlVXJsKHVybCk7XG4gICAgICAgIGxldCB7IHBhdGhuYW1lOiBwYXRobmFtZTEgLCBxdWVyeTogcXVlcnkxICB9ID0gcGFyc2VkO1xuICAgICAgICAvLyBUaGUgYnVpbGQgbWFuaWZlc3QgbmVlZHMgdG8gYmUgbG9hZGVkIGJlZm9yZSBhdXRvLXN0YXRpYyBkeW5hbWljIHBhZ2VzXG4gICAgICAgIC8vIGdldCB0aGVpciBxdWVyeSBwYXJhbWV0ZXJzIHRvIGFsbG93IGVuc3VyaW5nIHRoZXkgY2FuIGJlIHBhcnNlZCBwcm9wZXJseVxuICAgICAgICAvLyB3aGVuIHJld3JpdHRlbiB0b1xuICAgICAgICBsZXQgcGFnZXMsIHJld3JpdGVzO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcGFnZXMgPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIuZ2V0UGFnZUxpc3QoKTtcbiAgICAgICAgICAgICh7IF9fcmV3cml0ZXM6IHJld3JpdGVzICB9ID0gYXdhaXQgKDAsIF9yb3V0ZUxvYWRlcikuZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCgpKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyMSkge1xuICAgICAgICAgICAgLy8gSWYgd2UgZmFpbCB0byByZXNvbHZlIHRoZSBwYWdlIGxpc3Qgb3IgY2xpZW50LWJ1aWxkIG1hbmlmZXN0LCB3ZSBtdXN0XG4gICAgICAgICAgICAvLyBkbyBhIHNlcnZlci1zaWRlIHRyYW5zaXRpb246XG4gICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IGFzO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIC8vIElmIGFza2VkIHRvIGNoYW5nZSB0aGUgY3VycmVudCBVUkwgd2Ugc2hvdWxkIHJlbG9hZCB0aGUgY3VycmVudCBwYWdlXG4gICAgICAgIC8vIChub3QgbG9jYXRpb24ucmVsb2FkKCkgYnV0IHJlbG9hZCBnZXRJbml0aWFsUHJvcHMgYW5kIG90aGVyIE5leHQuanMgc3R1ZmZzKVxuICAgICAgICAvLyBXZSBhbHNvIG5lZWQgdG8gc2V0IHRoZSBtZXRob2QgPSByZXBsYWNlU3RhdGUgYWx3YXlzXG4gICAgICAgIC8vIGFzIHRoaXMgc2hvdWxkIG5vdCBnbyBpbnRvIHRoZSBoaXN0b3J5IChUaGF0J3MgaG93IGJyb3dzZXJzIHdvcmspXG4gICAgICAgIC8vIFdlIHNob3VsZCBjb21wYXJlIHRoZSBuZXcgYXNQYXRoIHRvIHRoZSBjdXJyZW50IGFzUGF0aCwgbm90IHRoZSB1cmxcbiAgICAgICAgaWYgKCF0aGlzLnVybElzTmV3KGNsZWFuZWRBcykgJiYgIWxvY2FsZUNoYW5nZSkge1xuICAgICAgICAgICAgbWV0aG9kID0gJ3JlcGxhY2VTdGF0ZSc7XG4gICAgICAgIH1cbiAgICAgICAgLy8gd2UgbmVlZCB0byByZXNvbHZlIHRoZSBhcyB2YWx1ZSB1c2luZyByZXdyaXRlcyBmb3IgZHluYW1pYyBTU0dcbiAgICAgICAgLy8gcGFnZXMgdG8gYWxsb3cgYnVpbGRpbmcgdGhlIGRhdGEgVVJMIGNvcnJlY3RseVxuICAgICAgICBsZXQgcmVzb2x2ZWRBcyA9IGFzO1xuICAgICAgICAvLyB1cmwgYW5kIGFzIHNob3VsZCBhbHdheXMgYmUgcHJlZml4ZWQgd2l0aCBiYXNlUGF0aCBieSB0aGlzXG4gICAgICAgIC8vIHBvaW50IGJ5IGVpdGhlciBuZXh0L2xpbmsgb3Igcm91dGVyLnB1c2gvcmVwbGFjZSBzbyBzdHJpcCB0aGVcbiAgICAgICAgLy8gYmFzZVBhdGggZnJvbSB0aGUgcGF0aG5hbWUgdG8gbWF0Y2ggdGhlIHBhZ2VzIGRpciAxLXRvLTFcbiAgICAgICAgcGF0aG5hbWUxID0gcGF0aG5hbWUxID8gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChkZWxCYXNlUGF0aChwYXRobmFtZTEpKSA6IHBhdGhuYW1lMTtcbiAgICAgICAgaWYgKHNob3VsZFJlc29sdmVIcmVmICYmIHBhdGhuYW1lMSAhPT0gJy9fZXJyb3InKSB7XG4gICAgICAgICAgICBvcHRpb25zLl9zaG91bGRSZXNvbHZlSHJlZiA9IHRydWU7XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0hBU19SRVdSSVRFUyAmJiBhcy5zdGFydHNXaXRoKCcvJykpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXdyaXRlc1Jlc3VsdCA9ICgwLCBfcmVzb2x2ZVJld3JpdGVzKS5kZWZhdWx0KGFkZEJhc2VQYXRoKGFkZExvY2FsZShjbGVhbmVkQXMsIHRoaXMubG9jYWxlKSksIHBhZ2VzLCByZXdyaXRlcywgcXVlcnkxLCAocCk9PnJlc29sdmVEeW5hbWljUm91dGUocCwgcGFnZXMpXG4gICAgICAgICAgICAgICAgLCB0aGlzLmxvY2FsZXMpO1xuICAgICAgICAgICAgICAgIHJlc29sdmVkQXMgPSByZXdyaXRlc1Jlc3VsdC5hc1BhdGg7XG4gICAgICAgICAgICAgICAgaWYgKHJld3JpdGVzUmVzdWx0Lm1hdGNoZWRQYWdlICYmIHJld3JpdGVzUmVzdWx0LnJlc29sdmVkSHJlZikge1xuICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGlzIGRpcmVjdGx5IG1hdGNoZXMgYSBwYWdlIHdlIG5lZWQgdG8gdXBkYXRlIHRoZSBocmVmIHRvXG4gICAgICAgICAgICAgICAgICAgIC8vIGFsbG93IHRoZSBjb3JyZWN0IHBhZ2UgY2h1bmsgdG8gYmUgbG9hZGVkXG4gICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lMSA9IHJld3JpdGVzUmVzdWx0LnJlc29sdmVkSHJlZjtcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VkLnBhdGhuYW1lID0gYWRkQmFzZVBhdGgocGF0aG5hbWUxKTtcbiAgICAgICAgICAgICAgICAgICAgdXJsID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHJlc29sdmVEeW5hbWljUm91dGUocGF0aG5hbWUxLCBwYWdlcyk7XG4gICAgICAgICAgICAgICAgaWYgKHBhcnNlZC5wYXRobmFtZSAhPT0gcGF0aG5hbWUxKSB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lMSA9IHBhcnNlZC5wYXRobmFtZTtcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VkLnBhdGhuYW1lID0gYWRkQmFzZVBhdGgocGF0aG5hbWUxKTtcbiAgICAgICAgICAgICAgICAgICAgdXJsID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgcm91dGUgPSAoMCwgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gpLnJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGhuYW1lMSk7XG4gICAgICAgIGlmICghaXNMb2NhbFVSTChhcykpIHtcbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIGhyZWY6IFwiJHt1cmx9XCIgYW5kIGFzOiBcIiR7YXN9XCIsIHJlY2VpdmVkIHJlbGF0aXZlIGhyZWYgYW5kIGV4dGVybmFsIGFzYCArIGBcXG5TZWUgbW9yZSBpbmZvOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9pbnZhbGlkLXJlbGF0aXZlLXVybC1leHRlcm5hbC1hc2ApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBhcztcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICByZXNvbHZlZEFzID0gZGVsTG9jYWxlKGRlbEJhc2VQYXRoKHJlc29sdmVkQXMpLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgIGlmICgoMCwgX2lzRHluYW1pYykuaXNEeW5hbWljUm91dGUocm91dGUpKSB7XG4gICAgICAgICAgICBjb25zdCBwYXJzZWRBcyA9ICgwLCBfcGFyc2VSZWxhdGl2ZVVybCkucGFyc2VSZWxhdGl2ZVVybChyZXNvbHZlZEFzKTtcbiAgICAgICAgICAgIGNvbnN0IGFzUGF0aG5hbWUgPSBwYXJzZWRBcy5wYXRobmFtZTtcbiAgICAgICAgICAgIGNvbnN0IHJvdXRlUmVnZXggPSAoMCwgX3JvdXRlUmVnZXgpLmdldFJvdXRlUmVnZXgocm91dGUpO1xuICAgICAgICAgICAgY29uc3Qgcm91dGVNYXRjaCA9ICgwLCBfcm91dGVNYXRjaGVyKS5nZXRSb3V0ZU1hdGNoZXIocm91dGVSZWdleCkoYXNQYXRobmFtZSk7XG4gICAgICAgICAgICBjb25zdCBzaG91bGRJbnRlcnBvbGF0ZSA9IHJvdXRlID09PSBhc1BhdGhuYW1lO1xuICAgICAgICAgICAgY29uc3QgaW50ZXJwb2xhdGVkQXMgPSBzaG91bGRJbnRlcnBvbGF0ZSA/IGludGVycG9sYXRlQXMocm91dGUsIGFzUGF0aG5hbWUsIHF1ZXJ5MSkgOiB7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKCFyb3V0ZU1hdGNoIHx8IHNob3VsZEludGVycG9sYXRlICYmICFpbnRlcnBvbGF0ZWRBcy5yZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBtaXNzaW5nUGFyYW1zID0gT2JqZWN0LmtleXMocm91dGVSZWdleC5ncm91cHMpLmZpbHRlcigocGFyYW0pPT4hcXVlcnkxW3BhcmFtXVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgaWYgKG1pc3NpbmdQYXJhbXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGAke3Nob3VsZEludGVycG9sYXRlID8gYEludGVycG9sYXRpbmcgaHJlZmAgOiBgTWlzbWF0Y2hpbmcgXFxgYXNcXGAgYW5kIFxcYGhyZWZcXGBgfSBmYWlsZWQgdG8gbWFudWFsbHkgcHJvdmlkZSBgICsgYHRoZSBwYXJhbXM6ICR7bWlzc2luZ1BhcmFtcy5qb2luKCcsICcpfSBpbiB0aGUgXFxgaHJlZlxcYCdzIFxcYHF1ZXJ5XFxgYCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKChzaG91bGRJbnRlcnBvbGF0ZSA/IGBUaGUgcHJvdmlkZWQgXFxgaHJlZlxcYCAoJHt1cmx9KSB2YWx1ZSBpcyBtaXNzaW5nIHF1ZXJ5IHZhbHVlcyAoJHttaXNzaW5nUGFyYW1zLmpvaW4oJywgJyl9KSB0byBiZSBpbnRlcnBvbGF0ZWQgcHJvcGVybHkuIGAgOiBgVGhlIHByb3ZpZGVkIFxcYGFzXFxgIHZhbHVlICgke2FzUGF0aG5hbWV9KSBpcyBpbmNvbXBhdGlibGUgd2l0aCB0aGUgXFxgaHJlZlxcYCB2YWx1ZSAoJHtyb3V0ZX0pLiBgKSArIGBSZWFkIG1vcmU6IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzLyR7c2hvdWxkSW50ZXJwb2xhdGUgPyAnaHJlZi1pbnRlcnBvbGF0aW9uLWZhaWxlZCcgOiAnaW5jb21wYXRpYmxlLWhyZWYtYXMnfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc2hvdWxkSW50ZXJwb2xhdGUpIHtcbiAgICAgICAgICAgICAgICBhcyA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKE9iamVjdC5hc3NpZ24oe1xuICAgICAgICAgICAgICAgIH0sIHBhcnNlZEFzLCB7XG4gICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lOiBpbnRlcnBvbGF0ZWRBcy5yZXN1bHQsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBvbWl0UGFybXNGcm9tUXVlcnkocXVlcnkxLCBpbnRlcnBvbGF0ZWRBcy5wYXJhbXMpXG4gICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBNZXJnZSBwYXJhbXMgaW50byBgcXVlcnlgLCBvdmVyd3JpdGluZyBhbnkgc3BlY2lmaWVkIGluIHNlYXJjaFxuICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24ocXVlcnkxLCByb3V0ZU1hdGNoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlU3RhcnQnLCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB2YXIgcmVmLCByZWYxO1xuICAgICAgICAgICAgbGV0IHJvdXRlSW5mbyA9IGF3YWl0IHRoaXMuZ2V0Um91dGVJbmZvKHJvdXRlLCBwYXRobmFtZTEsIHF1ZXJ5MSwgYXMsIHJlc29sdmVkQXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgbGV0IHsgZXJyb3IgLCBwcm9wcyAsIF9fTl9TU0cgLCBfX05fU1NQICB9ID0gcm91dGVJbmZvO1xuICAgICAgICAgICAgLy8gaGFuZGxlIHJlZGlyZWN0IG9uIGNsaWVudC10cmFuc2l0aW9uXG4gICAgICAgICAgICBpZiAoKF9fTl9TU0cgfHwgX19OX1NTUCkgJiYgcHJvcHMpIHtcbiAgICAgICAgICAgICAgICBpZiAocHJvcHMucGFnZVByb3BzICYmIHByb3BzLnBhZ2VQcm9wcy5fX05fUkVESVJFQ1QpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZGVzdGluYXRpb24gPSBwcm9wcy5wYWdlUHJvcHMuX19OX1JFRElSRUNUO1xuICAgICAgICAgICAgICAgICAgICAvLyBjaGVjayBpZiBkZXN0aW5hdGlvbiBpcyBpbnRlcm5hbCAocmVzb2x2ZXMgdG8gYSBwYWdlKSBhbmQgYXR0ZW1wdFxuICAgICAgICAgICAgICAgICAgICAvLyBjbGllbnQtbmF2aWdhdGlvbiBpZiBpdCBpcyBmYWxsaW5nIGJhY2sgdG8gaGFyZCBuYXZpZ2F0aW9uIGlmXG4gICAgICAgICAgICAgICAgICAgIC8vIGl0J3Mgbm90XG4gICAgICAgICAgICAgICAgICAgIGlmIChkZXN0aW5hdGlvbi5zdGFydHNXaXRoKCcvJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcnNlZEhyZWYgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwoZGVzdGluYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VkSHJlZi5wYXRobmFtZSA9IHJlc29sdmVEeW5hbWljUm91dGUocGFyc2VkSHJlZi5wYXRobmFtZSwgcGFnZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeyB1cmw6IG5ld1VybCAsIGFzOiBuZXdBcyAgfSA9IHByZXBhcmVVcmxBcyh0aGlzLCBkZXN0aW5hdGlvbiwgZGVzdGluYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY2hhbmdlKG1ldGhvZCwgbmV3VXJsLCBuZXdBcywgb3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBkZXN0aW5hdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKCgpPT57XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLmlzUHJldmlldyA9ICEhcHJvcHMuX19OX1BSRVZJRVc7XG4gICAgICAgICAgICAgICAgLy8gaGFuZGxlIFNTRyBkYXRhIDQwNFxuICAgICAgICAgICAgICAgIGlmIChwcm9wcy5ub3RGb3VuZCA9PT0gU1NHX0RBVEFfTk9UX0ZPVU5EKSB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBub3RGb3VuZFJvdXRlO1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudCgnLzQwNCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbm90Rm91bmRSb3V0ZSA9ICcvNDA0JztcbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoXykge1xuICAgICAgICAgICAgICAgICAgICAgICAgbm90Rm91bmRSb3V0ZSA9ICcvX2Vycm9yJztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByb3V0ZUluZm8gPSBhd2FpdCB0aGlzLmdldFJvdXRlSW5mbyhub3RGb3VuZFJvdXRlLCBub3RGb3VuZFJvdXRlLCBxdWVyeTEsIGFzLCByZXNvbHZlZEFzLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzaGFsbG93OiBmYWxzZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ2JlZm9yZUhpc3RvcnlDaGFuZ2UnLCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICB0aGlzLmNoYW5nZVN0YXRlKG1ldGhvZCwgdXJsLCBhcywgb3B0aW9ucyk7XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFwcENvbXAgPSB0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10uQ29tcG9uZW50O1xuICAgICAgICAgICAgICAgIHdpbmRvdy5uZXh0LmlzUHJlcmVuZGVyZWQgPSBhcHBDb21wLmdldEluaXRpYWxQcm9wcyA9PT0gYXBwQ29tcC5vcmlnR2V0SW5pdGlhbFByb3BzICYmICFyb3V0ZUluZm8uQ29tcG9uZW50LmdldEluaXRpYWxQcm9wcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChvcHRpb25zLl9oICYmIHBhdGhuYW1lMSA9PT0gJy9fZXJyb3InICYmICgocmVmID0gc2VsZi5fX05FWFRfREFUQV9fLnByb3BzKSA9PT0gbnVsbCB8fCByZWYgPT09IHZvaWQgMCA/IHZvaWQgMCA6IChyZWYxID0gcmVmLnBhZ2VQcm9wcykgPT09IG51bGwgfHwgcmVmMSA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVmMS5zdGF0dXNDb2RlKSA9PT0gNTAwICYmIChwcm9wcyA9PT0gbnVsbCB8fCBwcm9wcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogcHJvcHMucGFnZVByb3BzKSkge1xuICAgICAgICAgICAgICAgIC8vIGVuc3VyZSBzdGF0dXNDb2RlIGlzIHN0aWxsIGNvcnJlY3QgZm9yIHN0YXRpYyA1MDAgcGFnZVxuICAgICAgICAgICAgICAgIC8vIHdoZW4gdXBkYXRpbmcgcXVlcnkgaW5mb3JtYXRpb25cbiAgICAgICAgICAgICAgICBwcm9wcy5wYWdlUHJvcHMuc3RhdHVzQ29kZSA9IDUwMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIHNoYWxsb3cgcm91dGluZyBpcyBvbmx5IGFsbG93ZWQgZm9yIHNhbWUgcGFnZSBVUkwgY2hhbmdlcy5cbiAgICAgICAgICAgIGNvbnN0IGlzVmFsaWRTaGFsbG93Um91dGUgPSBvcHRpb25zLnNoYWxsb3cgJiYgdGhpcy5yb3V0ZSA9PT0gcm91dGU7XG4gICAgICAgICAgICB2YXIgX3Njcm9sbDtcbiAgICAgICAgICAgIGNvbnN0IHNob3VsZFNjcm9sbCA9IChfc2Nyb2xsID0gb3B0aW9ucy5zY3JvbGwpICE9PSBudWxsICYmIF9zY3JvbGwgIT09IHZvaWQgMCA/IF9zY3JvbGwgOiAhaXNWYWxpZFNoYWxsb3dSb3V0ZTtcbiAgICAgICAgICAgIGNvbnN0IHJlc2V0U2Nyb2xsID0gc2hvdWxkU2Nyb2xsID8ge1xuICAgICAgICAgICAgICAgIHg6IDAsXG4gICAgICAgICAgICAgICAgeTogMFxuICAgICAgICAgICAgfSA6IG51bGw7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnNldChyb3V0ZSwgcGF0aG5hbWUxLCBxdWVyeTEsIGNsZWFuZWRBcywgcm91dGVJbmZvLCBmb3JjZWRTY3JvbGwgIT09IG51bGwgJiYgZm9yY2VkU2Nyb2xsICE9PSB2b2lkIDAgPyBmb3JjZWRTY3JvbGwgOiByZXNldFNjcm9sbCkuY2F0Y2goKGUpPT57XG4gICAgICAgICAgICAgICAgaWYgKGUuY2FuY2VsbGVkKSBlcnJvciA9IGVycm9yIHx8IGU7XG4gICAgICAgICAgICAgICAgZWxzZSB0aHJvdyBlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlRXJyb3InLCBlcnJvciwgY2xlYW5lZEFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubG9jYWxlKSB7XG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5sYW5nID0gdGhpcy5sb2NhbGU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUNvbXBsZXRlJywgYXMsIHJvdXRlUHJvcHMpO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0gY2F0Y2ggKGVycjEpIHtcbiAgICAgICAgICAgIGlmIChlcnIxLmNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGVycjE7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2hhbmdlU3RhdGUobWV0aG9kLCB1cmwsIGFzLCBvcHRpb25zID0ge1xuICAgIH0pIHtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygd2luZG93Lmhpc3RvcnkgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgV2FybmluZzogd2luZG93Lmhpc3RvcnkgaXMgbm90IGF2YWlsYWJsZS5gKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodHlwZW9mIHdpbmRvdy5oaXN0b3J5W21ldGhvZF0gPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgV2FybmluZzogd2luZG93Lmhpc3RvcnkuJHttZXRob2R9IGlzIG5vdCBhdmFpbGFibGVgKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG1ldGhvZCAhPT0gJ3B1c2hTdGF0ZScgfHwgKDAsIF91dGlscykuZ2V0VVJMKCkgIT09IGFzKSB7XG4gICAgICAgICAgICB0aGlzLl9zaGFsbG93ID0gb3B0aW9ucy5zaGFsbG93O1xuICAgICAgICAgICAgd2luZG93Lmhpc3RvcnlbbWV0aG9kXSh7XG4gICAgICAgICAgICAgICAgdXJsLFxuICAgICAgICAgICAgICAgIGFzLFxuICAgICAgICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgICAgICAgX19OOiB0cnVlLFxuICAgICAgICAgICAgICAgIGlkeDogdGhpcy5faWR4ID0gbWV0aG9kICE9PSAncHVzaFN0YXRlJyA/IHRoaXMuX2lkeCA6IHRoaXMuX2lkeCArIDFcbiAgICAgICAgICAgIH0sIC8vIE1vc3QgYnJvd3NlcnMgY3VycmVudGx5IGlnbm9yZXMgdGhpcyBwYXJhbWV0ZXIsIGFsdGhvdWdoIHRoZXkgbWF5IHVzZSBpdCBpbiB0aGUgZnV0dXJlLlxuICAgICAgICAgICAgLy8gUGFzc2luZyB0aGUgZW1wdHkgc3RyaW5nIGhlcmUgc2hvdWxkIGJlIHNhZmUgYWdhaW5zdCBmdXR1cmUgY2hhbmdlcyB0byB0aGUgbWV0aG9kLlxuICAgICAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0hpc3RvcnkvcmVwbGFjZVN0YXRlXG4gICAgICAgICAgICAnJywgYXMpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIGhhbmRsZVJvdXRlSW5mb0Vycm9yKGVyciwgcGF0aG5hbWUsIHF1ZXJ5LCBhcywgcm91dGVQcm9wcywgbG9hZEVycm9yRmFpbCkge1xuICAgICAgICBpZiAoZXJyLmNhbmNlbGxlZCkge1xuICAgICAgICAgICAgLy8gYnViYmxlIHVwIGNhbmNlbGxhdGlvbiBlcnJvcnNcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoKDAsIF9yb3V0ZUxvYWRlcikuaXNBc3NldEVycm9yKGVycikgfHwgbG9hZEVycm9yRmFpbCkge1xuICAgICAgICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJywgZXJyLCBhcywgcm91dGVQcm9wcyk7XG4gICAgICAgICAgICAvLyBJZiB3ZSBjYW4ndCBsb2FkIHRoZSBwYWdlIGl0IGNvdWxkIGJlIG9uZSBvZiBmb2xsb3dpbmcgcmVhc29uc1xuICAgICAgICAgICAgLy8gIDEuIFBhZ2UgZG9lc24ndCBleGlzdHNcbiAgICAgICAgICAgIC8vICAyLiBQYWdlIGRvZXMgZXhpc3QgaW4gYSBkaWZmZXJlbnQgem9uZVxuICAgICAgICAgICAgLy8gIDMuIEludGVybmFsIGVycm9yIHdoaWxlIGxvYWRpbmcgdGhlIHBhZ2VcbiAgICAgICAgICAgIC8vIFNvLCBkb2luZyBhIGhhcmQgcmVsb2FkIGlzIHRoZSBwcm9wZXIgd2F5IHRvIGRlYWwgd2l0aCB0aGlzLlxuICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYgPSBhcztcbiAgICAgICAgICAgIC8vIENoYW5naW5nIHRoZSBVUkwgZG9lc24ndCBibG9jayBleGVjdXRpbmcgdGhlIGN1cnJlbnQgY29kZSBwYXRoLlxuICAgICAgICAgICAgLy8gU28gbGV0J3MgdGhyb3cgYSBjYW5jZWxsYXRpb24gZXJyb3Igc3RvcCB0aGUgcm91dGluZyBsb2dpYy5cbiAgICAgICAgICAgIHRocm93IGJ1aWxkQ2FuY2VsbGF0aW9uRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbGV0IENvbXBvbmVudDE7XG4gICAgICAgICAgICBsZXQgc3R5bGVTaGVldHM7XG4gICAgICAgICAgICBsZXQgcHJvcHM7XG4gICAgICAgICAgICBpZiAodHlwZW9mIENvbXBvbmVudDEgPT09ICd1bmRlZmluZWQnIHx8IHR5cGVvZiBzdHlsZVNoZWV0cyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICAoeyBwYWdlOiBDb21wb25lbnQxICwgc3R5bGVTaGVldHMgIH0gPSBhd2FpdCB0aGlzLmZldGNoQ29tcG9uZW50KCcvX2Vycm9yJykpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgcm91dGVJbmZvID0ge1xuICAgICAgICAgICAgICAgIHByb3BzLFxuICAgICAgICAgICAgICAgIENvbXBvbmVudDogQ29tcG9uZW50MSxcbiAgICAgICAgICAgICAgICBzdHlsZVNoZWV0cyxcbiAgICAgICAgICAgICAgICBlcnIsXG4gICAgICAgICAgICAgICAgZXJyb3I6IGVyclxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICghcm91dGVJbmZvLnByb3BzKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcm91dGVJbmZvLnByb3BzID0gYXdhaXQgdGhpcy5nZXRJbml0aWFsUHJvcHMoQ29tcG9uZW50MSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVyeVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChnaXBFcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgaW4gZXJyb3IgcGFnZSBgZ2V0SW5pdGlhbFByb3BzYDogJywgZ2lwRXJyKTtcbiAgICAgICAgICAgICAgICAgICAgcm91dGVJbmZvLnByb3BzID0ge1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByb3V0ZUluZm87XG4gICAgICAgIH0gY2F0Y2ggKHJvdXRlSW5mb0Vycikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlUm91dGVJbmZvRXJyb3Iocm91dGVJbmZvRXJyLCBwYXRobmFtZSwgcXVlcnksIGFzLCByb3V0ZVByb3BzLCB0cnVlKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBnZXRSb3V0ZUluZm8ocm91dGUsIHBhdGhuYW1lLCBxdWVyeSwgYXMsIHJlc29sdmVkQXMsIHJvdXRlUHJvcHMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nUm91dGVJbmZvID0gdGhpcy5jb21wb25lbnRzW3JvdXRlXTtcbiAgICAgICAgICAgIGlmIChyb3V0ZVByb3BzLnNoYWxsb3cgJiYgZXhpc3RpbmdSb3V0ZUluZm8gJiYgdGhpcy5yb3V0ZSA9PT0gcm91dGUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXhpc3RpbmdSb3V0ZUluZm87XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBjYWNoZWRSb3V0ZUluZm8gPSBleGlzdGluZ1JvdXRlSW5mbyAmJiAnaW5pdGlhbCcgaW4gZXhpc3RpbmdSb3V0ZUluZm8gPyB1bmRlZmluZWQgOiBleGlzdGluZ1JvdXRlSW5mbztcbiAgICAgICAgICAgIGNvbnN0IHJvdXRlSW5mbyA9IGNhY2hlZFJvdXRlSW5mbyA/IGNhY2hlZFJvdXRlSW5mbyA6IGF3YWl0IHRoaXMuZmV0Y2hDb21wb25lbnQocm91dGUpLnRoZW4oKHJlcyk9Pih7XG4gICAgICAgICAgICAgICAgICAgIENvbXBvbmVudDogcmVzLnBhZ2UsXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlU2hlZXRzOiByZXMuc3R5bGVTaGVldHMsXG4gICAgICAgICAgICAgICAgICAgIF9fTl9TU0c6IHJlcy5tb2QuX19OX1NTRyxcbiAgICAgICAgICAgICAgICAgICAgX19OX1NTUDogcmVzLm1vZC5fX05fU1NQXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBjb25zdCB7IENvbXBvbmVudDogQ29tcG9uZW50MSAsIF9fTl9TU0cgLCBfX05fU1NQICB9ID0gcm91dGVJbmZvO1xuICAgICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IGlzVmFsaWRFbGVtZW50VHlwZSAgfSA9IHJlcXVpcmUoJ3JlYWN0LWlzJyk7XG4gICAgICAgICAgICAgICAgaWYgKCFpc1ZhbGlkRWxlbWVudFR5cGUoQ29tcG9uZW50MSkpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBUaGUgZGVmYXVsdCBleHBvcnQgaXMgbm90IGEgUmVhY3QgQ29tcG9uZW50IGluIHBhZ2U6IFwiJHtwYXRobmFtZX1cImApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBkYXRhSHJlZjtcbiAgICAgICAgICAgIGlmIChfX05fU1NHIHx8IF9fTl9TU1ApIHtcbiAgICAgICAgICAgICAgICBkYXRhSHJlZiA9IHRoaXMucGFnZUxvYWRlci5nZXREYXRhSHJlZigoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIHBhdGhuYW1lLFxuICAgICAgICAgICAgICAgICAgICBxdWVyeVxuICAgICAgICAgICAgICAgIH0pLCByZXNvbHZlZEFzLCBfX05fU1NHLCB0aGlzLmxvY2FsZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBwcm9wcyA9IGF3YWl0IHRoaXMuX2dldERhdGEoKCk9Pl9fTl9TU0cgPyB0aGlzLl9nZXRTdGF0aWNEYXRhKGRhdGFIcmVmKSA6IF9fTl9TU1AgPyB0aGlzLl9nZXRTZXJ2ZXJEYXRhKGRhdGFIcmVmKSA6IHRoaXMuZ2V0SW5pdGlhbFByb3BzKENvbXBvbmVudDEsIC8vIHdlIHByb3ZpZGUgQXBwVHJlZSBsYXRlciBzbyB0aGlzIG5lZWRzIHRvIGJlIGBhbnlgXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBwYXRobmFtZSxcbiAgICAgICAgICAgICAgICAgICAgcXVlcnksXG4gICAgICAgICAgICAgICAgICAgIGFzUGF0aDogYXMsXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsZTogdGhpcy5sb2NhbGUsXG4gICAgICAgICAgICAgICAgICAgIGxvY2FsZXM6IHRoaXMubG9jYWxlcyxcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdExvY2FsZTogdGhpcy5kZWZhdWx0TG9jYWxlXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByb3V0ZUluZm8ucHJvcHMgPSBwcm9wcztcbiAgICAgICAgICAgIHRoaXMuY29tcG9uZW50c1tyb3V0ZV0gPSByb3V0ZUluZm87XG4gICAgICAgICAgICByZXR1cm4gcm91dGVJbmZvO1xuICAgICAgICB9IGNhdGNoIChlcnIyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVSb3V0ZUluZm9FcnJvcihlcnIyLCBwYXRobmFtZSwgcXVlcnksIGFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXQocm91dGUsIHBhdGhuYW1lLCBxdWVyeSwgYXMsIGRhdGEsIHJlc2V0U2Nyb2xsKSB7XG4gICAgICAgIHRoaXMuaXNGYWxsYmFjayA9IGZhbHNlO1xuICAgICAgICB0aGlzLnJvdXRlID0gcm91dGU7XG4gICAgICAgIHRoaXMucGF0aG5hbWUgPSBwYXRobmFtZTtcbiAgICAgICAgdGhpcy5xdWVyeSA9IHF1ZXJ5O1xuICAgICAgICB0aGlzLmFzUGF0aCA9IGFzO1xuICAgICAgICByZXR1cm4gdGhpcy5ub3RpZnkoZGF0YSwgcmVzZXRTY3JvbGwpO1xuICAgIH1cbiAgICAvKipcbiAgICogQ2FsbGJhY2sgdG8gZXhlY3V0ZSBiZWZvcmUgcmVwbGFjaW5nIHJvdXRlciBzdGF0ZVxuICAgKiBAcGFyYW0gY2IgY2FsbGJhY2sgdG8gYmUgZXhlY3V0ZWRcbiAgICovIGJlZm9yZVBvcFN0YXRlKGNiKSB7XG4gICAgICAgIHRoaXMuX2JwcyA9IGNiO1xuICAgIH1cbiAgICBvbmx5QUhhc2hDaGFuZ2UoYXMpIHtcbiAgICAgICAgaWYgKCF0aGlzLmFzUGF0aCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBjb25zdCBbb2xkVXJsTm9IYXNoLCBvbGRIYXNoXSA9IHRoaXMuYXNQYXRoLnNwbGl0KCcjJyk7XG4gICAgICAgIGNvbnN0IFtuZXdVcmxOb0hhc2gsIG5ld0hhc2hdID0gYXMuc3BsaXQoJyMnKTtcbiAgICAgICAgLy8gTWFrZXMgc3VyZSB3ZSBzY3JvbGwgdG8gdGhlIHByb3ZpZGVkIGhhc2ggaWYgdGhlIHVybC9oYXNoIGFyZSB0aGUgc2FtZVxuICAgICAgICBpZiAobmV3SGFzaCAmJiBvbGRVcmxOb0hhc2ggPT09IG5ld1VybE5vSGFzaCAmJiBvbGRIYXNoID09PSBuZXdIYXNoKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBJZiB0aGUgdXJscyBhcmUgY2hhbmdlLCB0aGVyZSdzIG1vcmUgdGhhbiBhIGhhc2ggY2hhbmdlXG4gICAgICAgIGlmIChvbGRVcmxOb0hhc2ggIT09IG5ld1VybE5vSGFzaCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIC8vIElmIHRoZSBoYXNoIGhhcyBjaGFuZ2VkLCB0aGVuIGl0J3MgYSBoYXNoIG9ubHkgY2hhbmdlLlxuICAgICAgICAvLyBUaGlzIGNoZWNrIGlzIG5lY2Vzc2FyeSB0byBoYW5kbGUgYm90aCB0aGUgZW50ZXIgYW5kXG4gICAgICAgIC8vIGxlYXZlIGhhc2ggPT09ICcnIGNhc2VzLiBUaGUgaWRlbnRpdHkgY2FzZSBmYWxscyB0aHJvdWdoXG4gICAgICAgIC8vIGFuZCBpcyB0cmVhdGVkIGFzIGEgbmV4dCByZWxvYWQuXG4gICAgICAgIHJldHVybiBvbGRIYXNoICE9PSBuZXdIYXNoO1xuICAgIH1cbiAgICBzY3JvbGxUb0hhc2goYXMpIHtcbiAgICAgICAgY29uc3QgWywgaGFzaF0gPSBhcy5zcGxpdCgnIycpO1xuICAgICAgICAvLyBTY3JvbGwgdG8gdG9wIGlmIHRoZSBoYXNoIGlzIGp1c3QgYCNgIHdpdGggbm8gdmFsdWUgb3IgYCN0b3BgXG4gICAgICAgIC8vIFRvIG1pcnJvciBicm93c2Vyc1xuICAgICAgICBpZiAoaGFzaCA9PT0gJycgfHwgaGFzaCA9PT0gJ3RvcCcpIHtcbiAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBGaXJzdCB3ZSBjaGVjayBpZiB0aGUgZWxlbWVudCBieSBpZCBpcyBmb3VuZFxuICAgICAgICBjb25zdCBpZEVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaGFzaCk7XG4gICAgICAgIGlmIChpZEVsKSB7XG4gICAgICAgICAgICBpZEVsLnNjcm9sbEludG9WaWV3KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhlcmUncyBubyBlbGVtZW50IHdpdGggdGhlIGlkLCB3ZSBjaGVjayB0aGUgYG5hbWVgIHByb3BlcnR5XG4gICAgICAgIC8vIFRvIG1pcnJvciBicm93c2Vyc1xuICAgICAgICBjb25zdCBuYW1lRWwgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5TmFtZShoYXNoKVswXTtcbiAgICAgICAgaWYgKG5hbWVFbCkge1xuICAgICAgICAgICAgbmFtZUVsLnNjcm9sbEludG9WaWV3KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdXJsSXNOZXcoYXNQYXRoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmFzUGF0aCAhPT0gYXNQYXRoO1xuICAgIH1cbiAgICAvKipcbiAgICogUHJlZmV0Y2ggcGFnZSBjb2RlLCB5b3UgbWF5IHdhaXQgZm9yIHRoZSBkYXRhIGR1cmluZyBwYWdlIHJlbmRlcmluZy5cbiAgICogVGhpcyBmZWF0dXJlIG9ubHkgd29ya3MgaW4gcHJvZHVjdGlvbiFcbiAgICogQHBhcmFtIHVybCB0aGUgaHJlZiBvZiBwcmVmZXRjaGVkIHBhZ2VcbiAgICogQHBhcmFtIGFzUGF0aCB0aGUgYXMgcGF0aCBvZiB0aGUgcHJlZmV0Y2hlZCBwYWdlXG4gICAqLyBhc3luYyBwcmVmZXRjaCh1cmwsIGFzUGF0aCA9IHVybCwgb3B0aW9ucyA9IHtcbiAgICB9KSB7XG4gICAgICAgIGxldCBwYXJzZWQgPSAoMCwgX3BhcnNlUmVsYXRpdmVVcmwpLnBhcnNlUmVsYXRpdmVVcmwodXJsKTtcbiAgICAgICAgbGV0IHsgcGF0aG5hbWU6IHBhdGhuYW1lMiAgfSA9IHBhcnNlZDtcbiAgICAgICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpIHtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmxvY2FsZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICBwYXRobmFtZTIgPSAoMCwgX25vcm1hbGl6ZUxvY2FsZVBhdGgpLm5vcm1hbGl6ZUxvY2FsZVBhdGgocGF0aG5hbWUyLCB0aGlzLmxvY2FsZXMpLnBhdGhuYW1lO1xuICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHBhdGhuYW1lMjtcbiAgICAgICAgICAgICAgICB1cmwgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpO1xuICAgICAgICAgICAgICAgIGxldCBwYXJzZWRBcyA9ICgwLCBfcGFyc2VSZWxhdGl2ZVVybCkucGFyc2VSZWxhdGl2ZVVybChhc1BhdGgpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxvY2FsZVBhdGhSZXN1bHQgPSAoMCwgX25vcm1hbGl6ZUxvY2FsZVBhdGgpLm5vcm1hbGl6ZUxvY2FsZVBhdGgocGFyc2VkQXMucGF0aG5hbWUsIHRoaXMubG9jYWxlcyk7XG4gICAgICAgICAgICAgICAgcGFyc2VkQXMucGF0aG5hbWUgPSBsb2NhbGVQYXRoUmVzdWx0LnBhdGhuYW1lO1xuICAgICAgICAgICAgICAgIG9wdGlvbnMubG9jYWxlID0gbG9jYWxlUGF0aFJlc3VsdC5kZXRlY3RlZExvY2FsZSB8fCB0aGlzLmRlZmF1bHRMb2NhbGU7XG4gICAgICAgICAgICAgICAgYXNQYXRoID0gKDAsIF91dGlscykuZm9ybWF0V2l0aFZhbGlkYXRpb24ocGFyc2VkQXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHBhZ2VzID0gYXdhaXQgdGhpcy5wYWdlTG9hZGVyLmdldFBhZ2VMaXN0KCk7XG4gICAgICAgIGxldCByZXNvbHZlZEFzID0gYXNQYXRoO1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX0hBU19SRVdSSVRFUyAmJiBhc1BhdGguc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgICAgICBsZXQgcmV3cml0ZXM7XG4gICAgICAgICAgICAoeyBfX3Jld3JpdGVzOiByZXdyaXRlcyAgfSA9IGF3YWl0ICgwLCBfcm91dGVMb2FkZXIpLmdldENsaWVudEJ1aWxkTWFuaWZlc3QoKSk7XG4gICAgICAgICAgICBjb25zdCByZXdyaXRlc1Jlc3VsdCA9ICgwLCBfcmVzb2x2ZVJld3JpdGVzKS5kZWZhdWx0KGFkZEJhc2VQYXRoKGFkZExvY2FsZShhc1BhdGgsIHRoaXMubG9jYWxlKSksIHBhZ2VzLCByZXdyaXRlcywgcGFyc2VkLnF1ZXJ5LCAocCk9PnJlc29sdmVEeW5hbWljUm91dGUocCwgcGFnZXMpXG4gICAgICAgICAgICAsIHRoaXMubG9jYWxlcyk7XG4gICAgICAgICAgICByZXNvbHZlZEFzID0gZGVsTG9jYWxlKGRlbEJhc2VQYXRoKHJld3JpdGVzUmVzdWx0LmFzUGF0aCksIHRoaXMubG9jYWxlKTtcbiAgICAgICAgICAgIGlmIChyZXdyaXRlc1Jlc3VsdC5tYXRjaGVkUGFnZSAmJiByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWYpIHtcbiAgICAgICAgICAgICAgICAvLyBpZiB0aGlzIGRpcmVjdGx5IG1hdGNoZXMgYSBwYWdlIHdlIG5lZWQgdG8gdXBkYXRlIHRoZSBocmVmIHRvXG4gICAgICAgICAgICAgICAgLy8gYWxsb3cgdGhlIGNvcnJlY3QgcGFnZSBjaHVuayB0byBiZSBsb2FkZWRcbiAgICAgICAgICAgICAgICBwYXRobmFtZTIgPSByZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWY7XG4gICAgICAgICAgICAgICAgcGFyc2VkLnBhdGhuYW1lID0gcGF0aG5hbWUyO1xuICAgICAgICAgICAgICAgIHVybCA9ICgwLCBfdXRpbHMpLmZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwYXJzZWQucGF0aG5hbWUgPSByZXNvbHZlRHluYW1pY1JvdXRlKHBhcnNlZC5wYXRobmFtZSwgcGFnZXMpO1xuICAgICAgICAgICAgaWYgKHBhcnNlZC5wYXRobmFtZSAhPT0gcGF0aG5hbWUyKSB7XG4gICAgICAgICAgICAgICAgcGF0aG5hbWUyID0gcGFyc2VkLnBhdGhuYW1lO1xuICAgICAgICAgICAgICAgIHBhcnNlZC5wYXRobmFtZSA9IHBhdGhuYW1lMjtcbiAgICAgICAgICAgICAgICB1cmwgPSAoMCwgX3V0aWxzKS5mb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJvdXRlID0gKDAsIF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoKS5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZTIpO1xuICAgICAgICAvLyBQcmVmZXRjaCBpcyBub3Qgc3VwcG9ydGVkIGluIGRldmVsb3BtZW50IG1vZGUgYmVjYXVzZSBpdCB3b3VsZCB0cmlnZ2VyIG9uLWRlbWFuZC1lbnRyaWVzXG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgICAgdGhpcy5wYWdlTG9hZGVyLl9pc1NzZyhyb3V0ZSkudGhlbigoaXNTc2cpPT57XG4gICAgICAgICAgICAgICAgcmV0dXJuIGlzU3NnID8gdGhpcy5fZ2V0U3RhdGljRGF0YSh0aGlzLnBhZ2VMb2FkZXIuZ2V0RGF0YUhyZWYodXJsLCByZXNvbHZlZEFzLCB0cnVlLCB0eXBlb2Ygb3B0aW9ucy5sb2NhbGUgIT09ICd1bmRlZmluZWQnID8gb3B0aW9ucy5sb2NhbGUgOiB0aGlzLmxvY2FsZSkpIDogZmFsc2U7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIHRoaXMucGFnZUxvYWRlcltvcHRpb25zLnByaW9yaXR5ID8gJ2xvYWRQYWdlJyA6ICdwcmVmZXRjaCddKHJvdXRlKSwgXG4gICAgICAgIF0pO1xuICAgIH1cbiAgICBhc3luYyBmZXRjaENvbXBvbmVudChyb3V0ZSkge1xuICAgICAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IGNhbmNlbCA9IHRoaXMuY2xjID0gKCk9PntcbiAgICAgICAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGNvbXBvbmVudFJlc3VsdCA9IGF3YWl0IHRoaXMucGFnZUxvYWRlci5sb2FkUGFnZShyb3V0ZSk7XG4gICAgICAgIGlmIChjYW5jZWxsZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKGBBYm9ydCBmZXRjaGluZyBjb21wb25lbnQgZm9yIHJvdXRlOiBcIiR7cm91dGV9XCJgKTtcbiAgICAgICAgICAgIGVycm9yLmNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2FuY2VsID09PSB0aGlzLmNsYykge1xuICAgICAgICAgICAgdGhpcy5jbGMgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjb21wb25lbnRSZXN1bHQ7XG4gICAgfVxuICAgIF9nZXREYXRhKGZuKSB7XG4gICAgICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcbiAgICAgICAgY29uc3QgY2FuY2VsID0gKCk9PntcbiAgICAgICAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuY2xjID0gY2FuY2VsO1xuICAgICAgICByZXR1cm4gZm4oKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgaWYgKGNhbmNlbCA9PT0gdGhpcy5jbGMpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNsYyA9IG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyMiA9IG5ldyBFcnJvcignTG9hZGluZyBpbml0aWFsIHByb3BzIGNhbmNlbGxlZCcpO1xuICAgICAgICAgICAgICAgIGVycjIuY2FuY2VsbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0aHJvdyBlcnIyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBfZ2V0U3RhdGljRGF0YShkYXRhSHJlZikge1xuICAgICAgICBjb25zdCB7IGhyZWY6IGNhY2hlS2V5ICB9ID0gbmV3IFVSTChkYXRhSHJlZiwgd2luZG93LmxvY2F0aW9uLmhyZWYpO1xuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJyAmJiAhdGhpcy5pc1ByZXZpZXcgJiYgdGhpcy5zZGNbY2FjaGVLZXldKSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMuc2RjW2NhY2hlS2V5XSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZldGNoTmV4dERhdGEoZGF0YUhyZWYsIHRoaXMuaXNTc3IpLnRoZW4oKGRhdGEpPT57XG4gICAgICAgICAgICB0aGlzLnNkY1tjYWNoZUtleV0gPSBkYXRhO1xuICAgICAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBfZ2V0U2VydmVyRGF0YShkYXRhSHJlZikge1xuICAgICAgICBjb25zdCB7IGhyZWY6IHJlc291cmNlS2V5ICB9ID0gbmV3IFVSTChkYXRhSHJlZiwgd2luZG93LmxvY2F0aW9uLmhyZWYpO1xuICAgICAgICBpZiAodGhpcy5zZHJbcmVzb3VyY2VLZXldKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zZHJbcmVzb3VyY2VLZXldO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLnNkcltyZXNvdXJjZUtleV0gPSBmZXRjaE5leHREYXRhKGRhdGFIcmVmLCB0aGlzLmlzU3NyKS50aGVuKChkYXRhKT0+e1xuICAgICAgICAgICAgZGVsZXRlIHRoaXMuc2RyW3Jlc291cmNlS2V5XTtcbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9KS5jYXRjaCgoZXJyMik9PntcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLnNkcltyZXNvdXJjZUtleV07XG4gICAgICAgICAgICB0aHJvdyBlcnIyO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgZ2V0SW5pdGlhbFByb3BzKENvbXBvbmVudCwgY3R4KSB7XG4gICAgICAgIGNvbnN0IHsgQ29tcG9uZW50OiBBcHAxICB9ID0gdGhpcy5jb21wb25lbnRzWycvX2FwcCddO1xuICAgICAgICBjb25zdCBBcHBUcmVlID0gdGhpcy5fd3JhcEFwcChBcHAxKTtcbiAgICAgICAgY3R4LkFwcFRyZWUgPSBBcHBUcmVlO1xuICAgICAgICByZXR1cm4gKDAsIF91dGlscykubG9hZEdldEluaXRpYWxQcm9wcyhBcHAxLCB7XG4gICAgICAgICAgICBBcHBUcmVlLFxuICAgICAgICAgICAgQ29tcG9uZW50LFxuICAgICAgICAgICAgcm91dGVyOiB0aGlzLFxuICAgICAgICAgICAgY3R4XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBhYm9ydENvbXBvbmVudExvYWQoYXMsIHJvdXRlUHJvcHMpIHtcbiAgICAgICAgaWYgKHRoaXMuY2xjKSB7XG4gICAgICAgICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlRXJyb3InLCBidWlsZENhbmNlbGxhdGlvbkVycm9yKCksIGFzLCByb3V0ZVByb3BzKTtcbiAgICAgICAgICAgIHRoaXMuY2xjKCk7XG4gICAgICAgICAgICB0aGlzLmNsYyA9IG51bGw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgbm90aWZ5KGRhdGEsIHJlc2V0U2Nyb2xsKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnN1YihkYXRhLCB0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10uQ29tcG9uZW50LCByZXNldFNjcm9sbCk7XG4gICAgfVxufVxuUm91dGVyLmV2ZW50cyA9ICgwLCBfbWl0dCkuZGVmYXVsdCgpO1xuZXhwb3J0cy5kZWZhdWx0ID0gUm91dGVyO1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZXIuanMubWFwIiwiaW1wb3J0IHsgRm9vdGVyLCBIZWFkLCBOYXZCYXIgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzJ1xyXG5pbXBvcnQgc3R5bGVkLCB7IGNzcywga2V5ZnJhbWVzIH0gZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcbmltcG9ydCB7VHh0LCBUZXh0QmdDb250YWluZXJ9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvVGV4dEJnJ1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IHsgTWVkaWFIZWFkLCBGaWx0ZXJEcm9wYm94LCBDYXRlZ29yeUJhcn0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9NZWRpYUNvbXBvbmVudCdcclxuXHJcblxyXG5jb25zdCBCb3ggPSBzdHlsZWQuZGl2YFxyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG5gXHJcblxyXG5jb25zdCBNZWRpYV9Dc3MgPSBjc3NgXHJcbiAgICBodG1sLFxyXG4gICAgYm9keSB7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IGFudGlxdWV3aGl0ZTtcclxuICAgIH1cclxuXHJcbiAgICAuY29uZGl0aW9uIHtcclxuICAgICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XHJcbiAgICB9XHJcblxyXG4gICAgLmNvbmRpdGlvbjpob3ZlcntcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcblxyXG4gICAgKiB7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgfVxyXG4gICAgXHJcbmBcclxuY29uc3QgSW1nQ3NzID0gY3NzYFxyXG5cclxuLmltZ0dhbGxlcnl7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIG1hcmdpbjogMTBweDtcclxufVxyXG5cclxuLkdhbENvbnRhaW5lcntcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHBhZGRpbmctdG9wOiAxMHZoO1xyXG59XHJcbi5jYXRlZ29yeUNvbnRhaW5lcntcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcbmBcclxuY29uc3QgRG9udEhhdmUgPSBzdHlsZWQuaDFgXHJcbiAgICBmb250LXNpemU6IDRyZW07XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuXHJcbmBcclxuXHJcbmNvbnN0IE1lZGlhID0gKCkgPT4ge1xyXG4gICAgbGV0IGRhdGEgPSByZXF1aXJlKFwiLi4vLi4vcHVibGljL21lZGlhX2NvbnRlbnQvY29udGVudHMuanNvblwiKTtcclxuICAgIGRhdGEgPSBkYXRhLndhbGxwYXBlci5jb25jYXQoZGF0YS52aWRlbywgZGF0YS5zY3JlZW5zaG90LCBkYXRhLmFydHdvcmssIGRhdGEubG9nbywgZGF0YS5jb250ZW50X2NyZWF0b3IpO1xyXG4gICAgY29uc3Qgc2l6ZSA9IFtbXCIyMHZ3XCIsXCIyMHZ3XCIgXSwgW1wiMjB2d1wiLCBcIjMwdndcIl0sIFtcIjMwdndcIiwgXCIzMHZ3XCJdXTtcclxuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8SGVhZCB0aXRsZT1cIlZBTE9SQU5UOiDguYDguIHguKHguKLguLTguIfguJvguLfguJnguIjguLLguIEgUmlvdCBHYW1lcyDguYPguJnguKPguLnguJvguYHguJrguJogNXY1IOC4l+C4teC5iOC4guC4seC4muC5gOC4hOC4peC4t+C5iOC4reC4meC5guC4lOC4ouC4leC4seC4p+C4peC4sOC4hOC4o+C4meC4seC4geC4ouC4tOC4h+C4m+C4t+C4meC4nOC4ueC5ieC4oeC4suC4geC4hOC4p+C4suC4oeC4quC4suC4oeC4suC4o+C4llwiIC8+XHJcbiAgICAgICAgICAgIDxOYXZCYXIgLz5cclxuICAgICAgICAgICAgPHN0eWxlPnsgTWVkaWFfQ3NzIH08L3N0eWxlPlxyXG4gICAgICAgICAgICA8c3R5bGU+eyBJbWdDc3MgfTwvc3R5bGU+XHJcbiAgICAgICAgICAgIDxNZWRpYUhlYWQ+PC9NZWRpYUhlYWQ+XHJcbiAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICA8Q2F0ZWdvcnlCYXIvPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJHYWxDb250YWluZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RG9udEhhdmUgc3R5bGU9e3sgZGlzcGxheTogYG5vbmVgfX0+4LiB4Lil4Lix4Lia4Lih4Liy4LiV4Lij4Lin4LiI4Liq4Lit4Lia4LmD4Lir4Lih4LmI4Lit4Li14LiB4LiE4Lij4Lix4LmJ4LiH4LmD4LiZ4Lig4Liy4Lii4Lir4Lil4Lix4LiHITwvRG9udEhhdmU+XHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhLm1hcCgoIGltYWdlLCBpbmRleCApPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaW1nU2l6ZSA9IHNpemVbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpKjMpXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICg8ZGl2IGtleT17IGluZGV4IH0gY2xhc3NOYW1lPVwiaW1nR2FsbGVyeVwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IGB1cmwoJHtpbWFnZS5wYXRofSlgLCBiYWNrZ3JvdW5kU2l6ZTogXCJjb3ZlclwiLCB3aWR0aDogYCR7aW1nU2l6ZVswXX1gLCBoZWlnaHQ6IGAke2ltZ1NpemVbMV19YH19ID48L2Rpdj4pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNZWRpYTtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuaW1wb3J0IHsgTmF2SXRlbUxheW91dCB9IGZyb20gJy4vTmF2SXRlbUxheW91dCdcclxuXHJcbmNvbnN0IFN0eWxlZENhcmV0RG93biA9IHN0eWxlZC5zdmdgXHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogMTZweDtcclxuICAgIGhlaWdodDogMTZweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA0cHg7XHJcbiAgICBwYWRkaW5nLXRvcDogNnB4O1xyXG4gICAgZmlsbDogIzdFN0U3RTtcclxuICAgICR7TmF2SXRlbUxheW91dH06aG92ZXIgJiB7XHJcbiAgICAgICAgZmlsbDogd2hpdGU7XHJcbiAgICB9XHJcbmBcclxuXHJcbmNvbnN0IENhcmV0RG93biA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFN0eWxlZENhcmV0RG93biB2aWV3Qm94PVwiMCAwIDE2IDE2XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNNy4yNDcgMTEuMTQgMi40NTEgNS42NThDMS44ODUgNS4wMTMgMi4zNDUgNCAzLjIwNCA0aDkuNTkyYTEgMSAwIDAgMSAuNzUzIDEuNjU5bC00Ljc5NiA1LjQ4YTEgMSAwIDAgMS0xLjUwNiAwelwiLz5cclxuICAgICAgICA8L1N0eWxlZENhcmV0RG93bj5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2FyZXREb3duOyIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcbmltcG9ydCB7IFN0eWxlZExpIH0gZnJvbSAnLi9TdHlsZWRMaSdcclxuXHJcbmNvbnN0IFN0eWxlZEFycm93VXAgPSBzdHlsZWQuc3ZnYFxyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgd2lkdGg6IDE2cHg7XHJcbiAgICBoZWlnaHQ6IDE2cHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMnB4O1xyXG4gICAgcGFkZGluZy10b3A6IDZweDtcclxuICAgIGZpbGw6ICM3RTdFN0U7XHJcbiAgICAke1N0eWxlZExpfTpob3ZlciAmIHtcclxuICAgICAgICBmaWxsOiB3aGl0ZTtcclxuICAgIH1cclxuYFxyXG5cclxuY29uc3QgRHJvcGRvd25BcnJvd1VwID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8U3R5bGVkQXJyb3dVcCB2aWV3Qm94PVwiMCAwIDE2IDE2XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGZpbGxSdWxlPVwiZXZlbm9kZFwiIGQ9XCJNMTQgMi41YS41LjUgMCAwIDAtLjUtLjVoLTZhLjUuNSAwIDAgMCAwIDFoNC43OTNMMi4xNDYgMTMuMTQ2YS41LjUgMCAwIDAgLjcwOC43MDhMMTMgMy43MDdWOC41YS41LjUgMCAwIDAgMSAwdi02elwiLz5cclxuICAgICAgICA8L1N0eWxlZEFycm93VXA+XHJcbiAgICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IERyb3Bkb3duQXJyb3dVcDsiLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5pbXBvcnQgeyBOYXZJdGVtTGF5b3V0IH0gZnJvbSAnLi9OYXZJdGVtTGF5b3V0J1xyXG5cclxuY29uc3QgU3R5bGVkQXJyb3dVcCA9IHN0eWxlZC5zdmdgXHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogMTZweDtcclxuICAgIGhlaWdodDogMTZweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAycHg7XHJcbiAgICBwYWRkaW5nLXRvcDogNnB4O1xyXG4gICAgZmlsbDogIzdFN0U3RTtcclxuICAgICR7TmF2SXRlbUxheW91dH06aG92ZXIgJiB7XHJcbiAgICAgICAgZmlsbDogd2hpdGU7XHJcbiAgICB9XHJcbmBcclxuXHJcbmNvbnN0IE5hdkFycm93VXAgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxTdHlsZWRBcnJvd1VwIHZpZXdCb3g9XCIwIDAgMTYgMTZcIj5cclxuICAgICAgICAgICAgPHBhdGggZmlsbFJ1bGU9XCJldmVub2RkXCIgZD1cIk0xNCAyLjVhLjUuNSAwIDAgMC0uNS0uNWgtNmEuNS41IDAgMCAwIDAgMWg0Ljc5M0wyLjE0NiAxMy4xNDZhLjUuNSAwIDAgMCAuNzA4LjcwOEwxMyAzLjcwN1Y4LjVhLjUuNSAwIDAgMCAxIDB2LTZ6XCIvPlxyXG4gICAgICAgIDwvU3R5bGVkQXJyb3dVcD5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2QXJyb3dVcDsiLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5cclxuZXhwb3J0IGNvbnN0IE5hdkl0ZW1MYXlvdXQgPSBzdHlsZWQuZGl2YFxyXG4gICAgZm9udC1mYW1pbHk6ICdCYWkgSmFtanVyZWUnLCBzYW5zLXNlcmlmO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxZW07XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxZW07XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBsaW5lLWhlaWdodDogODBweDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBtYXJnaW4tbGVmdDogNHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBib3JkZXItYm90dG9tOiAycHggcmdiKDI1NSwgNzAsIDg1KSBzb2xpZDtcclxuICAgIH1cclxuYCIsImltcG9ydCBzdHlsZWQgZnJvbSAnc3R5bGVkLWNvbXBvbmVudHMnXHJcbmltcG9ydCB7IFJpb3RHYW1lc0JhciB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvTmF2L1Jpb3RHYW1lc0JhcidcclxuXHJcbmNvbnN0IFN0eWxlZExvZ28gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IDI0cHg7XHJcbmBcclxuXHJcbmNvbnN0IFJpb3RMb2dvV3JhcHBlciA9IHN0eWxlZC5idXR0b25gXHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBtYXJnaW46IDAgMTJweDtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG5gXHJcblxyXG5jb25zdCBTdHlsZWRDYXJldERvd24gPSBzdHlsZWQuc3ZnYFxyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgd2lkdGg6IDE2cHg7XHJcbiAgICBoZWlnaHQ6IDE2cHg7XHJcbiAgICBtYXJnaW4tbGVmdDogOHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDZweDtcclxuICAgIGZpbGw6ICM3RTdFN0U7XHJcbiAgICAke1Jpb3RMb2dvV3JhcHBlcn06aG92ZXIgJiB7XHJcbiAgICAgICAgZmlsbDogd2hpdGU7XHJcbiAgICB9XHJcbmBcclxuXHJcbmNvbnN0IENhcmV0RG93biA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPFN0eWxlZENhcmV0RG93biB2aWV3Qm94PVwiMCAwIDE2IDE2XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNNy4yNDcgMTEuMTQgMi40NTEgNS42NThDMS44ODUgNS4wMTMgMi4zNDUgNCAzLjIwNCA0aDkuNTkyYTEgMSAwIDAgMSAuNzUzIDEuNjU5bC00Ljc5NiA1LjQ4YTEgMSAwIDAgMS0xLjUwNiAwelwiLz5cclxuICAgICAgICA8L1N0eWxlZENhcmV0RG93bj5cclxuICAgIClcclxufVxyXG5cclxuY29uc3QgUmlvdExvZ28gPSAoeyBpc0dhbWVCYXJPcGVuLCBvbkNsaWNrLCBzdGF0ZUNvbnRyb2wgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8UmlvdExvZ29XcmFwcGVyIG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICAgICAgICAgICAgPFN0eWxlZExvZ28gdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCIjZmZmXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xMi41MzQgMjEuNzdsLTEuMDktMi44MSAxMC41Mi41NC0uNDUxIDQuNXpNMTUuMDYgMEwuMzA3IDYuOTY5IDIuNTkgMTcuNDcxSDUuNmwtLjUyLTcuNTEyLjQ2MS0uMTQ0IDEuODEgNy42NTZoMy4xMjZsLS4xMTYtOS4xNS40NjItLjE0NCAxLjU4MiA5LjI5NGgzLjMxbC43OC0xMS4wNTMuNDYyLS4xNDQuODIgMTEuMTk3aDQuMzc2bDEuNTQtMTUuMzdaXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvU3R5bGVkTG9nbz5cclxuICAgICAgICAgICAgICAgIDxDYXJldERvd24gLz5cclxuICAgICAgICAgICAgPC9SaW90TG9nb1dyYXBwZXI+XHJcbiAgICAgICAgICAgIDxSaW90R2FtZXNCYXIgaXNPcGVuPXtpc0dhbWVCYXJPcGVufSBzdGF0ZUNvbnRyb2w9e3N0YXRlQ29udHJvbH0gLz5cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmlvdExvZ287IiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIlxyXG5cclxuZXhwb3J0IGNvbnN0IFN0eWxlZExpID0gc3R5bGVkLmxpYFxyXG4gICAgbGluZS1oZWlnaHQ6IDUwcHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDI0cHg7XHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzO1xyXG4gICAgfVxyXG5gIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIlxyXG5cclxuZXhwb3J0IGNvbnN0IFN0eWxlZExpbmsgPSBzdHlsZWQuYWBcclxuICAgIGZvbnQtZmFtaWx5OiAnQmFpIEphbWp1cmVlJywgc2Fucy1zZXJpZjtcclxuICAgIHBhZGRpbmctbGVmdDogMTJweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDEycHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBsaW5lLWhlaWdodDogODBweDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBtYXJnaW46IDAgLjg1ZW07XHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBib3JkZXItYm90dG9tOiAycHggcmdiKDI1NSwgNzAsIDg1KSBzb2xpZDtcclxuICAgIH1cclxuYCIsImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmNvbnN0IFN0eWxlZExvZ28gPSBzdHlsZWQuc3ZnYFxyXG4gICAgd2lkdGg6IDM1cHg7XHJcbiAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAyMi41cHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbmBcclxuXHJcbmNvbnN0IFZhbG9yYW50TG9nbyA9ICh7IGhyZWYgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8TGluayBocmVmPXtocmVmfSBwYXNzSHJlZj5cclxuICAgICAgICAgICAgPGE+XHJcbiAgICAgICAgICAgICAgICA8U3R5bGVkTG9nbyB2aWV3Qm94PVwiMCAwIDEwMCAxMDBcIiBmaWxsPVwiI2ZmZlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNOTkuMjUgNDguNjZWMTAuMjhjMC0uNTktLjc1LS44Ni0xLjEyLS4zOWwtNDEuOTIgNTIuNGEuNjI3LjYyNyAwIDAwLjQ5IDEuMDJoMzAuMjljLjgyIDAgMS41OS0uMzcgMi4xLTEuMDFsOS41Ny0xMS45NmMuMzgtLjQ4LjU5LTEuMDcuNTktMS42OHpNMS4xNyA1MC4zNEwzMi42NiA4OS43Yy41MS42NCAxLjI4IDEuMDEgMi4xIDEuMDFoMzAuMjljLjUzIDAgLjgyLS42MS40OS0xLjAyTDEuNyA5Ljg5Yy0uMzctLjQ2LTEuMTItLjItMS4xMi4zOXYzOC4zOGMwIC42MS4yMSAxLjIuNTkgMS42OHpcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9TdHlsZWRMb2dvPlxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBWYWxvcmFudExvZ287IiwiZXhwb3J0IHtOYXZJdGVtTGF5b3V0fSBmcm9tICcuL05hdkl0ZW1MYXlvdXQnXHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBOYXZBcnJvd1VwfSBmcm9tICcuL05hdkFycm93VXAnXHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBEcm9wZG93bkFycm93VXB9IGZyb20gJy4vRHJvcGRvd25BcnJvd1VwJ1xyXG5leHBvcnQge2RlZmF1bHQgYXMgQ2FyZXREb3dufSBmcm9tICcuL0NhcmV0RG93bidcclxuZXhwb3J0IHtTdHlsZWRMaW5rfSBmcm9tICcuL1N0eWxlZExpbmsnXHJcbmV4cG9ydCB7U3R5bGVkTGl9IGZyb20gJy4vU3R5bGVkTGknXHJcbmV4cG9ydCB7ZGVmYXVsdCBhcyBWYWxvcmFudExvZ299IGZyb20gJy4vVmFsb3JhbnRMb2dvJ1xyXG5leHBvcnQge2RlZmF1bHQgYXMgUmlvdExvZ299IGZyb20gJy4vUmlvdExvZ28nXHJcbiIsIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcInN0cm9rZVwiOiBcIk5ld3Nfc3Ryb2tlX18xR2VCb1wiLFxuXHRcInNsaWRlck5hdlwiOiBcIk5ld3Nfc2xpZGVyTmF2X18yQkhmNlwiLFxuXHRcInRleHRCYWNrZ3JvdW5kMVwiOiBcIk5ld3NfdGV4dEJhY2tncm91bmQxX19qcHV2elwiLFxuXHRcInRleHRCYWNrZ3JvdW5kMlwiOiBcIk5ld3NfdGV4dEJhY2tncm91bmQyX19qVjVxQVwiXG59O1xuIiwiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwic3Ryb2tlXCI6IFwibWVkaWFfc3Ryb2tlX19uQ28yN1wiXG59O1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Rpc3QvY2xpZW50L2xpbmsnKVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGguanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvaTE4bi9ub3JtYWxpemUtbG9jYWxlLXBhdGguanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvbWl0dC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXItY29udGV4dC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvZ2V0LWFzc2V0LXBhdGgtZnJvbS1yb3V0ZS5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvaXMtZHluYW1pYy5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcGFyc2UtcmVsYXRpdmUtdXJsLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9zaGFyZWQvbGliL3JvdXRlci91dGlscy9xdWVyeXN0cmluZy5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtbWF0Y2hlci5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtcmVnZXguanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvdXRpbHMuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9oZWFkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvcm91dGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LWlzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzdHlsZWQtY29tcG9uZW50c1wiKTsiLCIvKiAoaWdub3JlZCkgKi8iXSwibmFtZXMiOlsic3R5bGVkIiwiU3R5bGVkQnV0dG9uV3JhcHBlciIsImJ1dHRvbiIsIkNvbnRlbnQiLCJkaXYiLCJwcm9wcyIsImlzV2hpdGUiLCJpc0JvcmRlcmVkIiwiV2hpdGVCb3giLCJCdXR0b25Cb3JkZXIiLCJUb3BCb3JkZXIiLCJCb3R0b21Cb3JkZXIiLCJCdXR0b24iLCJjaGlsZHJlbiIsIlN0eWxlZExvZ28iLCJzdmciLCJGaXN0TG9nbyIsIkZvb3RlckxheW91dCIsIlJpb3RHYW1lc0xvZ28iLCJCdXR0b25XcmFwcGVyIiwiRmFjZWJvb2tJY29uIiwiSW5zdGFncmFtSWNvbiIsIllvdXR1YmVJY29uIiwiUCIsInAiLCJSZXNlcnZlZCIsIkxvZ29XcmFwcGVyIiwiVW5kZXJsaW5lIiwiTGlua1dyYXBwZXIiLCJTb2NpYWxXcmFwcGVyIiwiRm9vdGVyIiwiZm9vdGVyIiwiZGVmYXVsdCIsIldyYXBwZXIiLCJhIiwiaHJlZiIsIk5leHRIZWFkIiwiSGVhZCIsInRpdGxlIiwiTGluayIsIkZpbHRlckRyb3Bib3giLCJ1c2VSb3V0ZXIiLCJCYXIiLCJ1bCIsIkNhdGVnb3J5IiwibGkiLCJDYXRlZ29yeUJhciIsInJvdXRlciIsImNhdGVnb3J5IiwicXVlcnkiLCJjb2xvciIsImJvcmRlckJvdHRvbSIsInVzZVN0YXRlIiwiUmVhY3QiLCJUZXh0IiwiQm94IiwidHlwZSIsIm9uU2VsZWN0Q2hhbmdlIiwiZSIsImxvY2FsZSIsInRhcmdldCIsInZhbHVlIiwicHVzaCIsInBhdGhuYW1lIiwiYXNQYXRoIiwic2Nyb2xsIiwiY29udmVydCIsIml0ZW1MaXN0Iiwib3BlbkRyb3Bib3giLCJjb25zb2xlIiwibG9nIiwibWFwIiwiaXRlbSIsImluZGV4IiwiVHh0IiwiVGV4dEJnQ29udGFpbmVyIiwic3R5bGVzIiwiTWVkaWFIZWFkZXIiLCJNZWRpYVRvcGljQ29udGlhbmVyIiwiTWVkaWFUb3BpYyIsImgxIiwiTWVkaWFUb3BpY0NvbnRlbnQiLCJNZWRpYUhlYWRlckltZyIsInNwYW4iLCJCb3RMZWZ0SW1nIiwiTGluZSIsIk1lZGlhSGVhZCIsImhlaWdodCIsIm92ZXJmbG93IiwiYmFja2dyb3VuZCIsInpJbmRleCIsInRvcCIsInRleHRCYWNrZ3JvdW5kIiwic3Ryb2tlIiwiZm9udFNpemUiLCJMYW5nU2VsZWN0b3IiLCJMYW5nQnV0dG9uIiwiaXNPcGVuIiwib25DbGljayIsIlN0eWxlZExheW91dCIsIlN0eWxlZENoZWNrZWRJY29uIiwiQ2hlY2tlZEljb24iLCJTdHlsZWRUcmlhbmdsZVVwIiwiVHJpYW5nbGVVcCIsIkxhbmd1YWdlU3VwcG9ydCIsIlN0eWxlTGFuZ0l0ZW0iLCJzZWxlY3RlZCIsIkxhbmdJdGVtIiwiaSIsIk5hdkxheW91dCIsIk5hdkl0ZW0iLCJEcm9wZG93biIsIkV4dGVybmFsTGkiLCJMaSIsIkV4dGVybmFsIiwiVmFsb3JhbnRMb2dvIiwiUmlvdExvZ28iLCJTZXBhcmF0b3IiLCJQbGF5QnV0dG9uIiwiUmlnaHROYXYiLCJOYXZCYXIiLCJvcGVuUmlvdEdhbWVCYXIiLCJzZXRPcGVuUmlvdEdhbWVCYXIiLCJvcGVuTGFuZ1NlbGVjdG9yIiwic2V0T3BlbkxhbmdTZWxlY3RvciIsIm9wZW5QbGF5UG9wdXAiLCJzZXRPcGVuUGxheVBvcHVwIiwiaGFuZGxlUmlvdEdhbWVCYXJDbGljayIsInByZXZlbnREZWZhdWx0IiwiaGFuZGxlTGFuZ0NsaWNrIiwiaGFuZGxlUGxheVBvcHVwQ2xpY2siLCJSaW90R2FtZUJhclN0YXRlQ29udHJvbCIsInN0YXRlIiwiUGxheVBvcHVwU3RhdGVDb250cm9sIiwiRHJvcGRvd25BcnJvd1VwIiwiU3R5bGVkTGkiLCJOYXZJdGVtTGF5b3V0IiwiQ2FyZXREb3duIiwiVWwiLCJOYXZBcnJvd1VwIiwiRXh0ZXJuYWxMaW5rIiwiU3R5bGVkTGluayIsIk5hdiIsIm5hdiIsIk5hdlNlcGFyYXRvciIsIlBsYXlQb3B1cCIsInN0YXRlQ29udHJvbCIsIlBvcHVwV3JhcHBlciIsIkRpbW1lZEJhY2tncm91bmQiLCJQb3B1cCIsIlBvcHVwVGl0bGVXcmFwcGVyIiwiUG9wdXBCdXR0b25XcmFwcGVyIiwiQnV0dG9uTGFiZWwiLCJFeGl0QnV0dG9uV3JhcHBlciIsIkV4aXRCdXR0b24iLCJTdmdFeGl0IiwiRXhpdEJ1dHRvblN0eWxlIiwiR2FtZXNCYXIiLCJHYW1lc0JhcldyYXBwZXIiLCJUaXRsZVJpb3RHYW1lcyIsIlJpb3RHYW1lc0JhciIsImNzcyIsIlRleHRCRyIsInRleHRCYWNrZ3JvdW5kMSIsInRleHRCYWNrZ3JvdW5kMiIsIlN0eWxlZFRpdGxlIiwidGV4dENvbG9yIiwiVGl0bGUiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImV4cG9ydHMiLCJfcmVhY3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwicmVxdWlyZSIsIl9yb3V0ZXIiLCJfcm91dGVyMSIsIl91c2VJbnRlcnNlY3Rpb24iLCJvYmoiLCJfX2VzTW9kdWxlIiwicHJlZmV0Y2hlZCIsInByZWZldGNoIiwiYXMiLCJvcHRpb25zIiwiaXNMb2NhbFVSTCIsImNhdGNoIiwiZXJyIiwiY3VyTG9jYWxlIiwiaXNNb2RpZmllZEV2ZW50IiwiZXZlbnQiLCJjdXJyZW50VGFyZ2V0IiwibWV0YUtleSIsImN0cmxLZXkiLCJzaGlmdEtleSIsImFsdEtleSIsIm5hdGl2ZUV2ZW50Iiwid2hpY2giLCJsaW5rQ2xpY2tlZCIsInJlcGxhY2UiLCJzaGFsbG93Iiwibm9kZU5hbWUiLCJpbmRleE9mIiwiY3JlYXRlUHJvcEVycm9yIiwiYXJncyIsIkVycm9yIiwia2V5IiwiZXhwZWN0ZWQiLCJhY3R1YWwiLCJyZXF1aXJlZFByb3BzR3VhcmQiLCJyZXF1aXJlZFByb3BzIiwia2V5cyIsImZvckVhY2giLCJfIiwib3B0aW9uYWxQcm9wc0d1YXJkIiwicGFzc0hyZWYiLCJvcHRpb25hbFByb3BzIiwidmFsVHlwZSIsImhhc1dhcm5lZCIsInVzZVJlZiIsImN1cnJlbnQiLCJ3YXJuIiwidXNlTWVtbyIsInJlc29sdmVkSHJlZiIsInJlc29sdmVkQXMiLCJyZXNvbHZlSHJlZiIsImNyZWF0ZUVsZW1lbnQiLCJjaGlsZCIsIkNoaWxkcmVuIiwib25seSIsImNoaWxkUmVmIiwicmVmIiwic2V0SW50ZXJzZWN0aW9uUmVmIiwiaXNWaXNpYmxlIiwidXNlSW50ZXJzZWN0aW9uIiwicm9vdE1hcmdpbiIsInNldFJlZiIsInVzZUNhbGxiYWNrIiwiZWwiLCJ1c2VFZmZlY3QiLCJzaG91bGRQcmVmZXRjaCIsImlzUHJlZmV0Y2hlZCIsImNoaWxkUHJvcHMiLCJkZWZhdWx0UHJldmVudGVkIiwib25Nb3VzZUVudGVyIiwicHJpb3JpdHkiLCJsb2NhbGVEb21haW4iLCJpc0xvY2FsZURvbWFpbiIsImdldERvbWFpbkxvY2FsZSIsImxvY2FsZXMiLCJkb21haW5Mb2NhbGVzIiwiYWRkQmFzZVBhdGgiLCJhZGRMb2NhbGUiLCJkZWZhdWx0TG9jYWxlIiwiY2xvbmVFbGVtZW50IiwiX2RlZmF1bHQiLCJyZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCIsIm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoIiwicGF0aCIsImVuZHNXaXRoIiwic2xpY2UiLCJwcm9jZXNzIiwiZW52IiwiX19ORVhUX1RSQUlMSU5HX1NMQVNIIiwidGVzdCIsInJlcXVlc3RJZGxlQ2FsbGJhY2siLCJjYW5jZWxJZGxlQ2FsbGJhY2siLCJzZWxmIiwiYmluZCIsIndpbmRvdyIsImNiIiwic3RhcnQiLCJEYXRlIiwibm93Iiwic2V0VGltZW91dCIsImRpZFRpbWVvdXQiLCJ0aW1lUmVtYWluaW5nIiwiTWF0aCIsIm1heCIsImlkIiwiY2xlYXJUaW1lb3V0IiwibWFya0Fzc2V0RXJyb3IiLCJpc0Fzc2V0RXJyb3IiLCJnZXRDbGllbnRCdWlsZE1hbmlmZXN0IiwiY3JlYXRlUm91dGVMb2FkZXIiLCJfZ2V0QXNzZXRQYXRoRnJvbVJvdXRlIiwiX3JlcXVlc3RJZGxlQ2FsbGJhY2siLCJNU19NQVhfSURMRV9ERUxBWSIsIndpdGhGdXR1cmUiLCJnZW5lcmF0b3IiLCJlbnRyeSIsImdldCIsImZ1dHVyZSIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVzb2x2ZXIiLCJwcm9tIiwic2V0IiwidGhlbiIsImhhc1ByZWZldGNoIiwibGluayIsImRvY3VtZW50IiwiTVNJbnB1dE1ldGhvZENvbnRleHQiLCJkb2N1bWVudE1vZGUiLCJyZWxMaXN0Iiwic3VwcG9ydHMiLCJjYW5QcmVmZXRjaCIsInByZWZldGNoVmlhRG9tIiwicmVzIiwicmVqIiwicXVlcnlTZWxlY3RvciIsInJlbCIsImNyb3NzT3JpZ2luIiwiX19ORVhUX0NST1NTX09SSUdJTiIsIm9ubG9hZCIsIm9uZXJyb3IiLCJoZWFkIiwiYXBwZW5kQ2hpbGQiLCJBU1NFVF9MT0FEX0VSUk9SIiwiU3ltYm9sIiwiYXBwZW5kU2NyaXB0Iiwic3JjIiwic2NyaXB0IiwicmVqZWN0IiwiYm9keSIsImRldkJ1aWxkUHJvbWlzZSIsInJlc29sdmVQcm9taXNlV2l0aFRpbWVvdXQiLCJtcyIsImNhbmNlbGxlZCIsInIiLCJfX0JVSUxEX01BTklGRVNUIiwib25CdWlsZE1hbmlmZXN0IiwiX19CVUlMRF9NQU5JRkVTVF9DQiIsImdldEZpbGVzRm9yUm91dGUiLCJhc3NldFByZWZpeCIsInJvdXRlIiwic2NyaXB0cyIsImVuY29kZVVSSSIsIm1hbmlmZXN0IiwiYWxsRmlsZXMiLCJmaWx0ZXIiLCJ2IiwiZW50cnlwb2ludHMiLCJNYXAiLCJsb2FkZWRTY3JpcHRzIiwic3R5bGVTaGVldHMiLCJyb3V0ZXMiLCJtYXliZUV4ZWN1dGVTY3JpcHQiLCJmZXRjaFN0eWxlU2hlZXQiLCJmZXRjaCIsIm9rIiwidGV4dCIsImNvbnRlbnQiLCJ3aGVuRW50cnlwb2ludCIsIm9uRW50cnlwb2ludCIsImV4ZWN1dGUiLCJmbiIsImNvbXBvbmVudCIsImVycm9yIiwiaW5wdXQiLCJvbGQiLCJsb2FkUm91dGUiLCJyb3V0ZUZpbGVzUHJvbWlzZSIsImFsbCIsImhhcyIsImVudHJ5cG9pbnQiLCJmaW5hbGx5IiwiYXNzaWduIiwiY24iLCJuYXZpZ2F0b3IiLCJjb25uZWN0aW9uIiwic2F2ZURhdGEiLCJlZmZlY3RpdmVUeXBlIiwib3V0cHV0IiwiZW51bWVyYWJsZSIsIl93aXRoUm91dGVyIiwiY3JlYXRlUm91dGVyIiwibWFrZVB1YmxpY1JvdXRlckluc3RhbmNlIiwiX3JvdXRlckNvbnRleHQiLCJzaW5nbGV0b25Sb3V0ZXIiLCJyZWFkeUNhbGxiYWNrcyIsInJlYWR5IiwidXJsUHJvcGVydHlGaWVsZHMiLCJyb3V0ZXJFdmVudHMiLCJjb3JlTWV0aG9kRmllbGRzIiwiZXZlbnRzIiwiZmllbGQiLCJnZXRSb3V0ZXIiLCJvbiIsImV2ZW50RmllbGQiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInN1YnN0cmluZyIsIl9zaW5nbGV0b25Sb3V0ZXIiLCJtZXNzYWdlIiwic3RhY2siLCJ1c2VDb250ZXh0IiwiUm91dGVyQ29udGV4dCIsImluc3RhbmNlIiwicHJvcGVydHkiLCJBcnJheSIsImlzQXJyYXkiLCJoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciIsIkludGVyc2VjdGlvbk9ic2VydmVyIiwiZGlzYWJsZWQiLCJpc0Rpc2FibGVkIiwidW5vYnNlcnZlIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJ1bmRlZmluZWQiLCJ0YWdOYW1lIiwib2JzZXJ2ZSIsImlkbGVDYWxsYmFjayIsImVsZW1lbnQiLCJjYWxsYmFjayIsIm9ic2VydmVyIiwiZWxlbWVudHMiLCJjcmVhdGVPYnNlcnZlciIsImRlbGV0ZSIsInNpemUiLCJkaXNjb25uZWN0Iiwib2JzZXJ2ZXJzIiwiZW50cmllcyIsImlzSW50ZXJzZWN0aW5nIiwiaW50ZXJzZWN0aW9uUmF0aW8iLCJ3aXRoUm91dGVyIiwiQ29tcG9zZWRDb21wb25lbnQiLCJXaXRoUm91dGVyV3JhcHBlciIsImdldEluaXRpYWxQcm9wcyIsIm9yaWdHZXRJbml0aWFsUHJvcHMiLCJuYW1lIiwiZGlzcGxheU5hbWUiLCJkZWxMb2NhbGUiLCJoYXNCYXNlUGF0aCIsImRlbEJhc2VQYXRoIiwiaW50ZXJwb2xhdGVBcyIsIl9ub3JtYWxpemVUcmFpbGluZ1NsYXNoIiwiX3JvdXRlTG9hZGVyIiwiX2Rlbm9ybWFsaXplUGFnZVBhdGgiLCJfbm9ybWFsaXplTG9jYWxlUGF0aCIsIl9taXR0IiwiX3V0aWxzIiwiX2lzRHluYW1pYyIsIl9wYXJzZVJlbGF0aXZlVXJsIiwiX3F1ZXJ5c3RyaW5nIiwiX3Jlc29sdmVSZXdyaXRlcyIsIl9yb3V0ZU1hdGNoZXIiLCJfcm91dGVSZWdleCIsImRldGVjdERvbWFpbkxvY2FsZSIsIl9fTkVYVF9JMThOX1NVUFBPUlQiLCJiYXNlUGF0aCIsIl9fTkVYVF9ST1VURVJfQkFTRVBBVEgiLCJidWlsZENhbmNlbGxhdGlvbkVycm9yIiwiYWRkUGF0aFByZWZpeCIsInByZWZpeCIsInN0YXJ0c1dpdGgiLCJwYXRoTm9RdWVyeUhhc2giLCJub3JtYWxpemVMb2NhbGVQYXRoIiwiZGV0ZWN0ZWRMb2NhbGUiLCJkZXRlY3RlZERvbWFpbiIsImh0dHAiLCJkb21haW4iLCJwYXRoTG93ZXIiLCJ0b0xvd2VyQ2FzZSIsImxvY2FsZUxvd2VyIiwibGVuZ3RoIiwic3Vic3RyIiwicXVlcnlJbmRleCIsImhhc2hJbmRleCIsInVybCIsImxvY2F0aW9uT3JpZ2luIiwiZ2V0TG9jYXRpb25PcmlnaW4iLCJyZXNvbHZlZCIsIlVSTCIsIm9yaWdpbiIsImFzUGF0aG5hbWUiLCJpbnRlcnBvbGF0ZWRSb3V0ZSIsImR5bmFtaWNSZWdleCIsImdldFJvdXRlUmVnZXgiLCJkeW5hbWljR3JvdXBzIiwiZ3JvdXBzIiwiZHluYW1pY01hdGNoZXMiLCJnZXRSb3V0ZU1hdGNoZXIiLCJwYXJhbXMiLCJldmVyeSIsInBhcmFtIiwicmVwZWF0Iiwib3B0aW9uYWwiLCJyZXBsYWNlZCIsInNlZ21lbnQiLCJlbmNvZGVVUklDb21wb25lbnQiLCJqb2luIiwicmVzdWx0Iiwib21pdFBhcm1zRnJvbVF1ZXJ5IiwiZmlsdGVyZWRRdWVyeSIsImluY2x1ZGVzIiwicmVzb2x2ZUFzIiwiYmFzZSIsInVybEFzU3RyaW5nIiwiZm9ybWF0V2l0aFZhbGlkYXRpb24iLCJ1cmxQcm90b01hdGNoIiwibWF0Y2giLCJ1cmxBc1N0cmluZ05vUHJvdG8iLCJ1cmxQYXJ0cyIsInNwbGl0Iiwibm9ybWFsaXplZFVybCIsIm5vcm1hbGl6ZVJlcGVhdGVkU2xhc2hlcyIsImZpbmFsVXJsIiwiaW50ZXJwb2xhdGVkQXMiLCJpc0R5bmFtaWNSb3V0ZSIsInNlYXJjaFBhcmFtcyIsInNlYXJjaFBhcmFtc1RvVXJsUXVlcnkiLCJoYXNoIiwic3RyaXBPcmlnaW4iLCJwcmVwYXJlVXJsQXMiLCJocmVmSGFkT3JpZ2luIiwiYXNIYWRPcmlnaW4iLCJwcmVwYXJlZFVybCIsInByZXBhcmVkQXMiLCJyZXNvbHZlRHluYW1pY1JvdXRlIiwicGFnZXMiLCJjbGVhblBhdGhuYW1lIiwiZGVub3JtYWxpemVQYWdlUGF0aCIsInNvbWUiLCJwYWdlIiwicmUiLCJtYW51YWxTY3JvbGxSZXN0b3JhdGlvbiIsIl9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04iLCJoaXN0b3J5Iiwic2Vzc2lvblN0b3JhZ2UiLCJzZXRJdGVtIiwicmVtb3ZlSXRlbSIsIm4iLCJTU0dfREFUQV9OT1RfRk9VTkQiLCJmZXRjaFJldHJ5IiwiYXR0ZW1wdHMiLCJjcmVkZW50aWFscyIsInN0YXR1cyIsImpzb24iLCJkYXRhIiwibm90Rm91bmQiLCJmZXRjaE5leHREYXRhIiwiZGF0YUhyZWYiLCJpc1NlcnZlclJlbmRlciIsIlJvdXRlciIsImNvbnN0cnVjdG9yIiwicGF0aG5hbWUxIiwicXVlcnkxIiwiYXMxIiwiaW5pdGlhbFByb3BzIiwicGFnZUxvYWRlciIsIkFwcCIsIndyYXBBcHAiLCJDb21wb25lbnQiLCJDb21wb25lbnQxIiwiZXJyMSIsInN1YnNjcmlwdGlvbiIsImlzRmFsbGJhY2siLCJpc1ByZXZpZXciLCJzZGMiLCJzZHIiLCJfaWR4Iiwib25Qb3BTdGF0ZSIsImNoYW5nZVN0YXRlIiwiZ2V0VVJMIiwiX19OIiwiZm9yY2VkU2Nyb2xsIiwiaWR4IiwiSlNPTiIsInN0cmluZ2lmeSIsIngiLCJwYWdlWE9mZnNldCIsInkiLCJwYWdlWU9mZnNldCIsImdldEl0ZW0iLCJwYXJzZSIsInBhcnNlUmVsYXRpdmVVcmwiLCJpc1NzciIsIl9icHMiLCJjaGFuZ2UiLCJfc2hhbGxvdyIsImNvbXBvbmVudHMiLCJpbml0aWFsIiwiX19OX1NTRyIsIl9fTl9TU1AiLCJhdXRvRXhwb3J0RHluYW1pYyIsIl9fTkVYVF9EQVRBX18iLCJhdXRvRXhwb3J0Iiwic3ViIiwiY2xjIiwiX3dyYXBBcHAiLCJpc1JlYWR5IiwiZ3NzcCIsImdpcCIsImFwcEdpcCIsImdzcCIsImxvY2F0aW9uIiwic2VhcmNoIiwiX19ORVhUX0hBU19SRVdSSVRFUyIsImhvc3RuYW1lIiwiX3Nob3VsZFJlc29sdmVIcmVmIiwiYWRkRXZlbnRMaXN0ZW5lciIsInNjcm9sbFJlc3RvcmF0aW9uIiwicmVsb2FkIiwiYmFjayIsIm1ldGhvZCIsInNob3VsZFJlc29sdmVIcmVmIiwiX2giLCJwcmV2TG9jYWxlIiwicGFyc2VkQXMiLCJsb2NhbGVQYXRoUmVzdWx0IiwiZGlkTmF2aWdhdGUiLCJhc05vQmFzZVBhdGgiLCJTVCIsInBlcmZvcm1hbmNlIiwibWFyayIsInJvdXRlUHJvcHMiLCJfaW5GbGlnaHRSb3V0ZSIsImFib3J0Q29tcG9uZW50TG9hZCIsImNsZWFuZWRBcyIsImxvY2FsZUNoYW5nZSIsIm9ubHlBSGFzaENoYW5nZSIsImVtaXQiLCJzY3JvbGxUb0hhc2giLCJub3RpZnkiLCJwYXJzZWQiLCJyZXdyaXRlcyIsImdldFBhZ2VMaXN0IiwiX19yZXdyaXRlcyIsInVybElzTmV3IiwicmV3cml0ZXNSZXN1bHQiLCJtYXRjaGVkUGFnZSIsInJvdXRlUmVnZXgiLCJyb3V0ZU1hdGNoIiwic2hvdWxkSW50ZXJwb2xhdGUiLCJtaXNzaW5nUGFyYW1zIiwicmVmMSIsInJvdXRlSW5mbyIsImdldFJvdXRlSW5mbyIsInBhZ2VQcm9wcyIsIl9fTl9SRURJUkVDVCIsImRlc3RpbmF0aW9uIiwicGFyc2VkSHJlZiIsIm5ld1VybCIsIm5ld0FzIiwiX19OX1BSRVZJRVciLCJub3RGb3VuZFJvdXRlIiwiZmV0Y2hDb21wb25lbnQiLCJhcHBDb21wIiwibmV4dCIsImlzUHJlcmVuZGVyZWQiLCJzdGF0dXNDb2RlIiwiaXNWYWxpZFNoYWxsb3dSb3V0ZSIsIl9zY3JvbGwiLCJzaG91bGRTY3JvbGwiLCJyZXNldFNjcm9sbCIsImRvY3VtZW50RWxlbWVudCIsImxhbmciLCJoYW5kbGVSb3V0ZUluZm9FcnJvciIsImxvYWRFcnJvckZhaWwiLCJnaXBFcnIiLCJyb3V0ZUluZm9FcnIiLCJleGlzdGluZ1JvdXRlSW5mbyIsImNhY2hlZFJvdXRlSW5mbyIsIm1vZCIsImlzVmFsaWRFbGVtZW50VHlwZSIsImdldERhdGFIcmVmIiwiX2dldERhdGEiLCJfZ2V0U3RhdGljRGF0YSIsIl9nZXRTZXJ2ZXJEYXRhIiwiZXJyMiIsImJlZm9yZVBvcFN0YXRlIiwib2xkVXJsTm9IYXNoIiwib2xkSGFzaCIsIm5ld1VybE5vSGFzaCIsIm5ld0hhc2giLCJzY3JvbGxUbyIsImlkRWwiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwibmFtZUVsIiwiZ2V0RWxlbWVudHNCeU5hbWUiLCJwYXRobmFtZTIiLCJfaXNTc2ciLCJpc1NzZyIsImNhbmNlbCIsImNvbXBvbmVudFJlc3VsdCIsImxvYWRQYWdlIiwiY2FjaGVLZXkiLCJyZXNvdXJjZUtleSIsImN0eCIsIkFwcDEiLCJBcHBUcmVlIiwibG9hZEdldEluaXRpYWxQcm9wcyIsImtleWZyYW1lcyIsIk1lZGlhX0NzcyIsIkltZ0NzcyIsIkRvbnRIYXZlIiwiTWVkaWEiLCJ3YWxscGFwZXIiLCJjb25jYXQiLCJ2aWRlbyIsInNjcmVlbnNob3QiLCJhcnR3b3JrIiwibG9nbyIsImNvbnRlbnRfY3JlYXRvciIsImRpc3BsYXkiLCJpbWFnZSIsImltZ1NpemUiLCJmbG9vciIsInJhbmRvbSIsImJhY2tncm91bmRTaXplIiwid2lkdGgiLCJTdHlsZWRDYXJldERvd24iLCJTdHlsZWRBcnJvd1VwIiwiUmlvdExvZ29XcmFwcGVyIiwiaXNHYW1lQmFyT3BlbiJdLCJzb3VyY2VSb290IjoiIn0=